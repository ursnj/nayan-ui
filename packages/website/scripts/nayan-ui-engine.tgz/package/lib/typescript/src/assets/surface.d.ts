import type { Vec3 } from '../types.js';
import type { Geometry, SurfaceColor } from './shape.js';
export interface ParametricSurfaceOptions {
    uSegments?: number;
    vSegments?: number;
    /** Match the first/last positions and smooth their normals, keeping separate 0/1 UVs. */
    wrapU?: boolean;
    wrapV?: boolean;
    color?: SurfaceColor;
}
/**
 * Samples an arbitrary surface on u/v in [0,1]. Winding follows dP/du cross dP/dv.
 * Use for terrain, cloth, wings, twisted ribbons and custom mathematical forms. Wrapped edges
 * retain texture seams; coincident pole vertices share normals. Degenerate triangles are omitted.
 */
export declare function parametricSurface(sample: (u: number, v: number) => Vec3, options?: ParametricSurfaceOptions): Geometry;
//# sourceMappingURL=surface.d.ts.map