import { type ViewStyle } from 'react-native';
/** Written by `<Joystick>` on touch; read it from your game loop. Each axis is in -1..1, y is up. */
export type JoystickState = {
    x: number;
    y: number;
};
/** A joystick state that lives as long as the component: `const stick = useJoystick()`. */
export declare function useJoystick(): JoystickState;
export type JoystickProps = {
    state: JoystickState;
    /** Diameter of the pad in points. */
    size?: number;
    style?: ViewStyle;
};
/**
 * A relative touch stick: wherever the finger lands inside the pad is the center.
 * Updates `state` synchronously on the JS thread, so there is no React re-render per touch.
 */
export declare function Joystick({ state, size, style }: JoystickProps): import("react").JSX.Element;
//# sourceMappingURL=Joystick.d.ts.map