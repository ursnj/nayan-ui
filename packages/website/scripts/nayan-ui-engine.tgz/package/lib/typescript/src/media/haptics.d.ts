export type HapticTap = {
    /** Seconds from now. */
    time: number;
    /** 0..1 */
    intensity: number;
    /** 0 (dull thud) .. 1 (crisp click). */
    sharpness: number;
};
export declare const haptics: {
    /** Set false to silence all haptics (e.g. a settings toggle). */
    enabled: boolean;
    /** True if the device has a haptic actuator (false on simulators). */
    readonly supported: boolean;
    /** A single tap. Rapid repeats (< 35 ms apart) are dropped so collisions don't buzz. */
    impact(intensity?: number, sharpness?: number): void;
    /** A light, crisp tick for UI selection. */
    selection(): void;
    notify(type: "success" | "warning" | "error"): void;
    /** Any sequence of taps. */
    play(taps: readonly HapticTap[]): void;
};
//# sourceMappingURL=haptics.d.ts.map