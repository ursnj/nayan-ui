import type { EngineBridge } from './EngineBridge.js';
declare const _default: EngineBridge | null;
export default _default;
export type { Spec } from './spec/NativeNayanEngine.js';
//# sourceMappingURL=NativeNayanEngine.d.ts.map