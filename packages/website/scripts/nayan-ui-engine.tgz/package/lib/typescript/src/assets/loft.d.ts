import type { Vec3 } from '../types.js';
import type { Color } from '../world/types.js';
import { type Geometry } from './shape.js';
export interface LoftSection {
    z: number;
    bottom: number;
    top: number;
    /** Half the width at the lower corners. */
    width: number;
    topWidth?: number;
    /** Superellipse exponent, 2 = oval, larger values = boxier corners. Default 4. */
    square?: number;
}
export interface LoftOptions {
    around?: number;
    smoothness?: number;
    color?: Color | ((position: Vec3, normal: Vec3) => Color);
}
/**
 * Smooth closed body through rounded rectangular cross sections along Z. Useful for vehicle
 * shells, cabins, shoes and fairings. Caps have separate flat normals and planar UVs; sides have
 * continuous longitudinal UVs and a welded seam. Input sections may increase or decrease in Z.
 */
export declare function loft(sections: readonly LoftSection[], options?: LoftOptions): Geometry;
/** A rounded rectangular cross-section with flat front/back caps, centered at the origin. */
export declare function block(w: number, h: number, d: number, square?: number, color?: LoftOptions['color']): Geometry;
/** An exact ellipsoid with analytic normals, rather than capped/truncated poles. */
export declare function ellipsoid(radii: Vec3, color?: LoftOptions['color'], around?: number): Geometry;
/** Smooth Hermite interpolation through increasing [x,value] points; clamped beyond the ends. */
export declare function smoothCurve(points: readonly (readonly [number, number])[]): (x: number) => number;
//# sourceMappingURL=loft.d.ts.map