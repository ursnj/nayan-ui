import type { EngineBridge } from './EngineBridge.js';
export declare function prepareEngine(): Promise<void>;
export declare function readSavedAsset(key: string): Promise<ArrayBuffer | null>;
export declare function flushAssetStorage(): Promise<void>;
export declare function clearedAssetStorage(): Promise<void>;
export declare function attachCanvas(id: number, canvas: HTMLCanvasElement): Promise<void>;
export declare function detachCanvas(id: number): void;
declare const browser: EngineBridge;
export default browser;
//# sourceMappingURL=NativeNayanEngine.web.d.ts.map