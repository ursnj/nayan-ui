import type { ProceduralStorage } from './ProceduralCache.js';
export declare function proceduralStorage(revision: string): ProceduralStorage | undefined;
export declare function readPersistentAsset(key: string): Promise<ArrayBuffer | null>;
export declare function writePersistentAsset(key: string, bytes: ArrayBuffer): Promise<void>;
export declare function removePersistentAsset(key: string): Promise<void>;
export declare function clearPersistentStorage(): Promise<void>;
//# sourceMappingURL=storage.web.d.ts.map