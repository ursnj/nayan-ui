import { type MeshGeometry } from '../render/meshes.js';
import { type Shape, type Vec3 } from '../types.js';
import type { Color, Quat } from '../world/types.js';
import { type Model } from './model.js';
import type { OptimizeOptions } from './modelling.js';
type P2 = [number, number];
/**
 * A 2D outline, built like an SVG path: x right, y down. Solids made from it
 * (`extrude`, `lathe`) are flipped upright, so a path drawn the way it looks on screen stands the
 * same way in the world. Coordinates are in world units: a 1 x 1 path makes a 1 unit wide shape.
 *
 * ```ts
 * const heart = Path.fromSVG("M0.5 0.9 C0 0.5 0 0.1 0.25 0.1 C0.4 0.1 0.5 0.25 0.5 0.3 C0.5 0.25 0.6 0.1 0.75 0.1 C1 0.1 1 0.5 0.5 0.9 Z");
 * const star = new Path().addStar(0, 0, 0.5, 0.22, 5);
 * ```
 */
export declare class Path {
    private contours;
    private start;
    private last;
    private get current();
    private add;
    /** Starts a new contour at (x, y). */
    moveTo(x: number, y: number): this;
    lineTo(x: number, y: number): this;
    /** A quadratic Bézier through control point (cx, cy) to (x, y). */
    quadraticTo(cx: number, cy: number, x: number, y: number): this;
    /** A cubic Bézier through control points (c1x, c1y) and (c2x, c2y) to (x, y). */
    cubicTo(c1x: number, c1y: number, c2x: number, c2y: number, x: number, y: number): this;
    /**
     * An elliptical arc to (x, y), as in SVG's `A` command: radii rx, ry, the ellipse turned `rotation`
     * radians, and the flags choosing which of the four possible arcs.
     */
    arcTo(rx: number, ry: number, rotation: number, largeArc: boolean, sweep: boolean, x: number, y: number): this;
    /** Closes the current contour back to its first point. */
    close(): this;
    /** A closed polygon through `points`. */
    addPolygon(points: readonly (readonly [number, number])[], close?: boolean): this;
    addRect(x: number, y: number, width: number, height: number): this;
    /** A rectangle with corners rounded by `radius` (or [rx, ry]). */
    addRoundedRect(x: number, y: number, width: number, height: number, radius: number | readonly [number, number]): this;
    /** An ellipse filling the box. */
    addOval(x: number, y: number, width: number, height: number): this;
    addCircle(cx: number, cy: number, radius: number): this;
    /** A star with `points` tips at `outer` radius and notches at `inner`, the first tip pointing up. */
    addStar(cx: number, cy: number, outer: number, inner: number, points?: number): this;
    /** A regular polygon with `sides` corners, the first pointing up. */
    addRegularPolygon(cx: number, cy: number, radius: number, sides: number): this;
    /**
     * Parses SVG path data (`d`): M L H V C S Q T A Z, absolute and relative. Paste paths from Figma,
     * Illustrator or any icon set (scale them with `fit` on the shape, or `transform` here).
     */
    static fromSVG(d: string): Path;
    /** A copy moved by (dx, dy) and scaled by sx, sy (about the origin, before moving). */
    transform(sx: number, sy?: number, dx?: number, dy?: number): Path;
    /** The flattened contours (curves turned into points), y down as drawn. */
    toContours(): P2[][];
    /** [minX, minY, maxX, maxY], or undefined for an empty path. */
    bounds(): [number, number, number, number] | undefined;
}
/**
 * Shape geometry, before it's registered: 11 floats per vertex (position, normal, color, uv) and
 * triangle indices. Builders return it; `merge` combines it; `createShape` turns it into a mesh.
 */
export type Geometry = MeshGeometry;
/** A built-in shape's geometry (unit-sized, centered), to `merge` with others. */
export declare function shapeGeometry(shape: Exclude<Shape, 'none' | 'puff' | 'flame'>, options?: {
    color?: Color;
}): Geometry;
export type ExtrudeOptions = {
    /** How deep, in the path's units. 0 = a flat, one-sided face (facing +Z). Default 0.2. */
    depth?: number;
    /** SVG fill rules: "nonzero" (the default winding rule) or "evenodd" (every inner contour is a hole). */
    fillRule?: 'nonzero' | 'evenodd';
    /** Vertex color (multiplies the entity's color). Default white. */
    color?: Color;
};
/**
 * A 2D path filled and pushed into a solid, facing +Z: badges, coins, leaves, hearts, stars, logos,
 * fruit slices. Holes follow the fill rule. Textures map across the front face.
 */
export declare function extrude(path: Path, options?: ExtrudeOptions): Geometry;
/** Where a color function is asked about: `u` around (0..1), `v` along (0..1), and the surface there. */
export type SurfacePoint = {
    u: number;
    v: number;
    position: Vec3;
    normal: Vec3;
};
/** A flat color, or one per point of the surface: blushes, stripes, speckles, spots. */
export type SurfaceColor = Color | ((p: SurfacePoint) => Color);
/** A flat color, or one per point of a round face: `r` from its center (0) to its rim (1), `angle` around it. */
export type FaceColor = Color | ((r: number, angle: number) => Color);
export type LatheOptions = {
    /** Steps around the axis. Default 32. */
    segments?: number;
    /** How far around, in radians: TAU (default) is a full turn; Math.PI a half, for a cut fruit. */
    sweep?: number;
    /** Color of the outside: one color, or a function of the surface point (u around, v down the profile). Default white. */
    color?: SurfaceColor;
    /**
     * Pushes the surface out (or in, if negative) along its normal by this much at (u, v): peel dimples,
     * ribs, ridges, bumps. Normals are recomputed so the bumps catch the light. Make it repeat in u
     * (equal at u = 0 and 1) to avoid a seam.
     */
    displace?: (u: number, v: number) => number;
    /** Color of the flat ends where the profile stops away from the axis (the face of a fruit cut across). Default `color`. */
    capColor?: FaceColor;
    /** Rings across each end cap, for patterned `capColor`. Default 1, or 12 for a function. */
    capRings?: number;
    /**
     * Color of the faces where a partial sweep is cut open (the flesh of a fruit cut through its core).
     * As a function: `r` from the axis (0) to the skin (1) at that height, and the height `y`. Default `color`.
     */
    cutColor?: Color | ((r: number, y: number) => Color);
    /** Steps from the axis to the skin across each cut face, for a detailed `cutColor`. Default 12 for a function. */
    cutSteps?: number;
};
/**
 * Recolors geometry point by point (in place, and returned): two-tone leaves, painted tips, stripes on
 * an extrusion. `u` and `v` are the texture coordinates there.
 */
export declare function recolor(geometry: Geometry, color: (p: SurfacePoint) => Color): Geometry;
/**
 * Recomputes corner-angle-weighted normals in place, welding UV seams and poles at 1e-5 units.
 * Uses Rust when available. Call on a sculpted surface before merging caps or other hard edges:
 * coincident vertices share a normal. Degenerate faces leave the original normals intact.
 */
export declare function smoothNormals(g: Geometry): Geometry;
/**
 * Spins a profile around the vertical axis, like a potter's wheel: fruit (apples, oranges, lemons,
 * pears, cherries), vases, bottles, bowls, chess pieces, spinning tops. The profile is a `Path`
 * (x = distance from the axis, y down, as drawn) or [radius, height] points (y up), top to bottom.
 * Open ends away from the axis are capped. With `sweep` < TAU the cut faces are closed too.
 */
export declare function lathe(profile: Path | readonly (readonly [number, number])[], options?: LatheOptions): Geometry;
export type TubeOptions = {
    /** Radius, or a function of t (0 at the first point, 1 at the last) for tapering: bananas, horns, tails. Default 0.1. */
    radius?: number | ((t: number) => number);
    /**
     * The cross-section: a radius multiplier at each point around (0..1, repeating), e.g. ridges for a
     * banana or a star for a churro. Default round.
     */
    shape?: (around: number) => number;
    /** Steps around the tube. Default 12. */
    sides?: number;
    /** Steps between each pair of points (the path is smoothed through them). Default 8. */
    smoothness?: number;
    /** Cap the ends (where the radius isn't 0). Default true. */
    caps?: boolean;
    /** Join the last point to the first with a smooth, untwisted seam; no end caps. Default false. */
    closed?: boolean;
    /** Color: one, or a function of the surface point (u around, v = t along). Default white. */
    color?: SurfaceColor;
    /** Color of the end caps (the face of a cut banana). Default `color`. */
    capColor?: FaceColor;
};
/**
 * A tube along a smooth curve through `points`: bananas, stems, chillies, worms, snakes, ropes,
 * pipes, tentacles, candy canes.
 */
export declare function tube(points: readonly Vec3[], options?: TubeOptions): Geometry;
export type GeometryPart = {
    geometry: Geometry;
    position?: Vec3;
    /** A quaternion [x, y, z, w], as entities use. */
    rotation?: Quat;
    scale?: Vec3 | number;
    /** Multiplies the part's vertex colors: an apple's red body, brown stem and green leaf in one mesh. */
    color?: Color;
};
/**
 * Bakes parts into one geometry, each scaled, rotated, moved and colored. One mesh draws in one
 * instanced call and moves, spins and slices as one entity.
 */
export declare function merge(parts: readonly GeometryPart[]): Geometry;
export type ShapeOptions = {
    /** Clean/optimize before upload, or simplify within an error bound. Built once, then shared. Default false. */
    optimize?: boolean | OptimizeOptions;
    /** Move the bounding box's center to the origin, so `position` is the middle. Default true. */
    center?: boolean;
    /** Scale so the largest side is this long (1 matches the built-in shapes). Default: keep the size. */
    fit?: number;
    /** How glossy, 0..1 (as for models): around 0.6 for a waxy apple, 0.85 for glass. Default 0. */
    shine?: number;
};
/**
 * Registers geometry as a mesh: pass the result as an entity's `mesh` (or a burst's), with any
 * `texture`, physics and picking. Colliders default to a box holding the shape. Mesh ids are
 * shared by models, fonts and shapes (about 4,080) and live for the whole app. Equal geometry/options
 * automatically reuse preparation and registration; input buffers may still be edited for a later
 * call. Material variants remain independent. Build geometry during scene setup, outside onUpdate.
 *
 * ```ts
 * const orange = createShape(lathe(orangeProfile, { color: [1, 0.55, 0.1] }), { fit: 1, shine: 0.3 });
 * world.spawn({ mesh: orange, position: [0, 2, 0], physics: "dynamic" });
 * ```
 */
export declare function createShape(geometry: Geometry, options?: ShapeOptions): Model;
export declare function preparedModel(mesh: number, shine: number): Model;
export declare function prepareOptions(options: ShapeOptions): string;
export {};
//# sourceMappingURL=shape.d.ts.map