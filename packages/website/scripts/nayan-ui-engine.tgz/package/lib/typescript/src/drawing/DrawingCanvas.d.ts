export type { DrawingCanvasProps } from './types.js';
import type { DrawingCanvasProps } from './types.js';
/** Native coalesced finger/Pencil/stylus input, with pinch zoom and pan, bypasses the JS thread. */
export declare const DrawingCanvas: import("react").MemoExoticComponent<({ document, mode, background, active, onChange, onError, style }: DrawingCanvasProps) => import("react").JSX.Element>;
//# sourceMappingURL=DrawingCanvas.d.ts.map