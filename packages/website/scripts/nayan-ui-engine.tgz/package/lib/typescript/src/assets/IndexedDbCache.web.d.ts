export declare class IndexedDbCache {
    private readonly database;
    private tail;
    private pending;
    private generation;
    private clearOperation;
    private constructor();
    static open(): Promise<IndexedDbCache>;
    private enqueue;
    /** The Uint8Array is an owned copy made by Rust, never a view into growable WASM memory. */
    write(name: string, bytes: Uint8Array, geometry: boolean): Promise<void>;
    read(name: string): Promise<Uint8Array | undefined>;
    remove(name: string): Promise<void>;
    clear(): Promise<void>;
    flush(): Promise<void>;
    cleared(): Promise<void>;
    /** Read recent geometry only. Large source files remain in IndexedDB until requested by a loader. */
    warm(canFit: (size: number) => boolean, restore: (name: string, bytes: Uint8Array) => boolean): Promise<void>;
}
//# sourceMappingURL=IndexedDbCache.web.d.ts.map