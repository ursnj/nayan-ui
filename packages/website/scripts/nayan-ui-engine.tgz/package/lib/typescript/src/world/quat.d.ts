import type { Quat } from './types.js';
/** A writable quaternion; pass one as `out` to reuse it instead of allocating. */
export type MutableQuat = [number, number, number, number];
/**
 * Quaternion helpers for `rotation` options, keyframes and geometry parts ([x, y, z, w]). Every
 * function takes an optional `out` so per-frame code can reuse one array instead of allocating.
 *
 * ```ts
 * world.set(car, { rotation: quat.y(heading) });
 * const spin = quat.multiply(quat.y(yaw), quat.x(pitch), scratch); // pitch first, then yaw
 * ```
 */
export declare const quat: {
    /** No rotation. */
    identity: Quat;
    /** Rotation by `angle` radians around the unit axis (x, y, z). */
    axisAngle(x: number, y: number, z: number, angle: number, out?: MutableQuat): MutableQuat;
    /** Rotation around the x axis (pitch). */
    x(angle: number, out?: MutableQuat): MutableQuat;
    /** Rotation around the y axis (yaw, heading). */
    y(angle: number, out?: MutableQuat): MutableQuat;
    /** Rotation around the z axis (roll; spin for 2D games looking down -z). */
    z(angle: number, out?: MutableQuat): MutableQuat;
    /** `a` after `b`: `b` turns first. `out` may be `a` or `b`. */
    multiply(a: Quat, b: Quat, out?: MutableQuat): MutableQuat;
    /** Turns around x, then y, then z (radians): the same as `multiply(z(z), multiply(y(y), x(x)))`. */
    fromEuler(x: number, y: number, z: number, out?: MutableQuat): MutableQuat;
    /** Shortest-path interpolation from `a` (t = 0) to `b` (t = 1). */
    slerp(a: Quat, b: Quat, t: number, out?: MutableQuat): MutableQuat;
};
//# sourceMappingURL=quat.d.ts.map