import { type RenderSource, type Vec3 } from '../types.js';
import { Scoreboard } from './Scoreboard.js';
import { TransformBatch } from './TransformBatch.js';
import type { AnimateOptions, AnimateTarget, Bounds, BurstOptions, ClipOptions, CollisionInfo, Entity, EntityOptions, Keyframe, PickHit, RaycastHit, ScreenPlane } from './types.js';
/** True when the engine's native code is linked into this build (it is not in Expo Go). */
export declare const isEngineAvailable: boolean;
/**
 * A game world, simulated by the Rust core: entities, motion, Rapier physics, collisions,
 * animations and raycasts at a fixed 60 Hz, with rendering smoothed between steps. Pass it to `<GameView>`.
 *
 * ```ts
 * const world = new World(500);
 * const ball = world.spawn({ mesh: "sphere", position: [0, 5, 0], physics: "dynamic" });
 * world.set(ball, { color: [1, 0, 0] });
 * ```
 */
export declare class World implements RenderSource {
    readonly capacity: number;
    readonly matrices: Float32Array;
    readonly colors: Float32Array;
    readonly regions: Float32Array;
    readonly ranges: Uint32Array;
    private readonly events;
    private readonly eventFloats;
    private readonly finished;
    private readonly scratch;
    private readonly desc;
    private anim;
    private readonly burstDesc;
    private readonly info;
    /** Promise resolvers of running animations, by animation id. */
    private readonly pending;
    /** Callbacks of pending `after` timers, by timer id (the core counts the time). */
    private readonly timers;
    /** Timers for a native core built before `after` existed: [fire time, callback], on `clock`. */
    private fallbackTimers;
    private fallbackTimerId;
    private transformsValue;
    private clock;
    private scoreboardValue;
    private readonly texts;
    private readonly id;
    private disposed;
    private gravityValue;
    private boundsValue;
    private listenerValue;
    private updates;
    constructor(capacity: number);
    private get native();
    /** True once `dispose()` has run. Cleanup calls (despawn, set, has, queries, stopping animations
     * and timers) are safe no-ops afterwards, so late animation promises and timers need no guard.
     */
    get isDisposed(): boolean;
    /** Live entities (text letters count too). */
    get count(): number;
    /** Adds an entity (one native call; text adds one per letter). Throws if the world is full or an option is invalid. */
    spawn(options?: EntityOptions): Entity;
    /**
     * Changes an entity (one native call). Only the options you pass change; `null` removes.
     * Returns false if the entity is gone, the world is disposed, or an option was rejected (the others still apply).
     */
    set(e: Entity, options: EntityOptions): boolean;
    /**
     * This world's shared draw-only transform batch (created on first use). Queue per-frame moves with
     * its allocation-free methods; the next `update()` applies them first (or `flush()` them yourself
     * before reading positions or animating).
     */
    get transforms(): TransformBatch;
    /** Reusable draw-only transforms; use set() for text entities and flush before animations/queries. */
    createTransformBatch(): TransformBatch;
    /** Removes an entity and anything attached to it. Returns false if it was already gone. */
    despawn(e: Entity): boolean;
    /** A one-off push: jump, explosion, knockback (dynamic bodies only). */
    impulse(e: Entity, impulse: Vec3): void;
    private resolveMesh;
    private encodeColor;
    /** Updates a text entity's letters in place, growing or shrinking only when needed. */
    private buildText;
    /** Native world backing this render source; bone palettes stay in Rust. */
    get nativeWorld(): number;
    /** Play a named GLB clip. Re-selecting it changes speed without restarting; `time` explicitly seeks.
     * `fade` crossfades from the current pose (seconds). A speed of zero holds a pose for a ready screen.
     */
    playClip(entity: Entity, clip: string, options?: ClipOptions): boolean;
    /** Hold the current GLB pose, or return to its bind pose with `reset`. */
    stopClip(entity: Entity, reset?: boolean): boolean;
    /** Sample selected animated vertices in model space for foot contact and attachments.
     * Reuse both arrays. `after` previews the interpolated pose following the next update.
     */
    sampleSkinnedVertices(entity: Entity, vertices: Uint32Array, output: Float32Array, after?: number): boolean;
    /**
     * Animates in Rust, with no per-frame JS: from where things are to `to`, or through keyframes.
     * Each property (position, rotation, scale, color, shake) runs on its own, so a piece can move
     * while it pulses; animating a property again replaces only that property. Pass several entities
     * to animate them together (with `stagger` for waves). Resolves when every part has finished, been
     * replaced or stopped, or its entity was despawned.
     *
     * ```ts
     * await world.animate(piece, { position: [2, 0, 3] }, { duration: 0.25, easing: "back" });
     * world.animate(coin, { scale: 1.2 }, { repeat: "forever", yoyo: true }); // pulse
     * world.animate(piece, [{ moveBy: [1, 1.5, 0] }, { moveBy: [2, 0, 0] }], { path: "smooth" }); // hop
     * world.animate(card, { turn: [0, Math.PI, 0] }); // flip
     * world.animate(tiles, { scale: 1 }, { stagger: 0.03, easing: "back" }); // reveal a board
     * world.animate(cursor, { position: [x, 0, z] }, { spring: true }); // follows the finger smoothly
     * world.animate(wrongTile, { shake: 0.15 }, { duration: 0.4 });
     * ```
     */
    animate(targets: Entity | readonly Entity[], to: AnimateTarget | readonly Keyframe[], options?: AnimateOptions): Promise<void>;
    private encodeKeyframe;
    /** Stops every animation on the entity where it is (their promises resolve). */
    stopAnimation(e: Entity): void;
    /**
     * Particles: many small, short-lived pieces flying out of a point (explosions, sparks, dust,
     * confetti). One native call; they fall, spin, shrink away and clean themselves up. `endSize` and
     * `endColor` grow / shrink and recolor them over their life (fire cooling, smoke thinning out).
     * Returns how many were spawned (fewer if the world is nearly full).
     */
    burst(options: BurstOptions): number;
    /**
     * Runs `fn` after `seconds` of `update` time (game time: it pauses when updates stop). The clock is
     * kept in Rust, so there's no JS timer list to scan every frame. Due callbacks run inside `update`,
     * earliest first. Returns the timer's id for `cancelTimer`; `cancelTimers()` drops every pending one.
     * After `dispose()` it does nothing and returns 0.
     *
     * ```ts
     * world.after(0.3, () => checkMatches());
     * ```
     */
    after(seconds: number, fn: () => void): number;
    /** Drops one pending `after` timer so its callback never runs. Returns false if it already ran or was dropped. */
    cancelTimer(id: number): boolean;
    /** Drops every pending `after` timer: their callbacks never run (a new round, a reset). */
    cancelTimers(): void;
    /** Score, lives and the game clock, kept in Rust (created on first use). */
    get scoreboard(): Scoreboard;
    /** How many times `update` has run. GameView reads it to step the world only when `onUpdate` didn't. */
    get updateCount(): number;
    /** Timers waiting to fire. */
    get timerCount(): number;
    /** Resolves the promises of animations the core reports as ended, then runs due timers. */
    private resolveFinished;
    private runFallbackTimers;
    /**
     * Current simulated position (relative to the parent when attached), or null if the entity is gone.
     * Pass `out` to avoid allocating every frame.
     */
    position(e: Entity, out?: [number, number, number]): [number, number, number] | null;
    /** Where the entity was last drawn, in world space (parents and smoothing included), or null if it's gone. */
    worldPosition(e: Entity, out?: [number, number, number]): [number, number, number] | null;
    /** Current velocity, or null if the entity is gone. Pass `out` to avoid allocating every frame. */
    velocity(e: Entity, out?: [number, number, number]): [number, number, number] | null;
    /** True while the entity exists (false after `dispose()`). */
    has(e: Entity): boolean;
    /**
     * First solid (non-sensor) collider along the ray whose layer is in `mask`, as of the last update.
     * Pass `out` to reuse a hit object every frame.
     */
    raycast(origin: Vec3, direction: Vec3, maxDistance: number, mask?: number, out?: RaycastHit): RaycastHit | null;
    /**
     * The entity under a point of the GameView (e.g. a tap's `x, y`), tested against what was last
     * drawn. Needs no physics. Returns null if nothing pickable is there. Pass `out` to reuse a hit object.
     */
    pick(x: number, y: number, out?: PickHit): PickHit | null;
    /**
     * Where a world position appears in the GameView, in points from its top-left, or null if it's behind
     * the camera (or nothing has been drawn yet). Place React Native views over 3D objects with it.
     * Pass `out` to avoid allocating every frame.
     */
    toScreen(position: Vec3, out?: [number, number]): [number, number] | null;
    /**
     * Where a GameView point (a finger's `x, y`) lands on a plane, or null if the plane is behind the
     * camera or edge-on. Defaults to the ground (y = 0). Drag a piece across a board with it:
     * `world.screenToWorld(x, y, { point: [0, pieceHeight, 0] })`. 2D games looking down -z use
     * `{ normal: [0, 0, 1] }`. Like `toScreen`, it needs a drawn frame (null before the first one).
     * Pass `out` to avoid allocating every frame.
     */
    screenToWorld(x: number, y: number, plane?: ScreenPlane, out?: [number, number, number]): [number, number, number] | null;
    /** Called by GameView after drawing a frame, with the camera matrix and the view size in points. */
    setView(viewProj: Float32Array, width: number, height: number): void;
    private copyScratch;
    /** Default [0, -9.81, 0]. */
    get gravity(): Vec3;
    set gravity(g: Vec3);
    /** Keeps moving non-physics entities inside [minX, minZ, maxX, maxZ]. Physics bodies need walls. */
    get bounds(): Bounds | null;
    set bounds(b: Bounds | null);
    /** Impact sounds pan and fade relative to this entity (usually the player). */
    get listener(): Entity | null;
    set listener(e: Entity | null);
    /**
     * Advances the simulation (fixed 60 Hz steps), resolves finished animations, runs due timers and
     * scoreboard handlers, and refreshes what GameView draws. `GameView` calls it for you each frame;
     * call it yourself from `onUpdate` only to step with a different `dt` (it is then not stepped twice).
     */
    update(dt: number): void;
    /**
     * Calls `fn` for each touch that started or ended during the last `update`. `info` is reused:
     * copy what you need. Either entity may already be despawned by an earlier callback.
     */
    forEachCollision(fn: (a: Entity, b: Entity, info: CollisionInfo) => void): void;
    /**
     * Frees the native world. Pending animation promises resolve and timers are dropped. Later cleanup
     * calls and queries are no-ops (see `isDisposed`); `spawn` and `update` throw.
     */
    dispose(): void;
}
//# sourceMappingURL=World.d.ts.map