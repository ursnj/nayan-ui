import type { Vec3 } from '../types.js';
import { type ColorInput } from './color.js';
import type { BurstOptions, Entity } from './types.js';
import type { World } from './World.js';
/** Shared options of the layered effects (confetti, sparkle, shatter, splash, sparks, explosion). */
export type EffectOptions = {
    position: Vec3;
    /** One color (CSS string or tuple), or several to pick from at random. */
    colors: ColorInput | readonly ColorInput[];
    /** Typical particle size. */
    size: number;
    /** Top speed. */
    speed: number;
    /** About how many particles (a few extra go to the flash and puffs). */
    count: number;
    /** Seconds. */
    lifetime: number;
    /** Vertical acceleration (negative falls). Default 0. */
    gravity?: number;
    /** Main direction. Default up. */
    direction?: Vec3;
    /** Half-angle of the cone around `direction`. Default π (every direction). */
    spread?: number;
    /** A brief glow at the source. Default true. */
    flash?: boolean;
};
/** A soft cloud of puffs that swell and fade: landing dust, kicked-up sand, sawdust, steam, muzzle smoke. */
export type DustOptions = {
    position: Vec3;
    /** Start color (alpha is how thick it looks), or several to pick from. */
    color: ColorInput | readonly ColorInput[];
    /** Puff size at the start. */
    size: number;
    /** Top speed. */
    speed: number;
    count: number;
    /** Seconds. */
    lifetime: number;
    /** Default up. */
    direction?: Vec3;
    /** Half-angle around `direction`. Default π. */
    spread?: number;
    /** Default 0 (dust hangs; positive rises like smoke). */
    gravity?: number;
    /** How much each puff grows by the end. Default 2. */
    endSize?: number;
    /** Color at the end. Default: a single `color` faded to transparent; several colors keep theirs. */
    endColor?: ColorInput;
    /** Default "puff" (blended); "flame" adds light instead. */
    mesh?: BurstOptions['mesh'];
};
/** One glow that swells and fades at a point: a hit, a strike, a muzzle flash. */
export type FlashOptions = {
    position: Vec3;
    /** Use channels above 1 to glow (see `effects.hot`). */
    color: ColorInput;
    size: number;
    /** Seconds. Default 0.22. */
    lifetime?: number;
    /** How much it grows by the end. Default 2.2. */
    endSize?: number;
    /** Default: `color` faded to transparent. */
    endColor?: ColorInput;
    /** Default "flame" (adds light); "sphere" or "puff" for a solid or soft flash. */
    mesh?: BurstOptions['mesh'];
    /** Glows drawn at once (slightly scattered when `speed` > 0). Default 1. */
    count?: number;
    /** Default 0. */
    speed?: number;
};
/** The cleared-piece pop: swell, flash white, settle, shrink away. */
export type PopOptions = {
    /** Its scale at rest (what it has now): one number, or per axis. */
    scale: number | Vec3;
    /** Its color at rest, to return to after the white flash. Omit to flash `flash` only (or nothing). */
    color?: ColorInput;
    /** Parts to flash white as well (a group's visible children, whose rest color is white). */
    flash?: readonly Entity[];
    /** Seconds before it starts. Default 0. */
    delay?: number;
    /** Seconds it takes. Default `effects.POP_TIME`. */
    duration?: number;
};
type Rgba = [number, number, number, number];
/** The same hue, self-lit: its brightest channel lifted to `peak` (above 1 glows, through light, shadow and fog). */
declare function hot(input: ColorInput, peak?: number, alpha?: number): Rgba;
/** Part way (`t`, 0..1) to white, with `alpha`. */
declare function pale(input: ColorInput, t: number, alpha?: number): Rgba;
declare function flash(world: World, o: FlashOptions): number;
declare function dust(world: World, o: DustOptions): number;
/** Celebration confetti: tumbling paper in two layers, a few glinting sparkles, and a pop of light. */
declare function confetti(world: World, e: EffectOptions): void;
/** Glitter for a reward: solid bright beads (seen on any background) with additive glints around them. */
declare function sparkle(world: World, e: EffectOptions): void;
/**
 * Something breaking apart: big slow chunks, small fast crumbs, a glow at the break and a puff of
 * its dust. `mesh` is the chunks' shape.
 */
declare function shatter(world: World, e: EffectOptions & {
    mesh?: BurstOptions['mesh'];
    dust?: boolean;
}): void;
/** Liquid: droplets in two sizes thrown out of a fine mist of the same color. */
declare function splash(world: World, e: EffectOptions): void;
/** Hot metal sparks: additive streaks that burn out, with a few solid beads and a flash where they strike. */
declare function sparks(world: World, e: EffectOptions): void;
/**
 * A fiery blast: a white-hot flash, a fireball that cools into smoke, embers thrown out and, given
 * `debris` colors, chunks of whatever blew up. `size` is the fireball's puff size; `colors` its fire.
 * The fire and smoke swell every way; `direction`, `spread` and `gravity` aim the embers and debris.
 */
declare function explosion(world: World, e: Omit<EffectOptions, 'colors'> & {
    colors?: EffectOptions['colors'];
    debris?: readonly ColorInput[];
    smoke?: ColorInput;
}): void;
/** The piece swells, flashes white, settles and shrinks away. Resolves when it's gone (despawning it is the caller's). */
declare function pop(world: World, entity: Entity, o: PopOptions): Promise<void>;
/**
 * Ready-made effects. Each is one call; particles then live, fall, shrink and recolor in Rust.
 *
 * ```ts
 * effects.confetti(world, { position, colors: [RED, GOLD], size: 0.12, speed: 6, count: 40, lifetime: 1.2, gravity: -6 });
 * effects.dust(world, { position: feet, color: [0.8, 0.75, 0.65, 0.6], size: 0.3, speed: 1.5, count: 6, lifetime: 0.5 });
 * effects.flash(world, { position: hit, color: effects.hot(ORANGE), size: 0.8 });
 * await effects.pop(world, candy, { scale: 1, color: RED });
 * world.despawn(candy);
 * ```
 */
export declare const effects: {
    /** Celebration: tumbling paper, glints and a pop of light (wins, level-ups). */
    confetti: typeof confetti;
    /** Reward glitter: bright beads and glints (pickups, perfect moves). */
    sparkle: typeof sparkle;
    /** Breaking apart: chunks, crumbs, a glow and dust (bricks, crates, glass). `mesh` shapes the chunks. */
    shatter: typeof shatter;
    /** Liquid: droplets and mist (water, juice, paint). */
    splash: typeof splash;
    /** Hot metal: additive streaks and beads (scrapes, strikes, electricity). */
    sparks: typeof sparks;
    /** Fiery blast: flash, fireball cooling to smoke, embers and optional debris. */
    explosion: typeof explosion;
    /** Soft swelling puffs: dust, sand, sawdust, steam, smoke. */
    dust: typeof dust;
    /** One swelling glow: hits, strikes, muzzle flashes. */
    flash: typeof flash;
    /** The cleared-piece animation: swell, flash white, settle, shrink to nothing. */
    pop: typeof pop;
    /** Default `pop` duration in seconds. */
    POP_TIME: number;
    /** The same hue made self-lit (brightest channel lifted to `peak`), for glows. */
    hot: typeof hot;
    /** Part way (`t`, 0..1) to white. */
    pale: typeof pale;
};
export {};
//# sourceMappingURL=effects.d.ts.map