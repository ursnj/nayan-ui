/** Mobile is initialized by native module registration. */
export declare function prepareEngine(): Promise<void> | undefined;
//# sourceMappingURL=prepare.d.ts.map