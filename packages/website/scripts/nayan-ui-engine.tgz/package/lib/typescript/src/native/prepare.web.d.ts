export declare function prepareEngine(): Promise<void>;
//# sourceMappingURL=prepare.web.d.ts.map