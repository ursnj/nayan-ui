import { type ViewStyle } from 'react-native';
import { createTouchResponder } from './touch.js';
export declare const EngineSurface: import("react-native").HostComponent<{
    surfaceId: number;
    drawingId?: number;
    drawingMode?: number;
    drawingBackground?: number;
    onDrawingChange?: (event: {
        nativeEvent: {
            state: string;
            documentId: number;
        };
    }) => void;
    style?: ViewStyle;
}>;
export type { ViewStyle };
export { createTouchResponder };
export declare const pixelRatio: () => number;
export declare function useActive(): boolean;
interface SurfaceProps {
    surfaceId: number;
    style?: ViewStyle;
    onSize: (width: number, height: number) => void;
    onError: (error: Error) => void;
    touch?: ReturnType<typeof createTouchResponder>;
    onPrimaryAction?: () => void;
}
export declare function Surface({ surfaceId, style, onSize, touch }: SurfaceProps): import("react").JSX.Element;
//# sourceMappingURL=host.d.ts.map