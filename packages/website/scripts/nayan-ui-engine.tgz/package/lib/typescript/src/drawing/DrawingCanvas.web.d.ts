import type { DrawingCanvasProps } from './types.js';
export type { DrawingCanvasProps } from './types.js';
export declare const DrawingCanvas: import("react").MemoExoticComponent<({ document: drawing, mode, background, active, onError, onChange, style }: DrawingCanvasProps) => import("react").JSX.Element>;
//# sourceMappingURL=DrawingCanvas.web.d.ts.map