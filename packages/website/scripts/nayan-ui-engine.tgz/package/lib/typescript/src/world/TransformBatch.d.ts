import type { Entity, EntityOptions } from './types.js';
export type TransformOptions = Pick<EntityOptions, 'position' | 'rotation' | 'scale' | 'color'>;
export declare const TRANSFORM_STRIDE = 16;
/**
 * Explicit draw-only updates, applied in one native call by `flush()`. `world.update` flushes
 * `world.transforms` before stepping; flush yourself before reading positions or animating. Records and scratch storage are reused; values are
 * copied when queued, never retained by reference. The scalar methods (`position`, `rotation`,
 * `scale`, `color`, `transform`) allocate nothing; consecutive calls for the same entity share one
 * record.
 *
 * ```ts
 * const batch = world.transforms;
 * for (const p of pieces) batch.transform(p.entity, p.x, 0, p.z, 0, p.qy, 0, p.qw);
 * batch.flush();
 * ```
 */
export declare class TransformBatch {
    private readonly commit;
    private data;
    private count;
    constructor(commit: (data: Float64Array, count: number) => number);
    private record;
    position(entity: Entity, x: number, y: number, z: number): void;
    /** Rotation quaternion [x, y, z, w]. */
    rotation(entity: Entity, x: number, y: number, z: number, w: number): void;
    /** Uniform scale, or per axis. */
    scale(entity: Entity, x: number, y?: number, z?: number): void;
    /** RGBA color; alpha defaults to 1. */
    color(entity: Entity, r: number, g: number, b: number, a?: number): void;
    /** Position and rotation together (the common per-frame update for a moving piece). */
    transform(entity: Entity, x: number, y: number, z: number, qx: number, qy: number, qz: number, qw: number): void;
    /** Queued records (merged per entity). */
    get size(): number;
    set(entity: Entity, options: TransformOptions): void;
    private writeColor;
    flush(): number;
    clear(): void;
}
//# sourceMappingURL=TransformBatch.d.ts.map