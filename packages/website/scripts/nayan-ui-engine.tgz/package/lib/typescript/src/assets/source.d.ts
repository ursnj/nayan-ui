/** A `require("./file.ext")` asset, or a URI (http(s):// or file://). */
export type AssetSource = number | string;
/** The URI an asset resolves to (a Metro dev-server URL in development, a bundle path in release). */
export declare function assetUri(source: AssetSource): string | undefined;
/** Fetches an asset's bytes. */
export declare function loadAssetBytes(source: AssetSource): Promise<{
    uri: string;
    bytes: ArrayBuffer;
}>;
//# sourceMappingURL=source.d.ts.map