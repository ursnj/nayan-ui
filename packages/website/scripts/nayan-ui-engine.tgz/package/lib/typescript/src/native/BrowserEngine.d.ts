import type { EngineBridge } from './EngineBridge.js';
/** Raw C exports are shared with the mobile JSI bridge. All pointers stay private here. */
export interface WasmCore {
    memory: WebAssembly.Memory;
    [name: string]: unknown;
}
export declare function createBrowserEngine(core: WasmCore): EngineBridge;
//# sourceMappingURL=BrowserEngine.d.ts.map