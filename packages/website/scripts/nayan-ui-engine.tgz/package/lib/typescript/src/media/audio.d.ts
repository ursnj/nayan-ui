import type { AssetSource } from '../assets/source';
/** A decoded sound in the core's mixer. */
export type Sound = number & {
    readonly __sound: unique symbol;
};
/** A playing instance of a sound (for `audio.stop`). */
export type Voice = number & {
    readonly __voice: unique symbol;
};
export type AudioPlayOptions = {
    /** 0..2. Default 1. */
    volume?: number;
    /** -1 left .. 1 right. Default 0. */
    pan?: number;
    /** Playback speed (also shifts pitch). Default 1. */
    pitch?: number;
    /** Repeat until stopped (music, engines, ambience). */
    loop?: boolean;
};
/** A `require("./file.wav")` asset, or a URI. WAV, PCM or float, mono or stereo. */
export type SoundSource = AssetSource;
/** Named sounds. Plays are ignored until `ready` resolves (usually a few milliseconds). */
export declare class SoundBank<K extends string> {
    /** Resolves when every sound has loaded (failures are logged and skipped). */
    readonly ready: Promise<void>;
    private readonly ids;
    constructor(sources: Record<K, SoundSource>);
    /** The sound, once loaded (e.g. for an entity's `impact.sound`). */
    get(name: K): Sound | undefined;
    play(name: K, options?: AudioPlayOptions): Voice | null;
}
export declare const audio: {
    /** Initializes the engine and loads named sounds into its mixer. Each asset decodes once per session. */
    load<K extends string>(sources: Record<K, SoundSource>): SoundBank<K>;
    /** Plays a sound (low latency: mixed in Rust on the audio thread). Returns null if it couldn't play. */
    play(sound: Sound, { volume: v, pan, pitch, loop }?: AudioPlayOptions): Voice | null;
    stop(voice: Voice | null | undefined): void;
    muted: boolean;
    /** The inverse of `muted`, matching `haptics.enabled` (e.g. `audio.enabled = settings.enableSounds`). */
    enabled: boolean;
    /** Master volume, 0..2. */
    volume: number;
    /** True once the device's audio output is running. */
    readonly running: boolean;
};
//# sourceMappingURL=audio.d.ts.map