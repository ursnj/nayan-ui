/** Browser assets use URLs (including URLs emitted by Vite/webpack imports). */
export type AssetSource = number | string;
export declare function assetUri(source: AssetSource): string | undefined;
export declare function loadAssetBytes(source: AssetSource): Promise<{
    uri: string;
    bytes: ArrayBuffer;
}>;
//# sourceMappingURL=source.web.d.ts.map