export type ScoreboardHandlers = {
    /** The score changed (points, time-based points, reset). */
    onScore?: (score: number) => void;
    onLives?: (lives: number) => void;
    /** The whole seconds shown changed: time left for a countdown, elapsed otherwise. */
    onSecond?: (seconds: number) => void;
    /** A countdown reached 0 (the clock stops). */
    onTimeUp?: () => void;
    /** Lives went from above 0 to 0. */
    onLivesOut?: () => void;
};
/**
 * Score, lives and the game clock, kept and advanced in Rust by `world.update`: countdowns, elapsed
 * time and time-based points (survival, distance) cost no JS per frame. Handlers run from `update`
 * only when something they show changed. Set `handlers` for the game's own rules, and `listen` for
 * anything else that follows along (a UI showing the score), so neither replaces the other.
 *
 * ```ts
 * world.scoreboard.handlers = { onTimeUp: () => end(true) };
 * const stop = world.scoreboard.listen({ onScore: setScore, onSecond: setTime });
 * world.scoreboard.reset(3);
 * world.scoreboard.startCountdown(60);
 * world.scoreboard.add(10);
 * ```
 */
export declare class Scoreboard {
    private readonly world;
    /** The game's own handlers. `listen` adds more without replacing these. */
    handlers: ScoreboardHandlers;
    private readonly listeners;
    private readonly state;
    /** @internal */
    constructor(world: number);
    private op;
    get score(): number;
    get best(): number;
    get lives(): number;
    /** Seconds left (countdown) or elapsed, fractional. */
    get seconds(): number;
    /** Whole seconds as shown: rounded up while counting down, down while counting up. */
    get shownSeconds(): number;
    get running(): boolean;
    /** Adds points (negative to take away). Returns the score. */
    add(points: number): number;
    set(score: number): number;
    addLives(n: number): number;
    setLives(n: number): void;
    /** Counts `seconds` down to 0 (then `onTimeUp`), earning `pointsPerSecond` meanwhile. */
    startCountdown(seconds: number, pointsPerSecond?: number): void;
    /** Counts up from 0, earning `pointsPerSecond` (survival and distance scores). */
    startClock(pointsPerSecond?: number): void;
    stop(): void;
    resume(): void;
    /** Time bonus (or penalty) on the clock. */
    addTime(seconds: number): void;
    /**
     * Adds `pointsPerSecond` for each whole second saved: the seconds left on a countdown, or
     * `expectedSeconds` minus the seconds elapsed on a clock counting up. Returns the score.
     */
    awardTimeBonus(pointsPerSecond: number, expectedSeconds?: number): number;
    /**
     * A new run: score 0, `lives`, clock stopped at 0. With `countdownSeconds`, the stopped clock shows
     * that countdown in full (a ready screen); `resume()` starts it.
     */
    reset(lives?: number, countdownSeconds?: number): void;
    /**
     * Adds handlers alongside `handlers` (and other listeners); they run after them, in order of
     * listening. Returns a function that removes them.
     */
    listen(handlers: ScoreboardHandlers): () => void;
    /** @internal Runs handlers for what changed since the last call. */
    dispatch(): void;
    private run;
}
//# sourceMappingURL=Scoreboard.d.ts.map