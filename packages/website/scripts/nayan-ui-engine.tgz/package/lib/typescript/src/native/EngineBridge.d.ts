import type { Spec } from './spec/NativeNayanEngine.js';
/** Geometry returned by the core without registering a renderable mesh. */
export interface NativeGeometry {
    vertices: ArrayBuffer;
    indices: ArrayBuffer;
}
type BufferValue<T, Buffer> = T extends readonly number[] ? T : T extends Promise<unknown> ? T : T extends (...args: never[]) => unknown ? T : T extends object ? Buffer : T;
type BufferMethod<T> = T extends (...args: infer A) => infer R ? (...args: {
    [K in keyof A]: BufferValue<A[K], ArrayBufferLike>;
}) => BufferValue<R, ArrayBuffer> : T;
/** Native-only (a display clock and a render thread): absent on the web core and on older app builds. */
type NativeFrames = 'publishFrame' | 'renderStats' | 'hasFrameClock' | 'startFrames' | 'stopFrames';
type BinarySpec = Omit<Spec, 'geometrySolid' | 'geometryOptimize' | 'modelSize' | 'textureSize' | NativeFrames>;
/** The same runtime ABI on JSI and WASM, with precise TypeScript buffer and tuple contracts. */
export type EngineBridge = {
    [K in keyof BinarySpec]: BufferMethod<BinarySpec[K]>;
} & {
    geometrySolid(recipe: string): NativeGeometry;
    geometryOptimize(vertices: ArrayBufferLike, indices: ArrayBufferLike, ratio: number, error: number, lockBorders: boolean): NativeGeometry;
    modelSize(mesh: number): [x: number, y: number, z: number];
    textureSize(texture: number): [width: number, height: number];
} & {
    [K in NativeFrames]?: BufferMethod<Spec[K]>;
};
export {};
//# sourceMappingURL=EngineBridge.d.ts.map