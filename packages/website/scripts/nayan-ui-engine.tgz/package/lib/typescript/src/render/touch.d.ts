import type { DragEvent, OverlayTouchPhase, PinchEvent, SwipeDirection } from './GameView.js';
import { type PanResponderInstance } from './responder';
declare const TAP_SLOP = 10;
declare const TAP_TIME = 300;
declare const SWIPE_DISTANCE = 30;
declare const SWIPE_SPEED = 0.3;
declare const LONG_PRESS_TIME = 500;
type Handlers = {
    onTap?: (x: number, y: number) => void;
    onSwipe?: (direction: SwipeDirection) => void;
    onDrag?: (drag: DragEvent) => void;
    onLongPress?: (x: number, y: number) => void;
    onPinch?: (pinch: PinchEvent) => void;
    onOverlayTouch?: (phase: OverlayTouchPhase, x: number, y: number) => boolean | void;
};
/**
 * Creates a PanResponder that recognizes taps, swipes, drags, long presses and pinches.
 * `getHandlers` is called on each event so the caller can swap handlers without recreating the responder.
 */
export declare function createTouchResponder(getHandlers: () => Handlers): {
    responder: PanResponderInstance;
    dispose: () => void;
    cancel: () => void;
};
export { TAP_SLOP, TAP_TIME, SWIPE_DISTANCE, SWIPE_SPEED, LONG_PRESS_TIME };
//# sourceMappingURL=touch.d.ts.map