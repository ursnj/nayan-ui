export { proceduralStorage, readPersistentAsset, writePersistentAsset, removePersistentAsset, clearPersistentStorage } from './storage.shared.js';
//# sourceMappingURL=storage.d.ts.map