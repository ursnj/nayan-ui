import type { Color } from './types.js';
/** A color as an option takes it: `[r, g, b]` / `[r, g, b, a]` (0..1, channels above 1 glow) or a CSS string. */
export type ColorInput = Color | string;
/**
 * Any color input as an `[r, g, b, a]` tuple (0..1), with its alpha multiplied by `alpha`. Use it when
 * you need the numbers (to brighten, mix or fade a theme color); options take strings directly.
 *
 * ```ts
 * toColor('#FF4757'); // [1, 0.278, 0.341, 1]
 * toColor('#FF4757', 0.5); // half see-through
 * ```
 */
export declare function toColor(color: ColorInput, alpha?: number): [number, number, number, number];
/** A color input as a tuple, without copying tuples (the hot path of `spawn`, `set` and `animate`). */
export declare function resolveColor(color: ColorInput): Color;
/** One color input, or a list to pick from, as tuples. */
export declare function resolveColors(colors: ColorInput | readonly ColorInput[]): readonly Color[];
//# sourceMappingURL=color.d.ts.map