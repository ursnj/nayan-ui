export declare const cacheGeneration: () => number;
export declare const advanceCacheGeneration: () => number;
//# sourceMappingURL=CacheGeneration.d.ts.map