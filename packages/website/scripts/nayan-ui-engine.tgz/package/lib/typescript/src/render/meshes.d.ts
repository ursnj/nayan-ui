export declare const VERTEX_FLOATS = 11;
type V3 = readonly [number, number, number];
export declare class Builder {
    vertices: number[];
    indices: number[];
    /** Adds a vertex, returns its index. */
    vertex(p: V3, n: V3, u: number, v: number): number;
    /** Two triangles, counter-clockwise a b c d as seen from the front. */
    quad(a: number, b: number, c: number, d: number): void;
    /**
     * A (rows + 1) x (cols + 1) vertex grid; `at(u, v)` gives position and normal. u runs along a row and
     * v down the rows; the grid faces the side from which u goes right and v goes down.
     */
    grid(rows: number, cols: number, at: (u: number, v: number) => [V3, V3]): void;
    /** A flat disc at height y facing up (+1) or down (-1). */
    disc(y: number, radius: number, facing: 1 | -1, segments: number): void;
}
/** Render-ready geometry: VERTEX_FLOATS floats per vertex, u32 triangle indices. */
export type MeshGeometry = {
    vertices: Float32Array;
    indices: Uint32Array;
};
/** What the renderer draws for a mesh id: geometry, and a texture id (see `loadTexture`) if any. */
/** `shine` 0..1: how glossy (sun highlight and sky reflection), 0 = matte. */
export type MeshInfo = {
    geometry: MeshGeometry;
    texture?: number;
    shine?: number;
};
/** Registers what a mesh id draws (loaded models, glyphs, textured variants). */
export declare function registerMesh(mesh: number, info: MeshInfo, uploadGeometry?: boolean): void;
/** One past the highest mesh id in use: per-frame scans of a source's ranges stop here. */
export declare const getMeshIdLimit: () => number;
/** Generates the built-in shapes in the Rust core and registers them with the native renderer (once). */
export declare function uploadBuiltInMeshes(): void;
/**
 * Initializes the shared core and built-in meshes. Await before using the engine on the web.
 * Mobile initialization remains synchronous and also warms the GPU on a background thread.
 * Repeat calls reuse initialization and mesh registration.
 */
export declare function warmUpEngine(): Promise<void>;
/** What to draw for a mesh id, or undefined ("none", or unknown). Built-in shapes use native geometry. */
export declare function meshInfo(mesh: number): MeshInfo | undefined;
export {};
//# sourceMappingURL=meshes.d.ts.map