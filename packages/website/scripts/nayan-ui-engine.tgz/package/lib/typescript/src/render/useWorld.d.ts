import { type DependencyList } from 'react';
import { World } from '../world/World.js';
/** What `useWorld`'s setup may return: a cleanup, run just before the world is disposed. */
export type WorldSetup = (world: World) => void | (() => void);
/**
 * A `World` owned by a component: the engine is warmed up (needed on the web, cheap on mobile), the
 * world is created with `capacity` entity slots and handed to `setup` to fill, and it is disposed on
 * unmount. A change in `deps` replaces it with a fresh one. Returns null until it's ready (one frame),
 * and while the engine is unavailable (Expo Go) or failed to start (`onError`, console by default).
 *
 * ```tsx
 * const world = useWorld(100, (w) => {
 *   w.spawn({ mesh: 'plane', scale: [20, 1, 20], color: '#4C9A4C', physics: 'fixed' });
 *   w.spawn({ mesh: 'sphere', position: [0, 4, 0], color: '#3399FF', physics: 'dynamic' });
 * });
 * return world && <GameView source={world} style={{ flex: 1 }} />;
 * ```
 */
export declare function useWorld(capacity: number, setup?: WorldSetup, deps?: DependencyList, onError?: (error: Error) => void): World | null;
//# sourceMappingURL=useWorld.d.ts.map