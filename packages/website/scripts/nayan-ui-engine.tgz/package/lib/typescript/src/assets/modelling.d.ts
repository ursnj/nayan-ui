import type { Vec3 } from '../types.js';
import type { Color, Quat } from '../world/types.js';
import type { Model } from './model.js';
import { type Geometry, type ShapeOptions } from './shape.js';
type Node = {
    readonly kind: 'sphere';
    readonly radius: number;
} | {
    readonly kind: 'ellipsoid';
    readonly radii: Vec3;
} | {
    readonly kind: 'box';
    readonly size: Vec3;
    readonly radius: number;
} | {
    readonly kind: 'capsule';
    readonly start: Vec3;
    readonly end: Vec3;
    readonly radius: number;
} | {
    readonly kind: 'cylinder';
    readonly radius: number;
    readonly height: number;
} | {
    readonly kind: 'torus';
    readonly radius: number;
    readonly tube: number;
} | {
    readonly kind: 'union';
    readonly a: Node;
    readonly b: Node;
    readonly blend: number;
} | {
    readonly kind: 'subtract' | 'intersect';
    readonly a: Node;
    readonly b: Node;
} | {
    readonly kind: 'transform';
    readonly child: Node;
    readonly position: Vec3;
    readonly rotation: Quat;
    readonly scale: Vec3;
} | {
    readonly kind: 'paint';
    readonly child: Node;
    readonly color: Color;
} | {
    readonly kind: 'shell';
    readonly child: Node;
    readonly thickness: number;
} | {
    readonly kind: 'displace';
    readonly child: Node;
    readonly amplitude: number;
    readonly frequency: number;
    readonly seed: number;
    readonly octaves: number;
};
/**
 * An immutable, code-authored solid. Join primitives into a single surface, blend organic forms,
 * drill holes, hollow shells and add reproducible rock/terrain detail before tessellating once.
 * Distances use world units; primitives are centered at the origin, cylinders/tori use the Y axis.
 *
 * const torso = Solid.ellipsoid([0.5, 0.7, 0.3]).paint([0.5, 0.1, 0.9]);
 * const neck = Solid.capsule([0, 0.5, 0], [0, 0.9, 0], 0.15);
 * const geometry = solidGeometry(torso.blend(neck, 0.15), { resolution: 48 });
 */
export declare class Solid {
    private readonly node;
    private constructor();
    static sphere(radius?: number): Solid;
    static ellipsoid(radii: Vec3): Solid;
    /** Full width/height/depth. Rounding stays inside these dimensions. */
    static box(size: Vec3, radius?: number): Solid;
    static capsule(start: Vec3, end: Vec3, radius: number): Solid;
    static cylinder(radius: number, height: number): Solid;
    /** Major radius to the tube center; minor radius of the tube itself. */
    static torus(radius: number, tube: number): Solid;
    /** Balanced union for many parts; avoids building a deeply nested operation chain. */
    static union(...solids: readonly Solid[]): Solid;
    union(other: Solid): Solid;
    /** Smoothly weld overlapping forms; blend controls the transition width in world units. */
    blend(other: Solid, blend: number): Solid;
    subtract(other: Solid): Solid;
    intersect(other: Solid): Solid;
    translate(position: Vec3): Solid;
    rotate(rotation: Quat): Solid;
    scale(scale: number | Vec3): Solid;
    private transform;
    /** Vertex colors blend with the surface at smooth joins. Apply after subtract() to color cut walls. */
    paint(color: Color): Solid;
    /** A shell centered on the original surface; thickness is its full wall thickness. */
    shell(thickness: number): Solid;
    /** Seeded fractal value noise. Use a resolution fine enough to sample its smallest features. */
    displace(options: DisplacementOptions): Solid;
    /** Serializable recipe for caching or inspecting a generated asset. */
    toJSON(): Node;
}
export interface DisplacementOptions {
    amplitude: number;
    frequency?: number;
    seed?: number;
    /** 1..6 octaves. Default 3. */
    octaves?: number;
}
export interface SolidOptions {
    /** Cells across the longest dimension, 8..128. Default 48. Higher costs cubic sampling work. */
    resolution?: number;
    /** Planar UV projection. Use parametricSurface/loft for explicitly authored UVs. Default xy. */
    uv?: 'xy' | 'xz' | 'yz';
}
/** Tessellates into editable, unregistered geometry. Prefer createSolid() for automatic model reuse. */
export declare function solidGeometry(solid: Solid, options?: SolidOptions): Geometry;
/**
 * Tessellates, cleans and registers a solid once, then returns its cached model on later calls
 * with the same recipe/options. White vertex colors can be tinted per spawned entity. Temporary
 * intermediate meshes consume no IDs. Prepared solids persist automatically when platform storage
 * is available; storage failure falls back to building. Call after warmUpEngine(), before spawning a run.
 */
export declare function createSolid(solid: Solid, options?: SolidOptions & ShapeOptions): Model;
export interface OptimizeOptions {
    /** Target triangle fraction in (0,1]. Default 1: lossless cleanup, welding and GPU cache ordering. */
    ratio?: number;
    /** Maximum relative error, 0..1, against the largest dimension, with attribute error included. Default 0.001. */
    error?: number;
    /** Keep open borders fixed, useful for separately generated terrain chunks. Default true. */
    lockBorders?: boolean;
}
/**
 * Returns new geometry, preserving the input and its normal/color/UV seams. Removes degenerate
 * triangles and unused/identical vertices, simplifies within the error bound, then orders buffers
 * for GPU reuse. The error bound may prevent reaching the requested ratio. Opaque static meshes only:
 * do not use on skinning buffers or meshes whose vertex indices are used by external code.
 */
export declare function optimizeGeometry(geometry: Geometry, options?: OptimizeOptions): Geometry;
/**
 * Independently simplifies the original at each requested ratio, avoiding accumulated error.
 * Cache/register the results once. The caller selects a level when camera distance changes.
 */
export declare function createGeometryLods(geometry: Geometry, ratios?: readonly number[], options?: Omit<OptimizeOptions, 'ratio'>): Geometry[];
export interface GeometryStats {
    vertices: number;
    triangles: number;
    /** CPU geometry bytes, excluding registration/driver copies. */
    bytes: number;
    bounds: {
        min: Vec3;
        max: Vec3;
        size: Vec3;
    } | null;
}
/** Cheap counts and bounds without registering a mesh. */
export declare function getGeometryStats(geometry: Geometry): GeometryStats;
/** Copies/sculpts one smooth surface and updates its normals. Deform hard-edged parts separately. */
export declare function deformGeometry(geometry: Geometry, deform: (position: Vec3, uv: readonly [number, number]) => Vec3): Geometry;
export {};
//# sourceMappingURL=modelling.d.ts.map