export { PanResponder, type PanResponderInstance } from 'react-native';
//# sourceMappingURL=responder.d.ts.map