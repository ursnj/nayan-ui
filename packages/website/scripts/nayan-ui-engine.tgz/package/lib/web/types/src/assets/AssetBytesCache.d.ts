/** Share concurrent requests across loader variants; failed requests can always be retried. */
export declare function assetBytes(key: string, load: () => Promise<ArrayBuffer>): Promise<ArrayBuffer>;
/** A decoder rejected the payload: a later load must fetch fresh bytes, not replay bad data. */
export declare function forgetAssetBytes(key: string | undefined): void;
/** Clearing disk must also prevent an earlier request from retaining its old bytes. */
export declare function clearAssetBytes(): void;
