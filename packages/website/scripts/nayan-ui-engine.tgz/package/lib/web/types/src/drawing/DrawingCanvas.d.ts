import type { DrawingCanvasProps } from './types';
export type { DrawingCanvasProps } from './types';
export declare const DrawingCanvas: import("react").MemoExoticComponent<({ document: drawing, mode, background, active, onError, onChange, style }: DrawingCanvasProps) => import("react").JSX.Element>;
