import type { Camera, RenderSource } from '../types';
/** `camera.follow`: ease the target toward the entity (where it was last drawn) and keep the eye at the offset. */
export declare function follow(camera: Camera, source: RenderSource, out: [number, number, number], dt: number): void;
/** `camera.shake`: a jittered copy of the camera; the strength fades by itself. */
export declare function shake(camera: Camera, out: Camera, dt: number): Camera;
