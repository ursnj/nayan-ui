import type { EntityOptions } from './types';
export declare const DESC_LEN = 64;
/** Writes `options` into `d`, with the mesh id already resolved. Only the fields present are flagged. */
export declare function encode(d: Float64Array, o: EntityOptions, mesh: number | undefined): void;
export declare const ANIM_HEADER = 12;
export declare const ANIM_KEY_LEN = 23;
export declare const BURST_LEN = 36;
export declare const EASING: {
    readonly linear: 0;
    readonly easeIn: 1;
    readonly easeOut: 2;
    readonly easeInOut: 3;
    readonly back: 4;
    readonly bounce: 5;
    readonly elastic: 6;
};
