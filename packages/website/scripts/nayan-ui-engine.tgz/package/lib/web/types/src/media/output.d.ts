import type { WasmCore } from '../native/BrowserEngine';
/** The Rust mixer remains the source of all audio, including native collision feedback. */
export declare function installAudioOutput(core: WasmCore): () => boolean;
