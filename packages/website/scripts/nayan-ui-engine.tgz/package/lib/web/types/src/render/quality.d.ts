export type RenderQuality = 'high' | 'medium' | 'low' | 'lowest';
/** `"auto"` starts at "high" and steps down only while the device really can't keep up. */
export type RenderQualitySetting = RenderQuality | 'auto';
export type QualityLevel = {
    /** Most device pixels drawn per point (the screen's own ratio when lower). */
    maxPixelRatio: number;
    /** MSAA samples: 4 or 1 (off). */
    samples: 1 | 4;
    /** Shadow map width and height in texels. */
    shadowSize: number;
    /** 3x3 filtered (soft) shadow edges, or a single tap (hard). */
    softShadows: boolean;
};
/** From best looking to cheapest; "auto" walks down this list only as far as it must. */
export declare const QUALITIES: readonly RenderQuality[];
export declare const QUALITY_LEVELS: Record<RenderQuality, QualityLevel>;
/** One second of frames, as the frame loop measured it. */
export type FrameReport = {
    /** The typical (median) time between frames, in ms: hiccups (garbage collection, a busy JS frame) don't move it. */
    frameMs: number;
    /** The typical (median) time spent drawing a frame, in ms (including any wait for the screen). */
    renderMs: number;
};
/**
 * Picks the level for "auto": starts at the best, steps down one level after `SLOW_SECONDS`
 * consecutive seconds whose typical frame misses ~50 fps while drawing took most of it (after a
 * single second when it misses ~33 fps, so a struggling phone recovers in seconds rather than
 * stuttering through every level), and steps back up after `FAST_SECONDS` smooth seconds. A level that fails again soon after being restored
 * becomes the ceiling, so it never bounces.
 */
export declare class AutoQuality {
    private index;
    /** The best level it may return to (raised past a level that keeps failing). */
    private ceiling;
    private started;
    private changed;
    private raisedAt;
    private slow;
    private verySlow;
    private fast;
    get quality(): RenderQuality;
    /** Feeds one second of frames; returns true when the level changed. */
    report(now: number, frames: FrameReport): boolean;
    private moved;
}
/** The middle value of `values` (sorted in place). */
export declare function median(values: number[]): number;
