import { type CSSProperties } from 'react';
import { createTouchResponder } from './touch';
export { createTouchResponder };
export type ViewStyle = CSSProperties;
export declare const pixelRatio: () => number;
export declare function useActive(): boolean;
interface SurfaceProps {
    surfaceId: number;
    style?: CSSProperties;
    onSize: (width: number, height: number) => void;
    onError: (error: Error) => void;
    touch?: ReturnType<typeof createTouchResponder>;
    onPrimaryAction?: () => void;
}
export declare function Surface({ surfaceId, style, onSize, onError, touch, onPrimaryAction }: SurfaceProps): import("react").JSX.Element;
