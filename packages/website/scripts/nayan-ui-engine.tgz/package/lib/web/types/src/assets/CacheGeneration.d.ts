export declare const cacheGeneration: () => number;
export declare const advanceCacheGeneration: () => number;
