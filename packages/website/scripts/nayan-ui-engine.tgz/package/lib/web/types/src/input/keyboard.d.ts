export type KeyboardInputMode = 'pointer' | 'drag' | 'swipe';
export declare const PRIMARY_INPUT_EVENT = "nayan-engine-primary-action";
export interface KeyboardInputOptions {
    mode?: KeyboardInputMode;
    enabled?: () => boolean;
    /** Optional primary control, in CSS pixels relative to the input surface. */
    primary?: () => {
        x: number;
        y: number;
    };
}
/** Browser keyboard adapter. Reuses pointer input, including engine gestures and raw contact surfaces. */
export declare function createKeyboardInput(surface: HTMLElement, options?: KeyboardInputOptions): {
    cancel: () => void;
    dispose(): void;
};
