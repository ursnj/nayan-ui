import type { ViewStyle } from '../render/host';
import type { DrawingDocument, DrawingState } from './DrawingDocument';
export interface DrawingCanvasProps {
    document: DrawingDocument;
    mode?: 'draw' | 'move' | 'view';
    background?: string;
    active?: boolean;
    onChange?: (state: DrawingState) => void;
    onError?: (error: Error) => void;
    style?: ViewStyle;
}
