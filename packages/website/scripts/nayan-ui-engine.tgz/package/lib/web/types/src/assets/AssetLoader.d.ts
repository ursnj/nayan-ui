import type { EngineBridge } from '../native/EngineBridge';
import { type AssetSource } from './source';
/** Shared session handles; source-byte persistence stays in AssetBytesCache and Rust. */
export declare class AssetLoader<T> {
    private readonly name;
    private readonly loads;
    constructor(name: string);
    load(source: AssetSource, decode: (native: EngineBridge, bytes: ArrayBuffer) => T | Promise<T>, variant?: readonly (string | number | boolean)[]): Promise<T>;
    private error;
}
