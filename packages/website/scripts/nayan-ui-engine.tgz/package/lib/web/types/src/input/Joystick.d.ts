import { type CSSProperties } from 'react';
export type JoystickState = {
    x: number;
    y: number;
};
export declare function useJoystick(): JoystickState;
export interface JoystickProps {
    state: JoystickState;
    size?: number;
    style?: CSSProperties;
}
export declare function Joystick({ state, size, style }: JoystickProps): import("react").JSX.Element;
