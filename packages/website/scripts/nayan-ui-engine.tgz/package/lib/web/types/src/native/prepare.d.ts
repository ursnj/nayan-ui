export declare function prepareEngine(): Promise<void>;
