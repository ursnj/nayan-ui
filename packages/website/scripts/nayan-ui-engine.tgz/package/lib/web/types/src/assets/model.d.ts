import { type MeshGeometry } from '../render/meshes';
import type { Vec3 } from '../types';
import type { AssetSource } from './source';
export type ModelOptions = {
    /** Move the model's bounding box center to the origin, so `position` is its middle. Default true. */
    center?: boolean;
    /** Scale it so its largest side is this long (e.g. 1 to match the built-in shapes). Default: keep its size. */
    fit?: number;
    /**
     * How glossy, 0..1: a sharp sun highlight and a reflection of the sky that grows at grazing angles.
     * 0 is matte; around 0.8 reads as car paint or glass. Default 0.
     */
    shine?: number;
};
/** A loaded model: pass it as an entity's `mesh`. Colliders sized from the mesh fit its bounding box. */
export type Model = {
    /** Bounding box size [x, y, z] at scale 1 (after `fit`). */
    readonly size: Vec3;
    /** Mesh id in the core. */
    readonly id: number;
};
/** An animation embedded in a loaded GLB. */
export type ModelClip = {
    readonly name: string;
    readonly duration: number;
};
export type LoadedModel = Model & {
    readonly animations: readonly ModelClip[];
    readonly jointCount: number;
};
/** A registered mesh's geometry, aliasing native memory. */
export declare function nativeGeometry(mesh: number): {
    vertices: Float32Array<ArrayBuffer>;
    indices: Uint32Array<ArrayBuffer>;
};
/**
 * Registers a mesh the core already holds (a created, cached or loaded model, a glyph, an alias):
 * the renderer copies it inside Rust, and JS reads its geometry only if something asks for it
 * (merging, caching). Apps built before `renderModel` upload it through JS as before.
 */
export declare function registerCoreMesh(mesh: number, info?: {
    texture?: number;
    shine?: number;
}, geometry?: () => MeshGeometry): void;
/** Independent materials share core geometry without overwriting an existing model's appearance. */
export declare function registerModelMesh(mesh: number, shine: number): number;
/**
 * Initializes the engine automatically. Loads a glTF model once; pass it as an entity's `mesh`. Meshes, node transforms, material colors
 * and the base color texture are kept (one texture per model); skeletal animation clips are available through `animations` and `World.playClip`.
 * Every entity using the model is drawn in one instanced draw call.
 *
 * ```ts
 * const tree = await loadModel(require("./assets/tree.glb"), { fit: 2 });
 * world.spawn({ mesh: tree, position: [0, 1, 0], physics: "fixed" });
 * ```
 */
export declare function loadModel(source: AssetSource, options?: ModelOptions): Promise<LoadedModel>;
