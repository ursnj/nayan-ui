import { type Camera, type Light, type RenderSource } from '../types';
import { type ColorInput } from '../world/color';
import { type ViewStyle } from './host';
import { type RenderQuality, type RenderQualitySetting } from './quality';
/**
 * Runs `fn` right after the next frame a GameView hands to the screen, on the same display clock
 * (the native one where the platform has it): the time a frame leaves is the best moment for
 * background work, such as loading in slices. With no GameView running it falls back to
 * requestAnimationFrame. Returns a function that cancels it.
 *
 * ```ts
 * const cancel = afterNextFrame(() => buildNextChunk());
 * ```
 */
export declare function afterNextFrame(fn: () => void): () => void;
export type GameViewStats = {
    fps: number;
    /** Mean time spent in `onUpdate` per frame, in milliseconds. */
    updateMs: number;
    /** Average milliseconds per frame spent drawing (CPU side, including waiting on the GPU). */
    renderMs: number;
    /** The quality level drawn with (with `quality="auto"`, the one it settled on so far). */
    quality: RenderQuality;
    /** The graphics API drawing: "vulkan", "gl" (OpenGL ES) or "metal". */
    backend: string;
};
export type SwipeDirection = 'left' | 'right' | 'up' | 'down';
export type OverlayTouchPhase = 'start' | 'move' | 'end' | 'cancel';
export type DragEvent = {
    phase: 'start' | 'move' | 'end';
    /** Finger position in the view, in points. */
    x: number;
    y: number;
    /** Distance moved since the drag started, in points. */
    dx: number;
    dy: number;
    /** On "end": the drag was interrupted (a second finger started a pinch, or the system took the touch). Put a held piece back. */
    cancelled?: boolean;
};
export type PinchEvent = {
    phase: 'start' | 'move' | 'end';
    /** Finger spread relative to the start: 2 = twice as far apart (zoom in). */
    scale: number;
    /** Radians the two fingers turned since the start, clockwise on screen. */
    rotation: number;
    /** Midpoint between the fingers in the view, in points. */
    x: number;
    y: number;
};
export type GameViewProps = {
    /** What to draw (usually a `World`). Changing it restarts the view; never pass a disposed world. */
    source: RenderSource;
    /**
     * Your game loop, called once per frame before drawing, with the elapsed seconds (capped at 0.1;
     * 0 until the first frame is on screen, so nothing plays out unseen): read input, spawn, move the
     * camera. The world (and `overlay`) is stepped for you right after; call `world.update(dt)` here
     * yourself only to step it at a different point or with a different `dt`.
     */
    onUpdate?: (dt: number) => void;
    /** Mutate this object (e.g. `camera.eye`) from `onUpdate`; it is read every frame. */
    camera?: Camera;
    light?: Light;
    /** Sky / clear color: a CSS color or linear 0..1 RGB (alpha ignored). Also the fog color. Default dark navy. */
    background?: ColorInput;
    /** Distance fog density towards `background` (e.g. 0.02). Default 0 (off). */
    fog?: number;
    /**
     * Resolution, anti-aliasing and shadow quality. "auto" (default) starts at "high", steps down only
     * while the GPU really can't keep up (shadow detail first, then anti-aliasing, resolution last) and
     * steps back up once frames are smooth again, so every phone gets the best look it can hold.
     */
    quality?: RenderQualitySetting;
    /** Suspend updates and drawing while keeping the native surface mounted. */
    paused?: boolean;
    style?: ViewStyle;
    /** A quick tap, at `x, y` points in the view. `world.pick(x, y)` finds what was tapped. */
    onTap?: (x: number, y: number) => void;
    /** A quick flick in one direction (2048, runners, sliding puzzles). */
    onSwipe?: (direction: SwipeDirection) => void;
    /** Finger down, moving and up (aiming, dragging pieces, slicing). */
    onDrag?: (drag: DragEvent) => void;
    /** A finger held still for half a second (pick up, show moves). No tap follows. */
    onLongPress?: (x: number, y: number) => void;
    /** Two fingers spreading, pinching or turning (zoom and rotate a board). Ends any drag in progress. */
    onPinch?: (pinch: PinchEvent) => void;
    /** Host primary action for keyboard input, such as Start/Stop or Play Again. */
    onPrimaryAction?: () => void;
    /**
     * A screen-space layer drawn over the scene by the renderer (scoreboards, buttons): usually a second
     * `World`, in points from the view's top-left with y up (so on screen y <= 0) and z toward the viewer
     * within -100..100. Unlit (flat faces show their exact color) and always in front. Stepped each
     * frame like `source`.
     */
    overlay?: RenderSource;
    /**
     * Touches for the overlay, in points in the view. Return true from "start" to claim the touch (a
     * button was hit): its moves and end come here, and the game gets no drag, tap or swipe for it.
     * "cancel" when the system takes the touch.
     */
    onOverlayTouch?: (phase: OverlayTouchPhase, x: number, y: number) => boolean | void;
    /** Called once a second. */
    onStats?: (stats: GameViewStats) => void;
    /** GPU setup failures and rendering errors. Defaults to console.error. */
    onError?: (error: Error) => void;
};
export declare function GameView(props: GameViewProps): import("react").JSX.Element;
