/** Optional storage override. The engine selects a best-effort platform cache by default. */
export interface ProceduralStorage {
    read(key: string): Uint8Array | null;
    write(key: string, bytes: Uint8Array): void | Promise<void>;
    /**
     * The store itself verifies every record's integrity (the engine's own Rust store checksums each
     * one with SHA-256), so the cache needn't checksum and scan them again in JS. Geometry is still
     * validated by the core when it's registered.
     */
    readonly verified?: boolean;
}
/**
 * Persists the output of a deterministic model factory, including nested model arrays/objects.
 * Hits register saved vertices directly: no procedural tessellation, painting or optimization.
 * Imported/skinned/textured models are intentionally excluded; their own loaders retain their rigs.
 */
export declare class ProceduralCache {
    readonly revision: string;
    private storage;
    private memory;
    private hits;
    private builds;
    private invalid;
    private failures;
    private writes;
    constructor(revision: string, storage?: ProceduralStorage | undefined);
    get stats(): {
        hits: number;
        builds: number;
        invalid: number;
        failures: number;
        pendingWrites: number;
    };
    flush(): Promise<void>;
    /**
     * A value already cached (in memory, or saved by an earlier launch), without building anything:
     * undefined when there is none yet. Lets work that's spread over many frames (a level generated
     * step by step) skip itself entirely when a saved result exists, then save with `get`.
     */
    peek<T>(key: string): T | undefined;
    get<T>(key: string, build: () => T): T;
    private encode;
    private restore;
}
