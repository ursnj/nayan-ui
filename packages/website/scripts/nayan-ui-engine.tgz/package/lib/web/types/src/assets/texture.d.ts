import type { AssetSource } from './source';
/** A loaded image. Pass it as an entity's `texture`. */
export type Texture = {
    readonly id: number;
    readonly width: number;
    readonly height: number;
};
export type TextureImage = {
    width: number;
    height: number;
    pixels: Uint8Array;
};
/**
 * Initializes the engine automatically. Loads a PNG or JPEG once (up to 4096 x 4096). Use it on any entity: `{ mesh: "cube", texture }`.
 * The entity's `color` tints it; `textureRegion` shows part of it (sprite sheets, card atlases).
 *
 * ```ts
 * const crate = await loadTexture(require("./assets/crate.png"));
 * world.spawn({ mesh: "cube", texture: crate });
 * ```
 */
export declare function loadTexture(source: AssetSource): Promise<Texture>;
/** Pixels of a texture id (aliasing native memory), for the renderer. */
export declare function textureImage(id: number): TextureImage;
/**
 * The mesh id that draws `mesh`'s geometry with `texture`: a textured variant made on first use
 * (it shares the geometry, colliders and picking of the original).
 */
export declare function texturedMesh(mesh: number, texture: Texture): number;
