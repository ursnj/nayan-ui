import type { PointerEvent as ReactPointerEvent } from 'react';
type Touch = {
    pageX: number;
    pageY: number;
};
interface Event {
    nativeEvent: Touch & {
        locationX: number;
        locationY: number;
        touches: Touch[];
    };
}
interface Gesture {
    dx: number;
    dy: number;
}
interface Callbacks {
    onStartShouldSetPanResponder: () => boolean;
    onMoveShouldSetPanResponder: () => boolean;
    onPanResponderGrant: (event: Event) => void;
    onPanResponderMove: (event: Event, gesture: Gesture) => void;
    onPanResponderRelease: (event: Event, gesture: Gesture) => void;
    onPanResponderTerminate: (event: Event, gesture: Gesture) => void;
}
export interface PanResponderInstance {
    panHandlers: {
        onPointerDown: (event: ReactPointerEvent<HTMLDivElement>) => void;
        onPointerMove: (event: ReactPointerEvent<HTMLDivElement>) => void;
        onPointerUp: (event: ReactPointerEvent<HTMLDivElement>) => void;
        onPointerCancel: (event: ReactPointerEvent<HTMLDivElement>) => void;
        onLostPointerCapture: (event: ReactPointerEvent<HTMLDivElement>) => void;
    };
    cancel: () => void;
}
/** Adapt DOM pointer capture to the gesture recognizer used on mobile. Coordinates stay in CSS pixels. */
export declare const PanResponder: {
    create(callbacks: Callbacks): PanResponderInstance;
};
export {};
