import type { AssetSource } from './source';
/** Printable ASCII plus common arithmetic and typography, prewarmed for ordinary labels. */
export declare const DEFAULT_CHARS = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz !\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~\u00D7\u00F7\u00B1\u2212\u00B0\u00B7\u2022\u2013\u2014\u2026\u2018\u2019\u201C\u201D";
export type FontOptions = {
    /** How deep letters are extruded, as a fraction of the font size. 0 = flat. Default 0.2. */
    depth?: number;
    /** Characters to prewarm (space and ? are always included). Other font-supported characters load
     * once when text is measured or laid out. Fewer = faster startup and fewer unused meshes. Default: DEFAULT_CHARS. */
    chars?: string;
    /** Weight (e.g. 400, 600) for a variable font, such as the device's system font. Default: the font's own. */
    weight?: number;
};
type Glyph = {
    mesh: number;
    advance: number;
};
/** A loaded font. Use it on an entity with `text`: `{ text: "2048", font }`. */
export type Font = {
    readonly id: number;
    /** Height of capital letters at scale 1. */
    readonly capHeight: number;
    /** Cached mesh (-1 = nothing drawn, e.g. space) and advance per character. Grows as text is used. */
    readonly glyphs: ReadonlyMap<string, Glyph>;
};
/**
 * Initializes the engine automatically. Loads a TrueType / OpenType font (.ttf / .otf) for 3D text. The source/depth/weight are cached independently of the requested prewarm characters. Letters are real meshes: lit, shadowed,
 * and every copy of a letter on screen is drawn in one call. At scale 1, letters are 1 unit tall (em).
 * Additional Unicode glyphs are built on demand from the same font and cached. The font must contain
 * an outline for the character; missing characters still use ?, including unsupported emoji.
 *
 * ```ts
 * const font = await loadFont(require("./assets/Inter-Bold.ttf"), { chars: "0123456789" });
 * world.spawn({ text: "2048", font, scale: 0.5, color: [1, 1, 1] });
 * ```
 */
export declare function loadFont(source: AssetSource, options?: FontOptions): Promise<Font>;
export type TextAlign = 'left' | 'center' | 'right';
export type TextLayout = {
    /** Extra space between letters, in ems (at scale 1, letters are 1 em tall). Default 0. */
    letterSpacing?: number;
    /** Digits all as wide as the widest, so changing numbers (scores, timers) don't shift. Default false. */
    tabular?: boolean;
};
/** A line's advance in ems, with the same Unicode glyph loading, spacing and fallbacks as rendering. */
export declare function measureText(font: Font, text: string, options?: TextLayout): number;
/** Glyph placements for a line of text: centered vertically on capitals, aligned horizontally. */
export declare function layoutText(font: Font, text: string, align: TextAlign, options?: TextLayout): {
    mesh: number;
    x: number;
    y: number;
}[];
export {};
