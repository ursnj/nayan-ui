# @nayan-ui/engine

[![npm](https://img.shields.io/npm/v/@nayan-ui/engine?label=npm)](https://www.npmjs.com/package/@nayan-ui/engine) [![license](https://img.shields.io/npm/l/@nayan-ui/engine)](#license)

A fast 3D game engine for **React** and **React Native**. One TypeScript API on one Rust core: rendering (wgpu), physics (Rapier), skeletal and tween animation, particles, audio, haptics and 2D drawing.

**[Documentation](https://www.nayanui.com/game-engine)** · **[First game tutorial](https://www.nayanui.com/game-engine/first-game)** · **[API reference](https://www.nayanui.com/game-engine/api-reference)** · **[Guide for AI agents](https://www.nayanui.com/game-engine/agent-guide)**

- **Native speed on phones.** Rendering, physics, animation, culling and audio mixing run in Rust. On iOS and Android the game loop follows the display's clock, and frames are drawn on the engine's own render thread, so your JavaScript never waits on the GPU.
- **Small API.** `useWorld` + `GameView` is a complete scene. Spawn entities, move them, animate them: the engine steps, draws and cleans up.
- **Fast loading.** Images, glTF models, fonts and sounds decode on native background threads, and procedural meshes can be cached on disk between launches.
- **Same code on the web.** The core compiles to WebAssembly and draws with WebGPU, falling back to WebGL2.

| Platform    | Renders with                   | Needs                                                     |
| ----------- | ------------------------------ | --------------------------------------------------------- |
| iOS         | Metal                          | A development or store build (Expo Go doesn't include it) |
| Android     | Vulkan or OpenGL ES            | `minSdkVersion` 26, a development or store build          |
| Web (React) | WebAssembly + WebGPU or WebGL2 | A modern browser over HTTPS or localhost                  |

## Install

```sh
npm install @nayan-ui/engine
```

Peer dependencies: `react`, plus `react-native` for apps. `expo-asset` is optional and only needed to load bundled files with `require(...)` in Expo.

### React Native (Expo)

1. Let Metro bundle 3D models, in `metro.config.js`:

   ```js
   config.resolver.assetExts.push('glb', 'gltf');
   ```

2. Target Android 8.0 (API 26) or newer (with `expo-build-properties`), and allow vibration for haptics, in `app.json`:

   ```json
   {
     "expo": {
       "android": { "permissions": ["android.permission.VIBRATE"] },
       "plugins": [["expo-build-properties", { "android": { "minSdkVersion": 26 } }]]
     }
   }
   ```

3. Make a development build: `npx expo run:ios` / `npx expo run:android` (or an EAS build). The engine ships prebuilt native libraries, so no Rust toolchain is needed.

Bare React Native apps autolink the same way: run `pod install` in `ios/` and set `minSdkVersion` 26 in Gradle.

Guard screens for builds without the native module (for example Expo Go) with `isEngineAvailable`:

```tsx
import { isEngineAvailable } from '@nayan-ui/engine';

if (!isEngineAvailable) return <Text>This screen needs a development build.</Text>;
```

### React (web)

Nothing to configure. `useWorld` loads the WebAssembly core for you; if you create worlds yourself, `await warmUpEngine()` first.

## Quick start

A complete scene that works unchanged on every platform:

```tsx
import { GameView, useWorld } from '@nayan-ui/engine';

export function BouncingBall() {
  const world = useWorld(100, (w) => {
    w.spawn({ mesh: 'plane', scale: [20, 1, 20], color: '#4C9A4C', physics: 'fixed' });
    w.spawn({ mesh: 'sphere', position: [0, 5, 0], color: '#3399FF', physics: { type: 'dynamic', bounce: 0.6 } });
  });
  return world && <GameView source={world} camera={{ eye: [0, 4, 8], target: [0, 0, 0], fov: 1 }} style={{ flex: 1 }} />;
}
```

`useWorld` warms the engine up, creates the world (100 entity slots), runs your setup and disposes it on unmount. `GameView` draws it and steps it every frame.

## The five rules

1. **Own** a world with `useWorld(capacity, setup)`, or create it yourself after `await warmUpEngine()` and `dispose()` it on unmount.
2. **Play** in `GameView`'s `onUpdate(dt)`: read input, move things, spawn. The world is stepped for you right after (call `world.update(dt)` yourself only to step it earlier or with another `dt`).
3. **Keep handles**: `spawn` returns an `Entity`; change it with `set`, remove it with `despawn`.
4. **Batch per-frame moves** in `world.transforms`: they are applied in one native call when the world steps (`flush()` yourself before reading positions).
5. **Don't track disposal yourself**: check `world.isDisposed`. Cleanup calls are safe no-ops after `dispose()`.

## Performance

The engine is built so that a game written the obvious way stays smooth on mid-range Android phones.

- **Display clock and render thread (iOS and Android).** The display's vsync (`CADisplayLink` on iOS, `Choreographer` on Android) asks for each frame at 60 Hz. `onUpdate` steps the game and hands a copy of the frame to a native render thread, which culls, submits and presents it. The JS thread never waits on the GPU, and a frame that is still waiting when a newer one arrives is replaced, not queued. The clock stops while the app is in the background or the view is off screen. On the web, `requestAnimationFrame` drives the same loop.
- **Culling in Rust.** Everything outside the camera's view (and outside the light's box for shadows) is skipped every frame, so open levels and long tracks only pay for what is on screen. Don't cull scenery in JS.
- **Automatic quality.** `quality="auto"` (the default) starts at `high` and steps down (shadow detail first, then anti-aliasing, resolution last) only while the device can't keep up. `onStats` reports fps, update and render time, the quality chosen and the graphics backend.
- **Background loading.** `loadTexture`, `loadModel`, `loadFont` and `audio.load` decode on native threads in parallel, and meshes are registered with the renderer inside Rust.
- **Work between frames.** `afterNextFrame(fn)` runs `fn` right after the next frame leaves, so you can spread long setup work (map generation, mesh building) over several frames behind a loading screen.
- **Cached procedural assets.** `ProceduralCache` saves built geometry on disk keyed by a recipe, so later launches restore it instead of rebuilding; `peek(key)` returns a saved value without building anything.

Keep these habits:

- Build meshes once, at module scope or behind a cache, and spawn new entities from them. Mesh ids are app-wide and never freed (`getMeshIdLimit()` tells you how many there are), so never create a mesh per spawn or per frame.
- Move many things each frame through `world.transforms` and the `out` arguments of queries, which allocate nothing.
- Keep long one-off jobs out of gameplay frames: a single slow frame stalls Android's Hermes far longer than desktop JavaScript suggests.

## Common tasks

**Physics and collisions**

```ts
const ball = world.spawn({ mesh: 'sphere', position: [0, 5, 0], physics: { type: 'dynamic', bounce: 0.6 } });
const coin = world.spawn({ mesh: 'cylinder', position: [2, 1, 0], physics: { type: 'fixed', sensor: true } });
world.impulse(ball, [0, 4, 0]);
world.forEachCollision((a, b, { started }) => {
  if (started && (a === coin || b === coin)) world.despawn(coin);
});
```

**Animation** (runs in Rust and returns a Promise)

```ts
await world.animate(piece, { position: [2, 0, 3] }, { duration: 0.25, easing: 'back' });
world.animate(star, { scale: 1.2 }, { repeat: 'forever', yoyo: true });
```

**Skinned characters**: glTF clips play natively, with crossfades

```ts
const hero = await loadModel(require('./hero.glb'));
console.log(hero.animations.map((clip) => clip.name)); // e.g. ['idle', 'walk', 'run']
const player = world.spawn({ mesh: hero });
world.playClip(player, 'idle', { speed: 0 }); // hold the first pose on the ready screen
world.playClip(player, 'run', { fade: 0.2 }); // crossfade when play starts
world.stopClip(player);
```

`world.sampleSkinnedVertices` reads chosen vertices of the next pose (for planting feet on uneven ground) without skinning the whole character in JS.

**Ready-made effects**

```ts
import { effects } from '@nayan-ui/engine';

effects.confetti(world, {
  position: [0, 2, 0],
  colors: ['#FF4D4D', '#FFD933'],
  size: 0.12,
  speed: 6,
  count: 40,
  lifetime: 1.2,
  gravity: -6
});
effects.dust(world, { position: [0, 0, 0], color: [0.8, 0.75, 0.65, 0.6], size: 0.3, speed: 1.5, count: 6, lifetime: 0.5 });
await effects.pop(world, piece, { scale: 1, color: '#FF4D4D' }); // swell, flash white, shrink away
world.despawn(piece);
```

Also available: `sparkle`, `shatter`, `splash`, `sparks`, `explosion` and `flash`.

**Per-frame movement without allocations**

```ts
import { type MutableQuat, quat } from '@nayan-ui/engine';

const turn: MutableQuat = [0, 0, 0, 1];
const at: [number, number, number] = [0, 0, 0];

function onUpdate(dt: number) {
  world.position(player, at); // queries can fill an `out` array
  quat.y(heading, turn);
  world.transforms.transform(car, carX, 0, carZ, turn[0], turn[1], turn[2], turn[3]); // applied in one native call as the world steps
}
```

**Models built in code**: bake a shape once, spawn it many times

```ts
import { createShape, lathe, merge, tube } from '@nayan-ui/engine';

// Built once per app (after warmUpEngine), at module scope.
const vase = createShape(
  merge([
    {
      geometry: lathe(
        [
          [0, 0],
          [0.4, 0.1],
          [0.25, 0.8],
          [0.3, 1]
        ],
        { segments: 24 }
      )
    },
    {
      geometry: tube(
        [
          [0.3, 0.9, 0],
          [0.5, 0.7, 0],
          [0.3, 0.5, 0]
        ],
        { radius: 0.04 }
      ),
      color: [0.5, 0.25, 0.1]
    } // part colors are 0..1 tuples
  ])
);
world.spawn({ mesh: vase, color: '#C8763A' });
```

Also available: `extrude`, `loft`, `block`, `ellipsoid`, `parametricSurface`, `Solid` and `shapeGeometry` for the built-in shapes.

**Score, lives and timers**

```ts
world.scoreboard.handlers = { onTimeUp: () => endGame('lose') }; // the game's rules
const stopListening = world.scoreboard.listen({ onScore: setScore, onSecond: setTime }); // UI follows along
world.scoreboard.reset(3, 60); // 3 lives and a stopped 60 s countdown for the ready screen
world.scoreboard.resume(); // Start
world.scoreboard.add(10);
const timer = world.after(0.5, spawnWave); // game time: pauses with the game
world.cancelTimer(timer);
```

**Flat boards and puzzles**: `frontLight` keeps camera-facing surfaces at their exact color

```tsx
<GameView source={world} camera={{ eye: [0, 0, 50], target: [0, 0, 0], fov: 1, ortho: 10 }} light={frontLight([-0.4, 0.6, 1], 0.5)} />
```

**Input**

```tsx
<GameView
  source={world}
  onTap={(x, y) => {
    const hit = world.pick(x, y);
    if (hit) world.animate(hit.entity, { scale: 1.2 }, { yoyo: true, repeat: 1 });
  }}
  onSwipe={(direction) => move(direction)}
  onDrag={({ phase, x, y }) => drag(phase, x, y)}
/>
```

`onLongPress`, `onPinch`, the on-screen `Joystick` and `createKeyboardInput` (web) cover other controls.

**Models, textures, text, sound and haptics**

```ts
import { audio, haptics, loadFont, loadModel, loadTexture } from '@nayan-ui/engine';

const car = await loadModel(require('./car.glb'), { fit: 2 }); // or a URL string on the web
const crate = await loadTexture(require('./crate.png'));
const font = await loadFont(require('./Inter-Bold.ttf'));
world.spawn({ mesh: car, position: [0, 0, 0] });
world.spawn({ mesh: 'cube', texture: crate });
world.spawn({ text: '2048', font, position: [0, 2, 0], scale: 0.5 });

const sfx = audio.load({ coin: require('./coin.wav') });
sfx.play('coin');
haptics.impact(0.5);
audio.enabled = settings.sounds; // respect the player's preferences
haptics.enabled = settings.haptics;
```

**Colors** are CSS strings (`'#FF4757'`, `'rgba(0, 0, 0, 0.5)'`) or linear 0..1 tuples (`[1, 0.3, 0.3]`; channels above 1 glow) for entities, animations, particles, lights and the background. Vertex colors baked into geometry are tuples. `toColor('#FF4757')` converts a CSS color when you need the numbers.

**Drawing**: a native paint canvas, also usable as a live texture inside games

```tsx
import { DrawingCanvas, DrawingDocument } from '@nayan-ui/engine';

const paper = new DrawingDocument(512, 512);
paper.setBrush({ brushType: 'MARKER', color: '#e53935', width: 12, opacity: 1 });
<DrawingCanvas document={paper} mode="draw" />;
world.spawn({ mesh: 'plane', texture: paper.texture() }); // paint on a 3D object
```

Drawings save as SVG paths and export transparent PNG snapshots.

## Troubleshooting

| Symptom                                         | Fix                                                                                                      |
| ----------------------------------------------- | -------------------------------------------------------------------------------------------------------- |
| `isEngineAvailable` is `false`                  | You're in Expo Go or a build made before installing the engine: make a new development build.            |
| `.glb` files fail to bundle                     | Add `glb` and `gltf` to Metro's `assetExts`.                                                             |
| Android build fails on `minSdkVersion`          | Set it to 26 or higher.                                                                                  |
| An Android screenshot of the game view is blank | The engine draws into a `SurfaceView`: use `captureScreen(..., { handleGLSurfaceViewOnAndroid: true })`. |
| Out of mesh ids                                 | A mesh is being created per spawn or per frame: build it once and reuse it (`getMeshIdLimit()`).         |

## Learn more

| Topic                                 | Guide                                                                                                          |
| ------------------------------------- | -------------------------------------------------------------------------------------------------------------- |
| Build a complete game step by step    | [First game](https://www.nayanui.com/game-engine/first-game)                                                        |
| Copy-paste solutions                  | [Recipes](https://www.nayanui.com/game-engine/recipes)                                                              |
| Worlds, entities, rotations, disposal | [World & entities](https://www.nayanui.com/game-engine/world-entities)                                              |
| Effects and particles                 | [Effects](https://www.nayanui.com/game-engine/particles)                                                            |
| Procedural meshes and modelling       | [Geometry](https://www.nayanui.com/game-engine/procedural-geometry)                                                 |
| Drawing and painting                  | [Drawing](https://www.nayanui.com/game-engine/drawing)                                                              |
| Performance and caching               | [Performance](https://www.nayanui.com/game-engine/cache-performance)                                                |
| Coding agents                         | [Agent guide](https://www.nayanui.com/game-engine/agent-guide) · [engine.json](https://www.nayanui.com/engine.json) |

## License

MIT © [Niranjan Devasani](https://github.com/ursnj)

---

Made with ❤️ by [Niranjan Reddy Devasani](https://github.com/ursnj)
