// Autolinking. iOS uses NayanEngine.podspec; Android builds native/android/CMakeLists.txt into the app as a
// pure C++ TurboModule (the generated autolinking code instantiates NayanEngineModule).
module.exports = {
  dependency: {
    platforms: {
      android: {
        sourceDir: 'native/android',
        // The EngineSurface view (native/android/src/main/java).
        packageImportPath: 'import com.nayanui.engine.NayanEnginePackage;',
        packageInstance: 'new NayanEnginePackage()',
        cmakeListsPath: 'codegen/CMakeLists.txt',
        cxxModuleCMakeListsModuleName: 'NayanEngine',
        cxxModuleCMakeListsPath: 'CMakeLists.txt',
        cxxModuleHeaderName: 'NayanEngineModule'
      }
    }
  }
};
