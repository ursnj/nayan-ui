import { readFile, stat } from 'node:fs/promises';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(fileURLToPath(new URL('../..', import.meta.url)));
const metadata = JSON.parse(await readFile(resolve(root, 'package.json'), 'utf8'));
const required = new Set([
  'README.md',
  'NayanEngine.podspec',
  'react-native.config.js',
  'src/native/spec/NativeNayanEngine.ts',
  'native/cpp/generated/NayanEngineSpecJSI.h',
  'native/core/include/engine_core.h',
  'native/core/build/EngineCore.xcframework/Info.plist',
  'native/core/build/EngineCore.xcframework/ios-arm64/libengine_core.a',
  'native/core/build/EngineCore.xcframework/ios-arm64-simulator/libengine_core.a',
  'lib/web/engine_core_bg.wasm',
  'lib/web/audio-worklet.js'
]);
for (const abi of ['arm64-v8a', 'armeabi-v7a', 'x86_64', 'x86']) required.add(`native/core/build/android/${abi}/libengine_core.a`);
function exportedFiles(value) {
  if (typeof value === 'string') required.add(value);
  else for (const item of Object.values(value)) exportedFiles(item);
}
exportedFiles(metadata.exports);
const missing = [];
for (const path of required) {
  try {
    const info = await stat(resolve(root, path));
    if (!info.isFile() || info.size === 0) missing.push(path);
  } catch {
    missing.push(path);
  }
}
if (missing.length)
  throw new Error(
    `Engine package is incomplete:\n${missing.map((path) => `  ${path}`).join('\n')}\nBuild the native core on macOS and run engine:build before packing or publishing.`
  );
console.error(`Verified ${required.size} required engine package files for ${metadata.version}.`);
