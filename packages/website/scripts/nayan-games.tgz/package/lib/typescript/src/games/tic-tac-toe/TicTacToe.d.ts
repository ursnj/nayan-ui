export declare const TicTacToe: import("react").FC<import("../..").GameProps>;
//# sourceMappingURL=TicTacToe.d.ts.map