import { type Camera, World } from 'nayan-ui';
import type { GameTheme } from '../../services/ThemeService';
import type { GamePhase as Phase } from '../shared/useEngineGame';
import { type Layout } from './LudoKingConstants';
import { type Player } from './LudoKingRules';
import { type Scene } from './LudoKingScene';
export type Turn = 0 | 1;
/** 'rolling' waits for your die tap, 'await' for your token tap, others animate or are the AI's. */
type Stage = 'rolling' | 'await' | 'busy' | 'thinking';
export type GameEvent = 'tap' | 'roll' | 'six' | 'penalty' | 'cantMove' | 'move' | 'capture' | 'finish';
export declare function createGame(theme: GameTheme): {
    world: World;
    camera: Camera;
    theme: GameTheme;
    layout: Layout | null;
    scene: Scene | null;
    phase: Phase;
    players: Player[];
    turn: Turn;
    dice: number;
    stage: Stage;
    sixes: number;
    /** The score lives in the engine (Rust). */
    readonly score: number;
    won: boolean;
    onPhase: (_p: Phase) => void;
    onFinished: (_you: number, _ai: number) => void;
    onTurn: (_t: Turn) => void;
    onEvent: (_e: GameEvent, _who: Turn) => void;
};
export type Game = ReturnType<typeof createGame>;
export declare function setLayout(g: Game, l: Layout): void;
export declare function setTheme(g: Game, theme: GameTheme): void;
export declare function start(g: Game): void;
export declare function reset(g: Game): void;
/** Steps the world with a clamped frame, so a long one doesn't jump the turn's clock. */
export declare function tick(g: Game, dt: number): void;
export declare function tap(g: Game, x: number, y: number): void;
export {};
//# sourceMappingURL=LudoKingGame.d.ts.map