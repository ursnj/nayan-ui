import { type Entity, type Vec3, type World } from 'nayan-ui';
import { type IslandAssets, type Structure } from './IslandSurvivalConstants';
import type { IslandMap } from './IslandSurvivalIsland';
import { type Interaction, type Monster } from './IslandSurvivalRules';
type FarmPlant = {
    leaves: Entity;
    fruit?: Entity;
    size: number;
};
type FarmCrops = {
    plants: FarmPlant[];
    progress: number;
};
export declare function createScene(world: World, map: IslandMap, assets: IslandAssets): {
    water: Entity;
    springWater: Entity;
    resources: {
        mesh: Entity;
        pick: Entity;
        location: Vec3;
        rotation: import("nayan-ui").MutableQuat;
    }[];
    targets: Map<Entity, Interaction>;
    structures: Map<"shelter" | "fire" | "fence" | "farm" | "beacon", {
        root: Entity;
        pick?: Entity;
        crops?: FarmCrops;
    }>;
    fireSources: Vec3[];
};
export type IslandScene = ReturnType<typeof createScene>;
export declare function resetScene(world: World, scene: IslandScene): void;
export declare function placeStructure(world: World, scene: IslandScene, map: IslandMap, kind: Structure, spot: {
    x: number;
    z: number;
}, assets: IslandAssets): void;
export declare function updateFarmGrowth(world: World, scene: IslandScene, time: number, readyAt: number): void;
export declare function animateWater(world: World, scene: IslandScene, time: number): void;
export declare function smoke(world: World, scene: IslandScene): void;
export declare function spawnMonster(world: World, map: IslandMap, monster: Monster, assets: IslandAssets['monster']): {
    pick: Entity;
    root: Entity;
    body: Entity;
    animation: "hit" | "idle" | "walk" | "attack" | "run" | "fall" | null;
    rate: number;
    strikes: number;
    phase: number;
    indices: Uint32Array;
    supportIndices: Uint32Array;
    samples: Float32Array;
    leftCount: number;
    soles: [[number, number, number], [number, number, number]];
    shadows: [Entity[], Entity[]];
    settled: boolean;
    stagger: number;
    fallTime: number;
};
export {};
//# sourceMappingURL=IslandSurvivalScene.d.ts.map