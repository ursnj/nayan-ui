import type { TiltView } from '../shared/EngineTilt';
export declare const TIME_LIMIT = 120;
export declare const POINTS_PER_BLOCK = 500;
export declare const PERFECT_BONUS = 250;
export declare const PERFECT_THRESHOLD = 3;
export declare const MIN_OVERLAP_RATIO = 0.4;
/** Cycled up the tower. */
export declare const BLOCK_COLORS: readonly ["#FF4757", "#FFA502", "#2ED573", "#1E90FF", "#FF6BD6", "#A55EEA", "#00D2D3", "#FF6348"];
export declare const FRAME_MS = 16.67;
export declare const MAX_FRAMES = 2;
export declare const NEXT_BLOCK_DELAY = 0.2;
export declare const MISS_TIME = 0.45;
export declare const GAME_OVER_DELAY = 0.3;
export declare const SPAWN_FADE = 0.2;
export declare const PERFECT_SHOW = 0.6;
export declare const CAMERA_TIME = 0.35;
/** The camera looks down a little from in front, so the tower's top and its depth show. */
export declare const TILT = -0.24;
/** Lit from the upper left; faces toward the camera (+z) keep their exact color. */
export declare const LIGHT: import("nayan-ui").Light;
export type Layout = TiltView & {
    /** The slide's bounds: the game area, 30 narrower than the screen and at most 500 across. */
    left: number;
    gameWidth: number;
    blockWidth: number;
    blockHeight: number;
    /** Front to back. */
    blockDepth: number;
    speed: number;
    /** The base block's top. */
    baseY: number;
};
export declare function getLayout(width: number, height: number): Layout;
//# sourceMappingURL=StackTowerConstants.d.ts.map