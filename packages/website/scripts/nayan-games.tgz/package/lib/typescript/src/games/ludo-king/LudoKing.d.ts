export declare const LudoKing: import("react").FC<import("../..").GameProps>;
//# sourceMappingURL=LudoKing.d.ts.map