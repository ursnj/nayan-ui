export declare const PaperIo: import("react").FC<import("../..").GameProps>;
//# sourceMappingURL=PaperIo.d.ts.map