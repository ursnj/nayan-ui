export declare const TIME_LIMIT = 120;
export declare const LIVES = 3;
export declare const POINTS_PER_CATCH = 500;
export declare const MAX_STICKS = 18;
export declare const BASE_FALL_SPEED = 2.4;
export declare const SPEED_INC_PER_POINT = 0.00006;
export declare const MAX_FALL_SPEED = 3.8;
export declare const BASE_SPAWN_MS = 1450;
export declare const SPAWN_DEC_PER_POINT = 0.012;
export declare const MIN_SPAWN_MS = 1000;
export declare const SPIN_MAX = 2.2;
export declare const LAND_TILT_MAX = 6;
/** The first stick of a run drops almost at once. */
export declare const FIRST_SPAWN_TIMER: number;
export declare const STEP_MS: number;
export declare const MAX_PENDING_MS = 50;
export declare const STICK_COLORS: readonly ["#E53935", "#1E88E5", "#43A047", "#FB8C00", "#8E24AA", "#00ACC1", "#F4511E", "#FDD835"];
export type Layout = {
    width: number;
    height: number;
    left: number;
    right: number;
    spawnY: number;
    stickLen: number;
    stickW: number;
    hitRadius: number;
    spawnMargin: number;
    /** Sticks are missed once their centre passes this line (the grass). */
    floorY: number;
};
/** Keep catches below the HUD, above the controls and inside the centered, capped play width. */
export declare function getLayout(width: number, height: number, offset?: number): Layout;
//# sourceMappingURL=FallingSticksConstants.d.ts.map