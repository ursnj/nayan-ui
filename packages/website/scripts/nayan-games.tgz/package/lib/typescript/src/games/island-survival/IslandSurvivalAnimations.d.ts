export declare const ISLAND_MOTIONS: {
    readonly gather: {
        readonly clip: "islandGather";
        readonly duration: 0.9;
        readonly contact: 0.45;
    };
    readonly drink: {
        readonly clip: "islandDrink";
        readonly duration: 1.55;
        readonly contact: 1.02;
    };
    readonly cook: {
        readonly clip: "islandCook";
        readonly duration: 1.24;
        readonly contact: 0.76;
    };
    readonly rest: {
        readonly clip: "islandRest";
        readonly duration: 2.55;
        readonly contact: 0.66;
    };
};
type Vector = [number, number, number];
type Hand = {
    pos: Vector;
    pole: Vector;
    dir: Vector;
    palm: Vector;
    space: 'floor';
};
interface Pose {
    bones: Record<string, Vector>;
    root: {
        ground?: boolean;
        y?: number;
        z?: number;
    };
    ik?: {
        Left?: Hand;
        Right?: Hand;
    };
    blend?: {
        sample: Pose;
        w: number;
    };
}
/** Sampled offline by import-explorer. The game plays the resulting native GLB clips. */
export declare function islandClips(idle: {
    sample(time: number): Pose;
}): {
    id: "islandGather" | "islandDrink" | "islandCook" | "islandRest";
    name: "islandGather" | "islandDrink" | "islandCook" | "islandRest";
    category: "Actions";
    duration: 0.9 | 1.55 | 1.24 | 2.55;
    loop: boolean;
    sample(time: number): Pose;
}[];
export {};
//# sourceMappingURL=IslandSurvivalAnimations.d.ts.map