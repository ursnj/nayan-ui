import type { TiltView } from '../shared/EngineTilt';
export declare const TIME_LIMIT = 120;
export declare const KNIVES_PER_ROUND = 8;
export declare const OBSTACLES = 3;
export declare const POINTS_PER_KNIFE = 1500;
export declare const APPLE_BONUS = 1000;
export declare const APPLE_CHANCE = 0.4;
export declare const COLLISION_ANGLE = 0.18;
export declare const APPLE_REACH: number;
export declare const STEP_MS: number;
export declare const STEP_TOLERANCE_MS = 2;
export declare const MAX_PENDING_MS = 50;
export declare const ROTATION_SPEED = 0.025;
export declare const ROTATION_SPREAD = 0.008;
export declare const THROW_SPEED = 18;
export declare const FLIP_CHANCE = 0.4;
export declare const TURN_INTERVAL: readonly [100, 160];
export declare const BOUNCE_TIME = 0.52;
export declare const KICK_POINTS = 4;
/** The camera looks down a touch from in front, so the log's bark and the knives' depth show. */
export declare const TILT = -0.22;
/** Lit from the upper left; faces toward the camera (+z) keep their exact color. */
export declare const LIGHT: import("nayan-ui").Light;
export type Layout = TiltView & {
    /** The play area's top in the view, and its size (the original canvas: the game width x 500, 650 on a tablet). */
    top: number;
    gameWidth: number;
    areaHeight: number;
    logRadius: number;
    /** The log's centre, and where a knife waits to be thrown, in play-area points. */
    logX: number;
    logY: number;
    knifeStartY: number;
    knifeLength: number;
    knifeWidth: number;
    tipLength: number;
    appleRadius: number;
};
/** The play area centred in the view below the header (as the original game laid its canvas out). */
export declare function getLayout(width: number, height: number, offset: number): Layout;
/** An angle in -PI..PI. */
export declare function normalizeAngle(a: number): number;
//# sourceMappingURL=KnifeHitConstants.d.ts.map