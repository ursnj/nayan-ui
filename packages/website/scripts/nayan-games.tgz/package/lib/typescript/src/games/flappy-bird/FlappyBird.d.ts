export declare const FlappyBird: import("react").FC<import("../..").GameProps>;
//# sourceMappingURL=FlappyBird.d.ts.map