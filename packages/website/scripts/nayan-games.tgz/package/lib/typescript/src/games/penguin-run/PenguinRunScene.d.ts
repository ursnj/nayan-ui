import { type Entity, type Light, type Vec3, type World } from 'nayan-ui';
import type { GameTheme } from '../../services/ThemeService';
/** The last tile of the causeway: a few past the finish, ending at the far temple. */
export declare const LAST_TILE: number;
export declare const lightFor: (theme: GameTheme) => Light;
/** Hazy jungle air by day, deep blue by night; also the fog's color. */
export declare const backgroundFor: (theme: GameTheme) => readonly [number, number, number];
export declare const FOG = 0.02;
/** Builds every mesh ahead of time (each is made once per app). */
export declare function prepareRunMeshes(): void;
/** Each cached scenery mesh can be warmed independently without constructing a track. */
export declare function warmAssets(): Iterable<() => unknown>;
export type ObstacleKind = 'gap' | 'beam';
/** `wide`: part of a row spanning all three lanes (drawn once, as one piece, on the middle lane). */
export type PlanObstacle = {
    kind: ObstacleKind;
    lane: number;
    z: number;
    wide?: boolean;
};
export type PlanPickup = {
    lane: number;
    z: number;
    gem: boolean;
};
export type TrackPlan = {
    seed: number;
    obstacles: PlanObstacle[];
    pickups: PlanPickup[];
};
/**
 * Lays out the TRACK_LENGTH metres in rows of obstacles. Some rows span the whole causeway (a crack
 * you must jump, or a gateway you must slide under: gateways always span it); the rest break one or
 * two lanes with gaps, never all three. Rows come closer and harder the further along the track, always
 * leaving room to land and react. A trail of coins hops between lanes, steering clear of obstacles.
 * A new seed gives a new layout every attempt.
 */
export declare function generateTrack(seed: number): TrackPlan;
export type Obstacle = PlanObstacle & {
    e: Entity | null;
};
export type Pickup = {
    gem: boolean;
    lane: number;
    y: number;
    z: number;
    e: Entity;
    taken: boolean;
};
export type Tile = {
    index: number;
    z: number;
    entities: Entity[];
    obstacles: Obstacle[];
    pickups: Pickup[];
};
/**
 * Builds tile `index` (its near end at z = -index * TILE_LENGTH) from the run's plan: the causeway
 * slab by slab (broken out where there is a gap), its scenery, and the plan's obstacles, coins and
 * finish line that fall in it.
 */
export declare function spawnTile(world: World, index: number, theme: GameTheme, plan: TrackPlan): Tile;
export declare function despawnTile(world: World, tile: Tile): void;
export declare function coinSparkle(world: World, position: Vec3, gem: boolean): void;
export declare function crashDust(world: World, position: Vec3): void;
//# sourceMappingURL=PenguinRunScene.d.ts.map