import { type Camera, type DragEvent, World } from 'nayan-ui';
import type { GameTheme } from '../../services/ThemeService';
import type { GamePhase as Phase } from '../shared/useEngineGame';
import { type Layout } from './FruitMergerConstants';
import { type Body, type StepState } from './FruitMergerRules';
import { type Scene } from './FruitMergerScene';
/** drop: a fruit let go; merge: two became one; win: the pumpkin (its own sound, before the result's). */
export type GameEvent = 'drop' | 'merge' | 'win';
/** How a game ended. */
export type Outcome = 'win' | 'overflow' | 'time';
type Aimed = {
    id: string;
    typeId: number;
    x: number;
    y: number;
};
export declare function createGame(theme: GameTheme): {
    world: World;
    camera: Camera;
    theme: GameTheme;
    layout: Layout | null;
    scene: Scene | null;
    phase: Phase;
    bodies: Body[];
    current: Aimed | null;
    nextType: number;
    bestType: number;
    /** Seconds left: the countdown lives in the engine (Rust), advanced by world.update. */
    readonly time: number;
    /** Points from merges (each worth the fruit it makes, so higher fruits score far more): in the engine's scoreboard. */
    readonly score: number;
    outcome: Outcome | null;
    /** The physics' carried state, and the step clock. */
    st: StepState;
    pending: number;
    spawnAt: number;
    /** Where the drag started the aim from. */
    dragFrom: number;
    clock: number;
    onPhase: (_p: Phase) => void;
    onNext: (_type: number) => void;
    onBest: (_type: number) => void;
    onEvent: (_e: GameEvent) => void;
};
export type Game = ReturnType<typeof createGame>;
/** Lays the glass out for the view (first layout, header height, rotation): rebuilt where things stand. */
export declare function setLayout(g: Game, l: Layout): void;
export declare function setTheme(g: Game, theme: GameTheme): void;
/** Starts on the glass already shown (keeping the waiting fruit). */
export declare function start(g: Game): void;
/** Stop and Play Again: a fresh glass, not started. */
export declare function reset(g: Game): void;
/** The final score: the merges' points, plus (for a win) a bonus by its time against two minutes. */
export declare const finalScore: (g: Game) => number;
/** The pile's fixed steps and what it draws; the engine steps the world after. */
export declare function tick(g: Game, dt: number): void;
/** Drags the aimed fruit by how far the finger moves (kept inside the glass); lifting drops it. */
export declare function drag(g: Game, { phase, dx, cancelled }: DragEvent): void;
/** Lets the aimed fruit go: it joins the glass, and the next one is aimed a moment later. */
export declare function drop(g: Game): void;
export {};
//# sourceMappingURL=FruitMergerGame.d.ts.map