/** Native boards retain the established game width. */
export declare const MAX_GAME_WIDTH = 500;
export declare const gameWidthFor: (viewWidth: number) => number;
//# sourceMappingURL=EngineGameWidth.d.ts.map