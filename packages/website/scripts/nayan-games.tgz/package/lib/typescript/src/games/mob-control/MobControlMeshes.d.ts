import { type Model } from 'nayan-ui';
export declare function unitMeshes(): readonly [Model, Model];
//# sourceMappingURL=MobControlMeshes.d.ts.map