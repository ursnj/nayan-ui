import type { Color } from 'nayan-ui';
export { toColor } from '../shared/EngineUtils';
export declare const GRID_SIZE = 9;
export declare const NEXT_PIECES_COUNT = 3;
export declare const POINTS_PER_BLOCK = 50;
export declare const POINTS_PER_LINE = 500;
export declare const GAME_DURATION = 300;
export declare const BLOCK_COLORS: readonly ["#FF3B3B", "#32CD32", "#FFD700", "#4DA6FF", "#BF5AF2", "#FF9500"];
export declare const BLOCK_SHAPES: readonly (readonly (readonly number[])[])[];
export declare const TRAY_SCALE = 0.7;
export declare const DRAG_LIFT = 50;
export declare const LIFT_TIME = 0.14;
export declare const RETURN_TIME = 0.18;
export declare const DEAL_TIME = 0.34;
export declare const DEAL_STAGGER = 0.055;
export declare const FLASH_TIME = 0.26;
export declare const FLASH_AMOUNT = 0.55;
export declare const CLEAR_TIME = 0.5;
export declare const CLEAR_RIPPLE = 0.025;
export declare const PICKUP_SPRING: {
    stiffness: number;
    damping: number;
    mass: number;
};
export declare const CELL_GAP = 2;
export type Layout = {
    /** The GameView's size in points. */
    width: number;
    height: number;
    cell: number;
    /** Cell plus gap: the distance between neighbouring cells. */
    step: number;
    /** Board's outer square: top-left corner and side, in view points. */
    boardLeft: number;
    boardTop: number;
    boardSize: number;
    /** Centre of each tray slot, in view points. */
    slots: [number, number][];
    /** Width of each slot's touch area. */
    slotWidth: number;
    trayTop: number;
    trayHeight: number;
    /** Block thickness toward the camera. */
    depth: number;
};
export declare function getLayout(width: number, height: number, offset: number): Layout;
export declare const LIGHT: import("nayan-ui").Light;
/** Self-lit (flat, unshaded): the engine draws a color whose brightest channel is 2 at full brightness. */
export declare function flat([r, g, b, a]: Color): Color;
/** `color` blended toward white, for the placement glint. */
export declare function tint([r, g, b]: Color, amount: number): Color;
//# sourceMappingURL=BlockBlastConstants.d.ts.map