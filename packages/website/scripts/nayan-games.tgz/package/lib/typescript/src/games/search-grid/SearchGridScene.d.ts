import { type Entity, type World } from 'nayan-ui';
import type { GameTheme } from '../../services/ThemeService';
import type { EngineHud } from '../shared/EngineHud';
import { type Cell, type Layout } from './SearchGridConstants';
/** A pill: its middle and two round ends. */
export type Pill = [Entity, Entity, Entity];
/** The live selection's ends: where they're drawn now and where they're heading (world x, y). */
type Ends = {
    ax: number;
    ay: number;
    bx: number;
    by: number;
    tax: number;
    tay: number;
    tbx: number;
    tby: number;
    on: boolean;
};
export type Scene = {
    backdrop: Entity;
    panel: Entity;
    tiles: Entity[];
    glyphs: Entity[];
    selection: Pill;
    ends: Ends;
    found: Pill[];
};
export declare function buildScene(world: World, l: Layout, theme: GameTheme, grid: string[][]): Scene;
/** A new grid's characters on the same tiles. */
export declare function relabel(world: World, l: Layout, s: Scene, grid: string[][]): void;
export declare function removeScene(world: World, s: Scene): void;
export declare function setSceneTheme(world: World, l: Layout, s: Scene, theme: GameTheme): void;
/** The live selection, from its first cell to where the finger is now: `fresh` snaps it there, else it glides (followSelection). */
export declare function showSelection(world: World, l: Layout, s: Scene, from: Cell, to: Cell, fresh: boolean): void;
/** Eases the live selection's ends toward their targets each frame (frame-rate independent), redrawing it only while it moves. */
export declare function followSelection(world: World, l: Layout, s: Scene, dt: number): void;
export declare function hideSelection(world: World, s: Scene): void;
/** A found entry: circled in its color, its tiles bouncing one after another, a few sparkles. */
export declare function markFound(world: World, l: Layout, s: Scene, cells: Cell[], colorIndex: number, animate: boolean): void;
/** Confetti over the board when everything's found. */
export declare function celebrate(world: World, l: Layout): void;
export declare function drawEntryList(hud: EngineHud, entries: readonly string[], found: ReadonlySet<string>, layout: Layout): void;
export {};
//# sourceMappingURL=SearchGridScene.d.ts.map