export declare enum HapticType {
    LIGHT = "light",
    MEDIUM = "medium",
    HEAVY = "heavy",
    SUCCESS = "success",
    WARNING = "warning",
    ERROR = "error",
    SELECTION = "selection"
}
/**
 * Play haptic feedback through the engine's native haptics
 * @param type - Type of haptic feedback to play
 * @param hapticEnabled - Whether haptic feedback is enabled in settings
 */
export declare const playHaptic: (type: HapticType, hapticEnabled?: boolean) => void;
//# sourceMappingURL=HapticsService.d.ts.map