export declare const StackTower: import("react").FC<import("../..").GameProps>;
//# sourceMappingURL=StackTower.d.ts.map