export declare const MobControl: import("react").FC<import("../..").GameProps>;
//# sourceMappingURL=MobControl.d.ts.map