/** Fit a short control subtitle into its measured inner width without splitting Unicode code points. */
export declare function fitControlSubtitle(text: string, maxWidth: number, measure: (value: string) => number): string;
//# sourceMappingURL=EngineControlText.d.ts.map