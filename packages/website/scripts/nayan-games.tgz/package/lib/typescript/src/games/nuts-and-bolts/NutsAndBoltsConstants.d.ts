import type { TiltView } from '../shared/EngineTilt';
export declare const BOARD_COLS = 5;
export declare const BOARD_ROWS = 5;
export declare const EXTRA_HOLES = 3;
export declare const TIME_LIMIT = 120;
export declare const LIFT_TIME = 0.26;
export declare const MOVE_TIME = 0.6;
export declare const FALL_TIME = 0.6;
/** The camera leans back from straight down, so the planks' stack and the bolt heads stand up. */
export declare const TILT = 0.38;
/** Lit from the upper left; surfaces facing up off the board (+z) keep their exact color. */
export declare const LIGHT: import("nayan-ui").Light;
export declare const CLASSIC_BOARD = "rgba(255, 255, 255, 0.30)";
export declare const CLASSIC_SEPARATOR = "rgba(255, 255, 255, 0.1)";
export type Layout = TiltView & {
    cell: number;
    padding: number;
    boardWidth: number;
    boardHeight: number;
};
/** The board as the original version sized it (5 x 5 points and the swap row below), smaller if the screen is short. */
export declare function getLayout(width: number, height: number, offset: number): Layout;
/** A grid point (row 0 along the top) on the board, in world units: the 5 x 5 points centred across, in the board's top part. */
export declare function pointAt(l: Layout, row: number, col: number): [number, number];
/** Swap hole `i`'s centre, along the bottom, 1.2 cells apart. */
export declare function swapAt(l: Layout, i: number): [number, number];
/** The line between the grid and the swap row. */
export declare const separatorY: (l: Layout) => number;
//# sourceMappingURL=NutsAndBoltsConstants.d.ts.map