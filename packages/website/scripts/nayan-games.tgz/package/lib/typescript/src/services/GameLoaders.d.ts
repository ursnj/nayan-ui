import type React from 'react';
import { GAME_IDS, type GameProps } from './UtilsService';
/**
 * Get the React component for a game id, loading its module on first use.
 */
export declare const loadGameComponent: (gameId: GAME_IDS | null | undefined) => React.ComponentType<GameProps> | null;
/**
 * Call once the app has started (after the splash screen, when idle): the GPU device and its
 * pipelines are made on a native background thread, so the first game a player opens doesn't wait
 * for them. Game assets still load on the game's own screen.
 */
export declare const warmUpGames: () => (() => void);
/** Builds the scoreboard fonts every game uses, on native threads, ahead of the first game (call with `warmUpGames`). */
export declare const warmUpGameFonts: () => void;
/** @deprecated Games no longer preload from the catalog. */
export declare const prioritizeGameAssets: (_ids: readonly string[]) => void;
/** @deprecated Game-screen loaders own their cancellation. */
export declare const pauseGameAssetWarmup: () => void;
export declare const getGameAssetWarmupStatus: () => {
    running: boolean;
    completed: number;
    failed: number;
    complete: boolean;
};
//# sourceMappingURL=GameLoaders.d.ts.map