import { type Camera, type Entity, type Voice, World } from 'nayan-ui';
import type { HudFeedback } from '../shared/EngineHud';
import type { GamePhase as Phase } from '../shared/useEngineGame';
import { type Assets } from './CarRacingConstants';
import { type Fire, Track } from './CarRacingScene';
export type { Phase };
export declare function createGame(a: Assets, night: boolean): {
    world: World;
    night: boolean;
    track: Track;
    chase: {
        eye: [number, number, number];
        target: [number, number, number];
        initialized: boolean;
    };
    assets: Assets;
    camera: Camera;
    player: {
        root: Entity;
        body: Entity;
        glass: Entity;
        trim: Entity;
        lights: Entity[];
    };
    horizon: Entity;
    segments: import("./CarRacingScene").Segment[];
    traffic: Car[];
    /** Wrecks on fire. */
    burning: Fire[];
    phase: Phase;
    time: number;
    s: number;
    d: number;
    target: number;
    dragX: number;
    speed: number;
    lateral: number;
    steeringPose: {
        yaw: number;
        roll: number;
    };
    steeringGoal: number;
    spawnTimer: number;
    invulnerable: number;
    scrape: number;
    orbit: number;
    /** Score, lives and the countdown live in the engine (Rust), advanced by world.update. */
    readonly score: number;
    readonly lives: number;
    /** Metres left to the finish gate. */
    left: number;
    shake: number;
    engine: Voice | null;
    audible: boolean;
    onPhase: (_p: Phase) => void;
    onScore: (_s: number) => void;
    onLives: (_l: number) => void;
    onDistance: (_metres: number) => void;
    hudFeedback: HudFeedback;
};
export type Game = ReturnType<typeof createGame>;
export declare function start(g: Game): void;
/** Mirrors the shared screen's audible state without letting an engine loop leak to another screen. */
export declare function setAudible(g: Game, enabled: boolean): void;
/** Change only lighting and celestial details; preserve the current race and scenery layout. */
export declare function setNight(g: Game, night: boolean): void;
/** Steers toward the finger: `dx` is the drag's distance so far, `metresPerPoint` how far that moves the car. */
export declare function steer(g: Game, phase: 'start' | 'move' | 'end', dx: number, metresPerPoint: number): void;
/** Stops the run's sounds and frees its world (the screen unmounting). */
export declare function dispose(g: Game): void;
export declare function tick(g: Game, dt: number): void;
export type Car = {
    root: Entity;
    lights: Entity[];
    s: number;
    d: number;
    /** The lane it spawned in (a sideswipe can shove it out of it). */
    lane: number;
    /** Sideways speed from a sideswipe, fading back to 0. */
    vd: number;
    passed: boolean;
    crashed: boolean;
    /** It was sideswiped (no near-miss bonus for it). */
    bumped: boolean;
    /** Seconds until another sideswipe makes a sound again. */
    bumpCooldown: number;
    /** Closest it came beside the player, for near misses. */
    closest: number;
    /** How far ahead of the player it was last frame, and whether it's touching (and met nose to tail). */
    wasAhead: number;
    touching: boolean;
    headOn: boolean;
};
/** Traffic ahead, in a lane that doesn't close the road: cars close together always leave a lane open. */
export declare function spawnTraffic(g: Game, ahead?: number): void;
/** Demo bot: head for the lane whose next car is furthest away. */
export declare function autopilot(g: Game): void;
//# sourceMappingURL=CarRacingGame.d.ts.map