export declare const GRID_SIZE = 7;
export declare const MIN_CONNECT = 3;
export declare const TIME_LIMIT = 300;
export declare const LOOP_BONUS = 250;
export declare const DOT_COLORS: readonly ["#FF3B3B", "#32CD32", "#FFD700", "#4DA6FF", "#BF5AF2"];
/** 50 a dot, plus 75 for every dot past the third. */
export declare const scoreFor: (dots: number) => number;
export declare const FALL_TIME = 0.35;
export declare const INTRO_COL_STAGGER = 0.035;
export declare const INTRO_ROW_STAGGER = 0.03;
export declare const INTRO_SPRING: {
    damping: number;
    stiffness: number;
    mass: number;
};
export declare const POP_SCALE = 1.24;
export declare const CONNECTED_SCALE = 1.08;
export declare const POP_TIME = 0.2;
export declare const RELEASE_TIME = 0.14;
export declare const CLEAR_TIME = 0.45;
export declare const TRAIL_ALPHA = 0.75;
/** The halo round a connected dot: its size as a share of the dot, and its opacity at the dot's edge (it fades smoothly to nothing). */
export declare const GLOW_SIZE = 1.6;
export declare const GLOW_ALPHA = 0.38;
export declare const GLOW_IN_TIME = 0.2;
export declare const GLOW_OUT_TIME = 0.12;
/** The board panel's corner radius (points), as Block Blast's. */
export declare const BOARD_RADIUS = 8;
export declare const LIGHT: import("nayan-ui").Light;
export declare const DOT_SHINE = 0.4;
export type Layout = {
    /** The GameView's size. */
    width: number;
    height: number;
    boardLeft: number;
    boardTop: number;
    boardSize: number;
    /** From the board's edge to the outer dots' centres. */
    padding: number;
    spacing: number;
    radius: number;
    hitRadius: number;
};
/** Board as wide as the game area (360 phones / 500 tablets), centred in the space below the header. */
export declare function getLayout(width: number, height: number, offset: number): Layout;
//# sourceMappingURL=ConnectEmAllConstants.d.ts.map