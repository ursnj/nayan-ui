export declare const BubbleShooter: import("react").FC<import("../..").GameProps>;
//# sourceMappingURL=BubbleShooter.d.ts.map