import { type Camera, type Color, type Entity, World } from 'nayan-ui';
import type { GameTheme } from '../../services/ThemeService';
import type { GamePhase as Phase } from '../shared/useEngineGame';
import { type Layout } from './BlockBlastConstants';
import { type Board, type BoardColors } from './BlockBlastScene';
type Shape = readonly (readonly number[])[];
type Piece = {
    shape: Shape;
    css: string;
    color: Color;
    root: Entity | null;
};
type Drag = {
    slot: number;
    /** Finger offset from the piece's centre at pickup, so the piece doesn't jump to the finger. */
    offsetX: number;
    offsetY: number;
    x: number;
    y: number;
    liftedAt: number;
    /** Drop target: top-left cell, or null when not over the board. */
    row: number | null;
    col: number | null;
    valid: boolean;
    returning: boolean;
    drawnX?: number;
    drawnY?: number;
};
export declare function createGame(theme: GameTheme): {
    world: World;
    camera: Camera;
    colors: BoardColors;
    /** For the screen background (theme color and pattern, see EngineBackdrop). */
    theme: GameTheme;
    layout: Layout | null;
    board: Board | null;
    phase: Phase;
    time: number;
    /** Score and the countdown live in the engine (Rust), advanced by world.update. */
    readonly score: number;
    readonly timeLeft: number;
    won: boolean;
    /** Each cell's color (css, for the line-clear sound check), or null. */
    grid: (string | null)[];
    gridColors: (Color | null)[];
    blocks: (Entity | null)[];
    pieces: Piece[];
    drag: Drag | null;
    /** What each preview overlay shows, so a hover only touches the cells that changed. */
    ghostShown: (Color | null)[];
    previewColors: Map<string, Color>;
    highlightShown: boolean[];
    onPhase: (_p: Phase) => void;
    onPick: () => void;
    onInvalid: () => void;
    onPlace: () => void;
    onClear: (_lines: number) => void;
    onGameOver: () => void;
};
export type Game = ReturnType<typeof createGame>;
/** Lays the scene out for the view (first layout, rotation, header height): rebuilt from the run's state. */
export declare function setLayout(g: Game, l: Layout): void;
/** Repaints the board and background for a new theme without touching the run. */
export declare function setTheme(g: Game, theme: GameTheme): void;
export declare function start(g: Game): void;
/** A fresh board and tray (Stop, Play Again). The world, and the GPU view drawing it, are kept. */
export declare function reset(g: Game): void;
/** The held piece follows the finger; the engine steps the world after. */
export declare function tick(g: Game, dt: number): void;
/** Finger down: picks up the tray piece under it (anywhere in its slot). */
export declare function dragStart(g: Game, x: number, y: number): void;
export declare function dragMove(g: Game, x: number, y: number): void;
/** Finger up: drops the piece if it fits, otherwise it flies back to its slot. */
export declare function dragEnd(g: Game): void;
export {};
//# sourceMappingURL=BlockBlastGame.d.ts.map