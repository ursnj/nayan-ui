import { type Entity, type Vec3, type World } from 'nayan-ui';
import type { GameTheme } from '../../services/ThemeService';
import { type Direction, type Layout } from './Tank1990Constants';
import type { Bullet, Tank, Tile } from './Tank1990Rules';
export declare const heading: (d: Direction) => import("nayan-ui").MutableQuat;
/** Board points to the world, at height z. */
export declare const toWorld: (l: Layout, x: number, y: number, z?: number) => Vec3;
export type TankView = {
    body: Entity;
    shield: Entity;
    direction: Direction;
    shielded: boolean;
    x: number;
    y: number;
};
export type Scene = {
    backdrop: Entity;
    field: Entity;
    frame: Entity;
    grid: Entity;
    /** Each tile's wall, row by row (null where it's open ground). */
    walls: (Entity | null)[][];
    tanks: Map<number, TankView>;
    bullets: Map<number, Entity>;
};
export declare function buildScene(world: World, l: Layout, theme: GameTheme, tiles: Tile[][]): Scene;
export declare function removeScene(world: World, s: Scene): void;
export declare function setSceneTheme(world: World, l: Layout, s: Scene, theme: GameTheme): void;
/** A tile's wall after a hit: a layer down, or gone in a shower of rubble. */
export declare function updateWall(world: World, l: Layout, s: Scene, x: number, y: number, t: Tile, was: Tile['type']): void;
/** Builds a fresh map's walls (a new board). */
export declare function rebuildWalls(world: World, l: Layout, s: Scene, tiles: Tile[][]): void;
/** Puts every live tank and shell where the battle has them (spawning newcomers, clearing the gone). */
export declare function syncUnits(world: World, l: Layout, s: Scene, tanks: Tank[], bullets: Bullet[], now: number): void;
/** A muzzle flash at the end of a tank's barrel. */
export declare function muzzleFlash(world: World, l: Layout, t: Tank): void;
/** An explosion at a board point: a fireball and smoke, bigger for a tank. */
export declare function explode(world: World, l: Layout, x: number, y: number, big: boolean): void;
//# sourceMappingURL=Tank1990Scene.d.ts.map