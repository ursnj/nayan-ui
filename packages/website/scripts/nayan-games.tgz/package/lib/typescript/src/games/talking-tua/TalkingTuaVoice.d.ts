export type VoicePhase = 'off' | 'waiting' | 'hearing' | 'talking';
export type VoiceState = {
    phase: VoicePhase;
    /** Seconds since the speech began (while hearing). */
    heard: number;
    /** Seconds of quiet since the last loud moment (while hearing). */
    quiet: number;
    /** The room's own noise, followed slowly while waiting. */
    noise: number;
    /** Seconds left of Tua's voice, then of the cooldown after it (while talking). */
    talking: number;
};
/** What the game should do after a step. */
export type VoiceAction = 
/** Make a recording of `seconds` ending `skipEnd` seconds ago and play it as Tua. */
{
    kind: 'take';
    seconds: number;
    skipEnd: number;
}
/** Throw away what was heard (a short noise, or Tua's own voice). */
 | {
    kind: 'discard';
} | null;
export declare const newVoice: () => VoiceState;
/** The level that counts as speech in this room. */
export declare const speechLevel: (v: VoiceState) => number;
/** Starts listening (Talk on). */
export declare function listen(v: VoiceState): void;
/** Stops listening (Talk off, pause, leaving). */
export declare function deafen(v: VoiceState): void;
/**
 * Tua makes a sound `seconds` long (repeating you, or one of its own effects): it doesn't listen
 * until that has finished and the cooldown after it has passed. A sound that ends sooner than one
 * already playing never reopens the ears early.
 */
export declare function startTalking(v: VoiceState, seconds: number): void;
/** Advances by `dt` seconds with the microphone's current `level` (0..1). */
export declare function stepVoice(v: VoiceState, level: number, dt: number): VoiceAction;
/** The recording's RMS at playback time, interpolated so lips don't jump between level buckets. */
export declare function speechLoudness(levels: Float32Array, sample: number): number;
/** Quick syllable attacks, softer releases, and the resting mouth pose during recorded silence. */
export declare function mouthEnvelope(previous: number, rms: number, dt: number): number;
//# sourceMappingURL=TalkingTuaVoice.d.ts.map