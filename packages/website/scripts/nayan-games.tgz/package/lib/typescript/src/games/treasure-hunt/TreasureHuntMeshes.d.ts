import { type Geometry, type Vec3 } from 'nayan-ui';
import { type Landscape } from './TreasureHuntRules';
export type HumanSoles = readonly [Vec3, Vec3];
/** Keep the support foot planted; retain airborne height only for running. */
export declare function humanSupportHeight(feet: HumanSoles, ground: readonly [number, number], airborne?: boolean): number;
/** A shared horizontal disc; layered at low alpha for a soft contact shadow. */
export declare function contactShadowGeometry(): Geometry;
/** A brilliant cut: table, star/bezel crown, thin girdle and pointed pavilion.
 * Each facet owns flat normals and a cool reflected-light tint, so cuts stay crisp while spinning. */
export declare function diamondGeometry(): Geometry;
/** The river's water ribbon: it follows the channel, rippling and lighter towards the banks. */
export declare function riverGeometry(land: Landscape): Geometry;
/** Hollow stone tunnel: exterior and interior faces, open portals and planar-mapped end faces. */
export declare function caveGeometry(): Geometry;
/** Irregular stratified boulders (the same recipe gives their collision hulls). */
export declare function boulderGeometry(style: number): Geometry;
/** A pine: the games' conifer (shared/EngineTrees), one trunk for every style and a crown per style. */
export declare const pineGeometry: (style: number) => {
    bark: Geometry;
    crown: Geometry;
};
/** How far a birch's flared foot spreads at scale 1 (it stands on the lowest ground under it). */
export declare const BIRCH_FOOT_REACH: number;
/**
 * A birch: the games' broadleaf tree (shared/EngineTrees), pale, its flared foot buried for sloping
 * ground and its crown held above the explorer and the camera. `bark` and `crown` come from the same
 * seeded tree.
 */
export declare const birchGeometry: (style: number) => {
    bark: Geometry;
    crown: Geometry;
};
/** Tiny bent blades, distributed in shared clumps; actual grass rather than an entirely flat field. */
export declare function grassGeometry(style: number): Geometry;
//# sourceMappingURL=TreasureHuntMeshes.d.ts.map