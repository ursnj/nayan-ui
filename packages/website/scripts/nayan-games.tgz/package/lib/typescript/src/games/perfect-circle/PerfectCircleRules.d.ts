export type Point = {
    x: number;
    y: number;
};
export type Circle = {
    centerX: number;
    centerY: number;
    radius: number;
};
export declare const MIN_POINTS = 20;
export declare const WIN_ACCURACY = 80;
export declare const SUCCESS_ACCURACY = 70;
/** The circle that best fits the points (least squares), or the centroid's average radius if they're degenerate. */
export declare function fitCircle(points: Point[]): Circle;
/**
 * The stroke's score: its best single circle. The whole stroke counts as one circle by the original
 * rules (ends meeting, 85% of the way round), and so does every stretch of it that goes exactly once
 * round the guide's centre or the stroke's own, so a stroke that runs on past its start, or loops more
 * than once, scores its best full circle instead of nothing. `fit` is that circle (the whole stroke's
 * fit when none counts).
 */
export declare function scoreStroke(points: Point[], guide: Circle): {
    accuracy: number;
    fit: Circle;
};
/** The stroke's accuracy (0..100) against the guide circle (centre and radius in view points). */
export declare const accuracyOf: (points: Point[], guide: Circle) => number;
/** The accuracy levels the game-over card names, best first. */
export declare const ACCURACY_LEVELS: readonly [{
    readonly min: 95;
    readonly label: "PERFECT!";
}, {
    readonly min: 90;
    readonly label: "EXCELLENT!";
}, {
    readonly min: 85;
    readonly label: "GREAT!";
}, {
    readonly min: 80;
    readonly label: "GOOD!";
}, {
    readonly min: 70;
    readonly label: "NICE TRY!";
}, {
    readonly min: 0;
    readonly label: "KEEP TRYING!";
}];
export declare const levelOf: (accuracy: number) => {
    readonly min: 95;
    readonly label: "PERFECT!";
} | {
    readonly min: 90;
    readonly label: "EXCELLENT!";
} | {
    readonly min: 85;
    readonly label: "GREAT!";
} | {
    readonly min: 80;
    readonly label: "GOOD!";
} | {
    readonly min: 70;
    readonly label: "NICE TRY!";
} | {
    readonly min: 0;
    readonly label: "KEEP TRYING!";
};
//# sourceMappingURL=PerfectCircleRules.d.ts.map