import { type ReactNode } from 'react';
interface GameLoadingTransitionProps {
    ready: boolean;
    loader: ReactNode;
    children: ReactNode;
}
/** A game reports its first presented frame through any nested loading boundaries. */
export declare const GameOpeningFrameContext: import("react").Context<(() => void) | null>;
/** Reveal the world as soon as its first frame is presented. */
export declare const GameLoadingTransition: import("react").MemoExoticComponent<({ ready, loader, children }: GameLoadingTransitionProps) => import("react").JSX.Element>;
export {};
//# sourceMappingURL=GameLoadingTransition.d.ts.map