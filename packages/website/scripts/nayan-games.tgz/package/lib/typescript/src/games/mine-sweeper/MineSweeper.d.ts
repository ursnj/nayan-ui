export declare const MineSweeper: import("react").FC<import("../..").GameProps>;
//# sourceMappingURL=MineSweeper.d.ts.map