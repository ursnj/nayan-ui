export declare const Bluk: import("react").FC<import("../..").GameProps>;
//# sourceMappingURL=Bluk.d.ts.map