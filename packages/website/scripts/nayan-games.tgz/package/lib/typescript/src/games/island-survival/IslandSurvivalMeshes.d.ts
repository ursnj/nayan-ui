import { type Vec3 } from 'nayan-ui';
import { type Structure } from './IslandSurvivalConstants';
import { type ResourceKind } from './IslandSurvivalIsland';
export declare const grassMesh: () => import("nayan-ui").Model;
export declare const forestTree: (variant: number) => {
    bark: import("nayan-ui").Model;
    crown: import("nayan-ui").Model;
};
export declare const palmTree: (variant: number) => {
    bark: import("nayan-ui").Model;
    crown: import("nayan-ui").Model;
};
export declare const supplyMesh: (kind: Exclude<ResourceKind, "berries">) => import("nayan-ui").Model;
export declare const fruitBush: (variant: number) => {
    plant: import("nayan-ui").Model;
    fruit: import("nayan-ui").Model;
};
export declare const shoreRock: (style?: number) => import("nayan-ui").Model;
export declare const oceanMesh: () => import("nayan-ui").Model;
export declare const structureMesh: (kind: Structure) => import("nayan-ui").Model;
export declare const FARM_LETTUCE: (readonly [number, 0.14, number])[];
export declare const FARM_TOMATOES: (readonly [number, 0.14, -0.51])[];
export declare const TOMATO_CLUSTER: Vec3;
export declare const lettuce: () => import("nayan-ui").Model;
export declare const tomatoVine: () => import("nayan-ui").Model;
export declare const tomatoes: () => import("nayan-ui").Model;
export declare function warmMeshes(): Iterable<() => unknown>;
//# sourceMappingURL=IslandSurvivalMeshes.d.ts.map