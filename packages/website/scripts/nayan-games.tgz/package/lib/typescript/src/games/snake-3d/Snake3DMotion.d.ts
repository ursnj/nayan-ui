import type { Snake } from './Snake3DRules';
/** A bead's position and travel tangent, in grid units. The body follows the head's curved path. */
export declare function sampleSnakeMotion(prev: Snake, cur: Snake, index: number, fraction: number): [number, number, number, number];
//# sourceMappingURL=Snake3DMotion.d.ts.map