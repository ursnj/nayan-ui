export declare const SlidingNumbers: import("react").FC<import("../..").GameProps>;
//# sourceMappingURL=SlidingNumbers.d.ts.map