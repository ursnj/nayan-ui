export type Player = 'X' | 'O';
export type Cell = Player | null;
export type Board = Cell[];
export declare const LINES: readonly [readonly [0, 1, 2], readonly [3, 4, 5], readonly [6, 7, 8], readonly [0, 3, 6], readonly [1, 4, 7], readonly [2, 5, 8], readonly [0, 4, 8], readonly [2, 4, 6]];
export declare const emptyBoard: () => Board;
/** The line three in a row, if there is one. */
export declare function winningLine(b: Board): readonly [number, number, number] | null;
export declare const winnerOf: (b: Board) => Player | null;
/** A forgiving opponent that takes wins, sometimes misses blocks, and occasionally looks ahead. */
export declare function robotMove(b: Board): number;
//# sourceMappingURL=TicTacToeRules.d.ts.map