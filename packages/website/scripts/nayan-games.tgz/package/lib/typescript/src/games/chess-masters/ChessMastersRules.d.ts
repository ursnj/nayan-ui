export declare const PAWN = 1, KNIGHT = 2, BISHOP = 3, ROOK = 4, QUEEN = 5, KING = 6;
export declare const WHITE = 1, BLACK = -1;
export declare const PROMOTIONS: readonly [5, 4, 3, 2];
export type Piece = 1 | 2 | 3 | 4 | 5 | 6;
export type Side = typeof WHITE | typeof BLACK;
export type Promotion = (typeof PROMOTIONS)[number];
export type Move = {
    from: number;
    to: number;
    captured?: number;
    rookFrom?: number;
    rookTo?: number;
    promotion?: Promotion;
};
export type Position = {
    board: Int8Array;
    turn: Side;
    castling: number;
    enPassant: number;
    halfMoves: number;
};
export declare const opposite: (side: Side) => Side;
export declare function initialPosition(): Position;
export declare function checkSquare(position: Position): number | undefined;
/** Every candidate is played on a scratch board to catch pins, discovered checks and en passant exposures. */
export declare function legalMoves(position: Position, square?: number): Move[];
export declare function play(position: Position, move: Move): Position;
/** En passant changes a repeated position only when the side to move can legally take it. */
export declare function positionKey(position: Position, moves: Move[]): string;
export declare function insufficientMaterial(board: Int8Array): boolean;
export type Result = 'win' | 'lose' | 'draw';
export type Ending = {
    result: Result;
    reason: string;
};
export declare function ending(position: Position, moves: Move[], check: number | undefined, repetitions: number): Ending | undefined;
//# sourceMappingURL=ChessMastersRules.d.ts.map