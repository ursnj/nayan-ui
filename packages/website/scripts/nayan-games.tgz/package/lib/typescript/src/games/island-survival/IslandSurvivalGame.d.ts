import { type DragEvent, type Vec3, World } from 'nayan-ui';
import type { HudFeedback } from '../shared/EngineHud';
import type { GamePhase } from '../shared/useEngineGame';
import { type IslandAssets, type Structure } from './IslandSurvivalConstants';
import type { IslandMap } from './IslandSurvivalIsland';
import { type Event, type IslandState } from './IslandSurvivalRules';
type GameEvent = 'gather' | 'harvest' | 'build' | 'attack' | 'hit' | 'defeat' | 'drink' | 'cook' | 'rest' | 'hurt' | 'win' | 'lose';
export declare function snapshot(state: IslandState): {
    health: number;
    food: number;
    water: number;
    wood: number;
    stone: number;
    defeated: number;
    lightingTime: number;
    shelter: boolean;
    fire: boolean;
    fence: boolean;
    farm: boolean;
    cropsReady: boolean;
};
export type Snapshot = ReturnType<typeof snapshot>;
export declare function createGame(assets: IslandAssets, map: IslandMap): {
    readonly phase: GamePhase;
    readonly won: boolean;
    readonly score: number;
    world: World;
    assets: IslandAssets;
    state: {
        map: IslandMap;
        phase: GamePhase;
        won: boolean;
        score: number;
        time: number;
        elapsed: number;
        spawn: import("nayan-ui").Spot;
        player: {
            x: number;
            z: number;
        };
        yaw: number;
        speed: number;
        pace: number;
        grade: number;
        health: number;
        food: number;
        water: number;
        wood: number;
        stone: number;
        shellfish: number;
        vegetables: number;
        cropsReadyAt: number;
        cooked: number;
        defeated: number;
        explored: boolean;
        camp: Map<"shelter" | "fire" | "fence" | "farm" | "beacon", import("nayan-ui").Spot>;
        colliders: import("./IslandSurvivalIsland").IslandBody[];
        movementBodies: import("./IslandSurvivalIsland").IslandBody[];
        gathered: Map<number, number>;
        monsters: import("./IslandSurvivalRules").Monster[];
        actionTime: number;
        approach: {
            action: ({
                kind: "gather";
                resource: import("./IslandSurvivalIsland").Resource;
            } | {
                kind: "harvest" | "drink" | "cook" | "rest";
            }) & {
                point: import("nayan-ui").Spot;
                reach: number;
            };
            time: number;
        } | null;
        action: (({
            kind: "gather";
            resource: import("./IslandSurvivalIsland").Resource;
        } | {
            kind: "harvest" | "drink" | "cook" | "rest";
        }) & {
            point: import("nayan-ui").Spot;
            reach: number;
        }) | null;
        sleepTime: number;
        attackTime: number;
        punchBuffer: {
            targetId?: number;
            remaining: number;
        } | null;
        target: import("./IslandSurvivalRules").Monster | null;
        invulnerable: number;
        recovery: number;
        events: Event[];
    };
    scene: {
        water: import("nayan-ui").Entity;
        springWater: import("nayan-ui").Entity;
        resources: {
            mesh: import("nayan-ui").Entity;
            pick: import("nayan-ui").Entity;
            location: Vec3;
            rotation: import("nayan-ui").MutableQuat;
        }[];
        targets: Map<import("nayan-ui").Entity, import("./IslandSurvivalRules").Interaction>;
        structures: Map<"shelter" | "fire" | "fence" | "farm" | "beacon", {
            root: import("nayan-ui").Entity;
            pick?: import("nayan-ui").Entity;
            crops?: {
                plants: {
                    leaves: import("nayan-ui").Entity;
                    fruit?: import("nayan-ui").Entity;
                    size: number;
                }[];
                progress: number;
            };
        }>;
        fireSources: Vec3[];
    };
    human: import("../treasure-hunt/TreasureHuntModel").Human<"hit" | "idle" | "walk" | "run" | "punchStart" | "punchRight" | "punchLeft" | "combatIdle" | "combatExit" | "fall" | "celebrate" | "islandGather" | "islandDrink" | "islandCook" | "islandRest" | "islandWalkUp" | "islandWalkDown">;
    camera: import("nayan-ui").Camera;
    anchor: import("nayan-ui").Entity;
    monsters: ({
        pick: import("nayan-ui").Entity;
        root: import("nayan-ui").Entity;
        body: import("nayan-ui").Entity;
        animation: "hit" | "idle" | "walk" | "attack" | "run" | "fall" | null;
        rate: number;
        strikes: number;
        phase: number;
        indices: Uint32Array;
        supportIndices: Uint32Array;
        samples: Float32Array;
        leftCount: number;
        soles: [[number, number, number], [number, number, number]];
        shadows: [import("nayan-ui").Entity[], import("nayan-ui").Entity[]];
        settled: boolean;
        stagger: number;
        fallTime: number;
    } | undefined)[];
    swipe: import("../treasure-hunt/TreasureHuntControls").SwipeInput;
    reference: {
        active: boolean;
        yaw: number;
    };
    footsteps: {
        stop: () => void;
        update(motion: import("../treasure-hunt/TreasureHuntControls").FootstepMotion, dt: number): void;
    };
    active: boolean;
    poseTime: number;
    hudTime: number;
    sceneryTime: number;
    smokeTime: number;
    cameraX: number;
    cameraZ: number;
    cameraYaw: number;
    cameraGround: number;
    hudFeedback: HudFeedback;
    onEvent: (_event: GameEvent) => void;
    onPhase: (_phase: GamePhase) => void;
    onChange: (_snapshot: Snapshot) => void;
};
export type Game = ReturnType<typeof createGame>;
export declare function clearInput(game: Game): void;
export declare function setActive(game: Game, active: boolean): void;
export declare function start(game: Game): void;
export declare function reset(game: Game): void;
export declare function dispose(game: Game): void;
export declare function dragExplorer(game: Game, event: DragEvent, canStart: boolean): void;
export declare function tapScene(game: Game, x: number, y: number, structure?: Structure): boolean;
export declare function tick(game: Game, elapsed: number): void;
export {};
//# sourceMappingURL=IslandSurvivalGame.d.ts.map