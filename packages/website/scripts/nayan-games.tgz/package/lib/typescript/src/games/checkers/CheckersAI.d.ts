import type { CheckersBoard, FullMove } from './CheckersRules';
/**
 * Pick the AI's move among `moves` (the legal list for black on `src`).
 * Returns every root move whose depth-`depth` minimax score equals the best.
 *
 * Each root child used to be searched with a full (-Inf, Inf) window. Here the
 * window is (bestSoFar - 1, Inf): scores are integers, so fail-soft alpha-beta
 * still returns the exact score for any move >= bestSoFar and a value
 * <= bestSoFar - 1 for any worse move — the same best set, far fewer nodes.
 */
export declare const bestAIMoves: (src: CheckersBoard, moves: FullMove[], depth: number) => FullMove[];
//# sourceMappingURL=CheckersAI.d.ts.map