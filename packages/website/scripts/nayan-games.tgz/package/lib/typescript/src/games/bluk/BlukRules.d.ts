import { type Config } from './BlukConstants';
export type Pillar = {
    id: string;
    worldX: number;
    topY: number;
    width: number;
    colorIndex: number;
};
export type Velocity = {
    vx: number;
    vy: number;
};
/** The launch for a drag (it always goes forward and up), or null for a drag too small to count. */
export declare function launchVelocity(c: Config, dx: number, dy: number): Velocity | null;
/** The pillar a descending block (centre x, from prevY to y) lands on, if any: it must cross the top with enough overlap. */
export declare function landingOn(c: Config, targets: Pillar[], x: number, prevY: number, y: number): number;
/** The block's flight: centre and velocity. */
export type Flight = {
    x: number;
    y: number;
    vx: number;
    vy: number;
};
/** One 60 Hz step: falls, moves; says which target it landed on (the block snapped onto it), or that it fell, or neither. */
export declare function stepFlight(c: Config, f: Flight, targets: Pillar[]): {
    landed: number;
    fell: boolean;
};
/** The tilt in flight: leaning forward going up, back coming down. */
export declare const tiltFor: (vy: number) => number;
/** The preview arc's points [x0, y0, x1, y1, ...] (world x, view y), ending where it would land. */
export declare function trajectory(c: Config, v: Velocity, startX: number, startY: number, targets: Pillar[]): number[];
/** The run of pillars: where you stand, how many you've landed on (it gets harder), and the ids handed out. */
export type Course = {
    pillars: Pillar[];
    current: number;
    landed: number;
    seq: number;
};
/** A fresh run: the first pillar (at its widest) under the view's anchor, and four ahead. */
export declare function newCourse(c: Config): Course;
/** The pillars a jump can land on: everything ahead of the current one. */
export declare const targetsAhead: (k: Course) => Pillar[];
/** Landed on a pillar: it's the current one now; more are made ahead and old ones behind dropped (one kept). */
export declare function landOn(c: Config, k: Course, index: number): void;
/** A landing's points: perfect (within the sweet spot) adds the bonus and grows the combo. */
export declare function landingPoints(c: Config, p: Pillar, x: number, combo: number): {
    perfect: boolean;
    points: number;
    combo: number;
};
//# sourceMappingURL=BlukRules.d.ts.map