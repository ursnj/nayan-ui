import { type Entity, type Texture, type Vec3, type World } from 'nayan-ui';
import type { GameTheme } from '../../services/ThemeService';
import { type Layout } from './CandyCrushConstants';
/** A view point (from the top-left) at depth `z`, in world space. */
export declare const toWorld: (l: Layout, x: number, y: number, z?: number) => Vec3;
export declare const dragZ: (l: Layout) => number;
/** Where the candy at (row, col) rests (row may be negative: above the board). */
export declare const candyPosition: (l: Layout, row: number, col: number, z?: number) => Vec3;
export type Scenery = {
    backdrop: Entity;
    parts: Entity[];
};
export declare function buildScenery(world: World, l: Layout, theme: GameTheme): Scenery;
export declare function removeScenery(world: World, s: Scenery): void;
/** A new theme: the background is repainted and the board rebuilt in its colors. */
export declare function setSceneryTheme(world: World, l: Layout, s: Scenery, theme: GameTheme): void;
export declare const getCandyAtlas: () => Texture | undefined;
export declare function loadCandyAtlas(): Promise<Texture>;
export declare function spawnCandy(world: World, atlas: Texture, type: number, position: Vec3, size: number): Entity;
/** A color bomb just made: it grows in where its match was, with a little overshoot. */
export declare function popInBomb(world: World, root: Entity, size: number): void;
export declare function blastWave(world: World, l: Layout, origin: Vec3, type: number): void;
/** Stretch the streak toward its target, then pull its tail in as the candy breaks. */
export declare function zap(world: World, l: Layout, from: Vec3, to: Vec3, type: number, delay: number): void;
/** Ordinary matches use the same glow and flying glints as Block Blast. */
export declare function crushCandy(world: World, l: Layout, root: Entity, type: number, at: Vec3, duration: number, delay: number, glints: number): Promise<void>;
//# sourceMappingURL=CandyCrushScene.d.ts.map