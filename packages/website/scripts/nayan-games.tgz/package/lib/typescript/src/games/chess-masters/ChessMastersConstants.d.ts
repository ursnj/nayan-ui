import type { TiltView } from '../shared/EngineTilt';
export declare const WIN_POINTS = 50;
export declare const THINK_MIN = 0.24;
export declare const THINK_MAX = 0.9;
export declare const SEARCH_SLICE_MS = 1.5;
export declare const LIGHT: import("nayan-ui").Light;
export declare const COLORS: {
    lightSquare: string;
    darkSquare: string;
    rim: string;
    white: string;
    black: string;
    selected: string;
    lastMove: string;
    check: string;
    target: string;
    capture: string;
};
export declare const BOARD_UNITS = 8.58;
export type Layout = TiltView & {
    cell: number;
    row: number;
};
export declare function getLayout(width: number, height: number, offset: number): Layout;
export declare const squareCenter: (square: number) => [number, number];
export declare function squareAt(layout: Layout, x: number, y: number): number;
//# sourceMappingURL=ChessMastersConstants.d.ts.map