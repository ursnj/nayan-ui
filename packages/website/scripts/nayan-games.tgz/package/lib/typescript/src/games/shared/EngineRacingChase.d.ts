import type { Camera, Vec3 } from 'nayan-ui';
type Vector = [number, number, number];
export declare const createChase: () => {
    eye: Vector;
    target: Vector;
    initialized: boolean;
};
export type Chase = ReturnType<typeof createChase>;
/** Filter camera offsets only: translation stays locked to the exact displayed car pose. */
export declare function updateChase(chase: Chase, camera: Camera, anchor: Vec3, eye: Vec3, target: Vec3, dt: number): void;
export {};
//# sourceMappingURL=EngineRacingChase.d.ts.map