export declare const PipeConnect: import("react").FC<import("../..").GameProps>;
//# sourceMappingURL=PipeConnect.d.ts.map