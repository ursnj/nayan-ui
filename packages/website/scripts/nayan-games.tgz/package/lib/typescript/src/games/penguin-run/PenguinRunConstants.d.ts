export declare const PENGUIN_SIZE = 1.2;
/** Lane centres across the temple causeway. */
export declare const LANE_X: readonly [-1.7, 0, 1.7];
/** Lane changes follow a critically damped spring (higher = snappier), leaning into the move. */
export declare const LANE_STIFFNESS = 14;
export declare const LEAN_ROLL = 0.045;
export declare const LEAN_YAW = 0.035;
export declare const MAX_LEAN = 0.32;
/** How quickly the camera drifts after the penguin's lane. */
export declare const CAMERA_FOLLOW = 6;
/** Run speed, held for the whole track. */
export declare const SPEED_START = 7;
/** The track is this long; crossing the finish line wins. */
export declare const TRACK_LENGTH = 1000;
/** Clear running at the start and before the finish. */
export declare const START_CLEAR = 14;
export declare const FINISH_CLEAR = 6;
/** Paving rows are this long; a gap is one missing slab. */
export declare const SLAB = 2;
/** After a crash or a win, the scene plays (fall, dance) for this long before the results card. */
export declare const RESULTS_DELAY_LOSE = 1700;
export declare const RESULTS_DELAY_WIN = 2600;
/** The causeway is built from tiles this long; this many stay ahead of the penguin. */
export declare const TILE_LENGTH = 12;
export declare const TILES_AHEAD = 9;
export declare const TILES_BEHIND = 2;
/** Causeway laid behind the start line (ending at a temple), so the start screen has scenery all round. */
export declare const TILES_BEFORE_START = 3;
/** Causeway past the finish line before the far temple. */
export declare const TILES_PAST_FINISH = 3;
/**
 * Jumps and slides cover a set distance rather than a set time: the clips play faster as the run
 * speeds up, so a jump timed the same way always clears a gap. Metres spent airborne / ducked, and
 * the clip-length limits that keep them from feeling floaty when slow or frantic when fast.
 */
export declare const JUMP_AIR_METRES = 5.5;
export declare const SLIDE_LOW_METRES = 7;
export declare const JUMP_TIME: [number, number];
export declare const SLIDE_TIME: [number, number];
/**
 * Fractions of each clip during which the penguin counts as off the ground (clears a gap) or low
 * enough to pass under a gateway: generous, from just after it springs or drops to just before it lands
 * or rises.
 */
export declare const GAP_WINDOW: [number, number];
export declare const LOW_WINDOW: [number, number];
/** How far from a gap's centre the penguin falls in (the slab is SLAB long; the broken edges forgive). */
export declare const GAP_HALF = 0.45;
/** Hits the penguin can take; after one it stumbles on and can't be hurt again for a moment. */
export declare const MAX_LIVES = 3;
export declare const HURT_INVULNERABLE = 2.2;
/** How deep (along z) an obstacle is for collisions, and how close in x counts as the same lane. */
export declare const HIT_DEPTH = 0.3;
export declare const LANE_TOLERANCE = 0.7;
export declare const COIN_RADIUS = 1.1;
export declare const POINTS_PER_METRE = 2;
export declare const POINTS_COIN = 20;
export declare const POINTS_GEM = 200;
//# sourceMappingURL=PenguinRunConstants.d.ts.map