import { type Camera, type Entity, type World } from 'nayan-ui';
import type { GameTheme } from '../../services/ThemeService';
import { type Layout } from './MineSweeperConstants';
import { type Cell } from './MineSweeperRules';
export type Scene = {
    backdrop: Entity;
    panel: Entity;
    grid: Entity | null;
    tiles: Entity[];
    /** What sits on each cell: its count, a flag or a mine (null when nothing does). */
    marks: (Entity | null)[];
};
export declare function buildScene(world: World, l: Layout, theme: GameTheme, grid: Cell[][]): Scene;
export declare function removeScene(world: World, s: Scene): void;
export declare function setSceneTheme(world: World, l: Layout, s: Scene, theme: GameTheme): void;
/** Revealed cells sink to sand one after another, rippling out from the first, and show what they hold. */
export declare function reveal(world: World, l: Layout, s: Scene, cells: Cell[], origin: Cell): void;
/** A flag goes up, or comes down. */
export declare function flag(world: World, l: Layout, s: Scene, cell: Cell): void;
/** A mine goes off: a fireball, a jolt, and every mine shows. */
export declare function explode(world: World, l: Layout, s: Scene, camera: Camera, hit: Cell, mines: Cell[]): void;
/** Every safe cell cleared: confetti over the board. */
export declare function celebrate(world: World, l: Layout): void;
//# sourceMappingURL=MineSweeperScene.d.ts.map