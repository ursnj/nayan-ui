export declare const PerfectCircle: import("react").FC<import("../..").GameProps>;
//# sourceMappingURL=PerfectCircle.d.ts.map