import type { TiltView } from '../shared/EngineTilt';
export declare const GRID = 14;
export declare const GAME_DURATION = 120;
/** A win scores by its time against the full three minutes. */
export declare const BASE_SCORE = 100;
export declare const GAME_OVER_DELAY = 0.5;
export declare const COLORS: {
    readonly WALLS: readonly ["#7A4A24", "#8B4513", "#A0522D", "#9A5B2E"];
    readonly WALL_TOP: "#D2A06A";
    readonly BALL: "#4ECDC4";
    readonly BALL_BAND: "#FFFFFF";
    readonly BALL_DOT: "#2C8C86";
    readonly START: "#4CAF50";
    readonly START_INNER: "#81C784";
    readonly GOAL: "#FF5722";
    readonly GOAL_INNER: "#FF8A65";
};
/** Directly overhead so raised walls do not obscure the maze's passages. */
export declare const TILT = 0;
/** Overhead light, with cast shadows disabled by frontLight. */
export declare const LIGHT: import("nayan-ui").Light;
/** A wall's thickness and height, and the ball's size, of a cell. */
export declare const WALL_THICKNESS = 0.14;
export declare const WALL_HEIGHT = 0.42;
export declare const BALL_SIZE = 0.56;
/** The board's rim round the maze, in points: it counts toward the max width. */
export declare const BORDER = 6;
export type Layout = TiltView & {
    n: number;
    cell: number;
    size: number;
};
/** The maze square as big as the game area allows, viewed directly overhead. */
export declare function getLayout(width: number, height: number, offset: number): Layout;
/** A cell's centre (or any point in cells: 0.5 is the middle of the first column / row), in world units. */
export declare function cellPoint(l: Layout, cx: number, cy: number): [number, number];
//# sourceMappingURL=MazeRunnerConstants.d.ts.map