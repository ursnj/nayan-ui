import { type Layout } from './CrossyRoadConstants';
import type { VehicleStyle } from './CrossyRoadMeshes';
export type Vehicle = {
    id: number;
    row: number;
    x: number;
    width: number;
    speed: number;
    colorIndex: number;
    style: VehicleStyle;
};
/** Every road's traffic: one bus (sometimes two) or two cars (sometimes three), evenly spaced, all one way. */
export declare function buildTraffic(l: Layout, firstId?: number): Vehicle[];
/** One 60 Hz frame of traffic, wrapping off one side onto the other. */
export declare function moveTraffic(l: Layout, vs: Vehicle[], scale: number): void;
/** Whether traffic overlaps the pedestrian, including fractional rows while a step is in progress (every 60 Hz step: no allocation). */
export declare function hit(l: Layout, vs: Vehicle[], row: number, x: number): boolean;
/** The player: its lane and column, the furthest lane it's reached, and the roads crossed. */
export type Player = {
    row: number;
    col: number;
    maxRow: number;
    crossings: number;
};
export declare const startPlayer: () => Player;
/** A hop's outcome: whether it moved, whether it crossed a road, whether it reached the goal. */
export type Hop = {
    moved: boolean;
    crossed: boolean;
    goal: boolean;
};
export declare function hopForward(p: Player): Hop;
export declare function hopBack(p: Player): Hop;
export declare function hopSide(p: Player, dir: -1 | 1): Hop;
export declare const playerX: (l: Layout, p: Player) => number;
export declare const scaleFor: (p: Player) => number;
//# sourceMappingURL=CrossyRoadRules.d.ts.map