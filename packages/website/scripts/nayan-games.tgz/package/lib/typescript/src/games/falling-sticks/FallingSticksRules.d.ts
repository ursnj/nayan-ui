import { type Layout } from './FallingSticksConstants';
export declare const FREE = 0;
export declare const FALLING = 1;
/** Lying on the ground: stays visible, so its slot isn't reused. */
export declare const LANDED = 2;
/** One pool slot, in view points (x right, y down) and degrees (clockwise). */
export type Stick = {
    state: number;
    color: number;
    x: number;
    y: number;
    speed: number;
    rot: number;
    rotSpeed: number;
    restY: number;
    restRot: number;
};
export type Field = {
    sticks: Stick[];
    spawnTimer: number;
    score: number;
    nextColor: number;
};
export declare const newField: () => Field;
/**
 * One 60 Hz frame with `lives` left: sticks fall and spin, land (each a life), and maybe one spawns.
 * Returns the slots that landed and spawned, and the lives left.
 */
export declare function step(f: Field, l: Layout, lives: number): {
    landed: number[];
    spawned: number;
    lives: number;
};
/** Catch along the entire swipe and the stick's rotated length, so fast swipes and tip taps count. */
export declare function catchAlong(f: Field, l: Layout, fromX: number, fromY: number, x: number, y: number): number[];
export declare const catchAt: (f: Field, l: Layout, x: number, y: number) => number[];
//# sourceMappingURL=FallingSticksRules.d.ts.map