import { type Model } from 'nayan-ui';
export interface PersonMeshes {
    shirt: Model;
    skin: Model;
    details: Model;
    sleeve: Model;
    hand: Model;
    leg: Model;
    flags: readonly [Model, Model, Model];
}
export declare function personMeshes(): PersonMeshes;
/** Reusable assets; the game loader advances one builder per frame. */
export declare function warmAssets(): Iterable<() => unknown>;
//# sourceMappingURL=PaperIoMeshes.d.ts.map