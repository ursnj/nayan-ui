export declare const WordSearch: import("react").FC<import("../..").GameProps>;
//# sourceMappingURL=WordSearch.d.ts.map