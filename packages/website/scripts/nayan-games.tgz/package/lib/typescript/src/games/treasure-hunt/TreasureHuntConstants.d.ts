import { type Light, type SoundBank, type Texture } from 'nayan-ui';
import type { HumanAssets } from './TreasureHuntModel';
/** Shared strike timing and offline skeletal choreography for the imported explorer. */
export declare const HUMAN_PUNCH_TIME = 0.52;
export declare const HUMAN_CONTACT_TIME = 0.16;
export declare const HUMAN_GUARD_TIME = 1.15;
type Vector = [number, number, number];
interface HandTarget {
    pos: Vector;
    pole: Vector;
    dir: Vector;
    palm: Vector;
}
export interface CombatPose {
    bones: Record<string, Vector>;
    root: {
        ground: boolean;
    };
    ik?: {
        Left: HandTarget;
        Right: HandTarget;
    };
    thumbs?: {
        Left: number;
        Right: number;
    };
    blend?: {
        sample: CombatPose;
        w: number;
    };
}
interface CombatClip {
    id: string;
    name: string;
    category: 'Actions';
    duration: number;
    loop: boolean;
    sample(time: number): CombatPose;
}
/** Both hands share a planted stance. Only the striking shoulder, torso and arm change sides. */
export declare function fightingPose(hand: 'Left' | 'Right' | null, time: number): CombatPose;
export declare function createCombatClips(idle: {
    sample(time: number): CombatPose;
}): CombatClip[];
export declare const HUMAN_HEIGHT: number;
export declare const HUMAN_CAMERA_HEIGHT: number;
export declare const HUMAN_CLIPS: {
    idle: {
        duration: number;
        loop: boolean;
    };
    walk: {
        duration: number;
        loop: boolean;
    };
    run: {
        duration: number;
        loop: boolean;
    };
    punchStart: {
        duration: number;
        loop: boolean;
    };
    punchRight: {
        duration: number;
        loop: boolean;
    };
    punchLeft: {
        duration: number;
        loop: boolean;
    };
    combatIdle: {
        duration: number;
        loop: boolean;
    };
    combatExit: {
        duration: number;
        loop: boolean;
    };
    hit: {
        duration: number;
        loop: boolean;
    };
    fall: {
        duration: number;
        loop: boolean;
    };
    celebrate: {
        duration: number;
        loop: boolean;
    };
    islandGather: {
        duration: number;
        loop: boolean;
    };
    islandDrink: {
        duration: number;
        loop: boolean;
    };
    islandCook: {
        duration: number;
        loop: boolean;
    };
    islandRest: {
        duration: number;
        loop: boolean;
    };
    islandWalkUp: {
        duration: number;
        loop: boolean;
    };
    islandWalkDown: {
        duration: number;
        loop: boolean;
    };
};
export type HumanAnimation = keyof typeof HUMAN_CLIPS;
export declare const HUMAN_CLIP_TIME: Record<HumanAnimation, number>;
export declare const HUMAN_LOOPS: Set<"hit" | "idle" | "walk" | "run" | "punchStart" | "punchRight" | "punchLeft" | "combatIdle" | "combatExit" | "fall" | "celebrate" | "islandGather" | "islandDrink" | "islandCook" | "islandRest" | "islandWalkUp" | "islandWalkDown">;
export declare function isWalkingAnimation(animation: HumanAnimation | null): animation is "walk" | "islandWalkUp" | "islandWalkDown";
/** Hysteresis stops tiny gesture changes from repeatedly switching walk and run. */
export declare function locomotionAnimation(speed: number, previous?: HumanAnimation | null): 'idle' | 'walk' | 'run';
/** A margin around cadence buckets prevents finger noise from repeatedly rebuilding native tracks. */
export declare function locomotionRate(speed: number, previous?: number): number;
export declare const WORLD_EDGE = 128;
export declare const TERRAIN_PROFILES = 16;
export declare const MINIMAP_SIZE = 124;
export declare const MAX_HEALTH = 5;
export declare const GEM_GOAL = 24;
export declare const POINTS_GEM = 200;
export declare const POINTS_ROBOT_HIT = 50;
export declare const POINTS_ROBOT_DEFEAT = 300;
export declare const POINTS_HEALTH_BONUS = 400;
export declare const PLAYER_SPEED = 6;
export declare const PLAYER_RADIUS = 0.5;
export declare const MOVEMENT_START = 0.08;
export declare const MOVEMENT_STOP = 0.04;
export declare const ATTACK_RANGE = 1.9;
export declare const ATTACK_COOLDOWN = 0.52;
export declare const ATTACK_HIT_TIME = 0.16;
export declare const ENEMY_COUNT = 8;
export declare const SKY: readonly [0.62, 0.77, 0.86];
export declare const NATURE_LIGHT: Light;
export declare const NIGHT_SKY: readonly [0.07, 0.13, 0.2];
export declare const NIGHT_LIGHT: Light;
export interface Point {
    x: number;
    z: number;
}
export interface NatureAssets {
    meadow: Texture;
    stone: Texture;
    bark: Texture;
    pine: Texture;
    leaves: Texture;
    water: Texture;
}
export interface GameAssets extends NatureAssets {
    human: HumanAssets;
}
type SoundName = 'gem' | 'punch' | 'impact' | 'defeat' | 'hurt' | 'win' | 'footstepWalk' | 'footstepRun';
export declare let sounds: SoundBank<SoundName> | undefined;
/** Use fulfilled prepared resources on the first render, without another loading frame. */
export declare const getCachedAssets: () => GameAssets | null;
/** Load native resources once; tuning and rules remain usable without a native renderer. */
export declare function loadAssets(): Promise<GameAssets>;
/** Start the explorer and terrain downloads together, without serial idle/network round trips. */
export declare function warmAssets(): Iterable<() => unknown>;
export {};
//# sourceMappingURL=TreasureHuntConstants.d.ts.map