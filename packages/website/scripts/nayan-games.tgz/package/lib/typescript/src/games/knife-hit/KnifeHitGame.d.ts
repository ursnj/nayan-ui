import { type Camera, World } from 'nayan-ui';
import type { GameTheme } from '../../services/ThemeService';
import type { GamePhase as Phase } from '../shared/useEngineGame';
import { type Layout } from './KnifeHitConstants';
import { type Scene } from './KnifeHitScene';
/** throw: a knife left the hand; stick / apple / clash: how it landed. */
export type GameEvent = 'throw' | 'stick' | 'apple' | 'clash';
export declare function createGame(theme: GameTheme): {
    world: World;
    camera: Camera;
    theme: GameTheme;
    layout: Layout | null;
    scene: Scene | null;
    phase: Phase;
    /** The knives in the log (angles: the play area's, y down), the apple if there is one. */
    stuck: number[];
    apple: number | null;
    appleTaken: boolean;
    rotation: number;
    speed: number;
    direction: number;
    turnTimer: number;
    turnInterval: number;
    /** The knife in flight: its tip's height in the play area, or null. */
    flying: number | null;
    knivesLeft: number;
    /** Score and the countdown live in the engine (Rust), advanced by world.update. */
    readonly score: number;
    readonly timeLeft: number;
    won: boolean;
    pending: number;
    onPhase: (_p: Phase) => void;
    onKnives: (_n: number) => void;
    onEvent: (_e: GameEvent) => void;
};
export type Game = ReturnType<typeof createGame>;
/** Lays the log out for the view (first layout, header height, rotation): rebuilt from the round's state. */
export declare function setLayout(g: Game, l: Layout): void;
export declare function setTheme(g: Game, theme: GameTheme): void;
/** A fresh round: three knives in the log, sometimes an apple, the log's speed and turns varied a little. */
export declare function start(g: Game): void;
/** Back to the still preview log (Stop, Play Again). The world, and the GPU view drawing it, are kept. */
export declare function reset(g: Game): void;
/** The log and the knife at fixed 60 Hz steps; the engine steps the world after. */
export declare function tick(g: Game, dt: number): void;
/** A finger down throws the next knife, if one's ready and none is in the air. */
export declare function throwKnife(g: Game): void;
//# sourceMappingURL=KnifeHitGame.d.ts.map