import { type Direction, type TileType } from './Tank1990Constants';
export type Tank = {
    id: number;
    x: number;
    y: number;
    direction: Direction;
    isPlayer: boolean;
    isAlive: boolean;
    lastFireTime: number;
    spawnProtectionEndTime: number;
    lastDirectionChangeTime: number;
};
export type Bullet = {
    id: number;
    x: number;
    y: number;
    direction: Direction;
    isPlayerBullet: boolean;
};
export type Tile = {
    type: TileType;
    health: number;
};
export type Board = {
    tiles: Tile[][];
    cell: number;
    width: number;
    height: number;
};
export declare const BASE_X: number;
export declare const BASE_Y: number;
/** A fresh map: one of the arenas (sometimes mirrored), the base walled in steel, the spawns and the player's start kept clear. */
export declare function createMap(): Tile[][];
/** The player's tank, bottom left (away from the base), shielded for a moment. */
export declare function createPlayer(cell: number, now: number): Tank;
/** An enemy at the first free spawn point along the top (left, middle, right), or null if they're all taken. */
export declare function createEnemy(cell: number, enemies: Tank[], now: number): Tank | null;
/** A tank turned to `direction` and, if the way is clear, moved one tick along it. */
export declare function moveTank(tank: Tank, direction: Direction, speed: number, b: Board, tanks: Tank[]): Tank;
/** A bullet from the tank's muzzle, if its gun has cooled down. */
export declare function fire(tank: Tank, now: number): Bullet | null;
export declare function moveBullet(bullet: Bullet): void;
export type BulletHit = {
    hit: boolean;
    tile?: [number, number];
    base?: boolean;
    tank?: Tank;
};
/** What a bullet has hit: the edge, a wall (bricks and the base take damage), or an unshielded tank on the other side. */
export declare function bulletHit(bullet: Bullet, b: Board, tanks: Tank[], now: number): BulletHit;
/** A hit on a tile: a brick loses a layer (two and it's gone); the base is destroyed. Returns its new state. */
export declare function damageTile(tiles: Tile[][], x: number, y: number): Tile | null;
/** Opposing bullets that meet cancel out; returns the survivors and where each pair met. */
export declare function bulletClashes(bullets: Bullet[]): {
    remaining: Bullet[];
    points: [number, number][];
};
/**
 * An enemy's heading: when blocked, a clear way (toward the player if that's one), or straight back;
 * otherwise, every 800 ms, toward the player (40%), on as it was (35%) or anywhere (25%).
 */
export declare function enemyHeading(enemy: Tank, player: Tank, b: Board, tanks: Tank[], blocked: boolean, now: number): {
    direction: Direction;
    turned: boolean;
};
/** Whether an enemy pulls the trigger: always with the player ahead and nearly in line, otherwise 30% of the time. */
export declare function enemyWantsToFire(enemy: Tank, player: Tank): boolean;
//# sourceMappingURL=Tank1990Rules.d.ts.map