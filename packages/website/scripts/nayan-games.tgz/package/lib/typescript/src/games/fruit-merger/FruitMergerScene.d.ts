import { type Camera, type Entity, type World } from 'nayan-ui';
import type { GameTheme } from '../../services/ThemeService';
import { type Layout } from './FruitMergerConstants';
import type { Body } from './FruitMergerRules';
export type Scene = {
    backdrop: Entity;
    jar: Entity[];
    dashes: Entity[];
    dots: Entity[];
    preview: Entity | null;
    previewId: string | null;
    previewX: number;
    previewY: number;
    /** The next fruit, small, just above the aimed one, and which fruit it shows. */
    next: Entity | null;
    nextType: number;
    fruits: Map<string, Entity>;
    danger: number;
    hot: boolean;
};
/** Frames the glass where the layout puts it, looking from a little above. */
export declare function aim(camera: Camera, l: Layout): void;
export declare function buildScene(world: World, l: Layout, theme: GameTheme): Scene;
export declare function removeScene(world: World, s: Scene): void;
export declare function setSceneTheme(world: World, s: Scene, theme: GameTheme): void;
/** Warms the line toward red as the pile nears it (thicker as it does), pulsing once it's close. */
export declare function setDanger(world: World, s: Scene, theme: GameTheme, d: number): void;
/** Keeps the fruit entities in step with the bodies: each where its body is, turned by its roll. */
export declare function drawFruits(world: World, s: Scene, bodies: Body[]): void;
/** Two fruits merge: they shrink into the spot, the new one pops in there, with a ring and a burst. */
export declare function mergeFx(world: World, s: Scene, a: Body, b: Body, made: Body): void;
/** Clears every fruit (a new game). */
export declare function clearFruits(world: World, s: Scene): void;
/**
 * The aimed fruit at the top (growing in when it's new), with its drop guide down the glass and the next
 * fruit, small, just above it; null hides them.
 */
export declare function drawPreview(world: World, s: Scene, fruit: {
    id: string;
    typeId: number;
    x: number;
    y: number;
} | null, nextType?: number): void;
/** The pumpkin: confetti over the glass. */
export declare function celebrate(world: World): void;
/** The pile gave out (overflow or time): a jolt. */
export declare function jolt(camera: Camera): void;
/** Reusable assets; the game loader advances one builder per frame. */
export declare function warmAssets(): Iterable<() => unknown>;
//# sourceMappingURL=FruitMergerScene.d.ts.map