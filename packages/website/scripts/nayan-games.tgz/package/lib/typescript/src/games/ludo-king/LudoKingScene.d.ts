import { type Camera, type Entity, type Quat, type Vec3, type World } from 'nayan-ui';
import type { GameTheme } from '../../services/ThemeService';
import { type Layout, type PlayerColor } from './LudoKingConstants';
/** Above every layer of the board: pawn shadows, then the pawns and hint rings over them. */
export declare const SHADOW_Z: number;
export declare const PAWN_Z: number;
/** The die showing `value` toward the camera (shared/EngineDice), turned `twist` round its up axis. */
export declare const dieRotation: (value: number, twist?: number) => Quat;
export type Scene = {
    backdrop: Entity;
    board: Entity;
    tokens: Map<string, Entity>;
    tokenAt: Map<Entity, string>;
    bobbing: Set<string>;
    shadows: Map<string, Entity>;
    die: Entity;
    dieShadow: Entity;
    ring: Entity;
    hints: Entity[];
};
export declare const toWorld: (l: Layout, x: number, y: number, z: number) => Vec3;
export declare const aimCamera: (camera: Camera, l: Layout) => void;
export declare const dieRest: (l: Layout) => Vec3;
export declare function buildScene(world: World, l: Layout, theme: GameTheme, tokenIds: {
    id: string;
    color: PlayerColor;
}[]): Scene;
export declare function removeScene(world: World, s: Scene): void;
export declare function setSceneTheme(world: World, s: Scene, theme: GameTheme): void;
/** When players share a cell they shoulder apart a little. */
export declare function placeToken(world: World, l: Layout, s: Scene, id: string, cell: {
    row: number;
    col: number;
}, offset?: number): void;
/** Hops a token through a run of cells. */
export declare function hopToken(world: World, l: Layout, s: Scene, id: string, cells: {
    row: number;
    col: number;
}[], time: number): void;
export declare function bobToken(world: World, l: Layout, s: Scene, ids: string[]): void;
export declare function showHints(world: World, l: Layout, s: Scene, cells: {
    row: number;
    col: number;
}[]): void;
/** The die is tossed, tumbles and bounces to rest showing `value` (shared/EngineDice). */
export declare function rollDie(world: World, l: Layout, s: Scene, value: number, time: number, disposed?: () => boolean): void;
export declare function showRollHint(world: World, l: Layout, s: Scene, on: boolean): void;
export declare function captureBurst(world: World, l: Layout, cell: {
    row: number;
    col: number;
}): void;
export declare function finishBurst(world: World, l: Layout): void;
export declare function confetti(world: World, l: Layout, winner: PlayerColor): void;
//# sourceMappingURL=LudoKingScene.d.ts.map