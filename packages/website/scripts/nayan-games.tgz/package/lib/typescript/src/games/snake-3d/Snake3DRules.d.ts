export declare const GRID = 20;
export declare const INITIAL_LENGTH = 3;
/** Points per food: the original base points x its "medium" multiplier of 2. */
export declare const POINTS_PER_FOOD = 1000;
export declare const POINTS_PER_SPECIAL_FOOD = 2000;
export declare const SPECIAL_FOOD_CHANCE = 0.15;
export declare const SPECIAL_FOOD_DURATION = 10;
export type Direction = 'UP' | 'DOWN' | 'LEFT' | 'RIGHT';
export declare const VECTORS: Record<Direction, [number, number]>;
/** expiresAt: game-clock seconds (bonus food only). */
export type Food = {
    id: number;
    x: number;
    y: number;
    isSpecial: boolean;
    expiresAt?: number;
};
/** The snake's cells, head first, flattened [x0, y0, x1, y1, …]. */
export type Snake = number[];
/** In the middle of the grid, heading right. */
export declare function initialSnake(): Snake;
/** A random cell off the snake (giving up after 100 tries, as before). */
export declare function generateFood(s: Snake, isSpecial: boolean, id: number, now: number): Food;
export type SnakeState = {
    snake: Snake;
    direction: Direction;
    nextDirection: Direction;
    turns: Direction[];
    food: Food | null;
    nextFoodId: number;
};
export declare const freshState: () => SnakeState;
/** Buffer up to two turns in swipe order; refuse duplicates and reversals against the queued heading. */
export declare function turn(st: SnakeState, d: Direction): void;
export type StepResult = {
    crash: boolean;
    ate: Food | null;
    newFood: Food | null;
    grew: boolean;
};
/** One move: the head steps on, the tail follows; walls and the body kill; food grows it by one. */
export declare function step(st: SnakeState, now: number): StepResult;
//# sourceMappingURL=Snake3DRules.d.ts.map