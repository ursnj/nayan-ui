import { type Entity, type World } from 'nayan-ui';
import type { GameTheme } from '../../services/ThemeService';
import { type Layout } from './PaperIoConstants';
import type { Board } from './PaperIoRules';
interface PersonRig {
    root: Entity;
    visual: Entity;
    legs: readonly [Entity, Entity];
    arm: Entity;
    flag: Entity;
    stride: number;
    col: number;
    row: number;
    walking: boolean;
}
export type Scene = {
    root: Entity;
    backdrop: Entity;
    board: Entity;
    /** Land and trail cells, by cell index (spawned when first needed), and who each shows. */
    land: (Entity | null)[];
    landOwner: Int8Array;
    landCorners: Uint8Array;
    trail: (Entity | null)[];
    trailOwner: Int8Array;
    heads: PersonRig[];
};
export declare function buildScene(world: World, l: Layout, theme: GameTheme, b: Board): Scene;
export declare function removeScene(world: World, s: Scene): void;
export declare function setSceneTheme(world: World, l: Layout, s: Scene, theme: GameTheme): void;
/** Shows each cell's land and trail as the board has them; newly captured land flashes in if `flash`. */
export declare function syncBoard(world: World, l: Layout, s: Scene, b: Board, flash: boolean, dirty?: readonly number[]): void;
/** People glide between cells, turn with their feet, and carry their flags through each step. */
export declare function placeHeads(world: World, l: Layout, s: Scene, b: Board, glide: boolean, popped?: boolean[]): void;
/** The round's over: walking stops; the winner and their flag lift in celebration. */
export declare function finish(world: World, l: Layout, s: Scene, won: boolean): void;
/** Reusable assets; the game loader advances one builder per frame. */
export declare function warmAssets(): Iterable<() => unknown>;
export {};
//# sourceMappingURL=PaperIoScene.d.ts.map