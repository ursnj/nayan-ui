export declare const ColorSwitch: import("react").FC<import("../..").GameProps>;
//# sourceMappingURL=ColorSwitch.d.ts.map