import type { Model, RenderSource, World } from 'nayan-ui';
import type { Sim } from './MobControlRules';
export declare class MobControlRenderer implements RenderSource {
    private readonly world;
    private readonly poses;
    readonly capacity: number;
    readonly matrices: Float32Array;
    readonly colors: Float32Array;
    readonly regions: Float32Array;
    readonly ranges: Uint32Array;
    count: number;
    private disposed;
    private readonly sizeStrength;
    private readonly sizeKind;
    private readonly sizes;
    /** Live slots in drawing order (first pose, then second), and the second pose's while sorting. */
    private readonly order;
    private readonly secondPose;
    constructor(world: World, poses: readonly [Model, Model]);
    /**
     * The world's own instances keep their places and ranges (block copies, rather than a walk over
     * every mesh id the app has registered), and the soldiers follow at `world.capacity`, past anything
     * the world can draw: each pose one contiguous range, in slot order.
     */
    sync(s: Sim, alpha: number, clock: number): void;
    private place;
    setView(matrix: Float32Array, width: number, height: number): void;
    dispose(): void;
}
//# sourceMappingURL=MobControlRenderer.d.ts.map