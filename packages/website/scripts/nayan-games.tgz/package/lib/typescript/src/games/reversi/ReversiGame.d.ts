import { type Camera, type DragEvent, World } from 'nayan-ui';
import type { GameTheme } from '../../services/ThemeService';
import type { GamePhase as Phase } from '../shared/useEngineGame';
import { type Layout } from './ReversiConstants';
import { type Player } from './ReversiRules';
import { type Scene } from './ReversiScene';
/** place / robot: a disc down; invalid: a tap off the legal moves; pass: a side couldn't move; win / lose: how it ended (a timeout is silent). */
export type GameEvent = 'place' | 'robot' | 'invalid' | 'pass' | 'win' | 'lose';
export declare function createGame(theme: GameTheme): {
    world: World;
    camera: Camera;
    theme: GameTheme;
    layout: Layout | null;
    scene: Scene | null;
    phase: Phase;
    board: import("./ReversiRules").Board;
    turn: Player;
    /** Your legal moves (shown as rings; none on the robot's turn). */
    hints: number[];
    last: number;
    winner: Player | null;
    timedOut: boolean;
    black: number;
    white: number;
    /** Score and the countdown live in the engine (Rust), advanced by world.update. */
    readonly score: number;
    readonly timeLeft: number;
    press: {
        x: number;
        y: number;
    } | null;
    onPhase: (_p: Phase) => void;
    onScore: (_s: number) => void;
    onCounts: (_black: number, _white: number) => void;
    onTurn: (_p: Player) => void;
    onEvent: (_e: GameEvent) => void;
};
export type Game = ReturnType<typeof createGame>;
/** Lays the board out for the view (first layout, header height, rotation): rebuilt where things stand. */
export declare function setLayout(g: Game, l: Layout): void;
export declare function setTheme(g: Game, theme: GameTheme): void;
/** A fresh board, your move. */
export declare function start(g: Game): void;
/** The opening board, not started (Stop, Play Again). The world, and the GPU view drawing it, are kept. */
export declare function reset(g: Game): void;
/** Your move on a cell: a legal one is played, anything else just buzzes. */
export declare function select(g: Game, index: number): void;
/** The cell under a view point (on the felt), or -1. */
export declare function cellUnder(g: Game, x: number, y: number): number;
/** A tap (a finger down and up without wandering) on a cell. */
export declare function drag(g: Game, { phase, x, y }: DragEvent): void;
//# sourceMappingURL=ReversiGame.d.ts.map