import { GAME_IDS, type GameCategory } from './UtilsService';
export interface GameMetadata {
    id: GAME_IDS;
    title: string;
    description: string;
    instructions: string[];
    categories: GameCategory[];
    /** Catalog badge only; this does not restrict gameplay. */
    isPremium?: boolean;
}
export declare const GAMES_METADATA: Record<GAME_IDS, GameMetadata>;
export declare const GAMES_METADATA_LIST: GameMetadata[];
//# sourceMappingURL=GamesMetadata.d.ts.map