export declare const KnifeHit: import("react").FC<import("../..").GameProps>;
//# sourceMappingURL=KnifeHit.d.ts.map