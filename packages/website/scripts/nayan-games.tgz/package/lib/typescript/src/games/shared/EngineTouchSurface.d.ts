export interface EngineContact {
    identifier: number;
    pageX: number;
    pageY: number;
    timeStamp: number;
}
interface EngineTouchSurfaceProps {
    enabled: boolean;
    insets: {
        top: number;
        bottom: number;
    };
    onStart: (contact: EngineContact) => void;
    onMove: (contact: EngineContact) => void;
    onEnd: (contact: EngineContact) => void;
    onCancel: () => void;
}
/** Host adapter for simultaneous contacts until GameView exposes raw multi-touch itself. */
export declare const EngineTouchSurface: import("react").MemoExoticComponent<({ enabled, insets, onStart, onMove, onEnd, onCancel }: EngineTouchSurfaceProps) => import("react").JSX.Element>;
export {};
//# sourceMappingURL=EngineTouchSurface.d.ts.map