/** Responsive lane targeting with filtered input and an analytically damped movement curve. */
export type SteeringState = {
    d: number;
    target: number;
    lateral: number;
    steeringGoal?: number;
};
export declare function stepSteering(state: SteeringState, goal: number, dt: number, maxSpeed?: number, response?: number, playing?: boolean): void;
/** Closing speed across the road: moving away or travelling alongside does not trigger a wreck. */
export declare function sideImpactSpeed(playerLateral: number, trafficLateral: number, offset: number): number;
/** Ease the displayed yaw and lean independently so quick input changes do not snap the body. */
export declare function smoothSteeringPose(pose: {
    yaw: number;
    roll: number;
}, lateral: number, speed: number, dt: number): void;
//# sourceMappingURL=EngineRacingHandling.d.ts.map