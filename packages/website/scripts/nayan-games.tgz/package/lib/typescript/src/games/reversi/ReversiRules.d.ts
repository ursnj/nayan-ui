export declare const N = 8;
export type Player = 'black' | 'white';
export type Board = (Player | null)[];
export type Move = {
    index: number;
    flips: number[];
};
/** You play black and move first; the robot plays white. */
export declare const HUMAN: Player;
export declare const AI: Player;
export declare const opponent: (p: Player) => Player;
export declare function initialBoard(): Board;
/** The discs a move at `index` would flip (none: not a legal move). */
export declare function flipsFor(b: Board, index: number, player: Player): number[];
export declare function validMoves(b: Board, player: Player): Move[];
export declare function applyMove(b: Board, m: Move, player: Player): Board;
export declare function counts(b: Board): {
    black: number;
    white: number;
};
/** The robot's move: now and then a random one, otherwise a random pick among those near the best. */
export declare function chooseAIMove(b: Board): Move | null;
//# sourceMappingURL=ReversiRules.d.ts.map