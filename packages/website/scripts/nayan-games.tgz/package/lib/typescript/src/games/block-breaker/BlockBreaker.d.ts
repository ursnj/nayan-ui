export declare const BlockBreaker: import("react").FC<import("../..").GameProps>;
//# sourceMappingURL=BlockBreaker.d.ts.map