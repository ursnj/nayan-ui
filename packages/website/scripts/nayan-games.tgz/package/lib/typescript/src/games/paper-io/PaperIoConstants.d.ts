import type { TiltView } from '../shared/EngineTilt';
export declare const STEP_MS = 92;
export declare const PLAYER_COUNT = 2;
export declare const START_TERRITORY = 1;
export declare const GAME_DURATION_MS = 120000;
export declare const LOW_TIME = 10;
export declare const POINTS_PER_CELL = 10;
export declare const SWIPE = 10;
export type PlayerColor = {
    territory: string;
    trail: string;
    head: string;
    headDark: string;
};
/** 0 = you (green), 1 = the AI (red), as the original game. */
export declare const PLAYER_COLORS: PlayerColor[];
export declare const COLORS: {
    readonly CLASSIC_BOARD: "rgba(0, 0, 0, 0.18)";
    readonly FLASH: "#FFFFFF";
    readonly EYE: "#FFFFFF";
    readonly PUPIL: "#2C2C44";
};
/** A slightly lower tabletop view shows the people and their flags while keeping the grid readable. */
export declare const TILT = 0.48;
/** Render in compact world units so a full-screen board and tall people fit the camera's depth range. */
export declare const WORLD_SCALE = 0.25;
/** Lit from the upper left; surfaces facing up off the board (+z) keep their exact color. */
export declare const LIGHT: import("nayan-ui").Light;
/** Heights of land and trails, in cells. */
export declare const LAND = 0.32;
export declare const TRAIL = 0.22;
export declare const PERSON: {
    readonly SCALE: 3.2;
    readonly STRIDE: 0.38;
    readonly HEIGHT: 3.06;
    readonly CELEBRATION_SCALE: 1.5;
};
export declare const PERSON_COLORS: {
    readonly SKIN: readonly ["#DFAC87", "#A57355"];
    readonly HAIR: "#352A24";
    readonly PANTS: "#2F3D50";
    readonly SHOE: "#38414A";
    readonly SOLE: "#EEE9DF";
    readonly POLE: "#CCD4D8";
    readonly BADGE: "#E8D4A3";
};
export type Grid = {
    cols: number;
    rows: number;
    cell: number;
};
export type Layout = TiltView & Grid & {
    gridW: number;
    gridH: number;
    columnWidth: number;
    rowDepth: number;
    eyeDistance: number;
};
/**
 * The original grid: square cells a 32nd of the width (a 44th on a tablet) covering the whole view edge to
 * edge. The grid is fixed by the first layout (as the original game fixed it at load); later layouts only
 * remap those same cells and the camera to fill the view.
 */
export declare function gridFor(width: number, height: number, tablet: boolean): Grid;
export declare function getLayout(width: number, height: number, grid: Grid): Layout;
/** A cell's centre on the board, in world units (row 0 along the top). */
export declare const cellCentre: (l: Layout, col: number, row: number) => [number, number];
//# sourceMappingURL=PaperIoConstants.d.ts.map