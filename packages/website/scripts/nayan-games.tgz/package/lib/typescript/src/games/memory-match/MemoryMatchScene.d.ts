import { type Entity, type World } from 'nayan-ui';
import type { GameTheme } from '../../services/ThemeService';
import { type Layout } from './MemoryMatchConstants';
import { type Card } from './MemoryMatchRules';
/** A shared transform keeps the stock, printed faces, match seal and fruit together during a flip. */
type CardView = {
    root: Entity;
    body: Entity;
    backBody: Entity;
    back: Entity;
    front: Entity;
    seal: Entity;
    fruit: Entity;
    fruitScale: number;
};
export type Scene = {
    backdrop: Entity;
    cards: CardView[];
};
export declare function buildScene(world: World, l: Layout, theme: GameTheme, cards: Card[]): Scene;
export declare function removeScene(world: World, s: Scene): void;
export declare function setSceneTheme(world: World, s: Scene, theme: GameTheme): void;
/** A new deal: every card face down with its new fruit, popping in one after another. */
export declare function deal(world: World, l: Layout, s: Scene, cards: Card[]): void;
/** A card turns over (face up or face down), lifting off the table as it turns; its fruit shows only face up. */
export declare function flip(world: World, l: Layout, s: Scene, i: number, up: boolean): void;
/** A pair found: both cards turn green and pulse. */
export declare function matched(world: World, l: Layout, s: Scene, i: number): void;
/** A miss: both cards shake. */
export declare function mismatch(world: World, l: Layout, s: Scene, i: number): void;
/** Every pair found: a pulse wave across the board, and confetti. */
export declare function celebrate(world: World, l: Layout, s: Scene): void;
/** Out of time: the cards not matched dim. */
export declare function timeUp(world: World, s: Scene, cards: Card[]): void;
export {};
//# sourceMappingURL=MemoryMatchScene.d.ts.map