import { type ComponentType } from 'react';
import { type GAME_IDS, type GameProps } from '../../services/UtilsService';
/** Let the loading screen paint before evaluating the game module and building its world. */
export declare function withGameLoading(id: GAME_IDS, load: () => ComponentType<GameProps>): ComponentType<GameProps>;
//# sourceMappingURL=EngineGameLoader.d.ts.map