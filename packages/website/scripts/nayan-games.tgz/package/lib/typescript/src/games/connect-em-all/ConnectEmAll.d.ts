export declare const ConnectEmAll: import("react").FC<import("../..").GameProps>;
//# sourceMappingURL=ConnectEmAll.d.ts.map