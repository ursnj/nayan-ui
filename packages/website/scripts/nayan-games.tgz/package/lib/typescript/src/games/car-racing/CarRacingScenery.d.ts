import { type Model } from 'nayan-ui';
declare function buildScenery(): {
    podium: Model;
    roofs: Model[];
    facades: Model[];
    windows: Model;
    bench: Model;
    planter: Model;
    bin: Model;
    shelter: Model;
    grass: Model;
    flowers: Model;
    pavement: Model;
    drain: Model;
    house: Model;
    grassGround: Model;
    routeSign: Model;
    cloud: Model;
};
export type SceneryMeshes = ReturnType<typeof buildScenery>;
export declare function sceneryMeshes(): SceneryMeshes;
export {};
//# sourceMappingURL=CarRacingScenery.d.ts.map