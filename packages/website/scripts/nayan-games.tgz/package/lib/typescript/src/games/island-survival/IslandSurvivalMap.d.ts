import { type EngineHud } from '../shared/EngineHud';
import type { IslandState } from './IslandSurvivalRules';
export declare function mapBounds(width: number, height: number, offset: number, open: boolean): {
    side: number;
    x: number;
    y: number;
};
export declare function hitsMinimap(width: number, height: number, offset: number, x: number, y: number): boolean;
export declare function warmMap(): Generator<() => import("nayan-ui").Model, void, unknown>;
export declare function updateHud(hud: EngineHud, state: IslandState, open: boolean): void;
export declare function updateNotice(hud: EngineHud, state: IslandState, bottom: number, message?: string): void;
//# sourceMappingURL=IslandSurvivalMap.d.ts.map