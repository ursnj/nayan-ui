export declare const GRID = 3;
/** Tile ids 0..8 (8 is the gap, value 0); each tile's cell, row-major. */
export type Tile = {
    id: number;
    value: number;
    row: number;
    col: number;
};
export type Board = {
    tiles: Tile[];
    emptyRow: number;
    emptyCol: number;
};
/** A fresh board shuffled by 200 random slides of the gap, as the original store did (the same random draws). */
export declare function shuffled(): Board;
export declare const tileAt: (b: Board, row: number, col: number) => Tile | null;
/** Whether a tile is beside the gap (and so can slide into it). */
export declare function canSlide(b: Board, t: Tile): boolean;
/** Slides a tile into the gap (already checked). */
export declare function slide(b: Board, t: Tile): void;
/** Every tile home: 1..8 in reading order, the gap bottom right. */
export declare const solved: (b: Board) => boolean;
//# sourceMappingURL=SlidingNumbersRules.d.ts.map