import React from 'react';
import { StyleSheet } from 'react-native';
import { type GameTheme } from '../services/ThemeService';
import type { GameThemeMode } from '../services/UtilsService';
type NamedStyles = Parameters<typeof StyleSheet.create>[0];
interface GameThemeProviderProps {
    theme?: GameThemeMode;
    children: React.ReactNode;
}
/** Wrap a game in this to render its shared chrome (background, scoreboard, controls, modals) in the host's theme. */
export declare const GameThemeProvider: React.FC<GameThemeProviderProps>;
export declare const useGameTheme: () => GameTheme;
/**
 * Build a StyleSheet per theme, once. There are only three theme objects, so the cache stays tiny
 * and every render after the first is a Map lookup.
 */
export declare const createThemedStyles: <S extends NamedStyles>(factory: (theme: GameTheme) => S & NamedStyles) => (theme: GameTheme) => Readonly<S>;
export {};
//# sourceMappingURL=GameTheme.d.ts.map