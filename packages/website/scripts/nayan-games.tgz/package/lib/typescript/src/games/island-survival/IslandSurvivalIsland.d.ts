import { FieldGraph, type FieldInput, type Model, type ProceduralWorld, type Spot, type Vec3, type WorldRecipe } from 'nayan-ui';
export type ResourceKind = 'wood' | 'stone' | 'berries' | 'shellfish';
export type IslandBody = Spot & {
    radius: number;
};
export type Resource = Spot & {
    id: number;
    kind: ResourceKind;
    heading: number;
    bodies: readonly IslandBody[];
    reach: number;
};
export type Tree = Spot & {
    size: number;
    heading: number;
    palm: boolean;
};
type Rock = {
    position: Vec3;
    scale: Vec3;
    style: number;
};
export type IslandMap = {
    world: ProceduralWorld;
    land: readonly Model[];
    trees: Tree[];
    rocks: Rock[];
    grass: Float64Array;
    resources: Resource[];
    playerSites: Spot[];
    zombieSites: Spot[];
};
export declare const OCEAN_LEVEL = 0.012;
export declare function islandRockRecipe(style: number): {
    parts: ({
        kind: "cards";
        count: number;
        seed: number;
        randoms: number;
        corners: readonly (readonly [number, number, number, number])[];
        center: readonly [string, string, string];
        right: readonly [string, string, string];
        up: readonly [string, string, string];
        normal: readonly [string, string, string];
        color: readonly [string, string, string];
        double?: boolean;
    } | {
        rows: number;
        cols: number;
        double: boolean;
        kind: "surface";
        position: readonly [string, string, string];
        normal: readonly [string, string, string];
        uv: readonly [string, string];
        color: readonly [string, string, string];
        flip?: boolean;
    })[];
    fields: FieldGraph;
};
export declare function coast(f: FieldGraph, x: FieldInput, z: FieldInput): import("nayan-ui").FieldRef;
export declare function islandHeight(f: FieldGraph, x: FieldInput, z: FieldInput, inland?: import("nayan-ui").FieldRef): import("nayan-ui").FieldRef;
export declare function islandRecipe(): WorldRecipe;
export declare function loadIsland(): Promise<IslandMap>;
export {};
//# sourceMappingURL=IslandSurvivalIsland.d.ts.map