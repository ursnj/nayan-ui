export declare const WORDS: readonly string[];
//# sourceMappingURL=WordSearchWords.d.ts.map