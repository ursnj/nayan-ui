import { type Camera, World } from 'nayan-ui';
import type { GameTheme } from '../../services/ThemeService';
import type { GamePhase as Phase } from '../shared/useEngineGame';
import { type Layout } from './ColorSwitchConstants';
import { type Scene } from './ColorSwitchScene';
/** jump: a hop; pass: a ring cleared; color: a star caught; crash: the wrong colour, or off the screen. */
export type GameEvent = 'jump' | 'pass' | 'color' | 'crash';
export type Ring = {
    id: string;
    y: number;
    rotationSpeed: number;
    rotationBase: number;
    passed: boolean;
};
export type Star = {
    id: string;
    y: number;
    colorIndex: number;
};
export declare const ringRotation: (r: Ring, tick: number) => number;
export declare function createGame(theme: GameTheme): {
    world: World;
    camera: Camera;
    theme: GameTheme;
    layout: Layout | null;
    scene: Scene | null;
    phase: Phase;
    rings: Ring[];
    stars: Star[];
    ballY: number;
    velocity: number;
    /** The ball's burst: play stops and the round ends a moment later. */
    crashed: boolean;
    color: number;
    cameraY: number;
    /** Physics steps taken; every ring's rotation follows from it. */
    tick: number;
    highestY: number;
    passed: number;
    /** Score and the countdown live in the engine (Rust), advanced by world.update. */
    readonly score: number;
    readonly timeLeft: number;
    won: boolean;
    pending: number;
    onPhase: (_p: Phase) => void;
    onEvent: (_e: GameEvent) => void;
};
export type Game = ReturnType<typeof createGame>;
/** Lays the field out for the view (first layout, header height, rotation); a fresh preview if nothing's laid out yet. */
export declare function setLayout(g: Game, l: Layout): void;
export declare function setTheme(g: Game, theme: GameTheme): void;
/** Starts from the preview: a random colour, the waiting rings kept (extended to five), the ball already hopping. */
export declare function start(g: Game): void;
/** Back to the idle preview (Stop, Play Again). The world, and the GPU view drawing it, are kept. */
export declare function reset(g: Game): void;
/** The ball and rings in fixed steps; the engine steps the world after. */
export declare function tick(g: Game, dt: number): void;
/** A finger down hops the ball up. */
export declare function jump(g: Game): void;
//# sourceMappingURL=ColorSwitchGame.d.ts.map