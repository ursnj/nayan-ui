import { type Camera, type DragEvent, World } from 'nayan-ui';
import type { GameTheme } from '../../services/ThemeService';
import type { GamePhase as Phase } from '../shared/useEngineGame';
import { GhostMode, type Layout } from './PacManConstants';
import { type Scene } from './PacManScene';
export type GameEvent = 'chomp' | 'pellet' | 'fruit' | 'eatGhost' | 'eatGhostCombo' | 'lifeLost';
export declare function createGame(theme: GameTheme): {
    world: World;
    camera: Camera;
    theme: GameTheme;
    layout: Layout | null;
    scene: Scene | null;
    phase: Phase;
    maze: import("./PacManRules").Maze;
    pacman: import("./PacManRules").Pacman;
    ghosts: import("./PacManRules").Ghost[];
    fruit: {
        x: number;
        y: number;
    } | null;
    fruitExpireAt: number;
    /** Score, lives and the countdown live in the engine (Rust), advanced by world.update. */
    readonly score: number;
    readonly lives: number;
    won: boolean;
    combo: number;
    mode: GhostMode.SCATTER | GhostMode.CHASE;
    modeTimer: number;
    elapsed: number;
    readonly timeLeft: number;
    clock: number;
    pacPending: number;
    ghostPending: number;
    anchor: [number, number] | null;
    onPhase: (_p: Phase) => void;
    /** Lives as they're lost (pushed at once, not on the next world step). */
    onLives: (_l: number) => void;
    onEvent: (_e: GameEvent) => void;
};
export type Game = ReturnType<typeof createGame>;
export declare function setLayout(g: Game, l: Layout): void;
export declare function setTheme(g: Game, theme: GameTheme): void;
export declare function start(g: Game): void;
export declare function reset(g: Game): void;
export declare function drag(g: Game, { phase, x, y }: DragEvent): void;
/** Pac-Man and the ghosts on the game's own clock; the engine steps the world after. */
export declare function tick(g: Game, dt: number): void;
//# sourceMappingURL=PacManGame.d.ts.map