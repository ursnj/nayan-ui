import { type Color, type Entity, type TransformBatch, type World } from 'nayan-ui';
import type { GameTheme } from '../../services/ThemeService';
import { type View3D } from '../shared/EngineMeadow';
import { type Layout, type ObstacleKind } from './DinoJumpConstants';
/** An obstacle standing on the ground line, its box's left edge at screen x. */
export declare function spawnObstacle(world: World, v: View3D, l: Layout, kind: ObstacleKind, x: number, tint: Color): Entity;
export declare function placeObstacle(world: World, v: View3D, l: Layout, e: Entity, kind: ObstacleKind, x: number, updates?: TransformBatch): void;
export type DinoView = {
    root: Entity;
    body: Entity;
    near: Entity;
    far: Entity;
};
/** The dino, its feet on screen point (x, y) (its box's bottom middle). */
export declare function spawnDino(world: World, v: View3D, x: number, y: number, tint: Color): DinoView;
export declare const dinoCentre: (x: number) => number;
export declare function placeDino(world: World, v: View3D, d: DinoView, x: number, y: number): void;
/** Running: the legs swing in turn and the body bobs; otherwise they hold a pose (tucked in the air). */
export declare function setGait(world: World, v: View3D, d: DinoView, gait: 'stand' | 'run' | 'air'): void;
/** A hit: the dino flashes red and shakes. */
export declare function hurtDino(world: World, d: DinoView, tint: Color): void;
/** A mushroom eaten: a golden glow. */
export declare function cheerDino(world: World, d: DinoView, tint: Color): void;
/** A puff of sand at screen point (x, y): kicked up running, or a bigger one landing. */
export declare function dust(world: World, v: View3D, x: number, y: number, big: boolean): void;
/** Bits fly where the dino hit an obstacle (green and sand for a cactus, red and white for a mushroom). */
export declare function hitBurst(world: World, v: View3D, x: number, y: number, mushroom: boolean): void;
export type Tiles = {
    roots: Entity[];
};
/** Three desert tiles side by side, each its floor with its plants and rocks as children. */
export declare function spawnDesert(world: World, theme: GameTheme, runZ: number): Tiles;
/** Scrolls the desert `travelled` metres: each tile wraps round to the far side once it's well out of view. */
export declare function placeDesert(world: World, t: Tiles, travelled: number): void;
export declare function removeDesert(world: World, t: Tiles): void;
//# sourceMappingURL=DinoJumpScene.d.ts.map