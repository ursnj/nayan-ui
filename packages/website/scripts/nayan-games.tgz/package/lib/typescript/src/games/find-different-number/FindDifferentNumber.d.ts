export declare const FindDifferentNumber: import("react").FC<import("../..").GameProps>;
//# sourceMappingURL=FindDifferentNumber.d.ts.map