import type { TiltView } from '../shared/EngineTilt';
export declare const MIN_POINT_DISTANCE = 4;
export declare const STROKE_RADIUS = 2.5;
export declare const FIT_TRACE_TIME = 0.65;
export declare const TINT_TIME = 0.38;
export declare const COLORS: {
    readonly STROKE: "#00d4ff";
    readonly SUCCESS: "#4ecca3";
    readonly FAIL: "#ff6b6b";
    readonly GUIDE: "#ffffff";
    readonly UI: "#00d4ff";
};
/**
 * The camera looks straight down: the guide must be a true circle on screen, since the drawing is
 * scored in view points. The depth shows in the plate's bevel, the raised guide ring and the round tube.
 */
export declare const TILT = 0;
export declare const LIGHT: import("nayan-ui").Light;
export type Layout = TiltView & {
    cx: number;
    cy: number;
    radius: number;
};
/**
 * The guide circle: half the game width (the view less 30 points, at most 500) across, centred 55
 * points below the middle of the screen, as the original canvas put it. On a screen too short for that, it
 * shrinks and moves to fit between the scoreboard and the controls.
 */
export declare function getLayout(width: number, height: number, offset: number): Layout;
//# sourceMappingURL=PerfectCircleConstants.d.ts.map