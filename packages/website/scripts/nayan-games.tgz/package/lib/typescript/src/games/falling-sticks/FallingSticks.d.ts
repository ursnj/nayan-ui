export declare const FallingSticks: import("react").FC<import("../..").GameProps>;
//# sourceMappingURL=FallingSticks.d.ts.map