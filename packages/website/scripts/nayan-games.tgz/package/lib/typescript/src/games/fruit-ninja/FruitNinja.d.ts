export declare const FruitNinja: import("react").FC<import("../..").GameProps>;
//# sourceMappingURL=FruitNinja.d.ts.map