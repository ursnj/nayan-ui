export interface Hole {
    id: string;
    row: number;
    col: number;
    boltId: string | null;
}
export interface Bolt {
    id: string;
    row: number;
    col: number;
    originalRow: number;
    originalCol: number;
    holeId: string | null;
}
export interface Plank {
    id: string;
    orientation: 'horizontal' | 'vertical';
    startRow: number;
    startCol: number;
    length: number;
    color: string;
    zIndex: number;
}
export interface PuzzleState {
    holes: Hole[];
    bolts: Bolt[];
    planks: Plank[];
}
export declare const getPlankPositions: (plank: Plank) => {
    row: number;
    col: number;
}[];
export declare const plankCoversPosition: (plank: Plank, row: number, col: number) => boolean;
export declare const generatePuzzle: () => PuzzleState;
export declare const getBoltById: (boltId: string, bolts: Bolt[]) => Bolt | null;
export declare const getBoltAtPosition: (row: number, col: number, bolts: Bolt[]) => Bolt | null;
export declare const getHoleById: (holeId: string, holes: Hole[]) => Hole | null;
export declare const getPlanksAtPosition: (row: number, col: number, planks: Plank[]) => Plank[];
export declare const getPlankIntersections: (planks: Plank[]) => {
    row: number;
    col: number;
}[];
export declare const getValidBoltPositions: (planks: Plank[]) => {
    row: number;
    col: number;
}[];
export declare const getEmptyGridHoles: (_planks: Plank[], bolts: Bolt[]) => {
    row: number;
    col: number;
}[];
export declare const canSelectBolt: (bolt: Bolt, planks: Plank[]) => boolean;
export declare const canPlaceBoltInHole: (hole: Hole) => boolean;
export declare const moveBoltToHole: (boltId: string, holeId: string, bolts: Bolt[], holes: Hole[]) => {
    bolts: Bolt[];
    holes: Hole[];
};
export declare const moveBoltToGrid: (boltId: string, row: number, col: number, bolts: Bolt[], holes: Hole[]) => {
    bolts: Bolt[];
    holes: Hole[];
};
export declare const checkPlankRemoval: (planks: Plank[], bolts: Bolt[]) => {
    removedPlanks: Plank[];
    remainingPlanks: Plank[];
};
export declare const isPuzzleComplete: (planks: Plank[]) => boolean;
//# sourceMappingURL=NutsAndBoltsRules.d.ts.map