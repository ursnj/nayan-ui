import { type Color, type Entity, type Model, type Vec3, type World } from 'nayan-ui';
/** The scale that makes a block `size` (width, height, depth): for animating one back to full size (pops, grow-ins). */
export declare const raisedBlockScale: (size: Vec3) => Vec3;
/** The mesh and scale `spawnRaisedBlock` draws a block `size` with: to bake its picture. */
export declare const raisedBlockParts: (size: Vec3) => {
    model: Model;
    scale: Vec3;
};
export type BlockOptions = {
    /** The block's centre. */
    position: Vec3;
    /** Width, height and depth. */
    size: Vec3;
    color: Color;
    parent?: Entity;
    /** The block's scale as a fraction of `size` (0 to grow it in). Default 1. */
    grow?: number;
    /** Its soft shadow on the board. Default true. */
    shadow?: boolean;
};
/** A block and its shadow; the block is returned (scale, move, tint and despawn it as one). */
export declare function spawnRaisedBlock(world: World, { position, size, color, parent, grow, shadow }: BlockOptions): Entity;
//# sourceMappingURL=EngineBlocks.d.ts.map