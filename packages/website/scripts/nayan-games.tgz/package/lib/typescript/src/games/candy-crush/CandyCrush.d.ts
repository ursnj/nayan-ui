import { type GameProps } from '../../services/UtilsService';
export declare const CandyCrush: import("react").FC<GameProps>;
//# sourceMappingURL=CandyCrush.d.ts.map