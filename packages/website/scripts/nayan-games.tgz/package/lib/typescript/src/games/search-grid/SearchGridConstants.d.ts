import type { TiltView } from '../shared/EngineTilt';
export declare const GRID_SIZE = 10;
export declare const ITEMS = 8;
export declare const TIME_LIMIT = 300;
export declare const FIND_POINTS = 1000;
export type Cell = {
    row: number;
    col: number;
};
export type Placed = {
    text: string;
    cells: Cell[];
};
/**
 * A fresh grid: `ITEMS` entries from `list` placed in random directions (each tries the directions,
 * then the positions, in a random order, and may cross another where the characters agree), the rest
 * filled from `alphabet`.
 */
export declare function generate(list: readonly string[], alphabet: string): {
    grid: string[][];
    placed: Placed[];
};
/** The cells from one to another along a row, column or diagonal; none if they're not on one line. */
export declare function lineCells(from: Cell, to: Cell): Cell[];
/**
 * The not-yet-found entry the selected cells spell exactly (either way along the line), if any. Any line
 * spelling it counts, not only where it was hidden: with few characters (Number Search's ten digits) an
 * entry often turns up again by chance, and finding that copy is just as right.
 */
export declare function matchOf(cells: Cell[], grid: string[][], placed: Placed[], found: ReadonlySet<string>): Placed | null;
/** One per entry, by its place in the list: its found highlight and its chip. */
export declare const HIGHLIGHT_COLORS: string[];
export declare const SELECTION_COLOR = "rgba(77, 166, 255, 0.85)";
export declare const TILE_COLOR = "#FFFFFF";
export declare const INK_COLOR = "#333333";
export declare const CLASSIC_BOARD = "rgba(255, 255, 255, 0.3)";
/** The camera leans back from straight down, so the tiles and the lettering stand up off the board. */
export declare const TILT = 0.3;
/** Lit from the upper left; surfaces facing up off the board (+z) keep their exact color. */
export declare const LIGHT: import("nayan-ui").Light;
export declare const SELECT_TIME = 0.12;
export declare const FIND_TIME = 0.32;
/** Room above the board for the list of entries to find. */
export declare const LIST_HEIGHT = 52;
export type Layout = TiltView & {
    boardSize: number;
    cell: number;
    padding: number;
    /** Height of the tiles' top faces. */
    tileTop: number;
    /** Where the list goes (view points, from the top). */
    listTop: number;
    listWidth: number;
};
/** The board as wide as the game area (as the original board), the list above it, both centred under the scoreboard. */
export declare function getLayout(width: number, height: number, offset: number): Layout;
/** A cell's centre on the board (row 0 along the top), in world units. */
export declare function cellCentre(l: Layout, row: number, col: number): [number, number];
/** The cell under a board point (world units), or null off the grid. */
export declare function cellAt(l: Layout, x: number, y: number): Cell | null;
//# sourceMappingURL=SearchGridConstants.d.ts.map