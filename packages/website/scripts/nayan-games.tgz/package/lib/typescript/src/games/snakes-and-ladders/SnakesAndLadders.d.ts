export declare const SnakesAndLadders: import("react").FC<import("../..").GameProps>;
//# sourceMappingURL=SnakesAndLadders.d.ts.map