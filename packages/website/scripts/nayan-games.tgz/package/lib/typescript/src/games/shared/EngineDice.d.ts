import { type Entity, type Model, type Quat, type Vec3, type World } from 'nayan-ui';
/** The die, one unit across, centred. Made once per app. */
export declare function dieMesh(): Model;
/** The die showing `value` toward a camera leaning back by `tilt`, turned `twist` round its up axis. */
export declare const dieRotation: (tilt: number, value: number, twist?: number) => Quat;
export type DieRoll = {
    die: Entity;
    shadow: Entity;
    /** Where the die rests (its centre), and its shadow's place and size there. */
    rest: Vec3;
    shadowAt: Vec3;
    shadowScale: Vec3;
    /** The die's edge, in world units. */
    size: number;
    /** The camera's lean (the rolled face ends up facing it). */
    tilt: number;
    value: number;
    /** Seconds, from the toss to the die at rest. */
    duration: number;
    /** For delayed effects (the landing dust): whether the scene is gone. */
    disposed?: () => boolean;
};
/** Rolls the die to `value`: tossed up, tumbling, bouncing to rest on its spot showing `value`. */
export declare function rollDie(world: World, r: DieRoll): void;
//# sourceMappingURL=EngineDice.d.ts.map