export declare const SpaceFighter: import("react").FC<import("../..").GameProps>;
//# sourceMappingURL=SpaceFighter.d.ts.map