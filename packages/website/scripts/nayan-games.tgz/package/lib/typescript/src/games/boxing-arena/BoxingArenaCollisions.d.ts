import type { Entity, World } from 'nayan-ui';
import { type Fight } from './BoxingArenaRules';
export type ContactBox = [number, number, number, number, number, number];
type Part = 'left' | 'right' | 'torso' | 'head';
type Envelope = Record<Part, ContactBox>;
type RigActor = {
    mesh: Entity;
    loaded: boolean;
};
export type Collisions = ReturnType<typeof createCollisions>;
export declare const contactOverlap: (a: ContactBox, b: ContactBox) => boolean;
/** Separates the fighters by `penetration`, keeping an attacker planted and moving whoever the stage edge doesn't stop. */
export declare function separateFighters(left: number, right: number, penetration: number, attacking: -1 | 0 | 1): readonly [number, number];
/** Samples the fighters' rendered rigs each frame; `actors[i]` draws `fight.fighters[i]`. */
export declare function createCollisions(world: World, actors: readonly RigActor[]): {
    resolve(fight: Fight, after: number): void;
    /** Exposed for integration checks; the game never draws collision helpers. */
    bounds(index: 0 | 1): Envelope;
};
export {};
//# sourceMappingURL=BoxingArenaCollisions.d.ts.map