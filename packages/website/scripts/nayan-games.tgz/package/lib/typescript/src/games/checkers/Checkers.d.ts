export declare const Checkers: import("react").FC<import("../..").GameProps>;
//# sourceMappingURL=Checkers.d.ts.map