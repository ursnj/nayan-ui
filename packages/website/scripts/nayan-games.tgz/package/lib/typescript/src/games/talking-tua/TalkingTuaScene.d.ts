import { type Camera, type Entity, type Font, type LoadedModel, type World } from 'nayan-ui';
import type { GameTheme } from '../../services/ThemeService';
/** A real tiled dance floor; the room remains visible when the music stops. */
export declare const TILE_SIZE = 0.68;
export declare const DISCO_COLORS: readonly (readonly [number, number, number, number])[];
/** Tappable speaker cabinets, outside the walking circle. */
export declare const SPEAKERS: [number, number, number][];
/** The fruit bowl, on the floor at Tua's left (the viewer's right), and what's in it. */
export declare const BOWL: {
    position: [number, number, number];
    radius: number;
    height: number;
};
export interface Scene {
    character: Entity;
    floor: Entity;
    bowl: Entity;
    tiles: Entity[];
    discoBall: Entity;
    speakerCones: Entity[];
    roomLights: Entity[];
    font: Font;
    camera: Camera;
    /** The frame the layout chose, before zoom (target height and distance). */
    frame: {
        targetY: number;
        distance: number;
    };
    /** Pinch zoom: 1 is the framed view; larger is closer. */
    zoom: number;
    /** The theme's tile colour (the dance floor's dim tiles). */
    tileColor: [number, number, number, number];
    /** The view's width in points (where a touch is, left to right, for Tua to look at). */
    viewWidth: number;
}
export declare function buildScene(world: World, model: LoadedModel, font: Font, theme: GameTheme): Scene;
/** Frames Tua between the scoreboard and the controls; returns the scene's input band (points). */
export declare function layoutScene(scene: Scene, width: number, height: number, offset: number): {
    top: number;
    bottom: number;
};
/** Closest and farthest zoom. */
export declare const ZOOM_RANGE: readonly [0.75, 1.8];
/** Sets the camera for `scene.zoom`: closer zooms move towards Tua's head. */
export declare function applyZoom(scene: Scene): void;
export declare function setSceneTheme(world: World, scene: Scene, theme: GameTheme): void;
/** Builds the bowl's mesh ahead of the first visit (the game loader advances one builder per frame). */
export declare function warmAssets(): Iterable<() => unknown>;
/** Animate the party fixtures from the game clock; no timers or mesh allocation during play. */
export declare function stepRoom(world: World, scene: Scene, dancing: boolean, time: number, beat: number): void;
//# sourceMappingURL=TalkingTuaScene.d.ts.map