export declare const GRID = 10;
export declare const CELLS: number;
export declare const DIFFERENT_COUNT = 10;
export type Puzzle = {
    numbers: number[];
    different: Set<number>;
};
export declare function generatePuzzle(): Puzzle;
//# sourceMappingURL=FindDifferentNumberRules.d.ts.map