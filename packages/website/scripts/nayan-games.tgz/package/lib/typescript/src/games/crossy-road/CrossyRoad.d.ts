export declare const CrossyRoad: import("react").FC<import("../..").GameProps>;
//# sourceMappingURL=CrossyRoad.d.ts.map