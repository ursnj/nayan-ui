import { type Move, type Position } from './ChessMastersRules';
export type OpponentSearch = {
    best: Move;
    steps: Generator<void, void>;
};
export declare function startSearch(position: Position, moves: Move[], repetitions: ReadonlyMap<string, number>, random?: () => number): OpponentSearch;
//# sourceMappingURL=ChessMastersAI.d.ts.map