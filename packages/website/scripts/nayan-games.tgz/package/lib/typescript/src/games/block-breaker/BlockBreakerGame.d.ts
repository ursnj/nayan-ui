import { type Camera, type Entity, World } from 'nayan-ui';
import type { GameTheme } from '../../services/ThemeService';
import type { GamePhase as Phase } from '../shared/useEngineGame';
import { type Layout, PowerUpType } from './BlockBreakerConstants';
import { type BallView, type Paddle, type Scenery } from './BlockBreakerScene';
type Brick = {
    row: number;
    col: number;
    hits: number;
    entity: Entity | null;
};
type Ball = {
    x: number;
    y: number;
    vx: number;
    vy: number;
    view: BallView | null;
};
type PowerUp = {
    type: PowerUpType;
    x: number;
    y: number;
    entity: Entity | null;
};
export declare function createGame(theme: GameTheme): {
    world: World;
    camera: Camera;
    theme: GameTheme;
    colors: import("./BlockBreakerScene").PieceColors;
    layout: Layout | null;
    scenery: Scenery | null;
    phase: Phase;
    /** Score, lives and the countdown live in the engine (Rust), advanced by world.update. */
    readonly score: number;
    readonly lives: number;
    readonly timeLeft: number;
    won: boolean;
    /** Game clock, seconds: drives the delayed steps (they pause with the frame loop). */
    time: number;
    bricks: Brick[];
    balls: Ball[];
    powerUps: PowerUp[];
    /** Bricks broken since the ball last touched the paddle. */
    combo: number;
    paddle: Paddle | null;
    /** Paddle centre (board points), the width it collides with, and where a drag started. */
    paddleX: number;
    paddleWidth: number;
    dragFrom: number;
    /** The next wall to appear builds in. */
    intro: boolean;
    /** Game seconds the current intro has been playing (-1 until its board spawns). */
    introAge: number;
    onPhase: (_p: Phase) => void;
    onWall: () => void;
    onPaddle: () => void;
    onBrickHit: () => void;
    onBrickBreak: () => void;
    onCombo: () => void;
    onPowerUp: () => void;
    onLaunch: () => void;
    onLoseLife: () => void;
    onWin: () => void;
    onLose: () => void;
};
export type Game = ReturnType<typeof createGame>;
/** Lays the scene out for the view (first layout, header height, rotation): rebuilt from the run's state. */
export declare function setLayout(g: Game, l: Layout): void;
/** A new theme: the background and board are repainted and the ball and paddle recolored. */
export declare function setTheme(g: Game, theme: GameTheme): void;
export declare function start(g: Game): void;
/** A new wall, lives and timer (Stop, Play Again). The world, and the GPU view drawing it, are kept. */
export declare function reset(g: Game): void;
export declare function dispose(g: Game): void;
/** The balls and power-ups; the engine steps the world after. */
export declare function tick(g: Game, dt: number): void;
export declare function dragStart(g: Game): void;
/** Slides the paddle by the drag's distance, kept inside the board. */
export declare function dragMove(g: Game, dx: number): void;
export {};
//# sourceMappingURL=BlockBreakerGame.d.ts.map