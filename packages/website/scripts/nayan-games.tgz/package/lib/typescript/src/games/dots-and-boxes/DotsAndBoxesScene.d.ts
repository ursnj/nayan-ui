import { type Entity, type World } from 'nayan-ui';
import type { GameTheme } from '../../services/ThemeService';
import { type Layout } from './DotsAndBoxesConstants';
export type Owner = 1 | 2;
export type LineKind = 'h' | 'v';
export declare function boxCentre(l: Layout, row: number, col: number): [number, number];
export type Board = {
    backdrop: Entity;
    panel: Entity;
    rim: Entity | null;
    studs: Entity[];
    /** One per line, in the game's line order. */
    slots: Entity[];
};
/** The backdrop, the board and its rim, the studs and every line's groove. `lines` lists them in the game's order. */
export declare function buildBoard(world: World, l: Layout, theme: GameTheme, lines: readonly {
    kind: LineKind;
    row: number;
    col: number;
}[]): Board;
export declare function removeBoard(world: World, b: Board): void;
/** A new theme: backdrop, board, rim and grooves repainted; the studs, rods and tiles keep their colors. */
export declare function setBoardTheme(world: World, l: Layout, b: Board, theme: GameTheme): void;
/** A played line's rod; with `animate`, it drops in and grows out from its middle with a bright flash. */
export declare function spawnRod(world: World, l: Layout, kind: LineKind, row: number, col: number, owner: Owner, animate: boolean): Entity;
/** A claimed box's tile; with `animate`, it springs up out of the board and throws a little confetti. */
export declare function spawnTile(world: World, l: Layout, row: number, col: number, owner: Owner, animate: boolean): Entity;
/** Confetti over the board when you win. */
export declare function celebrate(world: World, l: Layout): void;
/** Hides a line's groove under its rod (or shows it again on a reset). */
export declare function showSlot(world: World, b: Board, index: number, on: boolean): void;
//# sourceMappingURL=DotsAndBoxesScene.d.ts.map