/** Asset loaders warm the engine before mounting a game, so it can draw immediately. */
export declare const EngineReadyContext: import("react").Context<boolean>;
//# sourceMappingURL=EngineReadyContext.d.ts.map