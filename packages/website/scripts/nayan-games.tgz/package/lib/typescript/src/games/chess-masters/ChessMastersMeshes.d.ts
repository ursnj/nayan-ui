import { type Piece } from './ChessMastersRules';
export declare const pieceMesh: (piece: Piece) => import("nayan-ui").Model;
//# sourceMappingURL=ChessMastersMeshes.d.ts.map