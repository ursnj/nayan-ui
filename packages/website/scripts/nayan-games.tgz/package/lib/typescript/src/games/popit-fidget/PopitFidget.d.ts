export declare const PopitFidget: import("react").FC<import("../..").GameProps>;
//# sourceMappingURL=PopitFidget.d.ts.map