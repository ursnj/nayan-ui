import type { TiltView } from '../shared/EngineTilt';
export declare const TIME_LIMIT = 120;
export declare const POINTS_PER_PUZZLE = 5000;
/** The grid is 7 x 7 on a phone, 8 x 8 on a tablet (as the original game decided it). */
export declare const gridSizeFor: (tablet: boolean) => 8 | 7;
export declare enum PipeType {
    EMPTY = "empty",
    STRAIGHT = "straight",
    CORNER = "corner",
    CROSS = "cross",
    T_SHAPE = "t-shape",
    SOURCE = "source",
    SINK = "sink"
}
/** Open sides, as a bitmask. */
export declare const DIRECTION: {
    readonly TOP: 1;
    readonly RIGHT: 2;
    readonly BOTTOM: 4;
    readonly LEFT: 8;
};
/** Each piece's open sides at rotations 0..3 (a quarter turn clockwise each). */
export declare const PIPE_OPENINGS: Record<PipeType, number[]>;
export declare const TURN_TIME = 0.2;
export declare const FLOW_STEP = 0.045;
export declare const WIN_STEP = 0.03;
/** The camera leans back from straight down, so the pipes stand up off their tiles. */
export declare const TILT = 0.32;
/** Lit from the upper left; surfaces facing up off the board (+z) keep their exact color. */
export declare const LIGHT: import("nayan-ui").Light;
export declare const COLORS: {
    readonly PIPE: "#8B9DC3";
    readonly WATER: "#4FC3F7";
    readonly SOURCE: "#4CAF50";
    readonly SINK: "#FF7043";
    readonly CLASSIC_BOARD: "rgba(255, 255, 255, 0.30)";
    readonly CLASSIC_CELL: "rgba(255, 255, 255, 0.10)";
};
export type Layout = TiltView & {
    size: number;
    cell: number;
    padding: number;
    board: number;
};
/** Whole-point cells as wide as the game area allows (as the original board), smaller if the screen is short. */
export declare function getLayout(width: number, height: number, offset: number, size: number): Layout;
export declare const isTabletWidth: (width: number) => boolean;
/** A cell's centre on the board (row 0 along the top), in world units. */
export declare function cellCentre(l: Layout, row: number, col: number): [number, number];
//# sourceMappingURL=PipeConnectConstants.d.ts.map