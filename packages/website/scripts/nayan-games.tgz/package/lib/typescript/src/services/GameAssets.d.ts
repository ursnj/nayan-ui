import type { AssetStage, AssetTask } from './GameAssetLoader';
import { GAME_IDS, type GameThemeMode } from './UtilsService';
export declare const isHeavyGame: (id: GAME_IDS) => boolean;
export declare const areGameAssetsReady: (id: GAME_IDS, mode?: GameThemeMode) => boolean;
/** Nothing here runs until the selected game's loader has painted. */
export declare function gameAssetStages(id: GAME_IDS, mode?: GameThemeMode): AssetStage[];
/** Asset audit tooling; production opens only gameAssetStages(selectedId). */
export declare function gameAssetGroups(): {
    id: string;
    tasks(): Generator<AssetTask, void, any>;
}[];
//# sourceMappingURL=GameAssets.d.ts.map