export declare const FruitMerger: import("react").FC<import("../..").GameProps>;
//# sourceMappingURL=FruitMerger.d.ts.map