export declare const NUMBERS: readonly string[];
//# sourceMappingURL=NumberSearchNumbers.d.ts.map