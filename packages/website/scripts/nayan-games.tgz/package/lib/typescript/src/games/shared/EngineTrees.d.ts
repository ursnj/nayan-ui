import { type Color, type Entity, type Geometry, type Vec3, type World } from 'nayan-ui';
/** A seeded linear congruential generator in [0, 1): the same seed gives the same tree everywhere. */
export declare const seededRandom: (seed: number) => () => number;
export type BranchingTreeOptions = {
    seed: number;
    /** Where the trunk's tip is (metres, before the entity's scale). */
    height: number;
    /** How far the trunk may lean at its tip, either way. */
    lean?: number;
    trunkRadius?: number;
    trunkSides?: number;
    /** Where the trunk starts (below 0 buries its foot, so it meets sloping ground all round; -0.3 by default). */
    base?: number;
    /** Simple surface roots out of the foot's stronger lobes (on by default), and the sides round each. */
    roots?: boolean;
    rootSides?: number;
    branches?: number;
    branchSides?: number;
    /** Tube smoothing (extra rings between path points): the trunk's and each branch's. */
    trunkSmoothness?: number;
    branchSmoothness?: number;
    /** The lowest branch leaves the trunk at this fraction of its height; each next one this much higher. */
    crownBase?: number;
    crownStep?: number;
    /** A branch's reach from the trunk (plus up to a metre more, shorter toward the top). */
    reach?: number;
    trunkColor?: Color;
    branchColor?: Color;
    /** Bark texture repeats per metre up the trunk. */
    barkRepeat?: number;
    /**
     * Called for each branch tip, lowest branch first (its main tip, then its fork's), with the tip,
     * its direction from the trunk (unit, level), the tree's random source and the tip's `share` of the
     * branch's leaves (the main tip carries most): add those leaves. Its draws shape the next branch, so
     * a given seed and callback always give the same tree.
     */
    foliage: (tip: Vec3, outward: [number, number], rand: () => number, share: number) => void;
};
/** The tree's bark (trunk and branches) as one geometry; `foliage` receives every branch and fork tip. */
export declare function branchingTree(o: BranchingTreeOptions): Geometry;
/** A small curved, pointed leaf (two-sided, 8 triangles), `shade` times `color`. */
export declare function shapedLeaf(center: Vec3, length: number, width: number, yaw: number, tilt: number, shade: number, color?: Color): Geometry;
/**
 * A leaf spray: a two-sided square card `size` across for an alpha leaf texture, turned `yaw` about
 * the vertical and tipped `tilt` from level, lit along `normal` (outward and up, so a crown shades
 * round like a volume rather than flat), tinted `shade`.
 */
export declare function leafCard(center: Vec3, size: number, yaw: number, tilt: number, shade: number, normal: Vec3): Geometry;
export type LeafSprays = {
    /** Seeds the sprays' own random source: the trunk and branches don't depend on the foliage. */
    seed?: number;
    /** Sprays for each branch, shared between its tip and its fork. */
    perBranch?: number;
    /** How far round the tip (metres) and how far above or below it they hang. */
    spread?: number;
    rise?: number;
    /** A spray's size across, from `size[0]` to `size[1]`. */
    size?: [number, number];
};
export type BroadleafTreeOptions = Omit<BranchingTreeOptions, 'foliage'> & {
    sprays?: LeafSprays;
};
/**
 * A broadleaf tree: its bark (trunk and forking branches; texture with a bark image) and its crown (leaf
 * sprays round each branch tip, facing outward and up, darker toward the trunk; texture with the alpha
 * leaf sprays). Both come from `options.seed`, so a game builds and caches them as two meshes.
 */
export declare function broadleafTree(options: BroadleafTreeOptions): {
    bark: Geometry;
    crown: Geometry;
};
/** How far a trunk of `trunkRadius` spreads at the soil, with its roots or (`roots` false, conifers) just its lobed foot (metres at scale 1), for `treeFootY`. */
export declare const footReach: (trunkRadius: number, roots?: boolean) => number;
/** The ground's tilt at (x, z): the rotation taking straight up to its surface normal. */
export declare function groundTilt(ground: (x: number, z: number) => number, x: number, z: number): import("nayan-ui").Quat;
/**
 * A tree's soft contact shadow on the ground under it (`radius` metres, darkest `opacity` in the
 * middle), lying along the slope: what makes a trunk look planted rather than stood on the terrain.
 */
export declare function spawnTreeShadow(world: World, ground: (x: number, z: number) => number, x: number, z: number, radius: number, opacity?: number): Entity[];
/**
 * Where to stand a tree on uneven ground: the lowest ground under its trunk and round its flared
 * foot (`reach` metres out, see `footReach`), so no side of it hangs in the air on a slope; the uphill
 * side just sinks deeper.
 */
export declare function treeFootY(ground: (x: number, z: number) => number, x: number, z: number, reach: number): number;
export type ConiferTreeOptions = {
    /** Seeds the crown (the trunk and its whorls are the same for every seed, so styles can share one). */
    seed: number;
    /** The trunk's tip (metres, before the entity's scale). */
    height?: number;
    /** Where the trunk starts: below 0 buries its foot for sloping ground. */
    base?: number;
    trunkRadius?: number;
    trunkSides?: number;
    /** Whorls of drooping branches up the trunk, from `branchBase` (fraction of the height), each `branchStep` higher. */
    branches?: number;
    branchBase?: number;
    branchStep?: number;
    /** The lowest whorl's reach (metres); higher ones are shorter. */
    branchReach?: number;
    /** A whorl branch's thickness where it leaves the trunk (metres). */
    branchRadius?: number;
    branchSides?: number;
    /** Needle cards in the crown, from `crownBase` up `crownHeight` (fractions of the height). */
    cards?: number;
    crownBase?: number;
    crownHeight?: number;
    /** The crown's reach at its foot (metres) and how much of it is left at the top (1 - `taper`). */
    crownReach?: number;
    taper?: number;
};
/**
 * A conifer: its bark (a gently crooked trunk with a flared foot, and whorls of branches drooping low
 * down and lifting near the top) and its crown (needle
 * cards spiralling up it, the golden angle apart, wide at the foot and narrow at the top, tipped up
 * a little; native-built). Texture the crown with an alpha needle spray (`textures/pine.png`).
 */
export declare function coniferTree(options: ConiferTreeOptions): {
    bark: Geometry;
    crown: Geometry;
};
//# sourceMappingURL=EngineTrees.d.ts.map