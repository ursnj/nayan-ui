export type Body = {
    id: string;
    typeId: number;
    r: number;
    /** Collision radius. */
    cr: number;
    x: number;
    y: number;
    vx: number;
    vy: number;
    /** Rolling angle (radians, clockwise on screen). */
    angle: number;
    /** x at the start of the step, for the roll. */
    px: number;
    /** When it entered the glass (ms on the game's clock): one still falling in isn't the pile. */
    born: number;
};
export type Merge = {
    a: Body;
    b: Body;
    made: Body;
};
export declare const radiusOf: (typeId: number) => number;
export declare function makeBody(id: string, typeId: number, x: number, y: number, vy: number, born: number): Body;
/** What a step left behind: the overflow count carried between steps, and how close the pile is to the top. */
export type StepState = {
    overflowSteps: number;
    danger: number;
    merges: number;
    generation: number;
};
/**
 * One 60 Hz step. Returns a merge if one happened (at most one a step: the step ends there, as before)
 * and sets `out.outcome` on a win or an overflow. Merged fruits leave `list` at once (the original list kept
 * them, out of the simulation, until their node unmounted: they changed nothing).
 */
export declare function step(list: Body[], now: number, st: StepState, out: {
    outcome: 'win' | 'lose' | null;
}): Merge | null;
//# sourceMappingURL=FruitMergerRules.d.ts.map