import { type GameProps } from '../../services/UtilsService';
export declare const TalkingTua: import("react").FC<GameProps>;
//# sourceMappingURL=TalkingTua.d.ts.map