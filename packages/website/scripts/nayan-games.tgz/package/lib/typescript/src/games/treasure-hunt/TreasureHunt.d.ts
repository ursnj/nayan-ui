import { type GameProps } from '../../services/UtilsService';
/** Shared Playtura chrome and lifecycle around the imported explorer and procedural wilderness. */
export declare const TreasureHunt: import("react").FC<GameProps>;
//# sourceMappingURL=TreasureHunt.d.ts.map