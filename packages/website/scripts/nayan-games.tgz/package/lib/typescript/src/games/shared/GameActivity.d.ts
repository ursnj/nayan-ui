import type { GameProps } from '../../services/UtilsService';
/** Hosts own navigation; the library reports play state without depending on a navigator. */
export declare const GamePlayingContext: import("react").Context<((playing: boolean) => void) | undefined>;
export declare const GameResultsContext: import("react").Context<Pick<GameProps, "resultContent" | "shouldShowResults" | "onResultsReady">>;
export declare function useGamePlaying(playing: boolean): void;
//# sourceMappingURL=GameActivity.d.ts.map