/** Hosts own navigation; the library reports play state without depending on a navigator. */
export declare const GamePlayingContext: import("react").Context<((playing: boolean) => void) | undefined>;
export declare function useGamePlaying(playing: boolean): void;
//# sourceMappingURL=GameActivity.d.ts.map