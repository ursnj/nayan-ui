import React from 'react';
import { type GameSettings } from '../services/UtilsService';
export interface GameSettingsProps {
    gameId: string;
    settings: GameSettings;
    onSettingsChange?: (settings: GameSettings) => void;
}
export declare const GameSettingsModal: React.NamedExoticComponent<GameSettingsProps>;
//# sourceMappingURL=GameSettingsModal.d.ts.map