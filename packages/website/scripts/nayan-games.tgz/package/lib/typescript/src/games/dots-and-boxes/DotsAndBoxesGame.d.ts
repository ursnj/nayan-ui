import { type Camera, type Entity, World } from 'nayan-ui';
import type { GameTheme } from '../../services/ThemeService';
import type { GamePhase as Phase } from '../shared/useEngineGame';
import { type Layout } from './DotsAndBoxesConstants';
import { type Board } from './DotsAndBoxesScene';
export type Turn = 'player' | 'opponent';
export type GameEvent = 'line' | 'box';
export declare function createGame(theme: GameTheme): {
    world: World;
    camera: Camera;
    theme: GameTheme;
    layout: Layout | null;
    board: Board | null;
    phase: Phase;
    turn: Turn;
    /** Who drew each line (0 = nobody yet). */
    lines: Uint8Array<ArrayBuffer>;
    /** Who claimed each box (0 = nobody yet). */
    boxes: Uint8Array<ArrayBuffer>;
    sideCounts: Uint8Array<ArrayBuffer>;
    drawn: number;
    rods: Entity[];
    tiles: Entity[];
    playerScore: number;
    opponentScore: number;
    won: boolean;
    onPhase: (_p: Phase) => void;
    onScores: (_player: number, _opponent: number) => void;
    onTurn: (_t: Turn) => void;
    onEvent: (_e: GameEvent, _who: Turn) => void;
};
export type Game = ReturnType<typeof createGame>;
/** Lays the scene out for the view (first layout, header height, rotation): rebuilt from the game's state. */
export declare function setLayout(g: Game, l: Layout): void;
export declare function setTheme(g: Game, theme: GameTheme): void;
export declare function start(g: Game): void;
/** A fresh board (Stop, Play Again). The world, and the GPU view drawing it, are kept. */
export declare function reset(g: Game): void;
/** Steps the world with a long frame clamped (so the engine doesn't step it again). */
export declare function tick(g: Game, dt: number): void;
/** The open line nearest a view point, if the point is close enough to it. */
export declare function lineAt(g: Game, x: number, y: number): number | null;
/** A tap: draws the line under it on your turn. */
export declare function tap(g: Game, x: number, y: number): void;
//# sourceMappingURL=DotsAndBoxesGame.d.ts.map