import type { MeadowOptions, Rig } from '../shared/EngineMeadow';
export declare const TIME_LIMIT = 120;
export declare const PASS_SCORE = 500;
export declare const STEP: number;
export declare const STEP_TOLERANCE = 0.002;
export declare const MAX_PENDING = 0.05;
export declare const BIRD_SIZE: number;
export declare const GRAVITY: number;
export declare const JUMP_VELOCITY: number;
export declare const MAX_FALL_SPEED: number;
export declare const DAMPING = 0.98;
export declare const PIPE_WIDTH: number;
export declare const PIPE_GAP: number;
export declare const PIPE_SPEED: number;
export declare const MIN_PIPE_HEIGHT: number;
export declare const FIRST_PIPE = 0.5;
export declare const PIPE_INTERVAL = 2.5;
export declare const BRICK_WIDTH: number;
export declare const BRICK_HEIGHT: number;
/** The bird leans with its speed: nose up climbing, diving as it falls (original's -30° to 90°). */
export declare const tiltFor: (velocity: number) => number;
/** Its wing lifts while climbing after a flap and tucks in as it falls. */
export declare const wingFor: (velocity: number) => number;
/** The horizon just above the bottom wall, so the hills and treeline show between the walls. */
export declare const RIG: Rig;
export declare const meadowFor: (sunY: number) => MeadowOptions;
export type Layout = {
    /** The GameView's size: the whole screen, as the original game area. */
    width: number;
    height: number;
    offset: number;
    birdX: number;
    birdStartY: number;
    /** The brick walls: the top one grows with the header; the bottom one is shorter under a header. */
    topWall: number;
    bottomWallTop: number;
};
export declare function getLayout(width: number, height: number, offset: number): Layout;
/** A pipe's gap top: on phones anywhere from just under the top wall to 60% down the playable band; on tablets near its middle. */
export declare function randomGapTop(l: Layout): number;
//# sourceMappingURL=FlappyBirdConstants.d.ts.map