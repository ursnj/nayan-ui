import type { TiltView } from '../shared/EngineTilt';
export declare const GRID_SIZE = 6;
export declare const BOX_POINTS = 2000;
export declare const PLAYER_COLOR = "#34D399";
export declare const OPPONENT_COLOR = "#F87171";
export declare const DOT_COLOR = "#D5DCE6";
export declare const CLASSIC_BOARD = "rgba(255, 255, 255, 0.25)";
export declare const CLASSIC_RIM = "rgba(255, 255, 255, 0.3)";
export declare const CLASSIC_SLOT = "rgba(255, 255, 255, 0.3)";
export declare const AI_FIRST_DELAY = 1;
export declare const AI_CHAIN_DELAY = 0.8;
export declare const LINE_TIME = 0.22;
export declare const BOX_TIME = 0.32;
/** The camera leans back this far from straight down, so the studs, rods and tiles read as 3D. */
export declare const TILT = 0.3;
/** Lit from the upper left; surfaces facing up off the board (+z) keep their exact color. */
export declare const LIGHT: import("nayan-ui").Light;
export type Layout = TiltView & {
    boardSize: number;
    /** From the board's edge to the outer dots' centres. */
    padding: number;
    /** Between neighbouring dots. */
    cell: number;
    dotRadius: number;
    lineWidth: number;
    /** Height of the board's top face. */
    boardTop: number;
};
/** The board as wide as the game area, centred between the scoreboard and the controls. */
export declare function getLayout(width: number, height: number, offset: number): Layout;
/** A dot's centre on the board (row 0 along the top), in world units. */
export declare function dotPoint(l: Layout, row: number, col: number): [number, number];
//# sourceMappingURL=DotsAndBoxesConstants.d.ts.map