import React from 'react';
import { type GameProps } from '../../services/UtilsService';
export { preloadBikeRacing } from './BikeRacingConstants';
export declare const BikeRacing: React.FC<GameProps>;
//# sourceMappingURL=BikeRacing.d.ts.map