import { type Entity, type Model, type World } from 'nayan-ui';
import type { EngineHud } from '../shared/EngineHud';
import { type NatureAssets } from './TreasureHuntConstants';
import { type Bridge, type NatureMap, type NatureState } from './TreasureHuntRules';
/** Decks, supports and guardrails use the exact span and height sampled by movement. */
export declare function spawnBridge(world: World, owner: Entity, map: NatureMap, bridge: Bridge, assets: NatureAssets): void;
export { spawnRobot, placeRobot } from './TreasureHuntModel';
export type { RobotVisual } from './TreasureHuntModel';
interface NatureMeshes {
    gem: Model;
    pineTrunk: Model;
    pine: Model[];
    /** Each birch style's own trunk and branches, under its crown. */
    birchTrunks: Model[];
    birch: Model[];
    rocks: Model[];
    grass: Model[];
    cave: Model;
}
type TerrainModels = {
    meadow: Model;
    stone: Model;
    shore: Model;
    water: Model;
};
export declare function prepareNature(): NatureMeshes;
/** Reusable scenery only: terrain profiles and seeded maps are built for the chosen run. */
export declare function warmAssets(): Iterable<() => unknown>;
export declare function terrainModels(map: NatureMap): TerrainModels;
export interface NatureVisual {
    root: Entity;
    water: Entity;
    flow: number;
}
/**
 * Keeps each generated world (layout, reachable ground, minimap and grass) in the engine's storage,
 * under this game's cache revision: a later visit to the same terrain profile restores it instead of
 * generating it again (the loader turns this on).
 */
export declare function keepWorlds(): void;
/** No second world or native entities: prepare only the next run's immutable scenery data. */
export declare function warmMapScenery(map: NatureMap): Iterable<() => void>;
/** A single owner root makes replay cleanup include every tree, grass blade and bridge. */
export declare function spawnNature(world: World, map: NatureMap, assets: NatureAssets): NatureVisual;
/** River motion shares the engine's existing frame tick. */
export declare function animateNature(world: World, nature: NatureVisual, dt: number): void;
export declare function spawnGem(world: World, x: number, y: number, z: number): Entity;
export declare function drawMiniMap(hud: EngineHud, state: NatureState): void;
//# sourceMappingURL=TreasureHuntScene.d.ts.map