import { type Color, type Entity, type Vec3, type World } from 'nayan-ui';
import type { GameTheme } from '../../services/ThemeService';
import type { PopBurstOptions } from '../shared/EngineBlasts';
import { type Layout } from './BlockBlastConstants';
/** A view point (from the top-left) at depth `z`, in world space. */
export declare const toWorld: (l: Layout, x: number, y: number, z?: number) => Vec3;
/** Centre of a board cell, in view points. */
export declare const cellCenter: (l: Layout, row: number, col: number) => [number, number];
export declare const trayZ: (l: Layout) => number;
export declare const dragZ = 80;
export type BoardColors = GameTheme['BOARD'];
/** The board: its panel and rim, the empty slots, and per-cell overlays for the drop preview. */
export type Board = {
    /** The game background (theme color and pattern), behind everything. */
    backdrop: Entity;
    rim: Entity;
    panel: Entity;
    empties: Entity[];
    /** Lines the hovered drop would complete. */
    highlights: Entity[];
    /** The hovered piece's cells (its color, or the invalid color). */
    ghosts: Entity[];
};
export declare function buildBoard(world: World, l: Layout, colors: BoardColors, theme: GameTheme): Board;
/** Repaints the board for a theme (the run carries on). */
export declare function colorBoard(world: World, b: Board, colors: BoardColors): void;
/** Shows or hides a preview overlay (`null` hides it). */
export declare function setOverlay(world: World, overlay: Entity, color: Color | null): void;
/** A placed block on the board. */
export declare function spawnBlock(world: World, l: Layout, row: number, col: number, color: Color): Entity;
/** A piece: an invisible root at its centre with one block per cell, at `scale` of board size. */
export declare function spawnPiece(world: World, l: Layout, shape: readonly (readonly number[])[], color: Color, at: [number, number], scale: number): Entity;
/** A board block's scale (for popping it away). */
export declare const blockScale: (l: Layout) => Vec3;
/** Where a cleared block's burst flies from (just in front of it) and glows (behind it, over its cell). */
export declare function blockBurst(l: Layout, row: number, col: number, color: Color): PopBurstOptions;
//# sourceMappingURL=BlockBlastScene.d.ts.map