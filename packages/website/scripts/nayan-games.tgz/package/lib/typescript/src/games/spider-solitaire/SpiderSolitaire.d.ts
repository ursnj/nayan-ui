export declare const SpiderSolitaire: import("react").FC<import("../..").GameProps>;
//# sourceMappingURL=SpiderSolitaire.d.ts.map