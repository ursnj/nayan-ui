export declare const SUITS: readonly ["hearts", "diamonds", "clubs", "spades"];
export declare const VALUES: readonly ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"];
export type Suit = (typeof SUITS)[number];
export type Value = (typeof VALUES)[number];
export type Card = {
    id: string;
    suit: Suit;
    value: Value;
    faceUp: boolean;
};
/** The 10 piles, the stock (dealt from its end) and the runs lifted out so far (each K first). */
export type Board = {
    tableau: Card[][];
    stock: Card[];
    completed: Card[][];
};
export declare const PILES = 10;
export declare const RUNS_TO_WIN = 8;
/** As the original game: always two suits. */
export declare const SUIT_COUNT = 2;
export declare const rank: (v: Value) => number;
/** A fresh deal: six cards in each of the first four piles, five in the rest, only the top ones face up; 50 left to deal. */
export declare function newBoard(): Board;
/** Descending by one all the way down (any suit), so it can be picked up together. */
export declare function isValidSequence(cards: Card[]): boolean;
/** Whether a run can go on a pile: anything on an empty one, else one rank below its face-up top card. */
export declare function canMove(b: Board, cards: Card[], to: number): boolean;
/** The run from `index` down, if it may be picked up (a single face-up card always may). */
export declare function pickable(b: Board, pile: number, index: number): Card[] | null;
/** Moves the run from `from` at `index` onto `to` (already checked), turning up the card it uncovers. */
export declare function moveRun(b: Board, from: number, index: number, to: number): void;
/** Why a row can't be dealt (an empty pile, or nothing left), or null if it can. */
export declare const dealBlocked: (b: Board) => "empty-pile" | "no-stock" | null;
/** One card face up onto every pile, from the stock's end. */
export declare function dealRow(b: Board): void;
/** Lifts a finished King-to-Ace run of one suit off the end of a pile, if there is one; returns it. */
export declare function takeCompletedRun(b: Board, pile: number): Card[] | null;
/** Deals left (each a row of 10). */
export declare const dealsLeft: (b: Board) => number;
//# sourceMappingURL=SpiderSolitaireRules.d.ts.map