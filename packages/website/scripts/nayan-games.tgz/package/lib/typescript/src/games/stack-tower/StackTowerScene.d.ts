import { type Entity, type Vec3, type World } from 'nayan-ui';
import type { GameTheme } from '../../services/ThemeService';
import { aimTilted, type TiltView } from '../shared/EngineTilt';
import { type Layout } from './StackTowerConstants';
/** How long a landing's dust and sparkles live (their longest lifetimes, `land`). */
export declare const DUST_TIME = 0.4;
export declare const SPARKLE_TIME = 0.5;
export type Scene = {
    /** The camera's share of the scroll, and the tower's (its root's), last applied. */
    cameraOffset?: number;
    rootOffset?: number;
    /** The root's height in the world: the tower slid down by its share of the scroll. */
    rootY: number;
    backdrop: Entity;
    /** The plinth and every block hang off it. */
    root: Entity;
    plinth: Entity;
};
/** The view the camera frames, scrolled down by `offset` points as the tower grows. */
export declare const viewFor: (l: Layout, offset: number) => TiltView;
/** A block's face centre in the world, from its top-left in tower points. */
export declare function blockAt(l: Layout, x: number, y: number): Vec3;
export declare const blockColor: (level: number) => [number, number, number, number];
export declare function buildScene(world: World, l: Layout, theme: GameTheme, rootOffset?: number): Scene;
/** Removes the scene, and with its root every block on it. */
export declare function removeScene(world: World, s: Scene): void;
export declare function setSceneTheme(world: World, s: Scene, theme: GameTheme): void;
/**
 * Frames the tower scrolled `cameraOffset + rootOffset` down: the camera scrolled its share (the
 * backdrop kept fixed behind it), the tower slid down the rest. Either is touched only when it changes.
 */
export declare function frame(world: World, l: Layout, s: Scene, camera: Parameters<typeof aimTilted>[0], cameraOffset: number, rootOffset: number): void;
export declare function spawnBlock(world: World, l: Layout, s: Scene, x: number, y: number, level: number, fadeIn?: boolean): Entity;
/** Moves the sliding block (`blockAt`, allocation free: it runs every frame). */
export declare function slideBlock(world: World, l: Layout, e: Entity, x: number, y: number): void;
/** Whether a block at tower row `y` has scrolled wholly below the screen's foot (its depth and a row to spare). */
export declare const belowView: (l: Layout, y: number, offset: number) => boolean;
/** Stops drawing something scrolled out of sight for good (the renderer skips scale-0 instances). */
export declare function hide(world: World, e: Entity): void;
/**
 * A block set down: it flashes bright and puffs dust from under its ends; a perfect one also rings gold.
 * The puffs are loose in the world, so they start where the tower's root has slid it.
 */
export declare function land(world: World, l: Layout, s: Scene, e: Entity, x: number, y: number, level: number, perfect: boolean): void;
/** A missed block tumbles off the way it was sliding, fading as it goes. */
export declare function tumble(world: World, l: Layout, e: Entity, x: number, y: number, direction: number, level: number): void;
//# sourceMappingURL=StackTowerScene.d.ts.map