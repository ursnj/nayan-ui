import { type Camera, type DragEvent, World } from 'nayan-ui';
import type { GameTheme } from '../../services/ThemeService';
import type { GamePhase as Phase } from '../shared/useEngineGame';
import { type Layout } from './TicTacToeConstants';
import { type Board, type Player } from './TicTacToeRules';
import { type Scene } from './TicTacToeScene';
/** How a game ended. */
export type Result = 'win' | 'lose' | 'draw' | 'timeout';
/** place / robot: a piece down; win / lose / draw: how a move ended it (a timeout is silent, as in the original game). */
export type GameEvent = 'place' | 'robot' | 'win' | 'lose' | 'draw';
export declare function createGame(theme: GameTheme): {
    world: World;
    camera: Camera;
    theme: GameTheme;
    layout: Layout | null;
    scene: Scene | null;
    phase: Phase;
    board: Board;
    turn: Player;
    result: Result | null;
    finalScore: number;
    line: readonly [number, number, number] | null;
    /** The countdown lives in the engine (Rust), advanced by world.update. */
    readonly timeLeft: number;
    /** A finger down on a cell (shown as a ghost O until it lifts). */
    press: number;
    onPhase: (_p: Phase) => void;
    onTurn: (_p: Player) => void;
    onEvent: (_e: GameEvent) => void;
};
export type Game = ReturnType<typeof createGame>;
/** A finished game's score: the result's points, plus a bonus for the time left (a win's full, a draw's half). */
export declare const scoreFor: (r: Result | null, timeLeft: number) => number;
/** The game-over card's score. */
export declare const shownScore: (g: {
    result: Result | null;
    finalScore: number;
}) => number;
/** Lays the board out for the view (first layout, header height, rotation): rebuilt where things stand. */
export declare function setLayout(g: Game, l: Layout): void;
export declare function setTheme(g: Game, theme: GameTheme): void;
/** A fresh board, your move first. */
export declare function start(g: Game): void;
/** An empty board, not started (Stop, Play Again). The world, and the GPU view drawing it, are kept. */
export declare function reset(g: Game): void;
/** Your move on a cell, if it's your turn and the cell is empty; the robot answers after its think. */
export declare function play(g: Game, i: number): void;
/** The cell under a view point (on the board's surface), or -1. */
export declare function cellUnder(g: Game, x: number, y: number): number;
/** A finger down on an empty cell shows a ghost O there; lifting on the same cell plays it. */
export declare function drag(g: Game, { phase, x, y }: DragEvent): void;
//# sourceMappingURL=TicTacToeGame.d.ts.map