export declare const MazeRunner: import("react").FC<import("../..").GameProps>;
//# sourceMappingURL=MazeRunner.d.ts.map