import type { TiltView } from '../shared/EngineTilt';
export type Direction = 'up' | 'down' | 'left' | 'right';
export type TileType = 'empty' | 'brick' | 'steel' | 'base';
export declare const GRID_WIDTH = 13;
export declare const GRID_HEIGHT = 17;
export declare const LIVES = 3;
export declare const POINTS_PER_ENEMY = 1000;
export declare const POINTS_PER_LEVEL = 2000;
export declare const ENEMIES_PER_LEVEL = 15;
export declare const MAX_ENEMIES = 4;
export declare const STEP_MS: number;
export declare const STEP_TOLERANCE_MS = 2;
export declare const MAX_PENDING_MS = 50;
export declare const REFERENCE_CELL = 24;
export declare const PLAYER_SPEED = 2;
export declare const ENEMY_SPEED = 1;
export declare const TANK_RATIO = 0.8;
export declare const HIT_TANK_SIZE = 20;
export declare const BULLET_SPEED = 6;
export declare const BULLET_SIZE = 4;
export declare const PLAYER_FIRE_COOLDOWN = 300;
export declare const ENEMY_FIRE_COOLDOWN = 1500;
export declare const SPAWN_PROTECTION = 2000;
export declare const ENEMY_TURN_INTERVAL = 800;
export declare const ENEMY_AIM_TOLERANCE: number;
export declare const FIRST_ENEMY = 1000;
export declare const ENEMY_SPAWN_INTERVAL = 5000;
export declare const SWIPE_THRESHOLD = 5;
export declare const TURN_TIME = 0.08;
export declare const EXPLOSION_TIME = 0.5;
/** The camera leans back from straight down, so the walls, tanks and turrets stand up off the field. */
export declare const TILT = 0.42;
/** Lit from the upper left; surfaces facing up off the field (+z) keep their exact color. */
export declare const LIGHT: import("nayan-ui").Light;
export declare const CLASSIC_FIELD = "rgba(255, 255, 255, 0.30)";
export declare const GRID_LINE = "rgba(0, 0, 0, 0.10)";
/** The steel frame round the field (at most this wide, half a cell on tiny boards): it counts toward the max width. */
export declare const FRAME = 10;
export type Layout = TiltView & {
    /** Whole points, as the original board used. */
    cell: number;
    boardWidth: number;
    boardHeight: number;
};
/** A whole-point cell as wide as the game area allows with the frame round it, smaller if the screen is short. */
export declare function getLayout(width: number, height: number, offset: number): Layout;
//# sourceMappingURL=Tank1990Constants.d.ts.map