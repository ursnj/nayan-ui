import type { TiltView } from '../shared/EngineTilt';
export declare const GAME_DURATION = 300;
export declare const POINTS_PER_CAPTURE = 500;
export declare const KING_BONUS = 500;
export declare const WIN_BONUS = 5000;
export declare const AI_MOVE_DELAY = 0.55;
export declare const SLIDE_TIME = 0.22;
export declare const HOP_TIME = 0.3;
export declare const COLORS: {
    readonly LIGHT_SQ: "#EED9B6";
    readonly DARK_SQ: "#A9744F";
    readonly BOARD_BORDER: "#61412E";
    readonly RED: "#E53935";
    readonly BLACK: "#37474F";
    readonly GOLD: "#FFC107";
    readonly SELECT: "#FFD54F";
    readonly MOVE: "#4CAF50";
    readonly CAPTURE: "#F44336";
};
/** A directly overhead view keeps the board flat while the turned pawns retain their depth. */
export declare const TILT = 0;
export declare const BOARD_BORDER_WIDTH = 3;
/** Lit from the upper left; surfaces facing up off the board (+z) keep their exact color. */
export declare const LIGHT: import("nayan-ui").Light;
/** A piece's height, of a square (a king is two stacked). */
export declare const PIECE_HEIGHT = 0.16;
export type Layout = TiltView & {
    cell: number;
    size: number;
};
/** The board as wide as the original board (the game width, at most 460 points, 560 on a tablet), smaller if the screen is short. */
export declare function getLayout(width: number, height: number, offset: number): Layout;
/** A square's centre (row 0 along the top, the robot's side), in world units. */
export declare const squareCentre: (l: Layout, index: number) => [number, number];
/** The square under a board point, or -1. */
export declare function squareAt(l: Layout, x: number, y: number): number;
//# sourceMappingURL=CheckersConstants.d.ts.map