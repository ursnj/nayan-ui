import React from 'react';
import { type GameProps } from '../../services/UtilsService';
export { preloadRacing as preloadCarRacing } from './CarRacingConstants';
export declare const CarRacing: React.FC<GameProps>;
//# sourceMappingURL=CarRacing.d.ts.map