import { type Camera, type DragEvent, World } from 'nayan-ui';
import type { GameTheme } from '../../services/ThemeService';
import type { GamePhase as Phase } from '../shared/useEngineGame';
import { type Layout } from './CheckersConstants';
import { type CheckerPlayer, type CheckersBoard } from './CheckersRules';
import { type Scene } from './CheckersScene';
/** select: a piece picked up; move / capture: a hop (yours or the robot's); king: crowned; win / lose: the end (a timeout is silent, as in the original game). */
export type GameEvent = 'select' | 'move' | 'capture' | 'king' | 'win' | 'lose';
export declare function createGame(theme: GameTheme): {
    world: World;
    camera: Camera;
    theme: GameTheme;
    layout: Layout | null;
    scene: Scene | null;
    phase: Phase;
    board: CheckersBoard;
    turn: CheckerPlayer;
    selected: number;
    targets: number[];
    captures: number[];
    /** Mid multi-jump: the piece that must keep jumping (-1 when not). */
    mustContinueFrom: number;
    winner: CheckerPlayer | null;
    timedOut: boolean;
    redCaptured: number;
    blackCaptured: number;
    /** Score and the countdown live in the engine (Rust), advanced by world.update. */
    readonly score: number;
    moves: number;
    readonly timeLeft: number;
    press: {
        x: number;
        y: number;
    } | null;
    onPhase: (_p: Phase) => void;
    onCaptured: (_n: number) => void;
    onEvent: (_e: GameEvent) => void;
};
export type Game = ReturnType<typeof createGame>;
/** Lays the board out for the view (first layout, header height, rotation): rebuilt where things stand. */
export declare function setLayout(g: Game, l: Layout): void;
export declare function setTheme(g: Game, theme: GameTheme): void;
/** A fresh board, your move. */
export declare function start(g: Game): void;
/** A fresh board, not started (Stop, Play Again). The world, and the GPU view drawing it, are kept. */
export declare function reset(g: Game): void;
/** The scene's own motion; the engine steps the world after. */
export declare function tick(g: Game, dt: number): void;
/** A square tapped: pick up one of your pieces, put it down, or move the picked one there. */
export declare function select(g: Game, index: number): void;
/** The square under a view point (on the pieces' tops), or -1. */
export declare function squareUnder(g: Game, x: number, y: number): number;
/** A tap (a finger down and up without wandering) selects the square under it. */
export declare function drag(g: Game, { phase, x, y }: DragEvent): void;
//# sourceMappingURL=CheckersGame.d.ts.map