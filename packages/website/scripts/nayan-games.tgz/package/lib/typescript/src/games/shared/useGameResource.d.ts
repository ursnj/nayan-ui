/** Keep native resources through React's effect replay; release them after a real unmount. */
export declare function useGameResource<T>(create: () => T, connect: (value: T) => () => void): T;
//# sourceMappingURL=useGameResource.d.ts.map