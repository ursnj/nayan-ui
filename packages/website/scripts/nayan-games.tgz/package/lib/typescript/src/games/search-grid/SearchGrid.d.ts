import type React from 'react';
import type { SoundConfig } from '../../services/SoundsService';
import type { GAME_IDS, GameProps } from '../../services/UtilsService';
import { type Content } from './SearchGridGame';
export type SearchGameConfig = Content & {
    gameId: GAME_IDS;
    sounds: {
        START: SoundConfig;
        FOUND: SoundConfig;
        WIN: SoundConfig;
        GAME_OVER: SoundConfig;
    };
    /** 'ALL WORDS FOUND!', 'Great word hunting!', 'Find hidden words!' */
    winTitle: string;
    winMessage: string;
    startSubtext: string;
    variant: 'word' | 'number';
    displayName: string;
};
export declare function createSearchGame(config: SearchGameConfig): React.FC<GameProps>;
//# sourceMappingURL=SearchGrid.d.ts.map