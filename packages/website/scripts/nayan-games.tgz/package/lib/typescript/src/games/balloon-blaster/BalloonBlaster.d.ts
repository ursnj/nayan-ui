export declare const BalloonBlaster: import("react").FC<import("../..").GameProps>;
//# sourceMappingURL=BalloonBlaster.d.ts.map