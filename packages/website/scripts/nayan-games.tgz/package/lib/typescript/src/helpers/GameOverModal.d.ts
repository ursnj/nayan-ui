import React from 'react';
/** What the card shows. Android back (and the web's primary key) plays again. */
export type GameOverCard = {
    title: string;
    message?: string;
    scoreLabel: string;
    score: number;
    formatter?: (score: number) => string;
    buttonText: string;
    onPlayAgain: () => void;
    onShare?: () => void;
};
export interface GameOverModalProps {
    /** The card, or null while there's none. */
    card: GameOverCard | null;
    /** A host banner ad under the buttons. */
    bannerAd?: React.ReactNode;
}
export declare const GameOverModal: React.NamedExoticComponent<GameOverModalProps>;
//# sourceMappingURL=GameOverModal.d.ts.map