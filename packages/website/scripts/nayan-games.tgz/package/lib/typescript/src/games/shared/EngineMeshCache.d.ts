/** Product recipe revisioning is separate from the engine's geometry/storage format. */
export declare function cacheGameAsset<T>(key: string, build: () => T): T;
/** The engine storage key for a record the native core saves itself under this game's cache revision. */
export declare function gameStorageKey(key: string): string;
/** A saved asset from this or an earlier launch, or undefined: nothing is built. */
export declare function peekGameAsset<T>(key: string): T | undefined;
export declare const flushProceduralCache: () => Promise<void>;
//# sourceMappingURL=EngineMeshCache.d.ts.map