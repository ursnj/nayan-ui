import type { Light } from 'nayan-ui';
import type { GAME_SOUNDS } from '../../services/SoundsService';
/** Clip IDs are also the names embedded in talking-tua.glb for other glTF viewers. */
export declare const TALKING_TUA_ANIMATIONS: {
    readonly standing: {
        readonly duration: 9.6;
        readonly loop: true;
    };
    readonly walking: {
        readonly duration: 3.75;
        readonly loop: true;
    };
    readonly running: {
        readonly duration: 3;
        readonly loop: true;
    };
    readonly jumping: {
        readonly duration: 2.5;
        readonly loop: false;
    };
    readonly waving: {
        readonly duration: 2.7;
        readonly loop: false;
    };
    readonly winking: {
        readonly duration: 1.65;
        readonly loop: false;
    };
    readonly dancing: {
        readonly duration: 5.25;
        readonly loop: true;
    };
    readonly laughing: {
        readonly duration: 3.6;
        readonly loop: true;
    };
    readonly fighting: {
        readonly duration: 7.8;
        readonly loop: false;
    };
    readonly falling: {
        readonly duration: 4.25;
        readonly loop: false;
    };
};
export type TalkingTuaAnimation = keyof typeof TALKING_TUA_ANIMATIONS;
export interface ActionSoundCue {
    at: number;
    sound: keyof typeof GAME_SOUNDS.TALKING_TUA;
    once?: boolean;
}
/** Contact times sampled from the shipped GLB: no JS skinning or timers during playback. */
export declare const TALKING_TUA_SOUND_CUES: Readonly<Record<TalkingTuaAnimation, readonly ActionSoundCue[]>>;
/** Feet at y=0, facing +Z. Scale the spawned entity for other sizes. */
export declare const TALKING_TUA_HEIGHT = 3.2;
export declare const TALKING_TUA_MODEL_SCALE = 1.21;
export declare const TALKING_TUA_CAMERA_HEIGHT: number;
export declare const TALKING_TUA_WORLD_CAPACITY = 256;
export declare const TALKING_TUA_LIGHT: Light;
export declare const TALKING_TUA_CONTROLS_HEIGHT = 156;
export declare const VOICE: {
    /** Seconds of input the microphone keeps. */
    readonly keepSeconds: 8;
    /** Speech starts above this level (0..1), or this far above the room's own noise, whichever is higher. */
    readonly speakLevel: 0.42;
    readonly speakAboveNoise: 0.16;
    /** Speech has ended after this much quiet. */
    readonly silenceSeconds: 0.7;
    /** Shorter sounds (a cough, a tap) are ignored. */
    readonly minSpeechSeconds: 0.3;
    /** Longer speech is repeated at once. */
    readonly maxSpeechSeconds: 6;
    /** Audio kept from just before the level crossed the threshold (a soft first syllable). */
    readonly prerollSeconds: 0.25;
    /** Quiet kept after Tua finishes, so the tail of its own voice isn't heard as you. */
    readonly cooldownSeconds: 0.45;
    /** Ears stay closed at least this long for one of Tua's sounds whose length isn't known yet. */
    readonly effectSeconds: 0.15;
    /** Loudness values per second for the talking bounce. */
    readonly levelsPerSecond: 30;
    /**
     * Tua's voice: the room and rumble turned down, the speech levelled to this RMS (about -11 dBFS
     * under the limiter: louder than any effect, whether you spoke softly or from across the room)
     * and played at full volume.
     */
    readonly loudness: 0.3;
    readonly volume: 1;
    /** Volume of the plain faster playback on app builds without `audio.shift` (not levelled). */
    readonly fallbackVolume: 1.3;
    /** How often Tua giggles at what it just said (now and then, not after every repeat). */
    readonly giggleChance: 0.12;
};
/**
 * One of Tua's silly voices: your words `pitch` times higher and `tempo` times faster. The engine
 * raises the pitch without racing the words (`audio.shift`), so they stay clear; app builds without
 * it play the recording `pitch` times faster instead. One voice each: no echoes or layered copies.
 */
export type VoiceStyle = {
    mood: string;
    pitch: number;
    tempo: number;
};
/** A different one each time Tua repeats you. */
export declare const VOICE_STYLES: readonly VoiceStyle[];
/**
 * Where Tua can be touched: four vertices of the shipped mesh per part (the nearest, spread at least
 * 8 cm apart, to the part's point in the bind pose: feet at y = 0, facing +z, left as seen from the
 * front) and the part's radius in model units. Regenerate them if the model changes.
 */
export declare const BODY_PARTS: {
    readonly head: {
        readonly vertices: readonly [8148, 11468, 5785, 8151];
        readonly radius: 0.7;
    };
    readonly belly: {
        readonly vertices: readonly [7340, 10857, 10740, 7942];
        readonly radius: 0.42;
    };
    readonly leftHand: {
        readonly vertices: readonly [1594, 1674, 1652, 1677];
        readonly radius: 0.3;
    };
    readonly rightHand: {
        readonly vertices: readonly [17580, 17520, 17581, 17593];
        readonly radius: 0.3;
    };
    readonly leftFoot: {
        readonly vertices: readonly [2469, 2506, 2531, 2445];
        readonly radius: 0.34;
    };
    readonly rightFoot: {
        readonly vertices: readonly [14004, 14050, 14326, 14014];
        readonly radius: 0.34;
    };
};
export type BodyPart = keyof typeof BODY_PARTS;
/** The two lip vertices recorded with the model (sources.json `mouthSamples`): where fruit is eaten. */
export declare const MOUTH_VERTICES: readonly [9820, 8586];
/** Everything Tua reacts to, as game events (each with its sound and haptic in TalkingTua.tsx). */
export type TuaEvent = 'head' | 'dizzy' | 'belly' | 'hand' | 'foot' | 'tickle' | 'fight' | 'walk' | 'hear' | 'talk' | 'deaf' | 'fruit' | 'eat' | 'miss' | 'full' | 'beat' | 'sleep' | 'wake' | 'giggle' | 'excuse' | 'toot' | 'sneeze' | 'achoo' | 'bite' | 'burp';
/** What each reaction plays, the mood it shows and the fun it adds. */
export declare const REACTIONS: {
    readonly head: {
        readonly clip: "winking";
        readonly mood: "Hey!";
        readonly fun: 1;
    };
    readonly dizzy: {
        readonly clip: "falling";
        readonly mood: "Dizzy";
        readonly fun: 3;
    };
    readonly belly: {
        readonly clip: "laughing";
        readonly mood: "Giggly";
        readonly fun: 1;
    };
    readonly hand: {
        readonly clip: "waving";
        readonly mood: "Hello!";
        readonly fun: 1;
    };
    readonly foot: {
        readonly clip: "jumping";
        readonly mood: "Hop!";
        readonly fun: 1;
    };
    readonly tickle: {
        readonly clip: "laughing";
        readonly mood: "Ticklish";
        readonly fun: 2;
    };
    readonly fight: {
        readonly clip: "fighting";
        readonly mood: "Play fight!";
        readonly fun: 2;
    };
    readonly eat: {
        readonly clip: "jumping";
        readonly mood: "Yummy";
        readonly fun: 2;
    };
    readonly full: {
        readonly clip: "winking";
        readonly mood: "Too full!";
        readonly fun: 1;
    };
    readonly wake: {
        readonly clip: "jumping";
        readonly mood: "Awake!";
        readonly fun: 1;
    };
    readonly giggle: {
        readonly clip: "laughing";
        readonly mood: "Hee hee!";
        readonly fun: 1;
    };
    readonly excuse: {
        readonly clip: "winking";
        readonly mood: "Bless me!";
        readonly fun: 1;
    };
};
export type Reaction = keyof typeof REACTIONS;
/** Three head/belly hits or fast swipes this close together knock Tua over. */
export declare const DIZZY_TAPS = 3;
export declare const DIZZY_WINDOW = 1.6;
/** Back-and-forth rubs over Tua that count as a tickle. */
export declare const TICKLE_TURNS = 3;
/** A drag across Tua this fast (points a second) starts a play fight. */
export declare const FIGHT_SPEED = 2600;
/** Tua walks to a tapped spot on the floor within this radius (world units), running when it's far. */
export declare const WALK_RADIUS = 2.4;
export declare const WALK_SPEED = 1.15;
export declare const RUN_SPEED = 2.6;
export declare const RUN_DISTANCE = 1.6;
/** Turning, radians a second. */
export declare const TURN_SPEED = 7;
/** Tua walks no closer than this to the fruit bowl's middle. */
export declare const BOWL_CLEARANCE = 0.85;
/** Fruit Tua can be fed, and how many in a row are too many. */
export declare const FOODS: readonly ["apple", "banana", "strawberry", "orange"];
export declare const FOOD_SIZE = 0.45;
/** How far in front of the lip vertices (inside the open mouth) Tua holds fruit it's chewing, metres. */
export declare const FOOD_AT_LIPS = 0.42;
export declare const FOOD_DETAIL = 0.6;
export declare const FULL_AFTER = 4;
export declare const FULL_WINDOW = 25;
/** Seconds without play before Tua waves for attention, and before it dozes off. */
export declare const BORED_SECONDS = 11;
export declare const SLEEP_SECONDS = 45;
/**
 * Asleep, Tua holds the laugh's deepest squint (eyes nearly shut, head tipped back): the rig's eyes
 * and brows have no closed pose of their own, and a slowed idle would doze with its eyes open.
 */
export declare const SLEEP_POSE: {
    readonly clip: "laughing";
    readonly time: 1.5;
};
/** Gags: the clip each starts with, its mood and its fun. */
export declare const GAGS: {
    readonly toot: {
        readonly clip: "jumping";
        readonly mood: "Oops! Toot!";
        readonly fun: 2;
    };
    readonly sneeze: {
        readonly clip: "standing";
        readonly mood: "Ah…";
        readonly fun: 2;
    };
    readonly chew: {
        readonly clip: "standing";
        readonly mood: "Nom nom";
        readonly fun: 1;
    };
    readonly burp: {
        readonly clip: "winking";
        readonly mood: "Burp!";
        readonly fun: 1;
    };
    readonly look: {
        readonly clip: "standing";
        readonly mood: "Hmm?";
        readonly fun: 0;
    };
    readonly stretch: {
        readonly clip: "standing";
        readonly mood: "Stretch!";
        readonly fun: 0;
    };
};
/** Seconds into chewing of each bite. */
export declare const CHEW_BITES: readonly [0.15, 0.55, 0.95];
/** How often a meal ends in a burp. */
export declare const BURP_CHANCE = 0.5;
/** The face (nose and lips): a tap there makes Tua sneeze. Model units, smaller than the head. */
export declare const FACE_RADIUS = 0.24;
/** What Tua does, in turn, when left alone a while. */
export declare const FIDGETS: readonly ["look", "stretch", "waving", "look", "winking"];
/** The dance party's beat (dance.wav is 2.625 s: 5 beats). */
export declare const BEAT_SECONDS = 0.525;
//# sourceMappingURL=TalkingTuaConstants.d.ts.map