import { type Color, type Entity, type PopOptions, type Quat, type Vec3, type World } from 'nayan-ui';
export type PopBurstOptions = {
    /** Where the beads fly out from (a little in front of the piece reads best). */
    position: Vec3;
    /** The piece's size across, which the burst scales with. */
    size: number;
    /** The piece's color. */
    color: Color;
    /** Depth of the glow (behind the piece, in front of the board). Default the burst's own depth. */
    glowZ?: number;
    /** Beads and glints, about. Default 8. */
    count?: number;
};
/** Bright beads and glints in the piece's color and white, over a glow that swells and fades behind it. */
export declare function popBurst(world: World, o: PopBurstOptions): void;
/** Both: the piece pops away and bursts as it swells. Resolves when it's gone (despawning it is the caller's). */
export declare function popAndBurst(world: World, entity: Entity, pop: PopOptions, burst: PopBurstOptions): Promise<void>;
/** A baton catch: a full-body pop, expanding ring, colorful splinters and two tip sprays. */
export declare function stickBlast(world: World, entity: Entity, o: {
    position: Vec3;
    rotation: Quat;
    scale: Vec3;
    color: Color;
}): Promise<void>;
/** Reusable assets; the game loader advances one builder per frame. */
export declare function warmAssets(): Iterable<() => unknown>;
//# sourceMappingURL=EngineBlasts.d.ts.map