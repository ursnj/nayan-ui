import { type Light, type Texture, type Vec3 } from 'nayan-ui';
import { type HumanAssets } from '../treasure-hunt/TreasureHuntModel';
export declare const WIN_SCORE = 50;
export declare const ZOMBIE_COUNT = 10;
export declare const ZOMBIE_RADIUS = 0.49;
export declare const ISLAND_EDGE = 65;
export declare const BEACH: {
    x: number;
    z: number;
};
export declare const CAMP: {
    x: number;
    z: number;
};
export declare const SPRING: {
    x: number;
    z: number;
};
export declare const LOOKOUT: {
    x: number;
    z: number;
};
export declare const CAMP_RADIUS = 8;
export declare const START_DUSK = 83;
export declare const START_NIGHT = 95;
export declare const RESCUE_TIME = 143;
export declare const START_DAWN: number;
export declare const PLAYER_RADIUS = 0.38;
export declare const PLAYER_SPEED = 5.65;
export declare const START_ZOMBIE_DISTANCE = 13;
export declare const CROP_GROW_SECONDS = 20;
export declare const FRUIT_BUSH_RADIUS = 0.54;
export declare const FRUIT_BUSH_BOUNDS: Vec3;
export declare const RECIPES: {
    readonly shelter: {
        readonly wood: 5;
        readonly stone: 2;
        readonly label: "Shelter";
    };
    readonly fire: {
        readonly wood: 2;
        readonly stone: 3;
        readonly label: "Fire";
    };
    readonly fence: {
        readonly wood: 6;
        readonly stone: 1;
        readonly label: "Fence";
    };
    readonly farm: {
        readonly wood: 4;
        readonly stone: 1;
        readonly label: "Farm";
    };
    readonly beacon: {
        readonly wood: 3;
        readonly stone: 2;
        readonly label: "Signal";
    };
};
export type Structure = keyof typeof RECIPES;
export declare const CAMP_STRUCTURES: readonly ["shelter", "fire", "fence"];
export declare const BUILD_OPTIONS: readonly ["shelter", "fire", "fence", "farm"];
export declare function lightingTime(time: number): number;
export declare function islandLighting(time: number): {
    background: Vec3;
    light: Light;
};
export type IslandAssets = {
    human: HumanAssets;
    monster: HumanAssets;
    sand: Texture;
    grass: Texture;
    stone: Texture;
    bark: Texture;
    leaves: Texture;
    water: Texture;
};
export declare function loadAssets(): Promise<IslandAssets>;
export declare function footstepSounds(): import("nayan-ui").SoundBank<"footstepWalk" | "footstepRun">;
//# sourceMappingURL=IslandSurvivalConstants.d.ts.map