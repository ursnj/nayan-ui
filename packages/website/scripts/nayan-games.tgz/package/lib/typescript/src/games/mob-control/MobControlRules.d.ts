import { type Barrier, type Base, type BoostPad, type Gate } from './MobControlConstants';
export interface Events {
    shots: number;
    gates: number;
    clashes: number;
    hits: number;
    breaches: number;
    captured: number;
    champion: boolean;
    barrierBroken: number;
    bossDefeated: boolean;
    won: boolean;
    lost: boolean;
    effectCount: number;
    effectX: Float32Array;
    effectZ: Float32Array;
    effectTeam: Uint8Array;
}
export interface Sim {
    alive: Uint8Array;
    x: Float32Array;
    z: Float32Array;
    previousX: Float32Array;
    previousZ: Float32Array;
    strength: Uint16Array;
    gatesPassed: Uint8Array;
    ticket: Uint32Array;
    kind: Uint8Array;
    boost: Float32Array;
    flight: Float32Array;
    next: Int16Array;
    playerGrid: Int16Array;
    enemyGrid: Int16Array;
    freePlayer: Uint16Array;
    freeEnemy: Uint16Array;
    freePlayerCount: number;
    freeEnemyCount: number;
    playerCount: number;
    enemyCount: number;
    playerStrength: number;
    enemyStrength: number;
    championCount: number;
    bossCount: number;
    charge: number;
    serial: number;
    seed: number;
    level: number;
    elapsed: number;
    battleClock: number;
    fireClock: number;
    cannonX: number;
    targetX: number;
    hp: number;
    score: number;
    finished: boolean;
    won: boolean;
    gates: Gate[];
    bases: Base[];
    barriers: Barrier[];
    boostPad: BoostPad | null;
    events: Events;
    collisionVisits: number;
}
export declare const isPlayer: (i: number) => boolean;
export declare function createSim(seed?: number, level?: number): Sim;
/** Pool pressure packs strength into an existing slot; it never silently deletes a multiplied army. */
export declare function spawn(s: Sim, player: boolean, x: number, z: number, strength?: number, passed?: number, kind?: number, airborne?: boolean): number;
export declare function step(s: Sim, dt: number): Events;
//# sourceMappingURL=MobControlRules.d.ts.map