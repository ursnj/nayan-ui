/** A vehicle's outline from above: its length, and its half width at each point along it (model z, front at -length / 2). */
export type Footprint = {
    length: number;
    halfWidth: (z: number) => number;
};
/**
 * How far two footprints overlap sideways (> 0 when they touch): `b` is `ahead` metres in front of
 * `a` along the road and `gap` across it, both facing down the road. Sampled along the stretch where
 * they overlap lengthways; -Infinity when they don't.
 */
export declare function overlapAcross(a: Footprint, b: Footprint, ahead: number, gap: number, samples?: number): number;
/**
 * Whether a contact that just began was nose to tail (a front hit) rather than side by side: they were
 * still (almost) clear lengthways a frame ago. `wasAhead` and `ahead` are the gap along the road then
 * and now. Allows for how far they closed in the frame and for tapered noses and tails.
 */
export declare function frontHit(a: Footprint, b: Footprint, wasAhead: number, ahead: number, taper?: number): boolean;
//# sourceMappingURL=EngineFootprint.d.ts.map