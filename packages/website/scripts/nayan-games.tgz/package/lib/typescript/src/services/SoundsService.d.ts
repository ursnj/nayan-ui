import type { AudioPlayOptions, SoundBank, Voice } from 'nayan-ui';
import { type SfxName } from './SfxSources';
export interface SoundConfig {
    /** The sound effect to play. */
    sfx?: SfxName;
    /** 0..2, default 1. */
    volume?: number;
    /** Playback speed, which also shifts the pitch. Default 1. */
    pitch?: number;
    /** No longer spoken; kept so older call sites that pass a phrase still type-check. */
    text?: string;
    rate?: number;
    language?: string;
    /** Minimum gap between repeated instances, in milliseconds. */
    cooldown?: number;
    /** Repeat a music/ambience clip until its voice is stopped. */
    loop?: boolean;
}
/** Loads the sound effects ahead of use (e.g. when a game opens), so the first one isn't skipped. */
export declare const preloadSounds: (sounds?: Record<string, SoundConfig> | SoundConfig[]) => void;
/** Loads a game's effects on opening, including games excluded from homepage preloading. */
export declare const preloadGameSounds: (gameId: string) => void;
/** Decode only the selected games' effects, sharing each clip and leaving other banks lazy. */
export declare function warmSoundAssets(gameIds: readonly string[]): Iterable<() => Promise<unknown>>;
export declare const playSound: (soundConfig: SoundConfig, soundEnabled: boolean, _force?: boolean) => void;
/** For game-owned effects that must stop immediately when an action changes. */
export declare const playSoundVoice: (soundConfig: SoundConfig, soundEnabled: boolean) => Voice | null;
/** How long one play of an effect lasts, in seconds (its length at its pitch; 0 until it has loaded). */
export declare const soundSeconds: (soundConfig: SoundConfig | undefined) => number;
/** Tracks custom native one-shots too, so race/forest effects stop with the shared game screen. */
export declare const playBankSound: <K extends string>(bank: SoundBank<K> | undefined, name: K, options?: AudioPlayOptions) => Voice | null;
export declare const stopAllSounds: () => void;
export declare const GAME_SOUNDS: {
    STOP: SoundConfig;
    RESET: SoundConfig;
    DRAW: SoundConfig;
    TALKING_TUA: {
        START: SoundConfig;
        STANDING: SoundConfig;
        WALKING: SoundConfig;
        RUNNING: SoundConfig;
        JUMPING: SoundConfig;
        WAVING: SoundConfig;
        WINKING: SoundConfig;
        DANCING: SoundConfig;
        LAUGHING: SoundConfig;
        FIGHTING: SoundConfig;
        FALLING: SoundConfig;
        LAND: SoundConfig;
        STUMBLE: SoundConfig;
        BOING: SoundConfig;
        POKE: SoundConfig;
        GIGGLE: SoundConfig;
        POP: SoundConfig;
        CHOMP: SoundConfig;
        MISS: SoundConfig;
        FART: SoundConfig;
        BURP: SoundConfig;
        SNEEZE: SoundConfig;
        BITE: SoundConfig;
    };
    TREASURE_HUNT: {
        START: SoundConfig;
        ATTACK: SoundConfig;
        IMPACT: SoundConfig;
        DEFEAT: SoundConfig;
        COLLECT: SoundConfig;
        HURT: SoundConfig;
        WIN: SoundConfig;
        LOSE: SoundConfig;
    };
    BOXING_ARENA: {
        START: SoundConfig;
        HIT: SoundConfig;
        BLOCK: SoundConfig;
        WIN: SoundConfig;
        LOSE: SoundConfig;
    };
    POP: SoundConfig;
    SWOOSH: SoundConfig;
    BOOM: SoundConfig;
    WHOOSH: SoundConfig;
    TIME_UP: SoundConfig;
    WELL_DONE: SoundConfig;
    WHACK_A_MOLE: {
        START: SoundConfig;
        HIT: SoundConfig;
        MISS: SoundConfig;
        SPAWN: SoundConfig;
        EMPTY_TAP: SoundConfig;
        TIME_WARNING: SoundConfig;
        GAME_OVER: SoundConfig;
    };
    BALLOON_BLASTER: {
        START: SoundConfig;
        POP: SoundConfig;
        BOMB: SoundConfig;
        GAME_OVER: SoundConfig;
    };
    FRUIT_NINJA: {
        START: SoundConfig;
        SLICE: SoundConfig;
        BOMB: SoundConfig;
        GAME_OVER: SoundConfig;
    };
    MAZE_RUNNER: {
        TURN: SoundConfig;
        BUMP: SoundConfig;
        GAME_OVER: SoundConfig;
        START: SoundConfig;
        COMPLETE: SoundConfig;
        STOP: SoundConfig;
    };
    SPACE_FIGHTER: {
        START: SoundConfig;
        DODGE: SoundConfig;
        COLLISION: SoundConfig;
        GRAB: SoundConfig;
        RELEASE: SoundConfig;
        GAME_OVER: SoundConfig;
        WIN: SoundConfig;
    };
    DINO_JUMP: {
        WIN: SoundConfig;
        START: SoundConfig;
        JUMP: SoundConfig;
        COLLECT: SoundConfig;
        HIT: SoundConfig;
        GAME_OVER: SoundConfig;
    };
    COLORS_SORT: {
        PICK: SoundConfig;
        DESELECT: SoundConfig;
        GAME_OVER: SoundConfig;
        START: SoundConfig;
        MATCH: SoundConfig;
        COMPLETE: SoundConfig;
        MISS: SoundConfig;
    };
    FRUIT_MERGER: {
        START: SoundConfig;
        MERGE: SoundConfig;
        DROP: SoundConfig;
        COMPLETE: SoundConfig;
        GAME_OVER: SoundConfig;
    };
    FLAPPY_BIRD: {
        START: SoundConfig;
        FLAP: SoundConfig;
        PASS: SoundConfig;
        GAME_OVER: SoundConfig;
        WIN: SoundConfig;
    };
    CAR_RACING: {
        START: SoundConfig;
        LANE_SWITCH: SoundConfig;
        PASS: SoundConfig;
        CRASH: SoundConfig;
        GAME_OVER: SoundConfig;
    };
    BIKE_RACING: {
        START: SoundConfig;
        LANE_SWITCH: SoundConfig;
        PASS: SoundConfig;
        CRASH: SoundConfig;
        GAME_OVER: SoundConfig;
    };
    BLOCK_BLAST: {
        PICK: SoundConfig;
        INVALID: SoundConfig;
        WIN: SoundConfig;
        START: SoundConfig;
        PLACE: SoundConfig;
        CLEAR: SoundConfig;
        GAME_OVER: SoundConfig;
    };
    CONNECT_EM_ALL: {
        WIN: SoundConfig;
        START: SoundConfig;
        CONNECT: SoundConfig;
        CLEAR: SoundConfig;
        GAME_OVER: SoundConfig;
    };
    POPIT_FIDGET: {
        START: SoundConfig;
        POP: SoundConfig;
        GAME_OVER: SoundConfig;
    };
    PERFECT_CIRCLE: {
        START: SoundConfig;
        DRAW_END: SoundConfig;
        SUCCESS: SoundConfig;
        FAIL: SoundConfig;
    };
    SPIDER_SOLITAIRE: {
        START: SoundConfig;
        DRAW: SoundConfig;
        SELECT: SoundConfig;
        DESELECT: SoundConfig;
        PLACE: SoundConfig;
        INVALID: SoundConfig;
        WIN: SoundConfig;
        COMPLETE: SoundConfig;
    };
    TIC_TAC_TOE: {
        TIME_UP: SoundConfig;
        START: SoundConfig;
        PLACE: SoundConfig;
        ROBOT: SoundConfig;
        WIN: SoundConfig;
        LOSE: SoundConfig;
        DRAW: SoundConfig;
    };
    STACK_TOWER: {
        START: SoundConfig;
        PLACE: SoundConfig;
        PERFECT: SoundConfig;
        MISS: SoundConfig;
        GAME_OVER: SoundConfig;
        WIN: SoundConfig;
    };
    BLOCK_BREAKER: {
        START: SoundConfig;
        HIT: SoundConfig;
        DESTROY: SoundConfig;
        PADDLE: SoundConfig;
        WALL: SoundConfig;
        LOSE_LIFE: SoundConfig;
        GAME_OVER: SoundConfig;
        WIN: SoundConfig;
        POWER_UP: SoundConfig;
        LAUNCH: SoundConfig;
        COMBO: SoundConfig;
    };
    MINE_SWEEPER: {
        START: SoundConfig;
        REVEAL: SoundConfig;
        FLAG: SoundConfig;
        MINE_HIT: SoundConfig;
        GAME_OVER: SoundConfig;
        WIN: SoundConfig;
    };
    SUDOKU: {
        START: SoundConfig;
        PLACE: SoundConfig;
        ERROR: SoundConfig;
        NOTE: SoundConfig;
        GAME_OVER: SoundConfig;
        WIN: SoundConfig;
    };
    COLOR_SWITCH: {
        START: SoundConfig;
        JUMP: SoundConfig;
        PASS: SoundConfig;
        COLOR_CHANGE: SoundConfig;
        GAME_OVER: SoundConfig;
    };
    KNIFE_HIT: {
        START: SoundConfig;
        THROW: SoundConfig;
        STICK: SoundConfig;
        HIT: SoundConfig;
        APPLE: SoundConfig;
        GAME_OVER: SoundConfig;
    };
    PIPE_CONNECT: {
        START: SoundConfig;
        ROTATE: SoundConfig;
        COMPLETE: SoundConfig;
        GAME_OVER: SoundConfig;
    };
    TILE_HOME: {
        START: SoundConfig;
        PICK: SoundConfig;
        MATCH: SoundConfig;
        SHUFFLE: SoundConfig;
        WIN: SoundConfig;
        GAME_OVER: SoundConfig;
    };
    BUBBLE_SHOOTER: {
        START: SoundConfig;
        SHOOT: SoundConfig;
        POP: SoundConfig;
        WIN: SoundConfig;
        GAME_OVER: SoundConfig;
    };
    DOTS_AND_BOXES: {
        START: SoundConfig;
        PLAYER_LINE: SoundConfig;
        OPPONENT_LINE: SoundConfig;
        BOX_CLAIMED: SoundConfig;
        OPPONENT_BOX: SoundConfig;
        WIN: SoundConfig;
        LOSE: SoundConfig;
    };
    CANDY_CRUSH: {
        BOMB: SoundConfig;
        BLAST: SoundConfig;
        START: SoundConfig;
        SELECT: SoundConfig;
        SWAP: SoundConfig;
        INVALID_SWAP: SoundConfig;
        MATCH: SoundConfig;
        COMBO: SoundConfig;
        WARNING: SoundConfig;
        TIME_UP: SoundConfig;
    };
    LUDO_KING: {
        TAP: SoundConfig;
        SIX: SoundConfig;
        PENALTY: SoundConfig;
        CANT_MOVE: SoundConfig;
        FINISH: SoundConfig;
        START: SoundConfig;
        ROLL: SoundConfig;
        MOVE: SoundConfig;
        CAPTURE: SoundConfig;
        WIN: SoundConfig;
        GAME_OVER: SoundConfig;
    };
    TANK_1990: {
        DAMAGE: SoundConfig;
        START: SoundConfig;
        FIRE: SoundConfig;
        DESTROY: SoundConfig;
        WIN: SoundConfig;
        GAME_OVER: SoundConfig;
    };
    NUTS_AND_BOLTS: {
        START: SoundConfig;
        SELECT: SoundConfig;
        PLACE: SoundConfig;
        COMPLETE: SoundConfig;
        GAME_OVER: SoundConfig;
    };
    WORD_SEARCH: {
        START: SoundConfig;
        FOUND: SoundConfig;
        WIN: SoundConfig;
        GAME_OVER: SoundConfig;
    };
    NUMBER_SEARCH: {
        START: SoundConfig;
        FOUND: SoundConfig;
        WIN: SoundConfig;
        GAME_OVER: SoundConfig;
    };
    SLIDING_NUMBERS: {
        BLOCKED: SoundConfig;
        START: SoundConfig;
        MOVE: SoundConfig;
        WIN: SoundConfig;
        GAME_OVER: SoundConfig;
    };
    SNAKE_3D: {
        TIME_UP: SoundConfig;
        START: SoundConfig;
        EAT: SoundConfig;
        SPECIAL: SoundConfig;
        COLLISION: SoundConfig;
        WIN: SoundConfig;
        GAME_OVER: SoundConfig;
    };
    GAME_2048: {
        TIME_UP: SoundConfig;
        START: SoundConfig;
        TILE_MOVE: SoundConfig;
        TILE_MERGE: SoundConfig;
        WIN: SoundConfig;
        GAME_OVER: SoundConfig;
        NEW_TILE: SoundConfig;
        INVALID_MOVE: SoundConfig;
    };
    ARROWS: {
        START: SoundConfig;
        CLEAR: SoundConfig;
        BLOCKED: SoundConfig;
        WIN: SoundConfig;
        GAME_OVER: SoundConfig;
    };
    FIND_DIFFERENT_NUMBER: {
        START: SoundConfig;
        CORRECT: SoundConfig;
        WRONG: SoundConfig;
        WIN: SoundConfig;
        GAME_OVER: SoundConfig;
    };
    TANGRAM: {
        START: SoundConfig;
        ROTATE: SoundConfig;
        PLACE: SoundConfig;
        WRONG: SoundConfig;
        WIN: SoundConfig;
        GAME_OVER: SoundConfig;
    };
    CHECKERS: {
        TIME_UP: SoundConfig;
        SELECT: SoundConfig;
        START: SoundConfig;
        MOVE: SoundConfig;
        CAPTURE: SoundConfig;
        KING: SoundConfig;
        WIN: SoundConfig;
        LOSE: SoundConfig;
    };
    MEMORY_MATCH: {
        START: SoundConfig;
        FLIP: SoundConfig;
        MATCH: SoundConfig;
        WRONG: SoundConfig;
        WIN: SoundConfig;
        GAME_OVER: SoundConfig;
    };
    FALLING_STICKS: {
        START: SoundConfig;
        CATCH: SoundConfig;
        MISS: SoundConfig;
        WIN: SoundConfig;
        GAME_OVER: SoundConfig;
    };
    REVERSI: {
        TIME_UP: SoundConfig;
        INVALID: SoundConfig;
        START: SoundConfig;
        PLACE: SoundConfig;
        PASS: SoundConfig;
        WIN: SoundConfig;
        LOSE: SoundConfig;
    };
    PAC_MAN: {
        START: SoundConfig;
        CHOMP: SoundConfig;
        CHOMP_ALT: SoundConfig;
        POWER_PELLET: SoundConfig;
        EAT_GHOST: SoundConfig;
        EAT_GHOST_COMBO: SoundConfig;
        DEATH: SoundConfig;
        LIFE_LOST: SoundConfig;
        FRUIT: SoundConfig;
        LEVEL_COMPLETE: SoundConfig;
        DIRECTION_CHANGE: SoundConfig;
        TUNNEL: SoundConfig;
    };
    SNAKES_AND_LADDERS: {
        TAP: SoundConfig;
        START: SoundConfig;
        ROLL: SoundConfig;
        MOVE: SoundConfig;
        SNAKE: SoundConfig;
        LADDER: SoundConfig;
        SIX: SoundConfig;
        PENALTY: SoundConfig;
        CANT_MOVE: SoundConfig;
        WIN: SoundConfig;
        GAME_OVER: SoundConfig;
    };
    BLUK: {
        WIN: SoundConfig;
        START: SoundConfig;
        JUMP: SoundConfig;
        LAND: SoundConfig;
        PERFECT: SoundConfig;
        FALL: SoundConfig;
        GAME_OVER: SoundConfig;
    };
    CHAMELEON_RUN: {
        HURT: SoundConfig;
        WIN: SoundConfig;
        START: SoundConfig;
        JUMP: SoundConfig;
        SWAP: SoundConfig;
        STAR: SoundConfig;
        LAND: SoundConfig;
        GAME_OVER: SoundConfig;
    };
    MOB_CONTROL: {
        START: SoundConfig;
        SHOOT: SoundConfig;
        GATE: SoundConfig;
        HIT: SoundConfig;
        CLASH: SoundConfig;
        LEVEL_UP: SoundConfig;
        DAMAGE: SoundConfig;
        WIN: SoundConfig;
        GAME_OVER: SoundConfig;
    };
    PAPER_IO: {
        WIN: SoundConfig;
        START: SoundConfig;
        CAPTURE: SoundConfig;
        TURN: SoundConfig;
        KILL: SoundConfig;
        GAME_OVER: SoundConfig;
    };
    CROSSY_ROAD: {
        TIME_UP: SoundConfig;
        WIN: SoundConfig;
        START: SoundConfig;
        HOP: SoundConfig;
        CROSS: SoundConfig;
        COIN: SoundConfig;
        SPLASH: SoundConfig;
        CRASH: SoundConfig;
        GAME_OVER: SoundConfig;
    };
    PENGUIN_RUN: {
        LANE_SWITCH: SoundConfig;
        START: SoundConfig;
        COIN: SoundConfig;
        GEM: SoundConfig;
        JUMP: SoundConfig;
        SLIDE: SoundConfig;
        CRASH: SoundConfig;
        GAME_OVER: SoundConfig;
    };
};
//# sourceMappingURL=SoundsService.d.ts.map