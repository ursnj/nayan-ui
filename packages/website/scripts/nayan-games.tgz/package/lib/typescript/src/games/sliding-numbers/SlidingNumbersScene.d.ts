import { type Entity, type World } from 'nayan-ui';
import type { GameTheme } from '../../services/ThemeService';
import { type Layout } from './SlidingNumbersConstants';
import type { Tile } from './SlidingNumbersRules';
/** A tile: its root (moved), and its block (pressed, tinted). */
type TileView = {
    root: Entity;
    block: Entity;
};
export type Scene = {
    backdrop: Entity;
    board: Entity[];
    tiles: Map<number, TileView>;
};
export declare function buildScene(world: World, l: Layout, theme: GameTheme, tiles: Tile[]): Scene;
export declare function removeScene(world: World, s: Scene): void;
export declare function setSceneTheme(world: World, l: Layout, s: Scene, theme: GameTheme): void;
/** A tile glides to its cell (or is put there at once). */
export declare function placeTile(world: World, l: Layout, s: Scene, t: Tile, animate?: boolean): void;
/** A finger down on a tile sinks it a little; lifting brings it back. */
export declare function press(world: World, s: Scene, id: number, down: boolean): void;
/** A tile that can't move (not beside the gap): a quick shake. */
export declare function shake(world: World, l: Layout, s: Scene, id: number): void;
/** Solved: the tiles hop in a wave across the board, and confetti bursts over it. */
export declare function celebrate(world: World, l: Layout, s: Scene, tiles: Tile[]): void;
/** Out of time: the tiles dim. */
export declare function dim(world: World, s: Scene, tiles: Tile[]): void;
/** Back to their own colors (a new game). */
export declare function undim(world: World, s: Scene, tiles: Tile[]): void;
export {};
//# sourceMappingURL=SlidingNumbersScene.d.ts.map