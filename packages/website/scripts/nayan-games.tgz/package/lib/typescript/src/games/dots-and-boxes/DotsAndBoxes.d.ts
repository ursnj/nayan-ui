export declare const DotsAndBoxes: import("react").FC<import("../..").GameProps>;
//# sourceMappingURL=DotsAndBoxes.d.ts.map