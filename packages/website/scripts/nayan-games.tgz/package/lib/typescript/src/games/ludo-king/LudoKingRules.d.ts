import { type PlayerColor } from './LudoKingConstants';
export type Token = {
    id: string;
    player: PlayerColor;
    /** -1 yard, 0..56 along the route (56 = home). */
    progress: number;
};
export type Player = {
    color: PlayerColor;
    tokens: Token[];
    isAI: boolean;
    finishedTokens: number;
};
export type GamePhase = 'rolling' | 'moving' | 'ai_turn' | 'over';
export declare const isInYard: (t: Token) => boolean;
export declare const isFinished: (t: Token) => boolean;
export declare const rollDice: () => number;
export declare function createPlayers(you: PlayerColor, ai: PlayerColor[]): Player[];
/** The absolute index on the shared track for a token `steps` from its entry (0..50). */
export declare const mainIndexAt: (player: PlayerColor, steps: number) => number;
export declare function canMove(token: Token, dice: number): boolean;
export declare const movableTokens: (player: Player, dice: number) => Token[];
/** The grid cell a token stands on now. */
export declare function tokenCell(token: Token): {
    row: number;
    col: number;
};
/** The cells a token passes through for a move of `dice` (for the hop animation), start included. */
export declare function journey(token: Token, dice: number): {
    row: number;
    col: number;
}[];
/** Applies a move, returning the moved token and any opponent token it captured. */
export declare function moveToken(token: Token, dice: number, players: Player[]): {
    moved: Token;
    captured: Token | null;
};
export declare const isGameOver: (players: Player[]) => boolean;
export declare const getWinner: (players: Player[]) => Player | null;
/** The AI's pick: a weighted score per move, best 70% of the time (as the original medium AI). */
export declare function selectAIMove(player: Player, dice: number, players: Player[]): Token | null;
export declare function calculateScore(player: Player): number;
//# sourceMappingURL=LudoKingRules.d.ts.map