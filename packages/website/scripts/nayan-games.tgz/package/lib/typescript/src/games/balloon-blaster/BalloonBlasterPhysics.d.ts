import { type Layout } from './BalloonBlasterConstants';
export interface BalloonBody {
    x: number;
    y: number;
    vx: number;
    vy: number;
}
export declare const balloonDistance: (l: Layout) => number;
export declare const balloonBounds: (l: Layout) => {
    left: number;
    right: number;
};
/** Subtract every occupied interval instead of accepting an overlapping last random attempt. */
export declare function findBalloonSpawn(balloons: readonly BalloonBody[], l: Layout, y: number, random?: () => number): number | null;
/** Keep constraints active at the walls during every pass, rather than undoing separation afterward. */
export declare function separateBalloons(balloons: BalloonBody[], l: Layout): void;
//# sourceMappingURL=BalloonBlasterPhysics.d.ts.map