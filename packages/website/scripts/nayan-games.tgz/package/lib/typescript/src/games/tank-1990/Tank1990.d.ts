export declare const Tank1990: import("react").FC<import("../..").GameProps>;
//# sourceMappingURL=Tank1990.d.ts.map