import { type GameProps } from '../../services/UtilsService';
/** Shared Playtura chrome and lifecycle around the rigged boxers and the forest stage. */
export declare const BoxingArena: import("react").FC<GameProps>;
//# sourceMappingURL=BoxingArena.d.ts.map