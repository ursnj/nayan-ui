export declare const ColorsSort: import("react").FC<import("../..").GameProps>;
//# sourceMappingURL=ColorsSort.d.ts.map