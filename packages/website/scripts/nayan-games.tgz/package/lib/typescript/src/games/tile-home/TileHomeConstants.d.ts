export declare const BOARD_COLS = 6;
export declare const BOARD_ROWS = 7;
export declare const LAYER_COUNT = 3;
export declare const TYPES_PER_BOARD = 12;
export declare const TILES_PER_TYPE = 6;
export declare const SLOT_CAPACITY = 7;
export declare const MATCH_COUNT = 3;
export declare const TIME_LIMIT = 300;
export declare const POINTS_PER_SET = 500;
/** Atlas order and each tile's match burst color. */
export declare const TILE_TYPES: readonly [{
    readonly icon: "wateringCan";
    readonly color: "#14b8a6";
}, {
    readonly icon: "lamp";
    readonly color: "#f97316";
}, {
    readonly icon: "rocket";
    readonly color: "#ef4444";
}, {
    readonly icon: "kite";
    readonly color: "#d946ef";
}, {
    readonly icon: "cactus";
    readonly color: "#22c55e";
}, {
    readonly icon: "headphones";
    readonly color: "#8b5cf6";
}, {
    readonly icon: "sailboat";
    readonly color: "#0284c7";
}, {
    readonly icon: "alarmClock";
    readonly color: "#f43f5e";
}, {
    readonly icon: "pencil";
    readonly color: "#eab308";
}, {
    readonly icon: "camera";
    readonly color: "#0d9488";
}, {
    readonly icon: "book";
    readonly color: "#4f46e5";
}, {
    readonly icon: "duck";
    readonly color: "#f59e0b";
}, {
    readonly icon: "umbrella";
    readonly color: "#db2777";
}, {
    readonly icon: "key";
    readonly color: "#ca8a04";
}, {
    readonly icon: "binoculars";
    readonly color: "#0f9f8e";
}, {
    readonly icon: "drum";
    readonly color: "#dc2626";
}, {
    readonly icon: "balloon";
    readonly color: "#2563eb";
}, {
    readonly icon: "mug";
    readonly color: "#ea580c";
}, {
    readonly icon: "boot";
    readonly color: "#0891b2";
}, {
    readonly icon: "train";
    readonly color: "#ef4444";
}, {
    readonly icon: "butterfly";
    readonly color: "#c026d3";
}, {
    readonly icon: "palette";
    readonly color: "#16a34a";
}, {
    readonly icon: "handbell";
    readonly color: "#d97706";
}, {
    readonly icon: "shell";
    readonly color: "#f97381";
}, {
    readonly icon: "controller";
    readonly color: "#8b5cf6";
}, {
    readonly icon: "guitar";
    readonly color: "#ea580c";
}, {
    readonly icon: "snowGlobe";
    readonly color: "#38bdf8";
}, {
    readonly icon: "rollerSkate";
    readonly color: "#f43f5e";
}, {
    readonly icon: "spinningTop";
    readonly color: "#14b8a6";
}, {
    readonly icon: "teddyBear";
    readonly color: "#b45309";
}, {
    readonly icon: "windmill";
    readonly color: "#dc2626";
}, {
    readonly icon: "whale";
    readonly color: "#2563eb";
}, {
    readonly icon: "treasureChest";
    readonly color: "#65a30d";
}, {
    readonly icon: "fan";
    readonly color: "#ec4899";
}, {
    readonly icon: "magicWand";
    readonly color: "#9333ea";
}, {
    readonly icon: "ladybug";
    readonly color: "#ef4444";
}, {
    readonly icon: "iceCream";
    readonly color: "#f472b6";
}, {
    readonly icon: "trafficCone";
    readonly color: "#f97316";
}, {
    readonly icon: "octopus";
    readonly color: "#a855f7";
}, {
    readonly icon: "lighthouse";
    readonly color: "#0284c7";
}, {
    readonly icon: "popcorn";
    readonly color: "#eab308";
}, {
    readonly icon: "sewingMachine";
    readonly color: "#2dd4bf";
}, {
    readonly icon: "scooter";
    readonly color: "#0d9488";
}, {
    readonly icon: "anchor";
    readonly color: "#1e40af";
}, {
    readonly icon: "jigsaw";
    readonly color: "#db2777";
}, {
    readonly icon: "beachBall";
    readonly color: "#2563eb";
}, {
    readonly icon: "mailbox";
    readonly color: "#dc2626";
}, {
    readonly icon: "circusTent";
    readonly color: "#f97316";
}];
/** Sets of three in a board: 24. */
export declare const TOTAL_SETS: number;
export declare const FLY_TIME = 0.25;
export declare const LIFT_AT = 0.28;
export declare const LIFT_SCALE = 1.08;
export declare const MATCH_CHECK_DELAY = 0.3;
export declare const MATCH_REMOVE_DELAY = 0.4;
export declare const MATCH_BURST_TIME = 0.55;
export declare const SHADE_TIME = 0.22;
export declare const SHIFT_SPRING: {
    stiffness: number;
    damping: number;
};
export declare const LAND_SPRING: {
    stiffness: number;
    damping: number;
};
export declare const LAND_SQUASH = 1.12;
export declare const INTRO_SPRING: {
    stiffness: number;
    damping: number;
    mass: number;
};
export declare const RIPPLE_TIME = 0.3;
export declare const LAYER_STAGGER = 0.07;
/** How dark a covered tile is: more tiles over it, darker. */
export declare const shadeFor: (blockingCount: number) => number;
export declare const LIGHT: import("nayan-ui").Light;
export declare const TILE_PICTURE_SIZE = 144;
export declare const TILE_PICTURE_GUTTER = 8;
export declare const TILE_PICTURE_EXTENT = 0.515;
export declare const TILE_ATLAS_COLUMNS = 6;
export declare const TILE_ATLAS_STRIDE: number;
export declare const TILE_ATLAS_WIDTH: number;
export declare const TILE_ATLAS_HEIGHT: number;
export declare const CLASSIC_BOARD = "rgba(255, 255, 255, 0.35)";
export declare const CLASSIC_TRAY = "rgba(255, 255, 255, 0.45)";
export declare const CLASSIC_TRAY_BORDER = "rgba(255, 255, 255, 0.6)";
export declare const CLASSIC_SLOT = "rgba(255, 255, 255, 0.25)";
export declare const CLASSIC_SLOT_BORDER = "rgba(255, 255, 255, 0.5)";
export type Layout = {
    /** The GameView's size. */
    width: number;
    height: number;
    boardLeft: number;
    boardTop: number;
    boardWidth: number;
    boardHeight: number;
    cell: number;
    /** A board tile's side. */
    tile: number;
    trayLeft: number;
    trayTop: number;
    trayWidth: number;
    trayHeight: number;
    /** A tray tile's side. */
    slot: number;
};
export declare function getLayout(width: number, height: number, offset: number): Layout;
/** A board tile's top-left, in view points. */
export declare const tileOrigin: (l: Layout, col: number, row: number, layer: number) => [number, number];
/** Tray slot `index`'s top-left, in view points. */
export declare const slotOrigin: (l: Layout, index: number) => [number, number];
//# sourceMappingURL=TileHomeConstants.d.ts.map