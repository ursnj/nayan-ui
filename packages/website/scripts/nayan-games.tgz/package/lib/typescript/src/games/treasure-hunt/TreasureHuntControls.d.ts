import { type Camera, type Entity, type Vec3, type Voice } from 'nayan-ui';
import { type HumanAnimation, type Point } from './TreasureHuntConstants';
import { type NatureInput, type NatureMap } from './TreasureHuntRules';
export interface SwipeContact {
    identifier: number | string;
    pageX: number;
    pageY: number;
}
interface TapContact {
    x: number;
    y: number;
    time: number;
    dragged: boolean;
}
export interface SwipeInput {
    x: number;
    y: number;
    filtered: {
        x: number;
        y: number;
    };
    filterActive: boolean;
    touchId: SwipeContact['identifier'] | null;
    startX: number;
    startY: number;
    contacts: Map<SwipeContact['identifier'], TapContact>;
}
export declare const createSwipeInput: () => SwipeInput;
export declare function resetSwipe(input: SwipeInput): void;
export declare function startSwipe(input: SwipeInput, touch: SwipeContact, time?: number): void;
export declare function moveSwipe(input: SwipeInput, touch: SwipeContact): void;
/** Sample once per engine frame: touch delivery frequency cannot introduce steering steps. */
export declare function sampleSwipe(input: SwipeInput, elapsed: number): {
    x: number;
    y: number;
};
/** A swipe, long hold or cancelled gesture never becomes a punch when the finger lifts. */
export declare function endSwipe(input: SwipeInput, touch: SwipeContact, time?: number): boolean;
export declare const FOLLOW_OFFSET: Vec3;
export declare function createNatureCamera(target: Entity, spawn: Point, yaw?: number, map?: NatureMap): Camera;
/** Stay behind the facing direction, lift over rising ground and pull in under cave roofs. */
export declare function updateNatureCamera(camera: Camera, yaw: number, map?: NatureMap, player?: Point, dt?: number): void;
export declare function resetNatureCamera(camera: Camera, spawn: Point, yaw?: number, map?: NatureMap): void;
export interface MovementReference {
    active: boolean;
    yaw: number;
}
/**
 * Use the explorer's facing when a swipe gesture begins. Holding a direction keeps a steady world
 * heading while the camera turns behind the explorer; recalculating against the rotating view every
 * frame would turn a held sideways input into an endless spin. Ending the swipe rebases the next gesture to the explorer.
 */
export declare function explorerRelativeInput(input: NatureInput, explorerYaw: number, reference: MovementReference): NatureInput;
type FootstepSound = 'footstepWalk' | 'footstepRun';
interface FootstepPlayback {
    play: (name: FootstepSound, options: {
        volume: number;
        pitch: number;
        pan: number;
    }) => Voice | null;
    stop: (voice: Voice | null) => void;
}
export interface FootstepMotion {
    animation: HumanAnimation | null;
    from: number;
    to: number;
    speed: number;
    audible: boolean;
}
/** One short native voice per landing. No timers, loop gaps or delayed playback after stopping. */
export declare function createFootsteps(playback: FootstepPlayback): {
    stop: () => void;
    update(motion: FootstepMotion, dt: number): void;
};
export {};
//# sourceMappingURL=TreasureHuntControls.d.ts.map