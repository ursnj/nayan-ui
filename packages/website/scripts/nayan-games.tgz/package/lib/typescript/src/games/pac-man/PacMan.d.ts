export declare const PacMan: import("react").FC<import("../..").GameProps>;
//# sourceMappingURL=PacMan.d.ts.map