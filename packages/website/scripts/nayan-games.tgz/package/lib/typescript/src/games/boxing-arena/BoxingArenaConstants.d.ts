import type { Color, Light, LoadedModel, Texture } from 'nayan-ui';
export type FighterId = 'tibo' | 'poteto';
export declare const FIGHTER_IDS: readonly FighterId[];
export declare const FIGHTER_NAMES: Record<FighterId, string>;
export declare const opponentOf: (id: FighterId) => FighterId;
/** Each fighter's height in metres; the GLBs are fitted to it. */
export declare const FIGHTER_HEIGHT = 1.8;
/** Every clip the rules play, by combat action. */
export declare const FIGHTER_CLIPS: readonly ["idle", "walk", "punch", "cross", "block", "dodge", "hit", "defeat", "victory"];
/** The raised circular canvas: its top, its radius and how far from the centre a fighter may stand. */
export declare const RING: {
    readonly surfaceY: 0.54;
    readonly radius: 3.7;
    readonly fighterEdge: 3;
};
/** Fighters stand side on to the camera, turned a little toward it. */
export declare const FIGHTER_YAW: number;
export declare const MATCH_SECONDS = 60;
export declare const START_HEALTH = 100;
export declare const HIT_DAMAGE = 5;
export declare const HIT_SCORE = 200;
/** A knockout's bonus, plus this much for every second left on the clock. */
export declare const WIN_BONUS = 500;
export declare const WIN_BONUS_PER_SECOND = 5;
/** An attack pressed during a move's recovery still lands if the move ends within this long. */
export declare const ATTACK_BUFFER_SECONDS = 0.22;
export declare const WALK_SPEED = 2;
export declare const DODGE_SPEED = 3.2;
/** Fighters never stand closer than this (centre to centre). */
export declare const MIN_GAP = 0.65;
/** Seconds of each move, when its fist can land (`windup`..`activeUntil`), its reach and its stamina cost. */
export declare const MOVES: {
    readonly punch: {
        readonly duration: 0.55;
        readonly windup: 0.12;
        readonly activeUntil: 0.29;
        readonly range: 0.95;
        readonly damage: 5;
        readonly cost: 12;
        readonly knockback: 0.1;
        readonly guardCost: 18;
    };
    readonly cross: {
        readonly duration: 0.8;
        readonly windup: 0.2;
        readonly activeUntil: 0.45;
        readonly range: 1.1;
        readonly damage: 5;
        readonly cost: 28;
        readonly knockback: 0.23;
        readonly guardCost: 34;
    };
    readonly dodge: {
        readonly duration: 0.48;
        readonly cost: 25;
    };
    readonly hit: {
        readonly duration: 0.32;
    };
};
/** A dodge only evades a blow during its first part. */
export declare const DODGE_WINDOW = 0.34;
/** The ending plays out (knockout, victory dance) before the results card covers it. */
export declare const RESULTS_DELAY = 1800;
export declare const DAY_LIGHT: Light;
export declare const NIGHT_LIGHT: Light;
export declare const SKY = "#a6b5aa";
export declare const NIGHT_SKY = "#354e4a";
export declare const FOG = 0.025;
/** The scoreboard's health colours: the player's and the opponent's. */
export declare const HEALTH_COLORS: {
    readonly light: readonly ["#15803d", "#b91c1c"];
    readonly dark: readonly ["#4ade80", "#fb7185"];
};
export declare const HIT_DUST: Color;
export declare const BLOCK_DUST: Color;
export type Assets = {
    fighters: Record<FighterId, LoadedModel>;
    ground: Texture;
    bark: Texture;
    /** The trees' alpha leaf sprays and pine needle sprays (shared with Treasure Hunt's birches and pines). */
    leaves: Texture;
    pine: Texture;
    canvas: Texture;
};
export declare const getCachedAssets: () => Assets | null;
/** The two rigged fighters (CC0, see assets/models/boxers/sources.json) and the stage's textures, decoded on native threads. */
export declare function loadAssets(): Promise<Assets>;
//# sourceMappingURL=BoxingArenaConstants.d.ts.map