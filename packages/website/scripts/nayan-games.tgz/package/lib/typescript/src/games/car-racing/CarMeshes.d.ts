import { type Color, type Geometry, type Model, type Quat, type Vec3 } from 'nayan-ui';
import type { Footprint } from '../shared/EngineFootprint';
/** Turns a lathe's axis (y) onto x, for wheels. */
export declare const AXLE_X: Quat;
export type WheelOptions = {
    /** The rim's radius as a share of the wheel's (a low-profile tyre is around 0.75). Default 0.7. */
    rim?: number;
    /** Spokes. Default 10. */
    spokes?: number;
    /** The rim's and the spokes' colors. Default gunmetal and bright silver. */
    rimColor?: Color;
    spokeColor?: Color;
    /** What shows between the spokes (the brake disc on a car; dark on a bike, as if open). Default disc grey. */
    gapColor?: Color;
    /** A red brake caliper behind the spokes, toward the front (-z) and up, as on a car. Default false. */
    caliper?: boolean;
};
/**
 * A wheel `radius` across and `width` wide around the y axis (turn it with AXLE_X): a tyre with a
 * rounded tread and darker sidewall, around a dished alloy rim with slim spokes over a brake disc.
 * Wheels don't spin in these games, so the caliper is painted where it shows.
 */
export declare function wheel(radius: number, width: number, options?: WheelOptions): Geometry;
export type CarMeshes = {
    body: Model;
    glass: Model;
    trim: Model;
};
/** The car's three meshes, built once per app. */
export declare function carMeshes(): CarMeshes;
/**
 * The car's outline from above, for collisions: the body's own half widths along its length (the
 * mirrors fold in on contact, so they don't count), a couple of centimetres inside the paint.
 */
export declare const CAR_FOOTPRINT: Footprint;
/** Where the car's lamps are (for the night glow over them): the headlights' centres and the tail-light bar. */
export declare const CAR_LAMPS: {
    headlights: Vec3[];
    headlightSize: Vec3;
    tail: Vec3;
    tailSize: Vec3;
};
/** A low-poly pine about 1.2 tall and 1.5 across, its base at the origin: a trunk under three tiers. */
export declare function treeMesh(): Model;
//# sourceMappingURL=CarMeshes.d.ts.map