export declare const PRIMARY_COLOR = "#ffffff";
export declare const BACKGROUND_COLOR = "#3a3a5e";
export declare const COLORS: {
    readonly BG_35: "rgba(255, 255, 255, 0.35)";
    readonly BG_40: "rgba(255, 255, 255, 0.40)";
    readonly BG_50: "rgba(255, 255, 255, 0.50)";
    readonly OVERLAY: "rgba(0, 0, 0, 0.8)";
    readonly OVERLAY_LIGHT: "rgba(0, 0, 0, 0.5)";
    readonly TEXT: "#ffffff";
    readonly TEXT_MUTED: "#cccccc";
    readonly ACCENT: "#3b82f6";
    readonly ACCENT_LIGHT: "#60a5fa";
    readonly SWITCH_TRACK_OFF: "#555555";
    readonly SWITCH_TRACK_ON: "#3b82f6";
    readonly SWITCH_THUMB: "#ffffff";
    readonly SCORE_GOLD: "#facc15";
};
export declare const HUD: {
    readonly SURFACE: "rgba(255, 255, 255, 0.3)";
    readonly BORDER: "rgba(255, 255, 255, 0.6)";
    readonly BORDER_WIDTH: 1.5;
    readonly DIVIDER: "rgba(255, 255, 255, 0.25)";
    readonly TEXT: "#ffffff";
    readonly TEXT_MUTED: "rgba(255, 255, 255, 0.85)";
    readonly TEXT_SHADOW: "rgba(0, 0, 0, 0.35)";
    readonly SOLID: "#ffffff";
    readonly ON_SOLID: "#3a3a5e";
};
export declare const GAME_NAMES: {
    readonly BALLOON_BLASTER: "balloonBlaster";
    readonly FRUIT_SLICER: "fruitSlicer";
    readonly MAZE_RUNNER: "mazeRunner";
    readonly CAT_POPPER: "catPopper";
    readonly SPACE_TRAVELLER: "spaceTraveller";
};
export type GameName = (typeof GAME_NAMES)[keyof typeof GAME_NAMES];
export declare const getGameTitle: (gameId: string) => string;
export declare const hexToRgb: (hex: string) => [number, number, number];
export declare const rgbToHex: (r: number, g: number, b: number) => string;
export declare const lighten: (hex: string, amount: number) => string;
export declare const darken: (hex: string, amount: number) => string;
//# sourceMappingURL=GamesConstants.d.ts.map