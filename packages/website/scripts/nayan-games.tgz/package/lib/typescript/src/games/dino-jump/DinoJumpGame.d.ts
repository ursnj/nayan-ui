import { type Camera, type Color, type Entity, World } from 'nayan-ui';
import type { GameTheme } from '../../services/ThemeService';
import { type MeadowLayers, type View3D } from '../shared/EngineMeadow';
import type { GamePhase as Phase } from '../shared/useEngineGame';
import { type Layout, type ObstacleKind } from './DinoJumpConstants';
import { type DinoView, type Tiles } from './DinoJumpScene';
/** An obstacle: its box's left edge (screen points). */
type Obstacle = {
    kind: ObstacleKind;
    x: number;
    root: Entity;
};
export declare function createGame(theme: GameTheme): {
    world: World;
    backdrop: World;
    camera: Camera;
    theme: GameTheme;
    tint: Color;
    layout: Layout | null;
    view: View3D | null;
    scenery: MeadowLayers | null;
    desert: Tiles | null;
    dino: DinoView | null;
    phase: Phase;
    /** Score, lives and the countdown live in the engine (Rust), advanced by world.update. */
    readonly score: number;
    readonly lives: number;
    readonly timeLeft: number;
    won: boolean;
    /** Game clock, seconds: drives the spawns and the dust (it pauses with the frame loop). */
    time: number;
    pending: number;
    /** The dino's height above the ground (points, negative is up) and its vertical speed. */
    jumpY: number;
    velocity: number;
    jumping: boolean;
    /** How far the desert has scrolled, in points at the play plane. */
    scroll: number;
    dustTimer: number;
    obstacles: Obstacle[];
    onPhase: (_p: Phase) => void;
    onJump: () => void;
    onHit: (_last: boolean) => void;
    onCollect: () => void;
};
export type Game = ReturnType<typeof createGame>;
/** Lays the world out for the view and header (the camera height follows the ground line). */
export declare function setLayout(g: Game, l: Layout): void;
/** A new theme: day or night (the screen swaps the light); the run carries on. */
export declare function setTheme(g: Game, theme: GameTheme): void;
export declare function start(g: Game): void;
/** A fresh run (Stop, Play Again): the dino back on the ground, standing. The world is kept. */
export declare function reset(g: Game): void;
/** Its timers stop before the world is disposed. */
export declare function dispose(g: Game): void;
/** The jump and obstacles in fixed steps, and the dust; the engine steps the world after. */
export declare function tick(g: Game, dt: number): void;
/** Finger down: jump, if on the ground. */
export declare function jump(g: Game): void;
export {};
//# sourceMappingURL=DinoJumpGame.d.ts.map