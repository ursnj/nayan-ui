export declare const BRICK_COLS = 8;
export declare const BRICK_ROWS = 5;
export declare const LIVES = 3;
export declare const TIME_LIMIT = 300;
export declare const POINTS_PER_BRICK = 200;
export declare const POINTS_PER_COMBO = 150;
export declare const COMBO_CALLOUT = 3;
export declare enum PowerUpType {
    WIDE_PADDLE = "wide_paddle",
    MULTI_BALL = "multi_ball",
    EXTRA_LIFE = "extra_life"
}
export declare const POWER_UP_TYPES: readonly [PowerUpType.WIDE_PADDLE, PowerUpType.MULTI_BALL, PowerUpType.EXTRA_LIFE];
export declare const POWER_UP_CHANCE = 0.15;
export declare const MAX_BALLS = 5;
export declare const WIDE_FACTOR = 1.3;
export declare const WIDE_MAX = 1.5;
export declare const WIDE_TIME = 10;
export declare const FRAME_TIME: number;
export declare const MAX_FRAMES = 2;
export declare const BALL_SPEED: number;
export declare const BALL_RADIUS: number;
export declare const LAUNCH_SPREAD: number;
export declare const PADDLE_BOUNCE: number;
export declare const POWER_UP_SPEED = 2;
export declare const POWER_UP_SIZE: number;
export declare const RELAUNCH_DELAY = 0.5;
export declare const PADDLE_WIDTH_TIME = 0.22;
export declare const BUMP_TIME = 0.06;
export declare const BUMP_SPRING: {
    damping: number;
    stiffness: number;
};
export declare const BALL_SPAWN_SPRING: {
    damping: number;
    stiffness: number;
};
export declare const BRICK_DROP = 18;
export declare const BRICK_INTRO_SPRING: {
    damping: number;
    stiffness: number;
};
export declare const BRICK_ROW_STAGGER = 0.07;
export declare const BRICK_COL_STAGGER = 0.018;
export declare const PULSE_TIME = 0.52;
export declare const TRAIL: readonly [{
    readonly k: 1.6;
    readonly r: 0.8;
    readonly o: 0.32;
}, {
    readonly k: 3.2;
    readonly r: 0.62;
    readonly o: 0.18;
}, {
    readonly k: 4.8;
    readonly r: 0.45;
    readonly o: 0.08;
}];
export declare const LIGHT: import("nayan-ui").Light;
export declare const BRICK_COLORS: readonly ["#FF3B3B", "#FFD700", "#32CD32", "#4DA6FF", "#BF5AF2", "#FF9500"];
export declare const POWER_UP_COLORS: Record<PowerUpType, string>;
export declare const PADDLE_COLOR = "#ffffff";
export declare const BALL_COLOR = "#e0e0e0";
export declare const TRAIL_COLOR = "#ffffff";
export declare const CLASSIC_BOARD = "rgba(255, 255, 255, 0.25)";
export declare const CLASSIC_BORDER = "rgba(255, 255, 255, 0.5)";
export declare const CLASSIC_RADIUS = 16;
export declare const THEMED_RADIUS = 8;
export type Layout = {
    /** The GameView's size. */
    width: number;
    height: number;
    /** The board: as wide as the game area, a fixed height, centred below the header. */
    boardLeft: number;
    boardTop: number;
    boardWidth: number;
    boardHeight: number;
    brickWidth: number;
    brickHeight: number;
    /** The first brick's left edge and the top row's top. */
    bricksLeft: number;
    bricksTop: number;
    /** One brick to the next. */
    brickStepX: number;
    brickStepY: number;
    paddleWidth: number;
    paddleHeight: number;
    paddleTop: number;
    /** Where the ball's centre stays between (side walls), and where a ball counts as lost. */
    minX: number;
    maxX: number;
    lostY: number;
};
export declare function getLayout(width: number, height: number, offset: number): Layout;
//# sourceMappingURL=BlockBreakerConstants.d.ts.map