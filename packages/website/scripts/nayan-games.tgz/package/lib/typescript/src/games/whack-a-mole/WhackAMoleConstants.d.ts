import { type MeadowOptions, type View3D } from '../shared/EngineMeadow';
export declare const GRID = 3;
export declare const HOLES: number;
export declare const TIME_LIMIT = 120;
export declare const POINTS_PER_MOLE = 500;
export declare const TIME_WARNING = 10;
export declare const FIRST_SPAWN = 1;
export declare const SPAWN_MAX = 1.5;
export declare const SPAWN_MIN = 1.05;
export declare const MOLE_UP_TIME = 2;
export declare const EYE_HEIGHT = 1.6;
/** Rows are further apart in depth than columns across, so the perspective doesn't squash them together. */
export declare const ROW_SPACING = 1.6;
export declare const HOLE_RADIUS = 0.36;
export declare const MOLE_HEIGHT = 0.62;
/**
 * Metres of lawn ahead of the eye kept in the live world (the rest of the meadow is a cached picture):
 * past the far row's props and their shadows, short of the meadow's bushes and rocks.
 */
export declare const LAWN_DEPTH = 6.2;
export type Layout = {
    width: number;
    height: number;
    view: View3D;
    /** Metres between neighbouring holes across; rows are `ROW_SPACING` times that apart. */
    spacing: number;
    /** Metres from the eye to the near row. */
    nearZ: number;
    /** Each hole's centre on the ground, row 0 (furthest) first, left to right. */
    holes: [number, number, number][];
};
/**
 * The camera at eye height looking across a lawn: the horizon a little under the scoreboard (sky,
 * hills and the treeline above it), the near row's rims just above the controls, the grid as wide as
 * fits the screen.
 */
export declare function getLayout(width: number, height: number, offset: number): Layout;
/** Where a world point appears in the view (screen points). */
export declare function toScreen(v: View3D, p: readonly [number, number, number]): [number, number];
/** The meadow around the lawn: the sun and clouds in the strip of sky above the horizon. */
export declare function meadowFor(l: Layout): MeadowOptions;
//# sourceMappingURL=WhackAMoleConstants.d.ts.map