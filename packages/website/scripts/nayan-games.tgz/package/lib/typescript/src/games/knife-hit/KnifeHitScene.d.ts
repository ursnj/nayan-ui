import { type Entity, type Vec3, type World } from 'nayan-ui';
import type { GameTheme } from '../../services/ThemeService';
import { type Layout } from './KnifeHitConstants';
/** A play-area point (y down) in the world, at height z. */
export declare function toWorld(l: Layout, x: number, y: number, z?: number): Vec3;
export type Scene = {
    countShown?: number;
    backdrop: Entity;
    /** The log's pivot (spins), and what rides on it. */
    pivot: Entity;
    log: Entity;
    stuck: Entity[];
    apple: Entity | null;
    /** The knife in hand. */
    knife: Entity;
    /** The round's knives, counted down the left. */
    counters: Entity[];
};
export declare function buildScene(world: World, l: Layout, theme: GameTheme): Scene;
export declare function removeScene(world: World, s: Scene): void;
export declare function setSceneTheme(world: World, s: Scene, theme: GameTheme): void;
/** The log's knives and apple for a round (or the preview), the log back at rest. */
export declare function dressLog(world: World, l: Layout, s: Scene, angles: number[], apple: number | null): void;
/** The log turned to `rotation` (radians, clockwise on screen). */
export declare function spinLog(world: World, s: Scene, rotation: number): void;
/** The knife in hand, its tip at play-area height `y`; hidden when there's none to throw. */
export declare function placeKnife(world: World, l: Layout, s: Scene, y: number, shown: boolean): void;
/** The count down the left: bright for knives left, dim for those thrown. */
export declare function showCount(world: World, s: Scene, left: number): void;
/** A knife sinks into the rim: it joins the log, the log jumps a touch, chips fly. */
export declare function stick(world: World, l: Layout, s: Scene, a: number): void;
/** A knife strikes another: sparks, the log shudders, the thrown knife spins away and falls. */
export declare function clash(world: World, l: Layout, s: Scene, tipY: number): void;
/** The apple's hit: it bursts in a spray of juice. */
export declare function burstApple(world: World, l: Layout, s: Scene): void;
/** Every knife in: a shower of confetti from the log. */
export declare function celebrate(world: World, l: Layout): void;
//# sourceMappingURL=KnifeHitScene.d.ts.map