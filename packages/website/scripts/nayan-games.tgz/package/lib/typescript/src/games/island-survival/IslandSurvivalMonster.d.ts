import { type World } from 'nayan-ui';
import { type Human, type HumanAssets } from '../treasure-hunt/TreasureHuntModel';
import type { IslandMap } from './IslandSurvivalIsland';
import type { Monster } from './IslandSurvivalRules';
declare const CLIPS: readonly ["idle", "walk", "run", "attack", "hit", "fall"];
export type MonsterClip = (typeof CLIPS)[number];
export declare function loadMonsterAssets(): Promise<HumanAssets>;
export type MonsterPose = Human<MonsterClip> & {
    settled: boolean;
    stagger: number;
    fallTime: number;
};
export declare function placeMonster(world: World, map: IslandMap, monster: Monster, pose: MonsterPose, dt: number, nearby: boolean): void;
export {};
//# sourceMappingURL=IslandSurvivalMonster.d.ts.map