import { type Camera, World } from 'nayan-ui';
import type { GameTheme } from '../../services/ThemeService';
import type { GamePhase as Phase } from '../shared/useEngineGame';
import { type Layout } from './PipeConnectConstants';
import { type PipeCell } from './PipeConnectRules';
import { type Scene } from './PipeConnectScene';
export declare function createGame(theme: GameTheme, size: number): {
    world: World;
    camera: Camera;
    theme: GameTheme;
    size: number;
    layout: Layout | null;
    scene: Scene | null;
    phase: Phase;
    grid: PipeCell[][];
    wet: Map<string, number>;
    /** Score and the countdown live in the engine (Rust), advanced by world.update. */
    readonly score: number;
    readonly time: number;
    won: boolean;
    onPhase: (_p: Phase) => void;
    /** A pipe turned; `solved` when that turn reached the sink. */
    onTurn: (_solved: boolean) => void;
};
export type Game = ReturnType<typeof createGame>;
/** Lays the board out for the view (first layout, header height, rotation): rebuilt from the puzzle's state. */
export declare function setLayout(g: Game, l: Layout): void;
export declare function setTheme(g: Game, theme: GameTheme): void;
/** Plays the puzzle that's showing. */
export declare function start(g: Game): void;
/** A fresh puzzle, not started (Stop, Play Again). The world, and the GPU view drawing it, are kept. */
export declare function reset(g: Game): void;
/** The cell under a view point (as seen on the pipes, a little above the tiles). */
export declare function cellAt(g: Game, x: number, y: number): [number, number] | null;
export declare function tap(g: Game, x: number, y: number): void;
/** Turns the pipe in a cell (not the source, sink or an empty one), then lets the water find its way. */
export declare function rotateAt(g: Game, row: number, col: number): void;
//# sourceMappingURL=PipeConnectGame.d.ts.map