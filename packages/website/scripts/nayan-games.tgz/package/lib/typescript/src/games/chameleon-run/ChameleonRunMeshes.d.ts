/** Facing +x, with the feet at -0.5. Shape and pigment remain readable from the chase camera. */
export declare const bodyMesh: () => import("nayan-ui").Model;
/** Restrained throat folds, a closed jaw seam and tiny nostrils; no smile or cartoon eye whites. */
export declare const detailsMesh: () => import("nayan-ui").Model;
/** Scaly turret eyelids with only a small forward-facing opening. Local +z is the gaze direction. */
export declare const eyeMesh: () => import("nayan-ui").Model;
export declare const eyeDetailsMesh: () => import("nayan-ui").Model;
export declare const tailMesh: () => import("nayan-ui").Model;
export interface LimbDefinition {
    x: number;
    y: number;
    side: -1 | 1;
    hind: boolean;
}
export declare const LIMBS: readonly LimbDefinition[];
export declare const legMesh: (side: number, hind?: boolean) => import("nayan-ui").Model;
export declare const starMesh: () => import("nayan-ui").Model;
/** Reusable assets; the game loader advances one builder per frame. */
export declare function warmAssets(): Iterable<() => unknown>;
//# sourceMappingURL=ChameleonRunMeshes.d.ts.map