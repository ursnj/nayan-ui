import { type Entity, type Model, type World } from 'nayan-ui';
import type { GameTheme } from '../../services/ThemeService';
/** Any front light works: these flat meshes face the camera, which it lights at exactly 1. */
export declare const BACKDROP_LIGHT: import("nayan-ui").Light;
/** The background mesh in pattern space: x right, y up from the window's top-left (y runs to -height). */
export declare function backdropMesh(theme: GameTheme): Model;
/**
 * The background behind a centred, one-unit-per-point scene `width` x `height` (the view's size), at
 * depth `z`: the pattern starts at the view's top-left, as the original screens draw it. It's `still`
 * (drawn once into the world's cached backdrop image, shared/EngineScenery): its full-screen layers
 * cost a tile GPU some 10 ms a frame at full quality otherwise. A game whose camera keeps moving
 * (following its player) passes `still: false`; under a scaled root, place it with `placeTiltedBackdrop`'s `unit`.
 */
export declare function spawnBackdrop(world: World, width: number, height: number, z: number, theme: GameTheme, still?: boolean): Entity;
/** Repaints a backdrop for a new theme (a still one is drawn again). */
export declare function setBackdropTheme(world: World, backdrop: Entity, theme: GameTheme): void;
//# sourceMappingURL=EngineBackdrop.d.ts.map