import { type Camera, World } from 'nayan-ui';
import type { GamePhase, GameResult } from '../shared/useEngineGame';
import { type Collisions } from './BoxingArenaCollisions';
import type { Assets, FighterId } from './BoxingArenaConstants';
import { type Framing, type TouchState, type Viewport } from './BoxingArenaControls';
import { type Fight, type FightInput } from './BoxingArenaRules';
import { type Scene } from './BoxingArenaScene';
/** `hit`: the player lands a blow; `hurt`: the player takes one; `block` / `guard`: the opponent / the player blocks. */
export type BoxingEvent = 'hit' | 'hurt' | 'block' | 'guard';
/** What the scoreboard shows. */
export type Hud = {
    character: FighterId;
    health: [number, number];
    score: number;
};
export type Game = {
    world: World;
    camera: Camera;
    assets: Assets;
    scene: Scene;
    collisions: Collisions;
    fight: Fight;
    /** The player's chosen boxer (kept for the next fight). */
    character: FighterId;
    input: FightInput;
    touch: TouchState;
    orbit: number;
    framing: Framing;
    view: Viewport;
    phase: GamePhase;
    score: number;
    won: boolean;
    onPhase: (phase: GamePhase) => void;
    onEvent: (event: BoxingEvent) => void;
    /** The scoreboard's values changed. */
    onChange: (hud: Hud) => void;
};
export declare function createGame(assets: Assets, character?: FighterId): Game;
export declare const hudOf: (g: Game) => Hud;
/** How the fight came out: a knockout or more health at the bell wins, equal health is a draw. */
export declare const outcome: (g: Game) => GameResult;
/** Drops held touches and buffered attacks (pause, settings, Stop, leaving). */
export declare function clearInput(g: Game): void;
export declare function start(g: Game): void;
/** A fresh fight on the same stage: full health, the clock wound back, the fighters on their marks. */
export declare function reset(g: Game): void;
/** Before the bell, plays as `character`: the boxers swap sides, so the player stays on the left. */
export declare function selectCharacter(g: Game, character: FighterId): void;
export declare function setActive(g: Game, active: boolean): void;
export declare function resize(g: Game, width: number, height: number, offset: number): void;
export declare function tick(g: Game, dt: number): void;
//# sourceMappingURL=BoxingArenaGame.d.ts.map