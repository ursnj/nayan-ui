import { type Entity, type World } from 'nayan-ui';
import type { GameTheme } from '../../services/ThemeService';
import { type Layout } from './ChessMastersConstants';
import { type Move } from './ChessMastersRules';
export declare function warmAssets(): Generator<() => import("nayan-ui").Model, void, unknown>;
export declare function createScene(world: World, layout: Layout, theme: GameTheme): {
    backdrop: Entity;
    board: Entity;
    labels: Entity[];
    highlights: Entity[];
    hints: Entity[];
    pieces: Map<number, Entity>;
    retiring: Entity | null;
};
export type Scene = ReturnType<typeof createScene>;
export declare function setSceneTheme(world: World, scene: Scene, theme: GameTheme): void;
export declare function layoutBoard(world: World, scene: Scene, layout: Layout): void;
export declare function resetPieces(world: World, scene: Scene, layout: Layout, board: Int8Array): void;
export declare function showHints(world: World, scene: Scene, layout: Layout, selected: number, moves: Move[], lastMove?: Move, check?: number): void;
export declare function lift(world: World, scene: Scene, layout: Layout, square: number, raised: boolean): void;
export declare function animateMove(world: World, scene: Scene, layout: Layout, move: Move, piece: number, duration: number): void;
export declare function settleMove(world: World, scene: Scene, layout: Layout, move: Move, piece: number): void;
export declare function celebrate(world: World, layout: Layout): void;
//# sourceMappingURL=ChessMastersScene.d.ts.map