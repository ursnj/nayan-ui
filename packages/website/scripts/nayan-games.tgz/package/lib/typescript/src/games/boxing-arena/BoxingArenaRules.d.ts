import { type FighterId } from './BoxingArenaConstants';
export type CombatAction = 'idle' | 'walk' | 'punch' | 'cross' | 'block' | 'dodge' | 'hit' | 'defeat' | 'victory';
export type Attack = 'punch' | 'cross' | 'dodge';
export type FightInput = {
    left: boolean;
    right: boolean;
    block: boolean;
    attack: Attack | null;
};
export declare const newInput: () => FightInput;
export declare const ARENA_EDGE: 3;
/** Where a fist met its target this move, from the rendered rigs. */
export type SurfaceContact = {
    position: [number, number, number];
    guarded: boolean;
    dodged: boolean;
};
export interface Fighter {
    character: FighterId;
    x: number;
    /** +1 faces +x (the player, on the left), -1 faces -x. */
    facing: -1 | 1;
    health: number;
    stamina: number;
    action: CombatAction;
    elapsed: number;
    /** This attack has landed (or missed) already. */
    struck: boolean;
    bufferedAttack: Attack | null;
    bufferRemaining: number;
    surfaceContact: SurfaceContact | null;
}
export interface CombatEvent {
    kind: 'hit' | 'block' | 'miss' | 'dodge';
    target: 0 | 1;
    damage: number;
    position?: [number, number, number];
}
export interface Fight {
    phase: 'ready' | 'playing' | 'over';
    /** The player, then the opponent. */
    fighters: [Fighter, Fighter];
    remaining: number;
    score: number;
    winner: 0 | 1 | 'draw' | null;
    /** This frame's contacts, for the presentation. */
    events: CombatEvent[];
    ai: {
        wait: number;
        input: FightInput;
    };
    accumulator: number;
    /** Contacts come from the sampled rigs (both fighters loaded and sampled this frame). */
    useRigContacts: boolean;
}
export declare function createFight(character: FighterId): Fight;
export declare function startFight(fight: Fight): void;
/** Before the match, swaps sides so the chosen character is the player (on the left). */
export declare function selectFighter(fight: Fight, character: FighterId): boolean;
/** Forgets any buffered attack (input is cleared on pause, settings and leaving). */
export declare function clearBuffers(fight: Fight): void;
/** Advances at a fixed 60 Hz (also on 120 Hz displays). Events are this frame's, for the presentation. */
export declare function tickFight(fight: Fight, input: FightInput, elapsed: number, random?: () => number): void;
//# sourceMappingURL=BoxingArenaRules.d.ts.map