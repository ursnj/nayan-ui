export declare const Tangram: import("react").FC<import("../..").GameProps>;
//# sourceMappingURL=Tangram.d.ts.map