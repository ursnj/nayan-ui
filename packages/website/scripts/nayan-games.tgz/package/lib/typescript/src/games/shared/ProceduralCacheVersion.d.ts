/** Follows every source: for cache keys outside a game folder's namespace. */
export declare const PROCEDURAL_CACHE_VERSION = "ee22204c639d5fc3af122644bea36cb1";
/** Per namespace ("<folder>/..." keys): a game's own sources, what it imports, shared code and the engine. */
export declare const PROCEDURAL_CACHE_VERSIONS: Readonly<Record<string, string>>;
//# sourceMappingURL=ProceduralCacheVersion.d.ts.map