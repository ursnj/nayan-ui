/** Follows every source: for cache keys outside a game folder's namespace. */
export declare const PROCEDURAL_CACHE_VERSION = "83a262a064dc4c3e2fcd7d1b79d773c5";
/** Per namespace ("<folder>/..." keys): a game's own sources, what it imports, shared code and the engine. */
export declare const PROCEDURAL_CACHE_VERSIONS: Readonly<Record<string, string>>;
//# sourceMappingURL=ProceduralCacheVersion.d.ts.map