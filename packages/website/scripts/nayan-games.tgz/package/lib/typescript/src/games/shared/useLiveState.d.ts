type SetState<T> = (next: T | ((previous: T) => T)) => void;
/** Like `useState`, but its updates show at once even while the frame loop keeps the JS thread busy (see above). */
export declare function useLiveState<T>(initial: T | (() => T), minInterval?: number): [T, SetState<T>];
export {};
//# sourceMappingURL=useLiveState.d.ts.map