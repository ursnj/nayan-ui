import { type Camera, type Entity, type Quat, type Vec3, type World } from 'nayan-ui';
import type { GameTheme } from '../../services/ThemeService';
import { type LadderData, type Layout, type SnakeData } from './SnakesAndLaddersConstants';
/**
 * A snake's spine from its head (t = 0) to its tail tip (t = 1): an S-curve across the board, on the
 * cells (with `raised`, at the height of its round body, before the board flattens it onto them).
 */
export declare function snakePath(s: SnakeData, raised?: boolean): Vec3[];
/** The ladder's line, from its foot to its top, on the cells where a pawn climbs it. */
export declare function ladderPath(l: LadderData): Vec3[];
export declare const SHADOW_Z: number;
/** The die showing `value` toward the camera (shared/EngineDice), turned `twist` round its up axis. */
export declare const dieRotation: (value: number, twist?: number) => Quat;
export type Scene = {
    backdrop: Entity;
    board: Entity;
    tokens: [Entity, Entity];
    shadows: [Entity, Entity];
    die: Entity;
    dieShadow: Entity;
    ring: Entity;
};
/** Board units to world units (view points). */
export declare const toWorld: (l: Layout, x: number, y: number, z: number) => Vec3;
/** Points the camera at the board so it lands where the layout puts it. */
export declare const aimCamera: (camera: Camera, l: Layout) => void;
export declare function buildScene(world: World, l: Layout, theme: GameTheme): Scene;
export declare function removeScene(world: World, s: Scene): void;
export declare function setSceneTheme(world: World, s: Scene, theme: GameTheme): void;
export declare const dieRest: (l: Layout) => Vec3;
/** The die is tossed, tumbles and bounces to rest showing `value` (shared/EngineDice). */
export declare function rollDie(world: World, l: Layout, s: Scene, value: number, time: number, disposed?: () => boolean): void;
/** The gold ring under the die pulses while it's the player's roll. */
export declare function showRollHint(world: World, l: Layout, s: Scene, on: boolean): void;
/** A pawn's place on a board point (x, y) at height z, and its shadow's under it. */
export declare function placeToken(world: World, l: Layout, s: Scene, who: number, at: Vec3): void;
/**
 * Moves a pawn through board points (x, y, z) in `time` seconds, along a smooth curve; with `hop`, it
 * arcs up between them. Its shadow follows along the board.
 */
export declare function moveToken(world: World, l: Layout, s: Scene, who: number, points: Vec3[], time: number, hop?: number): void;
/** The pawn whose turn it is bobs gently. */
export declare function bobToken(world: World, l: Layout, s: Scene, who: number | null): void;
/** A snake's bite: the pawn shakes and the board jolts. */
export declare function snakeBite(world: World, l: Layout, s: Scene, camera: Camera, who: number): void;
/** Sparkles at a board point (a ladder's top). */
export declare function sparkle(world: World, l: Layout, at: Vec3): void;
/** Confetti over the winning pawn. */
export declare function confetti(world: World, l: Layout, at: Vec3): void;
export declare function slidePath(from: number): Vec3[] | null;
//# sourceMappingURL=SnakesAndLaddersScene.d.ts.map