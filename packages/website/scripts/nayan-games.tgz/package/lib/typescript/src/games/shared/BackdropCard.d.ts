import React from 'react';
export declare const BackdropCard: React.MemoExoticComponent<() => React.JSX.Element>;
//# sourceMappingURL=BackdropCard.d.ts.map