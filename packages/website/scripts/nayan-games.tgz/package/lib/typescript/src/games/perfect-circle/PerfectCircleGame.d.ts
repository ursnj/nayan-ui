import { type Camera, type DragEvent, World } from 'nayan-ui';
import type { GameTheme } from '../../services/ThemeService';
import type { GamePhase as Phase } from '../shared/useEngineGame';
import { type Layout } from './PerfectCircleConstants';
import { type Point } from './PerfectCircleRules';
import { type Scene } from './PerfectCircleScene';
/** begin / end: the finger went down / lifted; scored: the stroke's accuracy is in (not for one too short to count). */
export type GameEvent = 'begin' | 'end' | 'scored';
export declare function createGame(theme: GameTheme): {
    world: World;
    camera: Camera;
    theme: GameTheme;
    layout: Layout | null;
    scene: Scene | null;
    phase: Phase;
    /** The stroke so far (view points, kept inside the guide), and whether a finger is drawing it. */
    points: Point[];
    drawing: boolean;
    accuracy: number;
    won: boolean;
    fit: {
        cx: number;
        cy: number;
        r: number;
    } | null;
    onPhase: (_p: Phase) => void;
    onAccuracy: (_a: number) => void;
    onEvent: (_e: GameEvent) => void;
};
export type Game = ReturnType<typeof createGame>;
/** Lays the plate out for the view (first layout, header height, rotation); a stroke on it is cleared. */
export declare function setLayout(g: Game, l: Layout): void;
export declare function setTheme(g: Game, theme: GameTheme): void;
export declare function start(g: Game): void;
/** An empty plate, not started (Stop, Play Again). The world, and the GPU view drawing it, are kept. */
export declare function reset(g: Game): void;
/** One stroke per round: down starts it, every move of 4 points or more adds to it, lifting scores it. */
export declare function drag(g: Game, { phase, x, y }: DragEvent): void;
//# sourceMappingURL=PerfectCircleGame.d.ts.map