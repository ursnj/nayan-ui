/** Directions: 0 none, 1 up, 2 right, 3 down, 4 left. A cell's open sides are a bitmask (1 << (dir - 1)). */
export declare const NONE = 0;
export declare const UP = 1;
export declare const RIGHT = 2;
export declare const DOWN = 3;
export declare const LEFT = 4;
export declare const ROLL_CELLS_PER_SEC = 5;
export declare const SWIPE_PX = 16;
export declare const FRAME_MS = 16.67;
export declare const dirDX: (d: number) => 1 | 0 | -1;
export declare const dirDY: (d: number) => 1 | 0 | -1;
/** A fresh maze: the hardest of several carved ones, by the length of the way through and its choices. */
export declare function generateMaze(n: number): number[];
export declare const isOpen: (open: number[], n: number, x: number, y: number, d: number) => boolean;
/** The ball's roll: the cell it last centred on, how far (0..1) it's gone toward the next, and which way. */
export type Roll = {
    cx: number;
    cy: number;
    p: number;
    dir: number;
    queued: number;
    anchorX: number;
    anchorY: number;
};
export declare const homeRoll: () => Roll;
/** A finger moved to (x, y): a swipe once it's gone SWIPE_PX one way from where the last began. Returns whether a new way was taken. */
export declare function swipe(r: Roll, x: number, y: number): boolean;
/** One display frame of rolling. Says whether the ball bumped a wall, and the cell it reached (if it reached one). */
export declare function roll(r: Roll, open: number[], n: number, frameMs: number): {
    bumped: boolean;
    reached: [number, number] | null;
};
/** Where the ball is drawn, in cells (its centre: 0.5 is the middle of the first column / row). */
export declare const rollAt: (r: Roll) => [number, number];
//# sourceMappingURL=MazeRunnerRules.d.ts.map