import { type Camera, type Entity, type World } from 'nayan-ui';
import type { GameTheme } from '../../services/ThemeService';
import { type Layout } from './FindDifferentNumberConstants';
type TileView = {
    root: Entity;
    block: Entity;
    digits: [Entity, Entity];
};
export type Scene = {
    backdrop: Entity;
    board: Entity[];
    tiles: TileView[];
};
export declare function buildScene(world: World, l: Layout, theme: GameTheme, numbers: number[], found: Set<number>): Scene;
export declare function removeScene(world: World, s: Scene): void;
/** Every tile's colors for the theme (found ones green). */
export declare function paint(world: World, s: Scene, theme: GameTheme, found: Set<number>): void;
export declare function setSceneTheme(world: World, l: Layout, s: Scene, theme: GameTheme, found: Set<number>): void;
/** Puts the round's numbers on the tiles (the digits' meshes swapped in place); blank with no round. */
export declare function showNumbers(world: World, s: Scene, numbers: number[]): void;
/** A fresh round: the tiles pop up in a wave from the top left. */
export declare function intro(world: World, s: Scene): void;
/** A different number found: the tile turns green and pops. */
export declare function markFound(world: World, s: Scene, i: number): void;
/** A wrong tap: the tile flashes red and the grid jolts. */
export declare function markWrong(world: World, l: Layout, s: Scene, camera: Camera, i: number, theme: GameTheme): void;
/** All ten found: the tiles hop in a wave, and confetti bursts over the board. */
export declare function celebrate(world: World, l: Layout, s: Scene): void;
/** Out of time: the tiles not found dim. */
export declare function dim(world: World, s: Scene, theme: GameTheme, found: Set<number>): void;
export {};
//# sourceMappingURL=FindDifferentNumberScene.d.ts.map