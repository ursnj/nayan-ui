import { type Camera, type Color, type Entity, type Light, type Model, type Quat, type Vec3, type World } from 'nayan-ui';
import { type GameTheme } from '../../services/ThemeService';
/** How a game frames the meadow. */
export type Rig = {
    /** Metres from the ground to the eye. Default 1.6. */
    eyeHeight?: number;
    /** How far down the screen the horizon sits, 0..1. Default 0.62. */
    horizon?: number;
    /** Metres from the eye to the play plane; keep it nearer than the ground at the screen's bottom edge. Default 3.6. */
    playDepth?: number;
};
export type View3D = {
    width: number;
    height: number;
    eye: Vec3;
    /** Camera axes: looking along `forward`, `up` and `right` span the screen. */
    forward: Vec3;
    up: Vec3;
    /** tan(fov / 2). */
    tanHalf: number;
    /** The camera's pitch up, radians. */
    pitch: number;
    horizon: number;
    playDepth: number;
};
export declare function makeView(width: number, height: number, rig?: Rig): View3D;
export declare function cameraFor(v: View3D): Camera;
/** Metres per screen point on a plane `depth` metres ahead. */
export declare const pointSize: (v: View3D, depth?: number) => number;
/** Where screen point (x, y) lands on the plane `depth` metres ahead. */
export declare function at(v: View3D, x: number, y: number, depth?: number): Vec3;
/** A screen-plane vector (points per second, y down) in world metres per second at the play plane. */
export declare function planeVector(v: View3D, dx: number, dy: number): Vec3;
/** Turns something drawn facing +z to face the camera, then by `angle` in the screen's plane. */
export declare function facing(v: View3D, angle?: number): Quat;
/** The direction from the eye through screen point (x, y). */
export declare function rayThrough(v: View3D, x: number, y: number): Vec3;
export declare const add: (a: Vec3, b: Vec3) => Vec3;
export declare const scale: (a: Vec3, k: number) => Vec3;
/**
 * The meadow's sun. With the whole land cached (`cached` 'all'), only the backdrop draws shadows: what
 * flies in front of it would cast them on nothing that shows them, so frames skip the shadow pass.
 */
export declare const lightFor: (theme: GameTheme, cached?: MeadowBackdrop) => Light;
type RGB = [number, number, number];
/** What far-off things fade toward. */
export declare const HAZE: RGB;
/** The color multiplier scenery takes for a theme (night dims and cools it), for games adding their own. */
export declare const sceneryTint: (theme: GameTheme) => Color;
/** Value noise, 0..1. */
export declare function noise(x: number, y: number): number;
export declare const fbm: (x: number, y: number) => number;
export declare function random(seed: number): () => number;
/** Where the scene is: green rolling hills and a grass meadow, or sandstone mesas over a desert. */
export type Biome = 'meadow' | 'desert';
/** A pine about one unit tall: a trunk and stacked cones, each a little narrower. */
export declare const pineMesh: () => Model;
/** A bush about half a unit tall: a few overlapping leafy clumps. */
export declare const bushMesh: () => Model;
/** A weathered grey boulder, one unit across. */
export declare const rockMesh: () => Model;
/** A tuft of grass blades, about a third of a unit tall, dark at the root and sunlit at the tips. */
export declare const tuftMesh: () => Model;
/** A little flower: white petals (tinted where it's placed) round a golden centre. */
export declare const flowerMesh: () => Model;
/** What's in a game's meadow, and where the sun and clouds sit on its screen. */
export type MeadowOptions = {
    /** The sun (or moon), as fractions of the screen. Default [0.8, 0.2]. */
    sun?: readonly [number, number];
    /** The band of sky the clouds sit in, as fractions down the screen. Default [0.1, 0.42]. */
    clouds?: readonly [number, number];
    /** The big oak and pine framing the play area. Default true. */
    framingTrees?: boolean;
    /** Grass tufts and flowers right in front. Default true. */
    foreground?: boolean;
    /** Hot-air balloons drifting far off. Default 0. */
    hotAirBalloons?: number;
    /**
     * With the land cached (`spawnMeadow`'s 'all'): metres of ground ahead of the eye (rounded out to
     * the ground's next row) that also stay in the live world, the same vertices drawn over the cached
     * picture, for pieces that sink into the lawn (Whack a Mole's moles) and the shadows cast on it.
     * Keep it nearer than the meadow's details (bushes and rocks, 6.8 m on).
     */
    liveGround?: number;
    /** Meadow (default) or desert. */
    biome?: Biome;
    /**
     * The ground and everything standing on it (treeline, framing trees, bushes, rocks, foreground).
     * Default true; a game that scrolls its own ground passes false and gets only the sky and far hills.
     */
    near?: boolean;
    /** Trees, bushes, rocks and foreground plants on the ground. Default true. */
    groundDetails?: boolean;
};
/** Spawns the whole world for a view and theme; returns every entity, to despawn on a new layout or theme. */
export declare function spawnWorld(world: World, v: View3D, theme: GameTheme, options?: MeadowOptions): Entity[];
/**
 * What of the meadow a cached backdrop (shared/EngineScenery) holds: `all` of it but what moves (for a
 * game that plays in front of the whole meadow), or only the `sky` (sky, sun or moon, stars and clouds,
 * the costly translucent part) for a game whose own pieces stand on, sink into or scroll over the land:
 * the land then stays in the game's world, where it's depth-sorted with them.
 */
export type MeadowBackdrop = 'all' | 'sky';
/** A meadow split between a game's backdrop and its world. */
export type MeadowLayers = {
    backdrop: Entity[];
    live: Entity[];
};
/**
 * Spawns the meadow with its still parts in `backdrop` (stepped, so the renderer draws it again) and
 * the rest (hot-air balloons, and the land unless `cached` is 'all') in `live`. With the land cached,
 * `options.liveGround` keeps the nearest ground live as well, over its cached copy.
 */
export declare function spawnMeadow(backdrop: World, live: World, v: View3D, theme: GameTheme, options?: MeadowOptions, cached?: MeadowBackdrop): MeadowLayers;
/** Removes a meadow from both worlds. */
export declare function removeMeadow(backdrop: World, live: World, m: MeadowLayers): void;
/** How far ahead of the eye the live ground for `liveGround: depth` reaches, in metres. */
export declare const liveGroundDepth: (depth: number) => number;
/** The clear color behind everything (only ever peeks out at the very edges). */
export declare const backgroundFor: (theme: GameTheme) => readonly [number, number, number];
/** Fixed scenery shared by the meadow games; seeded placement remains per run. */
export declare function warmAssets(theme: GameTheme, biomes?: readonly Biome[]): Iterable<() => unknown>;
export {};
//# sourceMappingURL=EngineMeadow.d.ts.map