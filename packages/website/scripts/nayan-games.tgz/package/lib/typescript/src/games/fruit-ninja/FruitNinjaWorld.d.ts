import type { Entity, World } from 'nayan-ui';
import type { GameTheme } from '../../services/ThemeService';
import { type View3D } from '../shared/EngineMeadow';
export { at, backgroundFor, cameraFor, facing, lightFor, planeVector, pointSize, type View3D } from '../shared/EngineMeadow';
/** Metres from the eye to the play plane. */
export declare const PLAY_DEPTH = 3.6;
export declare const makeView: (width: number, height: number) => View3D;
export declare const spawnWorld: (world: World, v: View3D, theme: GameTheme) => Entity[];
//# sourceMappingURL=FruitNinjaWorld.d.ts.map