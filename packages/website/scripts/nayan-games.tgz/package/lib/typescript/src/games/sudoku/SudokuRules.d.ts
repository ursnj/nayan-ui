export declare const POINTS_PER_CORRECT = 200;
export declare const POINTS_PER_UNIT = 500;
export declare const WIN_BONUS = 5000;
export declare const CLUES = 36;
export type Cell = {
    value: number;
    given: boolean;
    error: boolean;
};
export type Puzzle = {
    grid: Cell[][];
    solution: number[][];
    toFill: number;
};
/** A fresh puzzle: a solved board with all but 36 cells emptied, at random. */
export declare function newPuzzle(): Puzzle;
/** The cells of the row, column and box through (row, col) that are now all solved, each unit once, and the points for them. */
export declare function completedUnits(p: Puzzle, row: number, col: number): {
    cells: number[];
    points: number;
};
/** How many of each digit are still to place (9 minus the right-looking ones on the board), as the original pad counted. */
export declare function remaining(p: Puzzle): number[];
//# sourceMappingURL=SudokuRules.d.ts.map