import { GAME_IDS, type GameDefinition } from './UtilsService';
export declare const GAMES: Record<GAME_IDS, GameDefinition>;
export declare const GAMES_LIST: GameDefinition[];
export declare const GAMES_MAPPING: any;
//# sourceMappingURL=GamesService.d.ts.map