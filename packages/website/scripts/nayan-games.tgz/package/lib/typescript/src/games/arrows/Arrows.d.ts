export declare const Arrows: import("react").FC<import("../..").GameProps>;
//# sourceMappingURL=Arrows.d.ts.map