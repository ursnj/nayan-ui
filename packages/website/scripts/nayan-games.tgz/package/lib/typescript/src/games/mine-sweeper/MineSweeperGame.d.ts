import { type Camera, type DragEvent, World } from 'nayan-ui';
import type { GameTheme } from '../../services/ThemeService';
import type { GamePhase as Phase } from '../shared/useEngineGame';
import { type Board, type Layout } from './MineSweeperConstants';
import { type Cell } from './MineSweeperRules';
import { type Scene } from './MineSweeperScene';
/** reveal: cells opened; flag: a flag planted; mine: one went off. */
export type GameEvent = 'reveal' | 'flag' | 'mine';
export declare function createGame(theme: GameTheme, board: Board): {
    world: World;
    camera: Camera;
    theme: GameTheme;
    board: Board;
    layout: Layout | null;
    scene: Scene | null;
    phase: Phase;
    grid: Cell[][];
    firstReveal: boolean;
    /** Set the moment a mine goes off: nothing more counts in the beat before the round ends. */
    mineHit: boolean;
    /** Score and the countdown live in the engine (Rust), advanced by world.update. */
    readonly score: number;
    readonly timeRemaining: number;
    minesRemaining: number;
    revealed: number;
    won: boolean;
    /** A finger down on the board: where, when, and whether it's already flagged (so the lift isn't a tap). */
    press: {
        x: number;
        y: number;
        at: number;
        cell: [number, number] | null;
        flagged: boolean;
    } | null;
    /** Seconds on the game's clock, for telling taps from presses. */
    clock: number;
    onPhase: (_p: Phase) => void;
    onMines: (_n: number) => void;
    onEvent: (_e: GameEvent) => void;
};
export type Game = ReturnType<typeof createGame>;
/** Lays the board out for the view (first layout, header height, rotation): rebuilt from the grid's state. */
export declare function setLayout(g: Game, l: Layout): void;
export declare function setTheme(g: Game, theme: GameTheme): void;
export declare function start(g: Game): void;
/** A fresh, hidden board, not started (Stop, Play Again). The world, and the GPU view drawing it, are kept. */
export declare function reset(g: Game): void;
/** The game's clock, and a resting finger's flag; the engine steps the world after. */
export declare function tick(g: Game, dt: number): void;
/** The cell under a view point (on the raised tiles' tops), or null between cells or off the board. */
export declare function cellUnder(g: Game, x: number, y: number): [number, number] | null;
/** Down on a cell starts a press; resting there flags it (in `tick`); a quick lift without wandering reveals it. */
export declare function drag(g: Game, { phase, x, y }: DragEvent): void;
/** Reveals a cell: a mine ends the round; otherwise it (and any empty run) opens, 100 points a cell. */
export declare function revealAt(g: Game, row: number, col: number): void;
/** Flags a hidden cell (50 points, one fewer mine to find) or takes its flag back off. */
export declare function toggleFlag(g: Game, row: number, col: number): void;
//# sourceMappingURL=MineSweeperGame.d.ts.map