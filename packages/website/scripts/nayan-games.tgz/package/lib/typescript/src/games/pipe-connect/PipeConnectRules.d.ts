import { PipeType } from './PipeConnectConstants';
export interface PipeCell {
    id: string;
    row: number;
    col: number;
    type: PipeType;
    rotation: number;
    filled: boolean;
    fixed: boolean;
}
export declare const getOpenDirections: (cell: PipeCell) => number;
export declare const findConnectedPath: (grid: PipeCell[][]) => Set<string>;
export declare const isPuzzleCompleteFromSet: (grid: PipeCell[][], connected: Set<string>) => boolean;
export declare const isPuzzleComplete: (grid: PipeCell[][]) => boolean;
export declare const generatePuzzle: (size: number) => PipeCell[][];
export declare const rotatePipe: (cell: PipeCell) => PipeCell;
//# sourceMappingURL=PipeConnectRules.d.ts.map