import type { Vec3 } from 'nayan-ui';
export declare function facadeWindowQuads(): Iterable<{
    corners: [Vec3, Vec3, Vec3, Vec3];
    normal: Vec3;
}>;
//# sourceMappingURL=CarRacingFacade.d.ts.map