export declare const NutsAndBolts: import("react").FC<import("../..").GameProps>;
//# sourceMappingURL=NutsAndBolts.d.ts.map