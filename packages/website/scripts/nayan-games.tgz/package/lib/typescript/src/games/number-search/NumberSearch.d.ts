export declare const NumberSearch: import("react").FC<import("../..").GameProps>;
//# sourceMappingURL=NumberSearch.d.ts.map