import { type Color, type Entity, type Vec3, type World } from 'nayan-ui';
export type PenguinAnim = 'idle' | 'walk' | 'run' | 'punch' | 'jab' | 'jump' | 'slide' | 'hit' | 'dance' | 'dead';
/** Clips that loop until another one starts. */
export declare const LOOPING: ReadonlySet<PenguinAnim>;
/** How long each one-shot clip runs, in seconds. */
export declare const CLIP_TIME: Record<PenguinAnim, number>;
export type Penguin = {
    root: Entity;
    pelvis: Entity;
    body: Entity;
    flipperL: Entity;
    flipperR: Entity;
    footL: Entity;
    footR: Entity;
    /** Where the root stands (ground x), kept in step with root moves. */
    x: number;
    /** The yaw the root faces, radians (0 looks at the camera). */
    yaw: number;
    anim: PenguinAnim | null;
};
/** Builds the meshes ahead of time (each is made once per app). */
export declare function preparePenguin(): void;
/** Spawns a penguin standing at `position` (feet on the ground), `size` units tall, facing the camera. */
export declare function spawnPenguin(world: World, position: Vec3, size?: number, tint?: Color): Penguin;
/** Turns the whole bird to `yaw` (0 faces the camera, π/2 faces +x). */
export declare function facePenguin(world: World, p: Penguin, yaw: number, duration?: number): void;
/** Walks, runs or slides the root to ground x over `duration` (the limbs play whatever clip is on). */
export declare function movePenguin(world: World, p: Penguin, x: number, duration: number, easing?: 'linear' | 'easeOut' | 'easeInOut'): Promise<void>;
/** Snaps the bird to ground x, upright and facing `yaw`, every limb at rest (a new run). */
export declare function placePenguin(world: World, p: Penguin, x: number, yaw?: number): void;
/**
 * Plays a clip. Looping clips (idle, walk, run, dance) run until the next call and resolve at once;
 * one-shots resolve when they end. `speed` scales the clip's pace.
 *
 * Every clip is keyed for weight and timing rather than evenly: a beat of anticipation before each
 * action, a fast action, overshoot and a settle after it; feet planted while the body shifts its
 * weight over them; flippers trailing the body's moves (overlapping action); squash on landings and
 * stretch on take-offs. Curves run through the keys smoothly.
 */
export declare function playPenguin(world: World, p: Penguin, anim: PenguinAnim, speed?: number): Promise<void>;
/** Hand position for effects: where a strike lands, in world space, for a bird of `size` at its x and yaw. */
export declare function strikePoint(p: Penguin, size: number): Vec3;
//# sourceMappingURL=PenguinModel.d.ts.map