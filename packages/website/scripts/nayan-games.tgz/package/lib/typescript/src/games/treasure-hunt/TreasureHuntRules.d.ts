import { type MeshRecipe, type ProceduralWorld, type Quat, type WorldRecipe } from 'nayan-ui';
import { type Point } from './TreasureHuntConstants';
export declare const ROCK_RINGS = 12;
export declare const ROCK_SIDES = 18;
export declare const CAVE_INNER_WIDTH = 3.5;
export declare const CAVE_INNER_HEIGHT = 4.8;
export declare const BRIDGE_RAIL_INSET = 0.15;
export declare const BRIDGE_RAIL_DEPTH = 0.09;
export declare const BRIDGE_POST_WIDTH = 0.3;
export declare const BRIDGE_POST_HEIGHT = 1.12;
export interface BridgeBarrier extends Point {
    kind: 'rail' | 'post';
    halfX: number;
    halfZ: number;
}
/** The renderer and collision share every railing and post position. */
export declare function bridgeBarriers(bridge: {
    halfLength: number;
    halfWidth: number;
}): BridgeBarrier[];
/**
 * A boulder style's surface: one recipe draws the rock and, through its convex hull, blocks walkers
 * (the native core builds both). Inputs u (around) and v (top to bottom).
 */
export declare function boulderRecipe(style: number): MeshRecipe;
export interface Hill extends Point {
    height: number;
    width: number;
    depth: number;
    yaw: number;
}
export interface Cave extends Point {
    y: number;
    length: number;
}
export interface Bridge extends Point {
    halfLength: number;
    halfWidth: number;
    y: number;
}
export type TerrainSurface = 'grass' | 'hill' | 'river' | 'shore' | 'cave' | 'bridge';
/** Terrain materials: meshes drawn with their own textures. */
export declare const TERRAIN_MATERIALS: {
    readonly meadow: 0;
    readonly stone: 1;
    readonly shore: 2;
};
export declare const TERRAIN_STEP = 1.6;
export declare const TERRAIN_EDGE: number;
export declare const TERRAIN_GRID: readonly number[];
export interface NatureProp extends Point {
    kind: 'pine' | 'birch' | 'rock';
    y: number;
    scale: number;
    yaw: number;
    style: number;
}
export interface NatureDecoration extends Point {
    kind: 'rock' | 'pine';
    area: 'horizon' | 'cave-roof' | 'cave-entrance';
    y: number;
    scale: [number, number, number];
    yaw: number;
    style: number;
}
export interface Landscape {
    profile: number;
    phase: number;
    hills: Hill[];
    caves: Cave[];
    bridges: Bridge[];
}
export interface GrassPlacement {
    position: [number, number, number];
    scale: number;
    yaw: number;
    style: number;
}
export interface NatureMap {
    seed: number;
    edge: number;
    rotation: number;
    landscape: Landscape;
    spawn: Point;
    props: NatureProp[];
    decorations: NatureDecoration[];
    gems: Point[];
    enemies: Point[];
    /** The native world: terrain, solids, reachable ground and every query. */
    world: ProceduralWorld;
}
/** Mulberry32, the same stream the native core draws. */
export declare function random(seed: number): () => number;
/** The river's centre and half-width as sine terms of z ([fx, fz, phase, amp], as the field graph takes them). */
export declare const riverTerms: (phase: number) => readonly [readonly [0, 0.035, number, 11], readonly [0, 0.073, 0, 2]];
export declare const riverWidthTerms: (phase: number) => readonly [readonly [0, 0.05, number, 0.6]];
export declare const riverX: (landscape: Landscape, z: number) => number;
export declare const riverWidth: (landscape: Landscape, z: number) => number;
export declare const waterLevel: (_landscape: Landscape, z: number) => number;
/** Each terrain profile's hills, caves and bridges (a fixed seed per profile). */
export declare function landscapeFor(profile: number): Landscape;
/** The whole wilderness as a native world recipe. */
export declare function natureRecipe(seed: number): WorldRecipe;
/** Grass clumps generated with the world (on clear grass only). */
export declare function grassPlacements(map: NatureMap): GrassPlacement[];
/** Reachable navigation cells (the lattice the objectives are picked from). */
export declare function reachablePoints(map: NatureMap): Point[];
export declare function toWorld(map: Pick<NatureMap, 'rotation'>, x: number, z: number): Point;
export declare function toLocal(map: Pick<NatureMap, 'rotation'>, x: number, z: number): Point;
export declare const groundHeight: (map: NatureMap, x: number, z: number) => number;
/** Surface tilt in a parent's yaw basis, for contact shadows that lie against the ground. */
export declare const groundTilt: (map: NatureMap, x: number, z: number, yaw?: number) => Quat;
export declare const surfaceAt: (map: NatureMap, x: number, z: number) => TerrainSurface;
export declare const bridgeAt: (map: NatureMap, x: number, z: number) => Bridge | undefined;
export declare const waterDepth: (map: NatureMap, x: number, z: number) => number;
export declare function caveAt(map: NatureMap, x: number, z: number): Cave | undefined;
/** Grass, bridge decks and cave passages are walkable; complete body footprints stay outside solids. */
export declare const isWalkable: (map: NatureMap, x: number, z: number, radius?: number) => boolean;
export declare const navigationClearance: (map: NatureMap, x: number, z: number, radius?: number) => number;
export declare const solidClearance: (map: NatureMap, x: number, z: number, radius: number, bottom: number, top: number) => number;
export declare function mapOverview(map: NatureMap, size: number): readonly (TerrainSurface | null)[];
/**
 * The next run in the same world (Play Again, Stop): fresh places for the diamonds and robots, picked
 * by the native world from a seed derived from the world's and the run's number. The terrain, scenery
 * and reachable ground are reused as they are.
 */
export declare function createRunState(map: NatureMap, run: number): NatureState;
/** Generates a world now (explicit seeds and openings that didn't preload). */
export declare function generateNature(seed?: number): NatureMap;
/** Where generated worlds are kept between visits: the native core saves and restores them itself. */
export interface WorldStore {
    /** The storage key of a world (tied to the game's cache revision). */
    key(seed: number): string;
    /** Whether a world is kept, cheaply (without reading it). */
    has?(seed: number): boolean;
    /** Whether the visit also needs the terrain meshes built (they aren't cached yet). */
    needsTerrain?(profile: number): boolean;
}
/** Generated worlds are saved to, and restored from, `store` (none: every visit generates). */
export declare function keepWorlds(store: WorldStore | undefined): void;
/** Whether a world is kept under the store's key. */
export declare const isWorldStored: (seed: number) => boolean;
/** The one world each terrain profile has, generated once and then restored. */
export declare const worldSeed: (profile: number) => number;
/**
 * Prepares the next visit's world: one job that generates (or restores) it on a native thread, so
 * the loader keeps animating while it builds.
 */
export declare function warmNextMap(): Iterable<() => Promise<void>>;
export declare const peekNextMap: () => NatureMap | undefined;
export type Phase = 'ready' | 'playing' | 'won' | 'lost';
export interface Enemy extends Point {
    id: number;
    home: Point;
    health: number;
    yaw: number;
    windup: number;
    recovery: number;
    stagger: number;
    moving: boolean;
}
export interface Gem extends Point {
    id: number;
    taken: boolean;
}
export interface NatureState {
    map: NatureMap;
    phase: Phase;
    player: Point;
    yaw: number;
    health: number;
    gems: number;
    defeated: number;
    score: number;
    time: number;
    attackCooldown: number;
    attackPending: number;
    invulnerable: number;
    moving: boolean;
    speed: number;
    velocity: Point;
    yawVelocity: number;
    enemies: Enemy[];
    pickups: Gem[];
}
export interface NatureInput {
    x: number;
    y: number;
    attack: boolean;
}
export interface NatureEvent {
    kind: 'attack' | 'hit' | 'defeated' | 'gem' | 'hurt' | 'won' | 'lost';
    x: number;
    z: number;
    id?: number;
}
export declare const distance: (a: Point, b: Point) => number;
export declare function createState(seed?: number): NatureState;
export interface ActorBody extends Point {
    radius: number;
}
/** Sweep the full direction, settle just before contact, then slide along the contact normal (native). */
export declare function moveActor(map: NatureMap, point: Point, dx: number, dz: number, radius?: number, bodies?: readonly ActorBody[]): void;
/** No React or native rendering: rules emit events for the engine's effects and HUD. */
export declare function step(state: NatureState, input: NatureInput, elapsed: number): NatureEvent[];
//# sourceMappingURL=TreasureHuntRules.d.ts.map