export declare const ROWS = 5;
export declare const COLS = 4;
export type FruitSymbol = 'apple' | 'orange' | 'banana' | 'grapes' | 'kiwi' | 'strawberry' | 'mango' | 'peach' | 'cherries' | 'pineapple' | 'watermelon' | 'pomegranate';
export declare const FRUIT_SYMBOLS: FruitSymbol[];
export type CardState = 'down' | 'up' | 'matched';
export type Card = {
    symbol: number;
    state: CardState;
};
/** A fresh deck: a pair of each of the first ten fruits, Fisher-Yates shuffled (the same draws as the original store). */
export declare function buildDeck(): {
    cards: Card[];
    totalPairs: number;
};
//# sourceMappingURL=MemoryMatchRules.d.ts.map