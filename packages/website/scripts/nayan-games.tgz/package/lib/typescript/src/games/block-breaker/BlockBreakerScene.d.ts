import { type Color, type Entity, type Vec3, type World } from 'nayan-ui';
import type { GameTheme } from '../../services/ThemeService';
import { type Layout, type PowerUpType } from './BlockBreakerConstants';
/** A board point at depth `z`, in world space. */
export declare const toWorld: (l: Layout, x: number, y: number, z?: number) => Vec3;
export declare const brickColor: (row: number) => [number, number, number, number];
/** Ball, trail and paddle colors: white reads on classic and dark; light mode draws them in its text color. */
export type PieceColors = {
    ball: Color;
    trail: Color;
    paddle: Color;
};
export declare function pieceColors(theme: GameTheme): PieceColors;
export type Scenery = {
    backdrop: Entity;
    parts: Entity[];
};
export declare function buildScenery(world: World, l: Layout, theme: GameTheme): Scenery;
export declare function removeScenery(world: World, s: Scenery): void;
export declare function setSceneryTheme(world: World, l: Layout, s: Scenery, theme: GameTheme): void;
/** A brick by its top-left; with `intro`, it drops into place `intro` seconds in, with a bounce. */
export declare function spawnBrick(world: World, l: Layout, x: number, y: number, row: number, intro: number | null): Entity;
/** A broken brick: it pops (swells, flashes, settles, shrinks away) and bursts in its color, then it's gone. */
export declare function breakBrick(world: World, l: Layout, brick: Entity, x: number, y: number, row: number): void;
/** A brick that took a hit but stands: a quick shake. */
export declare function hitBrick(world: World, brick: Entity): void;
/** The paddle: a root that squashes (about its centre) carrying the body, which widens. */
export type Paddle = {
    root: Entity;
    body: Entity;
};
export declare function spawnPaddle(world: World, l: Layout, x: number, width: number, color: Color): Paddle;
export declare function placePaddle(world: World, l: Layout, p: Paddle, x: number): void;
export declare function setPaddleWidth(world: World, l: Layout, p: Paddle, width: number, animate: boolean): void;
/** Squash and stretch when the ball (strength 1) or a power-up (1.4) lands on it. */
export declare function bumpPaddle(world: World, p: Paddle, strength: number): void;
/** A ball and the three fading dots trailing it. */
export type BallView = {
    ball: Entity;
    trail: Entity[];
};
export declare function spawnBall(world: World, l: Layout, x: number, y: number, colors: PieceColors): BallView;
export declare function placeBall(world: World, l: Layout, v: BallView, x: number, y: number, vx: number, vy: number): void;
export declare function colorBall(world: World, v: BallView, colors: PieceColors): void;
export declare function removeBall(world: World, v: BallView): void;
/** A falling power-up: a sphere in its color with a breathing glow behind it. */
export declare function spawnPowerUp(world: World, l: Layout, type: PowerUpType, x: number, y: number): Entity;
export declare function placePowerUp(world: World, l: Layout, e: Entity, x: number, y: number): void;
//# sourceMappingURL=BlockBreakerScene.d.ts.map