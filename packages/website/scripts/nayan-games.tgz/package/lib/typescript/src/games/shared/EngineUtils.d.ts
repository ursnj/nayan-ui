export { frontLight, toColor } from 'nayan-ui';
/** A theme color's RGB. */
export declare function toRgb(css: string): readonly [number, number, number];
export { MAX_GAME_WIDTH, gameWidthFor } from './EngineGameWidth';
/** Ages a due intro by `dt`; once it's played long enough, clears `intro` so later rebuilds show the board at rest. */
export declare function introPlayed(g: {
    intro: boolean;
    introAge: number;
}, dt: number): void;
//# sourceMappingURL=EngineUtils.d.ts.map