import type { Vec3 } from 'nayan-ui';
import type { FightInput } from './BoxingArenaRules';
export type TouchState = {
    phase: 'idle' | 'pressed' | 'moving' | 'vertical' | 'blocking';
    held: number;
    coast: number;
    /** The contact being followed (other fingers are ignored), and where it went down. */
    contact: number | null;
    startX: number;
    startY: number;
};
export declare const newTouch: () => TouchState;
/** Drops the gesture and everything it was holding. */
export declare function cancelTouch(touch: TouchState, input: FightInput): void;
export declare function startTouch(touch: TouchState, input: FightInput, id: number, x: number, y: number): void;
export declare function moveTouch(touch: TouchState, input: FightInput, id: number, x: number, y: number): void;
export declare function endTouch(touch: TouchState, input: FightInput, id: number): void;
/** Advances the hold-to-block and the drag's coast by the game's frame time. */
export declare function updateTouch(touch: TouchState, input: FightInput, dt: number): void;
export declare const FOV = 0.68;
export declare const READY_ORBIT = 0.55;
export declare function advanceOrbit(angle: number, ready: boolean, elapsed: number): number;
export type Viewport = {
    width: number;
    height: number;
    offset: number;
};
/** What the camera frames: the fighters' midpoint and how far apart they are, and whether it's re-framing. */
export type Framing = {
    x: number;
    spread: number;
    moving: boolean;
};
/** Advances `framing` toward the fighters at `left` and `right`; `follow` (or `dt` 0) frames them at once. */
export declare function updateFraming(framing: Framing, left: number, right: number, dt: number, follow: boolean): void;
/**
 * Keeps both fighters large and whole between the scoreboard and the controls (and the fighter
 * choices while `selecting`), `orbit` radians round the stage.
 */
export declare function fightCamera(left: number, right: number, view: Viewport, orbit?: number, selecting?: boolean): {
    eye: Vec3;
    target: Vec3;
    fov: number;
};
//# sourceMappingURL=BoxingArenaControls.d.ts.map