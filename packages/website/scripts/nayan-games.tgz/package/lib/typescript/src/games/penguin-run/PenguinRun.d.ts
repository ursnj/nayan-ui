export declare const PenguinRun: import("react").FC<import("../..").GameProps>;
//# sourceMappingURL=PenguinRun.d.ts.map