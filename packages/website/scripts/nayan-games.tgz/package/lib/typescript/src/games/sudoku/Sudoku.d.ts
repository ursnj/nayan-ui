export declare const Sudoku: import("react").FC<import("../..").GameProps>;
//# sourceMappingURL=Sudoku.d.ts.map