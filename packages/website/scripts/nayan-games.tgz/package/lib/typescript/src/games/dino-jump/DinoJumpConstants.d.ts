import type { MeadowOptions, Rig } from '../shared/EngineMeadow';
export declare const TIME_LIMIT = 120;
export declare const LIVES = 3;
export declare const POINTS_PER_SECOND = 200;
export declare const MUSHROOM_POINTS = 1000;
export type ObstacleKind = 'cactus_small' | 'cactus_large' | 'mushroom';
/** Each obstacle's size in screen points (its collision box, and what's drawn). */
export declare const OBSTACLE_SIZE: Record<ObstacleKind, {
    width: number;
    height: number;
}>;
export declare const MUSHROOM_CHANCE = 0.05;
export declare const SMALL_CHANCE = 0.5;
export declare const STEP: number;
export declare const STEP_TOLERANCE = 0.002;
export declare const MAX_PENDING = 0.05;
export declare const GRAVITY = 1.4;
export declare const JUMP_FORCE = -28;
export declare const RUN_SPEED = 6;
export declare const DINO_X = 50;
export declare const DINO_WIDTH = 70;
export declare const DINO_HEIGHT = 75;
export declare const DINO_HIT_WIDTH = 50;
export declare const DINO_HIT_HEIGHT = 60;
export declare const MAX_OBSTACLES = 5;
export declare const MIN_OBSTACLE_GAP = 300;
export declare const REMOVE_X = -100;
export declare const FIRST_OBSTACLE = 1.5;
export declare const SPAWN_MIN = 2.5;
export declare const SPAWN_SPREAD = 2;
export declare const STRIDE_TIME = 0.16;
export declare const DUST_INTERVAL = 0.24;
/** The screen line the dino runs on: higher with no header, as the original ground strip was. */
export declare const groundLine: (height: number, offset: number) => number;
/**
 * A low camera over the desert floor, at the height that puts the real ground under the play plane
 * exactly on the original game's ground line: the dino runs on the sand, which runs on to the horizon.
 */
export declare function rigFor(height: number, offset: number): Rig;
export declare const MEADOW: MeadowOptions;
/** The scrolling desert floor comes in tiles this many metres wide (three cover any view). */
export declare const TILE = 80;
export type Layout = {
    width: number;
    height: number;
    offset: number;
    groundY: number;
};
export declare const getLayout: (width: number, height: number, offset: number) => Layout;
//# sourceMappingURL=DinoJumpConstants.d.ts.map