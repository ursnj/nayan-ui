import { type Entity, type World } from 'nayan-ui';
import { type Assets } from './BoxingArenaConstants';
import type { CombatAction, CombatEvent, Fight } from './BoxingArenaRules';
/** Builds every mesh ahead of the first visit (the game loader's stage); cached for the app's life. */
export declare function warmAssets(): Iterable<() => unknown>;
/** A fighter's entities: `root` on the canvas, `body` at mid-height, `mesh` the rigged model. */
export type Actor = {
    root: Entity;
    body: Entity;
    mesh: Entity;
    loaded: boolean;
    action: CombatAction | null;
    elapsed: number;
};
export type Scene = {
    actors: Actor[];
};
export declare function buildScene(world: World, backdrop: World, assets: Assets, fight: Fight): Scene;
/** Puts each fighter back on its mark, facing the other (after choosing a side, or a reset). */
export declare function placeActors(world: World, scene: Scene, fight: Fight): void;
/** Moves (allocation-free, applied as the world steps) and animates the fighters to the rules' state. */
export declare function presentFighters(world: World, scene: Scene, fight: Fight): void;
/**
 * A puff where a blow lands (paler on a guard); returns the camera shake it calls for, or 0. Only
 * hits shake the camera: every shaken frame redraws the cached forest too.
 */
export declare function impact(world: World, fight: Fight, event: CombatEvent): number;
//# sourceMappingURL=BoxingArenaScene.d.ts.map