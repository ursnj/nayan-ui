export declare const Game2048: import("react").FC<import("../..").GameProps>;
//# sourceMappingURL=Game2048.d.ts.map