import { type Camera, type DragEvent, World } from 'nayan-ui';
import type { GameTheme } from '../../services/ThemeService';
import type { GamePhase as Phase } from '../shared/useEngineGame';
import { type Layout } from './SpiderSolitaireConstants';
import { type Board } from './SpiderSolitaireRules';
import { type Held, type Scene } from './SpiderSolitaireScene';
/** select / deselect: a run picked up or put back; invalid: a move or deal not allowed; place: a run moved; deal: a row dealt; complete: a run lifted off; win: the eighth. */
export type GameEvent = 'select' | 'deselect' | 'invalid' | 'place' | 'deal' | 'complete' | 'win';
/** What a finger is on: a pile's card, a pile (its empty place or below its cards), or the deck. */
type Hit = {
    kind: 'card';
    pile: number;
    index: number;
} | {
    kind: 'pile';
    pile: number;
} | {
    kind: 'stock';
} | null;
export declare function createGame(theme: GameTheme): {
    world: World;
    camera: Camera;
    theme: GameTheme;
    layout: Layout | null;
    scene: Scene | null;
    phase: Phase;
    board: Board;
    /** The run picked up (tapped), or being dragged. */
    held: Held;
    /** A finger down: where, on what, and (once it's moved off) where it grabbed the dragged run. */
    press: {
        x: number;
        y: number;
        hit: Hit;
        grab: [number, number] | null;
        dragging: boolean;
    } | null;
    /** Seconds since the start (the original game's elapsed clock), and the score a win reports: both in the engine (Rust). */
    readonly time: number;
    readonly score: number;
    won: boolean;
    onPhase: (_p: Phase) => void;
    onDeals: (_n: number) => void;
    onCompleted: (_n: number) => void;
    onEvent: (_e: GameEvent) => void;
};
export type Game = ReturnType<typeof createGame>;
/** Lays the table out for the view (first layout, header height, rotation); the first deal glides out of the deck. */
export declare function setLayout(g: Game, l: Layout): void;
export declare function setTheme(g: Game, theme: GameTheme): void;
/** Starts play on the deal already on the table. */
export declare function start(g: Game): void;
/** A fresh shuffle dealt out, not started (Stop, Play Again). The world, and the GPU view drawing it, are kept. */
export declare function reset(g: Game): void;
/** What's under a view point: the top-most card there, a pile's column, or the deck. */
export declare function hitAt(g: Game, sx: number, sy: number): Hit;
/** A quick tap does what it did in the original game; a finger that moves off a face-up run drags it. */
export declare function drag(g: Game, e: DragEvent): void;
/** A card tapped: put back the run if it's the one picked up, move the picked-up run here, or pick up from here. */
export declare function select(g: Game, pile: number, index: number): void;
/** Puts the picked-up run on a pile, if it may go there. */
export declare function moveTo(g: Game, to: number): void;
/** One card onto every pile from the deck (not while a pile is empty). */
export declare function deal(g: Game): void;
export {};
//# sourceMappingURL=SpiderSolitaireGame.d.ts.map