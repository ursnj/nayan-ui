import { type Entity, type Texture, type Vec3, type World } from 'nayan-ui';
import type { GameTheme } from '../../services/ThemeService';
import { type Layout } from './TileHomeConstants';
export declare const Z_BACKDROP = 1;
export declare const Z_FLYING = 420;
export declare const layerZ: (layer: number) => number;
export declare const trayZ = 20;
/** A view point (from the top-left) at depth `z`, in world space. */
export declare const toWorld: (l: Layout, x: number, y: number, z?: number) => Vec3;
export type Scenery = Entity[];
/** The background, the board panel and the tray with its empty slots, for a theme. */
export declare function buildScenery(world: World, l: Layout, theme: GameTheme): Scenery;
export declare const getTileAtlas: () => Texture | undefined;
export declare function loadTileAtlas(): Promise<Texture>;
export declare const tilePictureSide: (size: number) => number;
export declare function shadeTile(world: World, entity: Entity | null, shade: number, duration: number): void;
export declare function spawnTile(world: World, atlas: Texture, type: number, position: Vec3, scale: number, shade?: number): Entity;
//# sourceMappingURL=TileHomeScene.d.ts.map