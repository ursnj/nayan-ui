import { type Camera, type DragEvent, World } from 'nayan-ui';
import type { GameTheme } from '../../services/ThemeService';
import type { GamePhase as Phase } from '../shared/useEngineGame';
import { type Grid, type Layout } from './PaperIoConstants';
import { type Board, type DirCode, type Stats } from './PaperIoRules';
import { type Scene } from './PaperIoScene';
/** turn: your swipe took; capture: you banked land; over: the round ended. */
export type GameEvent = 'turn' | 'capture' | 'over';
export declare function createGame(theme: GameTheme): {
    world: World | null;
    camera: Camera;
    theme: GameTheme;
    grid: Grid | null;
    layout: Layout | null;
    scene: Scene | null;
    phase: Phase;
    board: Board | null;
    stats: Stats | null;
    won: boolean;
    sinceStep: number;
    /** The first frame after starting credits no time (as the original loop's first frame). */
    fresh: boolean;
    /** The swipe in progress: where it went down, and the last turn it asked for. */
    swipe: {
        x: number;
        y: number;
        last: DirCode | null;
    } | null;
    onPhase: (_p: Phase) => void;
    onStats: (_s: Stats) => void;
    onTime: (_t: number) => void;
    onEvent: (_e: GameEvent) => void;
};
export type Game = ReturnType<typeof createGame>;
/**
 * Lays the board out for the view. The first layout fixes the grid (as the original game fixed it at load)
 * and makes the world, sized for every cell's land and trail; later ones (header, rotation) keep the
 * board and only rebuild the scene round it.
 */
export declare function setLayout(g: Game, l: Layout): void;
export declare function setTheme(g: Game, theme: GameTheme): void;
/** Starts a round on a fresh board, as the original Start did. */
export declare function start(g: Game): void;
/** A fresh board, not started (Stop, Play Again). */
export declare function reset(g: Game): void;
/** The grid's steps on the original loop's clock; the engine steps the world after. */
export declare function tick(g: Game, dt: number): void;
/** Swipes steer: once a drag has gone 10 points from where it went down, its main way is a turn. */
export declare function drag(g: Game, { phase, x, y }: DragEvent): void;
//# sourceMappingURL=PaperIoGame.d.ts.map