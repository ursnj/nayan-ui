export declare const ChameleonRun: import("react").FC<import("../..").GameProps>;
//# sourceMappingURL=ChameleonRun.d.ts.map