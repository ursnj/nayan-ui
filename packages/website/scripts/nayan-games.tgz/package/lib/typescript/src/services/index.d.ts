export * from './GamesMetadata';
export * from './SoundsService';
export * from './UtilsService';
export * from './GameLoaders';
export * from './ThemeService';
export { gamePattern, GAME_PATTERN_RECIPE, PATTERN_GRID_COLOR } from '../helpers/GamePatternData';
//# sourceMappingURL=index.d.ts.map