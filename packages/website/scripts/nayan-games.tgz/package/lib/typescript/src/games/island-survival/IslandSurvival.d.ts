import { type GameProps } from '../../services/UtilsService';
export declare const IslandSurvival: import("react").FC<GameProps>;
//# sourceMappingURL=IslandSurvival.d.ts.map