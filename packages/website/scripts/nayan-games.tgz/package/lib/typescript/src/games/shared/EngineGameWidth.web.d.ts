/** Keep browser boards compact, with room around raised pieces and the shared HUD. */
export declare const MAX_GAME_WIDTH = 420;
export declare const gameWidthFor: (viewWidth: number) => number;
//# sourceMappingURL=EngineGameWidth.web.d.ts.map