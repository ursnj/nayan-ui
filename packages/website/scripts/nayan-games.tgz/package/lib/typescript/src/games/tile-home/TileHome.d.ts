import { type GameProps } from '../../services/UtilsService';
export declare const TileHome: import("react").FC<GameProps>;
//# sourceMappingURL=TileHome.d.ts.map