import type { MeadowOptions, Rig } from '../shared/EngineMeadow';
export declare const TIME_LIMIT = 120;
export declare const MAX_LIVES = 3;
export declare const POINTS_PER_BALLOON = 100;
export declare const SPECIAL_CHANCE = 0.2;
/** The ordinary balloon colors (the multicolored one is the life balloon, not one of these). */
export declare const BALLOON_COLORS: readonly ["#FF0040", "#0080FF", "#FFD700", "#00FF80", "#8000FF", "#FF0080", "#FF4000", "#00FFFF", "#FF00FF", "#FFB000", "#00FF00"];
export type BalloonColor = (typeof BALLOON_COLORS)[number];
/** The life balloon's bands, knot to crown. */
export declare const RAINBOW: readonly ["#FF0080", "#8000FF", "#0080FF", "#00FF80", "#FFD700", "#FF4000"];
export declare const FIRST_BALLOONS = 3;
export declare const FIRST_STAGGER = 0.1;
export declare const SPAWN_INTERVAL = 0.8;
export declare const FRAME_TIME: number;
export declare const MAX_FRAMES = 3;
export declare const BALLOON_SIZE: number;
export declare const RISE_SPEED = -1.2;
export declare const LIFT = -0.005;
export declare const DRIFT_RANGE = 0.5;
export declare const SPIN_RANGE = 0.02;
export declare const WALL_BOUNCE = 0.8;
export declare const BALLOON_BOUNCE = 0.5;
export declare const BALLOON_HIT = 1.6;
export declare const BALLOON_GAP = 6;
export declare const TOUCH_PAD = 10;
export declare const POP_TIME = 0.2;
export declare const POP_SWELL = 1.22;
/** Eye height with the horizon low on the screen: open sky to float up through, the meadow below. */
export declare const RIG: Rig;
export declare const MEADOW: MeadowOptions;
export type Layout = {
    /** The GameView's size: the whole screen, as the original game area. */
    width: number;
    height: number;
    size: number;
    /** The balloon's body (it's taller than wide) and its whole height with the string. */
    bodyHeight: number;
    totalHeight: number;
};
export declare function getLayout(width: number, height: number): Layout;
//# sourceMappingURL=BalloonBlasterConstants.d.ts.map