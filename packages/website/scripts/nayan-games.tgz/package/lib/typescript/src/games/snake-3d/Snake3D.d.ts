export declare const Snake3D: import("react").FC<import("../..").GameProps>;
//# sourceMappingURL=Snake3D.d.ts.map