import { type Camera, type DragEvent, World } from 'nayan-ui';
import type { GameTheme } from '../../services/ThemeService';
import type { GamePhase as Phase } from '../shared/useEngineGame';
import { type Layout } from './Game2048Constants';
import { type Direction, type Grid } from './Game2048Rules';
import { type Scene } from './Game2048Scene';
/** How a game ended. */
export type Result = 'win' | 'timeout' | 'stuck';
/** move / merge: a slide (and whether it merged); invalid: a swipe that moved nothing; win / stuck: how a slide ended it. */
export type GameEvent = 'move' | 'merge' | 'invalid' | 'win' | 'stuck';
export declare function createGame(theme: GameTheme): {
    world: World;
    camera: Camera;
    theme: GameTheme;
    layout: Layout | null;
    scene: Scene | null;
    phase: Phase;
    grid: Grid;
    nextId: number;
    result: Result | null;
    /** Score and the countdown live in the engine (Rust), advanced by world.update. */
    readonly score: number;
    readonly timeLeft: number;
    /** A finger down, and whether its swipe has been taken. */
    press: {
        swiped: boolean;
    } | null;
    onPhase: (_p: Phase) => void;
    onEvent: (_e: GameEvent) => void;
};
export type Game = ReturnType<typeof createGame>;
/** Lays the board out for the view (first layout, header height, rotation): rebuilt where things stand. */
export declare function setLayout(g: Game, l: Layout): void;
export declare function setTheme(g: Game, theme: GameTheme): void;
/** Starts on the board already shown, with fifteen minutes on the clock. */
export declare function start(g: Game): void;
/** A fresh board, not started (Stop, Play Again, as the original game re-dealt both). */
export declare function reset(g: Game): void;
/** A slide one way, as the original store made it: a new tile if anything moved, then the win and stuck checks. */
export declare function move(g: Game, direction: Direction): void;
/** A swipe anywhere: taken the moment it's gone far enough (or on the lift), its longer way. */
export declare function drag(g: Game, { phase, dx, dy }: DragEvent): void;
//# sourceMappingURL=Game2048Game.d.ts.map