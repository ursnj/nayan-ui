import { type Color, type Entity, type Vec3, type World } from 'nayan-ui';
import type { GameTheme } from '../../services/ThemeService';
import { type Layout } from './BubbleShooterConstants';
/** A board point at depth `z`, in world space. */
export declare const toWorld: (l: Layout, x: number, y: number, z?: number) => Vec3;
export declare const bubblePosition: (l: Layout, x: number, y: number) => Vec3;
/** A grid bubble's size (the sphere mesh is one across). */
export declare const bubbleSize: (l: Layout) => number;
export declare const bubbleColor: (color: number) => [number, number, number, number];
/** White aim dots on classic; light / dark draw them in the theme's text color. */
export declare const aimColor: (theme: GameTheme) => Color;
export type Scenery = {
    backdrop: Entity;
    parts: Entity[];
};
export declare function buildScenery(world: World, l: Layout, theme: GameTheme): Scenery;
export declare function removeScenery(world: World, s: Scenery): void;
export declare function setSceneryTheme(world: World, l: Layout, s: Scenery, theme: GameTheme): void;
/** A bubble at (x, y), `scale` of its full size. */
export declare function spawnBubble(world: World, l: Layout, color: number, x: number, y: number, scale?: number): Entity;
/** A popped bubble: it pops (swells, flashes, settles, shrinks away) and bursts in its color, then it's gone. */
export declare function popBubble(world: World, l: Layout, e: Entity, color: number, x: number, y: number): void;
/** The aim dots, hidden until placed. */
export declare function spawnAimDots(world: World): Entity[];
/** Shows dots at `points` (x, y, radius triples, nearest first); the rest hide. */
export declare function placeAimDots(world: World, l: Layout, dots: Entity[], points: number[], color: Color): void;
//# sourceMappingURL=BubbleShooterScene.d.ts.map