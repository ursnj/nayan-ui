import { GAME_IDS, type GameThemeMode } from '../../services/UtilsService';
interface GameLoadingProps {
    gameId: GAME_IDS;
    theme?: GameThemeMode;
    label?: string;
    phase?: number;
    phases?: number;
    error?: boolean;
    message?: string;
    onRetry?: () => void;
    offset?: number;
    visible?: boolean;
}
export declare const GameLoading: import("react").MemoExoticComponent<({ gameId, theme, label, phase, phases, error, message, onRetry, offset, visible }: GameLoadingProps) => import("react").JSX.Element>;
export {};
//# sourceMappingURL=GameLoading.d.ts.map