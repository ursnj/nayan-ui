import type { Board } from './MineSweeperConstants';
export declare enum CellState {
    HIDDEN = "hidden",
    REVEALED = "revealed",
    FLAGGED = "flagged"
}
export type Cell = {
    row: number;
    col: number;
    isMine: boolean;
    state: CellState;
    adjacentMines: number;
};
export declare function emptyGrid(b: Board): Cell[][];
/** Lays the mines anywhere but the 3 x 3 round the first reveal, then counts each cell's neighbours. */
export declare function placeMines(grid: Cell[][], b: Board, safeRow: number, safeCol: number): void;
/** The cells a reveal opens, breadth first from the tapped one: past every empty cell to its neighbours, stopping at flags and mines. */
export declare function floodReveal(grid: Cell[][], b: Board, startRow: number, startCol: number): Cell[];
//# sourceMappingURL=MineSweeperRules.d.ts.map