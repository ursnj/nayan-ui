export declare const GAME_DURATION = 120;
export declare const POINTS_PER_LAND = 1000;
export declare const PERFECT_BONUS = 500;
export declare const LOOKAHEAD = 4;
export declare const PERFECT_SHOW = 0.6;
export declare const FALL_DELAY = 0.25;
export declare const GRAVITY = 0.62;
export declare const POWER_MULTIPLIER = 0.16;
export declare const MIN_LAUNCH_SPEED = 6;
export declare const STEP_MS: number;
export declare const STEP_TOLERANCE_MS = 2;
export declare const MAX_PENDING_MS = 34;
export declare const TRAJECTORY_DOTS = 16;
export declare const TRAJECTORY_STEP = 3;
/** Everything sized from the view (the original game sized it from the screen). */
export type Config = {
    width: number;
    height: number;
    blockSize: number;
    pillarMinWidth: number;
    pillarMaxWidth: number;
    pillarTopMin: number;
    pillarTopMax: number;
    pillarDepth: number;
    gapMin: number;
    gapMax: number;
    gapGrowthPerScore: number;
    gapGrowthMax: number;
    widthShrinkPerScore: number;
    widthShrinkMax: number;
    viewportMargin: number;
    anchorX: number;
    maxLaunchSpeed: number;
    sweetSpotWidth: number;
    fallThresholdY: number;
};
export declare function getConfig(width: number, height: number, tablet: boolean): Config;
/** The block's colors, cycling as you go. */
export declare const BLOCK_COLORS: readonly ["#FF6B6B", "#4ECDC4", "#FFD93D", "#6BCB77", "#4D96FF", "#FF6FB5", "#A66CFF", "#FF9F45"];
export declare const START_COLOR = 2;
export declare const COLORS: {
    readonly PILLAR: "#537A8D";
    readonly PILLAR_TOP: "#84AFC0";
    readonly PILLAR_EDGE: "#CDEBF5";
    readonly PILLAR_BAND: "#365463";
    readonly ROCK: "#7C8A93";
    readonly GRASS: "#5DAE4A";
    readonly GRASS_DARK: "#3E8A35";
    readonly MOSS: "#4A7A3A";
    readonly SWEET_RECESS: "#0C1B22";
    readonly SWEET_SPOT: "#FFDD22";
    readonly TRAJECTORY: "#64D2FF";
    readonly SKIN: "#F5C99A";
    readonly PUPIL: "#2C2C2C";
    readonly SMILE: "#C0785A";
    readonly PERFECT: "#FFD700";
};
/** Each theme's sky (top to bottom), whether it has stars, and its far towers' tint. */
export type Sky = {
    stops: string[];
    stars: boolean;
    tower: string;
};
export declare const SKIES: Record<'classic' | 'light' | 'dark', Sky>;
export declare const SKY_POSITIONS: number[];
/** The camera looks down from above and round from the right, so the pillars' tops, sides and depth all show. */
export declare const PITCH = 0.3;
export declare const YAW = 0.42;
/** Lit from the upper left front. */
export declare const LIGHT: import("nayan-ui").Light;
//# sourceMappingURL=BlukConstants.d.ts.map