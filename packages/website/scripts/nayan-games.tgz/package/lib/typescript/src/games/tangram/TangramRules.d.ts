export type PieceType = 'large' | 'medium' | 'small' | 'square' | 'para';
export type Pt = {
    x: number;
    y: number;
};
export type TanTarget = {
    id: number;
    type: PieceType;
    color: string;
    /** The tan's shape, centred on its centroid (board points at full size, unrotated). */
    localPoints: Pt[];
    /** Where it goes when solved, and at what turn (degrees, clockwise on screen). */
    targetCx: number;
    targetCy: number;
    targetRot: number;
    /** Its rotational symmetry (degrees). */
    symmetry: number;
    /** Its solved outline, in board points. */
    silPoints: Pt[];
    /** Where it starts, in the tray. */
    initialRot: number;
    scatterCx: number;
    scatterCy: number;
};
export type TangramLevel = {
    pieces: TanTarget[];
    mirror: boolean;
    silhouetteRect: {
        x: number;
        y: number;
        w: number;
        h: number;
    };
};
/** The board, in tan units: the 4 x 4 square silhouette with the tray in the strip under it. */
export declare const TOTAL_BOARD_UNITS = 6;
export declare const TRAY_SCALE = 0.4;
export declare const RIM_RADIUS = 0.024;
export declare const ROT_TOL = 30;
export declare const SNAP_UNITS = 1.8;
export declare const TOTAL_PIECES = 7;
export declare const rotatePt: (x: number, y: number, deg: number, ox: number, oy: number) => Pt;
export declare function canonicalShapes(mirror: boolean): Record<PieceType, Pt[]>;
/** A level: its silhouette (centred across the board, near its top) and its tray, for a board `unit` points to the tan unit. */
export declare function generateLevel(levelIndex: number, unit: number, boardW: number, boardH: number): TangramLevel;
/** Whether a turn matches a target within tolerance, allowing for the tan's symmetry. */
export declare const isRotationMatched: (cur: number, target: number, sym: number) => boolean;
/** The turn nearest `cur` that equals the target (modulo symmetry), to snap smoothly to. */
export declare const snappedRotation: (cur: number, target: number, sym: number) => number;
/**
 * Where a tan dropped at (x, y) at turn `rot` goes: the nearest free slot of its type within reach at
 * a matching turn (claimed), 'nudge' if it's over one at the wrong turn, or null. As the original board.
 */
export declare function claimSlot(level: TangramLevel, occupied: boolean[], unit: number, type: PieceType, x: number, y: number, rot: number): {
    slot: number;
    cx: number;
    cy: number;
    rot: number;
} | 'nudge' | null;
/** Whether a board point lies inside a tan drawn at (cx, cy), turned `rot`, at `scale`, give or take `margin`. */
export declare function insidePiece(local: Pt[], cx: number, cy: number, rot: number, scale: number, px: number, py: number, margin?: number): boolean;
//# sourceMappingURL=TangramRules.d.ts.map