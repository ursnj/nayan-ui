export declare const MemoryMatch: import("react").FC<import("../..").GameProps>;
//# sourceMappingURL=MemoryMatch.d.ts.map