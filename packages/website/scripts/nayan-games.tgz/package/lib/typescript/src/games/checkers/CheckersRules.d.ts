export declare const BOARD_N = 8;
export declare const PIECES_PER_SIDE = 12;
export declare const AI_DEPTH = 5;
/** You play red (bottom rows, moving up); the robot plays black (top, moving down). */
export type CheckerPlayer = 'red' | 'black';
export type Piece = {
    player: CheckerPlayer;
    king: boolean;
};
export type Cell = Piece | null;
export type CheckersBoard = Cell[];
/** One hop: where it lands, and the square it jumps (null for a slide). */
export type Step = {
    to: number;
    captured: number | null;
};
/** A whole move: a slide, or a full (maybe multi-) jump. */
export type FullMove = {
    from: number;
    steps: Step[];
};
export declare const HUMAN: CheckerPlayer;
export declare const AI: CheckerPlayer;
export declare const rc: (index: number) => {
    row: number;
    col: number;
};
export declare const idx: (row: number, col: number) => number;
export declare const inBounds: (row: number, col: number) => boolean;
/** Pieces live on the dark squares. */
export declare const isPlayable: (row: number, col: number) => boolean;
export declare function createInitialBoard(): CheckersBoard;
export declare function singleJumps(board: CheckersBoard, from: number, player: CheckerPlayer, king: boolean): Step[];
export declare function singleSlides(board: CheckersBoard, from: number, player: CheckerPlayer, king: boolean): Step[];
/** One hop on a copy of the board; says whether the mover was crowned. */
export declare function applyStep(board: CheckersBoard, from: number, step: Step, player: CheckerPlayer): {
    board: CheckersBoard;
    promoted: boolean;
};
export declare function playerHasCapture(board: CheckersBoard, player: CheckerPlayer): boolean;
/** Every legal whole move for a side (captures forced when there are any). */
export declare function generateMoves(board: CheckersBoard, player: CheckerPlayer): FullMove[];
export declare function applyFullMove(board: CheckersBoard, move: FullMove): CheckersBoard;
/** A piece's single hops when it isn't forced to capture: jumps first, then slides. */
export declare const allSteps: (board: CheckersBoard, index: number, player: CheckerPlayer, king: boolean) => Step[];
export declare function countPieces(board: CheckersBoard, player: CheckerPlayer): number;
/** The robot's move: the only one, or a random one of the best its search finds. */
export declare function chooseAIMove(board: CheckersBoard): FullMove | null;
//# sourceMappingURL=CheckersRules.d.ts.map