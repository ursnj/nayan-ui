import type { TiltView } from '../shared/EngineTilt';
export declare const GAME_TIME = 900;
export declare const MIN_SWIPE = 50;
export declare const SLIDE_TIME = 0.11;
export declare const MERGE_POP = 1.18;
export declare const tileColors: (value: number) => [string, string];
export declare const COLORS: {
    readonly FRAME: "#5c4033";
    readonly SLOT: "#3d2a1f";
};
/** The camera looks straight down at the board. */
export declare const TILT = 0;
/** Evenly lit, straight from the camera and all ambient: every face keeps its exact color, with no shading or shadow anywhere. */
export declare const LIGHT: import("nayan-ui").Light;
/** A tile's height, of its width. */
export declare const TILE_HEIGHT = 0.4;
export type Layout = TiltView & {
    tile: number;
    gap: number;
    pitch: number;
    pad: number;
    size: number;
};
/** The grid as wide as the game area (30 narrower than the screen, at most 500), smaller if the screen is short. */
export declare function getLayout(width: number, height: number, offset: number, tablet: boolean): Layout;
/** A cell's centre on the board (row 0 along the top), in world units. */
export declare const cellCentre: (l: Layout, row: number, col: number) => [number, number];
//# sourceMappingURL=Game2048Constants.d.ts.map