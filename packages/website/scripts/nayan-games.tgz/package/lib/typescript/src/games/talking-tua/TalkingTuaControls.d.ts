/** A body part on screen: its centre and radius in points. */
export type ScreenPart<P extends string> = {
    part: P;
    x: number;
    y: number;
    radius: number;
};
/**
 * The part a point is on: the one whose centre is nearest relative to its size, if the point is
 * inside it. Small parts (hands, feet) win over the big ones they overlap (the belly, the head).
 */
export declare function partAt<P extends string>(parts: readonly ScreenPart<P>[], x: number, y: number): P | null;
/** A finger rubbing back and forth over Tua. */
export type Tickle = {
    lastX: number;
    direction: -1 | 0 | 1;
    travel: number;
    turns: number;
};
export declare const newTickle: (x: number) => Tickle;
/** Follows the finger to `x`; true once it has turned back and forth enough to be a tickle. */
export declare function rub(t: Tickle, x: number): boolean;
/** A floor point Tua can walk to: inside the play circle around the stage's middle. */
export declare function walkTarget(x: number, z: number): [number, number];
/** The shortest signed turn from angle `from` to `to`, in -π..π. */
export declare function turnBetween(from: number, to: number): number;
//# sourceMappingURL=TalkingTuaControls.d.ts.map