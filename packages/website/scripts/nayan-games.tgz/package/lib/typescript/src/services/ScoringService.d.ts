export declare const TIME_BONUS_PER_SECOND = 100;
export declare const calculateTimeBasedScore: (completionTimeSeconds: number, expectedTime: number, baseScore?: number, bonusPerSecond?: number) => number;
//# sourceMappingURL=ScoringService.d.ts.map