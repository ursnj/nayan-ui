import { type DragEvent, type Entity, type Font, type LoadedModel, type PinchEvent, type Recording, type Sound, World } from 'nayan-ui';
import type { GameTheme } from '../../services/ThemeService';
import { type Fruit } from '../shared/EngineFruits';
import { type ActionSoundCue, type TalkingTuaAnimation, type TuaEvent, type VoiceStyle } from './TalkingTuaConstants';
import { type Tickle } from './TalkingTuaControls';
import { type BodyPose } from './TalkingTuaModel';
import { type Scene } from './TalkingTuaScene';
import { type VoiceState } from './TalkingTuaVoice';
type Phase = 'ready' | 'playing';
/** What Tua plays to repeat you: a sound at a playback rate, and its loudness over time for the bounce. */
export type SpeechVoice = {
    sound: Sound;
    rate: number;
    volume: number;
    levels: Float32Array;
    levelsPerSecond: number;
    length: number;
};
/** Tua repeating a recording: the take, the voice made from it (its own sound when shifted) and how far it has got. */
type Speech = {
    recording: Recording;
    voice: SpeechVoice;
    style: VoiceStyle;
    elapsed: number;
};
type Food = {
    entity: Entity;
    fruit: Fruit;
    scale: number;
    position: [number, number, number];
    held: boolean;
    velocity: number;
    landed: number;
};
type DragKind = 'none' | 'turn' | 'rub' | 'food';
/** A gag in progress: what it is, how far along, and the fruit being chewed. */
type GagKind = 'toot' | 'sneeze' | 'chew' | 'burp' | 'look' | 'stretch';
type Gag = {
    kind: GagKind;
    time: number;
    food: Food | null;
};
export interface Game extends Scene {
    world: World;
    phase: Phase;
    /** Fun points: one or more per reaction. */
    score: number;
    mood: string;
    /** The clip playing and its clock (for its sound cues). */
    move: TalkingTuaAnimation;
    moveTime: number;
    soundTime: number;
    /** A one-off reaction plays until its clip ends, then Tua goes back to standing. */
    reacting: boolean;
    /** The reaction is Tua asking for attention (waving when bored), not an answer to play. */
    attention: boolean;
    dancing: boolean;
    beat: number;
    beatTime: number;
    /** Tua's place on the floor and which way it faces (0 = the camera). */
    position: [number, number, number];
    yaw: number;
    walk: [number, number] | null;
    /** Turning back to face the camera after a walk. */
    homing: boolean;
    pose: BodyPose;
    hitTimes: number[];
    drag: {
        kind: DragKind;
        startYaw: number;
        tickle: Tickle;
        tickled: boolean;
        lastX: number;
        lastY: number;
        lastTime: number;
        zoomStart: number;
    };
    food: Food | null;
    fed: number[];
    /** Talk mode, its ears and what Tua is saying. */
    listening: boolean;
    voice: VoiceState;
    speech: Speech | null;
    /** The last voice style used (the next one differs). */
    lastStyle: number;
    /** A gag in progress, and a burp due after a meal (game time, or 0). */
    gag: Gag | null;
    burpAt: number;
    /** Squash and stretch for gags/breathing and lean (radians about x, + forward). */
    /** Audio-driven native lip pose (0 shut, 1 open). */
    mouthOpen: number;
    gagStretch: number;
    breath: number;
    tilt: number;
    /** Leaning in while it hears you, and the bob that follows your voice's loudness. */
    lean: number;
    hearStretch: number;
    /** The squash of a landing (1 on touchdown, easing to 0). */
    landing: number;
    /** Turning to look (radians, on top of its facing): at a touch, or round the room when idle. */
    glance: number;
    /** The slow weight shift while it stands. */
    sway: number;
    glanceTarget: number;
    glanceHold: number;
    /** Fidgets so far (they take turns). */
    fidgets: number;
    idle: number;
    sleeping: boolean;
    zzz: {
        entity: Entity;
        age: number;
        x: number;
    }[];
    zzzTimer: number;
    bored: number;
    time: number;
    inputTop: number;
    inputBottom: number;
    audible: boolean;
    active: boolean;
    theme: GameTheme;
    onSound: (cue: ActionSoundCue) => void;
    onSilence: () => void;
    /** How long an event's sound and an action cue's sound last (seconds; 0 if silent or unknown). */
    eventSeconds: (event: TuaEvent) => number;
    cueSeconds: (sound: ActionSoundCue['sound']) => number;
    /** Plays Tua's voice; returns false if it couldn't (muted). */
    onSpeak: (voice: SpeechVoice) => boolean;
    /** Stops Tua's voice. */
    onHush: () => void;
    onEvent: (event: TuaEvent) => void;
    onPhase: (phase: Phase | 'over') => void;
    onScore: (score: number) => void;
    onMood: (mood: string) => void;
}
export declare function createGame(model: LoadedModel, font: Font, theme: GameTheme): Game;
export declare function reset(g: Game): void;
export declare function start(g: Game): void;
/** Silences Tua and releases the microphone; the world is disposed after this. */
export declare function dispose(g: Game): void;
export declare function setAudible(g: Game, audible: boolean): void;
/** Pausing (settings, the app in the background) stops listening; Talk resumes it after. */
export declare function setActive(g: Game, active: boolean): void;
export declare function setTheme(g: Game, theme: GameTheme): void;
export declare function resize(g: Game, width: number, height: number, offset: number): void;
/** Plays `move` from its start (with its sound cues), looping or once. */
export declare function playMove(g: Game, move: TalkingTuaAnimation, loop?: boolean, fade?: number): boolean;
/** Talk mode on or off (the screen asks for the microphone first). */
export declare function setListening(g: Game, on: boolean): void;
/** The dance party: Tua dances to the music while the floor lights up on the beat. */
export declare function toggleDance(g: Game): void;
/** A fruit appears in front of Tua: drag it to Tua's mouth. */
export declare function offerFood(g: Game): void;
export declare function tap(g: Game, x: number, y: number): void;
/** A hit starts a play fight; three quick hits knock Tua over, then it gets back up. */
export declare function hit(g: Game): void;
export declare function drag(g: Game, event: DragEvent): void;
/** A long press anywhere on the stage starts (or ends) the dance party. */
export declare function longPress(g: Game, _x: number, y: number): void;
export declare function pinch(g: Game, event: PinchEvent): void;
/** Toot: a startled hop, a green cloud from behind, then Tua laughs at itself. */
export declare function toot(g: Game): void;
/** Sneeze: "ah... ah..." leaning back, then a "choo!" that throws Tua forward. */
export declare function sneeze(g: Game): void;
export declare function tick(g: Game, dt: number): void;
export {};
//# sourceMappingURL=TalkingTuaGame.d.ts.map