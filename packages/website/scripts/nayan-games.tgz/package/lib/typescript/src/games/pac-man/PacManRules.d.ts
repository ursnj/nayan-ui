import { type Direction, GhostMode, GhostName } from './PacManConstants';
export type Position = {
    x: number;
    y: number;
};
export type Pacman = {
    x: number;
    y: number;
    direction: Direction;
    nextDirection: Direction;
};
export type Ghost = {
    name: GhostName;
    x: number;
    y: number;
    direction: Direction;
    mode: GhostMode;
    previousMode: GhostMode;
    /** Seconds of fright left. */
    frightenedTimer: number;
    isFlashing: boolean;
};
export type Fruit = {
    x: number;
    y: number;
} | null;
export type Maze = {
    cells: number[][];
    dotsRemaining: number;
    totalDots: number;
};
export declare function initMaze(): Maze;
export declare const initPacman: () => Pacman;
export declare const initGhosts: () => Ghost[];
export declare function canMove(cells: number[][], x: number, y: number): boolean;
export declare function canGhostMove(cells: number[][], x: number, y: number, ghost: Ghost): boolean;
/** One cell forward, taking the queued turn when it opens up. Returns whether the maze wrapped round the side. */
export declare function stepPacman(p: Pacman, cells: number[][]): {
    moved: boolean;
    wrapped: boolean;
};
/** Eats whatever is on a cell. */
export declare function eatAt(maze: Maze, x: number, y: number): {
    points: number;
    pellet: boolean;
} | null;
/** One cell of ghost movement, by its mode. `blinky` is Blinky's cell before this step (Inky aims off it). */
export declare function moveGhost(cells: number[][], ghost: Ghost, pacman: Pacman, blinky: Position | null): Ghost;
export declare function frightenGhosts(ghosts: Ghost[], duration: number): Ghost[];
export declare const releaseGhost: (g: Ghost) => Ghost;
export declare const reachedHouse: (g: Ghost) => Ghost;
export declare const collides: (p: Pacman, g: Ghost) => boolean;
//# sourceMappingURL=PacManRules.d.ts.map