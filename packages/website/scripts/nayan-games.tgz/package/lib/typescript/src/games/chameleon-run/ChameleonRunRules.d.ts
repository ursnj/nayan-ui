import { type Config, type RunColor } from './ChameleonRunConstants';
export interface Platform {
    id: number;
    start: number;
    end: number;
    height: number;
    color: RunColor | null;
    star: boolean;
    starCollected: boolean;
}
export type Failure = 'fall' | 'color';
export type JumpKind = 'jump' | 'double';
export interface Run {
    seed: number;
    platforms: Platform[];
    seq: number;
    distance: number;
    y: number;
    vy: number;
    onGround: boolean;
    jumpsUsed: number;
    currentPlatformId: number;
    color: RunColor;
    coyote: number;
    jumpBuffer: number;
    mismatchTime: number;
    score: number;
    stars: number;
    combo: number;
    bestCombo: number;
    lives: number;
    invulnerable: number;
    failure: Failure | null;
    finished: boolean;
}
/** Single-jump range at the slowest speed; generation keeps an extra reaction margin. */
export declare function jumpReach(c: Config, rise: number): number;
export declare function ensureAhead(c: Config, r: Run): void;
export declare function newRun(c: Config, seed?: number): Run;
export declare const platformUnder: (r: Run, distance?: number) => Platform | null;
export declare const nextPlatform: (r: Run) => Platform | null;
export declare function switchColor(r: Run): void;
export declare function jump(c: Config, r: Run): JumpKind | null;
export interface StepEvents {
    landed: Platform | null;
    star: Platform | null;
    jumped: JumpKind | null;
    failure: Failure | null;
    hurt: Failure | null;
    won: boolean;
}
export declare function step(c: Config, r: Run, dt: number): StepEvents;
//# sourceMappingURL=ChameleonRunRules.d.ts.map