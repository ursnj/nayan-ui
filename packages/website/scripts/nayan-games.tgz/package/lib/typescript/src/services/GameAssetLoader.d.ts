export type AssetTask = () => unknown;
export interface AssetStage {
    label: string;
    tasks: () => Iterable<AssetTask>;
}
export interface LoadTiming {
    afterPaint(run: () => void): () => void;
    now?: () => number;
}
/**
 * Allow space for UI work in each frame while preparing the game.
 */
export declare const FRAME_BUDGET_MS = 10;
/** Paint first, then batch small jobs within a frame budget, yielding between expensive builders. */
export declare class GameAssetLoader {
    private stages;
    private changed;
    private finished;
    private failed;
    private clock;
    private stage;
    private iterator?;
    private task?;
    private cancel?;
    private active;
    private busy;
    private disposed;
    private done;
    /** Who's loading (a game id), for the dev log. */
    name: string;
    constructor(stages: readonly AssetStage[], changed: (label: string, phase: number) => void, finished: () => void, failed: (error: unknown) => void, clock?: LoadTiming);
    start(): void;
    pause(): void;
    dispose(): void;
    private schedule;
    private step;
    private reject;
}
//# sourceMappingURL=GameAssetLoader.d.ts.map