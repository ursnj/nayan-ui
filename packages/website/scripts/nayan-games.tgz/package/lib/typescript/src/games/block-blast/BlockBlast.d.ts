export declare const BlockBlast: import("react").FC<import("../..").GameProps>;
//# sourceMappingURL=BlockBlast.d.ts.map