export declare const GRID = 5;
export declare const TARGET = 1024;
export type Tile = {
    id: number;
    value: number;
    row: number;
    col: number;
};
export type Grid = (Tile | null)[][];
/** A tile swallowed by a merge: it slides into its partner's cell, then goes. */
export type Ghost = {
    id: number;
    value: number;
    fromRow: number;
    fromCol: number;
    toRow: number;
    toCol: number;
};
export type Direction = 'up' | 'down' | 'left' | 'right';
export declare const emptyGrid: () => Grid;
/** A 2 (or a 4) in a random empty cell, with this id; null if the grid's full. */
export declare function addRandomTile(grid: Grid, id: number): Tile | null;
/** Slides every tile one way, merging equal pairs once (in place). */
export declare function moveTiles(grid: Grid, direction: Direction): {
    moved: boolean;
    score: number;
    ghosts: Ghost[];
};
/** No empty cell and no equal neighbours: no move left. */
export declare function stuck(grid: Grid): boolean;
export declare const reached: (grid: Grid, target?: number) => boolean;
export declare const tilesOf: (grid: Grid) => Tile[];
//# sourceMappingURL=Game2048Rules.d.ts.map