import { type Entity, type Quat, type World } from 'nayan-ui';
import type { GameTheme } from '../../services/ThemeService';
import { type Layout } from './MazeRunnerConstants';
export type Scene = {
    backdrop: Entity;
    floor: Entity;
    inner: Entity | null;
    walls: Entity[];
    pads: Entity[];
    ring: Entity;
    ball: Entity;
    /** The ball's turn so far, from rolling. */
    spin: Quat;
};
export declare function buildScene(world: World, l: Layout, theme: GameTheme, open: number[]): Scene;
export declare function removeScene(world: World, s: Scene): void;
export declare function setSceneTheme(world: World, l: Layout, s: Scene, theme: GameTheme): void;
/** Builds a maze's walls; on a new maze they rise out of the board, from the start corner outward. */
export declare function setMaze(world: World, l: Layout, s: Scene, open: number[], animate: boolean): void;
/** The ball at a point (in cells), turned by how far it rolled to get there from (px, py). */
export declare function placeBall(world: World, l: Layout, s: Scene, cx: number, cy: number, px: number, py: number): void;
/** Back to the start's look (a new game, or the preview). */
export declare function resetBall(world: World, l: Layout, s: Scene): void;
/** It ran into a wall: a little jolt. */
export declare function bump(world: World, l: Layout, s: Scene): void;
/** The exit reached: the ball turns gold with a pop, and confetti bursts over the maze. */
export declare function celebrate(world: World, l: Layout, s: Scene): void;
/** Out of time: the ball dims where it stopped. */
export declare function timeUp(world: World, s: Scene): void;
//# sourceMappingURL=MazeRunnerScene.d.ts.map