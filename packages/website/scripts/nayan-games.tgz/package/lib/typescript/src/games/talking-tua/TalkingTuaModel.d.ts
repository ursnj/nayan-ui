import { type ClipOptions, type Entity, type LoadedModel, type Vec3, type World } from 'nayan-ui';
import { type BodyPart, type TalkingTuaAnimation } from './TalkingTuaConstants';
export declare const getCachedCharacter: () => LoadedModel | null;
export declare function loadCharacter(): Promise<LoadedModel>;
export declare function spawnCharacter(world: World, model: LoadedModel): Entity;
/** Native clip playback; independent poses per entity, with no JS vertex updates. */
export declare function playAnimation(world: World, entity: Entity, animation: TalkingTuaAnimation, options?: ClipOptions): boolean;
/** Seek the native mouth pose with playback loudness; skinning stays entirely in Rust. */
export declare function poseMouth(world: World, entity: Entity, openness: number): boolean;
export declare const PARTS: BodyPart[];
/** Where each part (and the mouth) is in the world for the pose being drawn. */
export type BodyPose = Record<BodyPart | 'mouth', MutableVec3>;
type MutableVec3 = [number, number, number];
export declare const emptyPose: () => BodyPose;
/**
 * Fills `pose` from the rendered rig of Tua standing at `position` and turned `yaw` radians about y.
 * False before the rig has a pose (the first frame).
 */
export declare function sampleBody(world: World, entity: Entity, position: Vec3, yaw: number, pose: BodyPose): boolean;
/** Reusable assets; the game loader advances one builder per frame. */
export declare function warmAssets(): Iterable<() => unknown>;
export {};
//# sourceMappingURL=TalkingTuaModel.d.ts.map