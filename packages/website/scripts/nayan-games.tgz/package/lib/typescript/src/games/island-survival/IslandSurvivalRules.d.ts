import type { Spot } from 'nayan-ui';
import type { GamePhase } from '../shared/useEngineGame';
import { ISLAND_MOTIONS } from './IslandSurvivalAnimations';
import { type Structure } from './IslandSurvivalConstants';
import type { IslandBody, IslandMap, Resource } from './IslandSurvivalIsland';
export type Daylight = 'day' | 'dusk' | 'night';
export type Monster = Body & {
    home: Spot;
    id: number;
    yaw: number;
    speed: number;
    health: number;
    charge: number;
    recovery: number;
    pace: number;
    roamTime: number;
    roamYaw: number;
    roaming: boolean;
};
export type Interaction = {
    kind: 'resource';
    id: number;
} | {
    kind: 'fight';
    id: number;
} | {
    kind: 'harvest' | 'drink' | 'cook' | 'rest' | 'signal';
};
type Action = ({
    kind: 'gather';
    resource: Resource;
} | {
    kind: 'harvest' | 'drink' | 'cook' | 'rest';
}) & {
    point: Spot;
    reach: number;
};
export type Event = {
    kind: 'message';
    text: string;
} | {
    kind: 'pose';
    action: keyof typeof ISLAND_MOTIONS;
} | {
    kind: 'gather';
    resource: Resource;
} | {
    kind: 'build';
    structure: Structure;
    spot: Spot;
} | {
    kind: 'regrow';
    id: number;
} | {
    kind: 'hit' | 'defeat';
    monster: Monster;
} | {
    kind: 'cook';
    food: 'shellfish' | 'vegetables';
} | {
    kind: 'rest';
    overnight: boolean;
} | {
    kind: 'attack' | 'cropsReady' | 'harvest' | 'drink' | 'hurt' | 'win' | 'lose';
};
type Body = IslandBody;
export type IslandState = ReturnType<typeof createState>;
export declare const distance: (a: Spot, b: Spot) => number;
export declare const yawTo: (a: Spot, b: Spot) => number;
export declare const angleDelta: (target: number, angle: number) => number;
export declare const daylight: (state: IslandState) => Daylight;
export declare const MONSTER_WINDUP = 0.52;
export declare const MONSTER_CONTACT = 0.71;
export declare const structurePosition: (structure: Structure) => Spot;
export declare const fenceSections: (site: Spot) => ({
    x: number;
    z: number;
    yaw: 0;
} | {
    x: number;
    z: number;
    yaw: number;
} | {
    x: number;
    z: number;
    yaw: number;
})[];
export declare function createState(map: IslandMap, seed?: number, previousSpawn?: Spot): {
    map: IslandMap;
    phase: GamePhase;
    won: boolean;
    score: number;
    time: number;
    elapsed: number;
    spawn: Spot;
    player: {
        x: number;
        z: number;
    };
    yaw: number;
    speed: number;
    pace: number;
    grade: number;
    health: number;
    food: number;
    water: number;
    wood: number;
    stone: number;
    shellfish: number;
    vegetables: number;
    cropsReadyAt: number;
    cooked: number;
    defeated: number;
    explored: boolean;
    camp: Map<"shelter" | "fire" | "fence" | "farm" | "beacon", Spot>;
    colliders: Body[];
    movementBodies: Body[];
    gathered: Map<number, number>;
    monsters: Monster[];
    actionTime: number;
    approach: {
        action: Action;
        time: number;
    } | null;
    action: Action | null;
    sleepTime: number;
    attackTime: number;
    punchBuffer: {
        targetId?: number;
        remaining: number;
    } | null;
    target: Monster | null;
    invulnerable: number;
    recovery: number;
    events: Event[];
};
export declare function task(s: IslandState): "Gather wood and stone, then build a shelter at camp" | "Build a campfire to cook food" | "Build a fence to keep zombies out of camp" | "Tap the farm to harvest vegetables" | "Gather shellfish or grow vegetables" | "Cook a meal at your campfire" | "Rest at your shelter to sleep until sunrise" | "Follow the red arrows on the map";
export declare function build(s: IslandState, structure: Structure, spot?: Spot): void;
export declare function interact(s: IslandState, action: Interaction): void;
export declare function cancelApproach(s: IslandState): void;
/** Aim at the tapped zombie if reachable, or the nearest visible one for an open-scene tap. */
export declare function punch(s: IslandState, targetId?: number): void;
export declare function step(s: IslandState, dx: number, dz: number, dt: number): void;
export {};
//# sourceMappingURL=IslandSurvivalRules.d.ts.map