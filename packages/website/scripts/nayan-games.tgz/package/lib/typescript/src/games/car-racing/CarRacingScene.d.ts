import { type Camera, type Color, type Entity, type Font, type Quat, type Vec3, type World } from 'nayan-ui';
import { type Assets } from './CarRacingConstants';
export declare const rand: (min: number, max: number) => number;
export declare const pick: <T>(items: readonly T[]) => NonNullable<T>;
export declare const clamp: (v: number, lo: number, hi: number) => number;
export type Sample = {
    x: number;
    y: number;
    z: number;
    heading: number;
    pitch: number;
};
export declare const newSample: () => Sample;
/** The centre line, integrated a metre at a time as the player drives. */
export declare class Track {
    private xs;
    private zs;
    private hs;
    private ensure;
    sample(s: number, out: Sample): Sample;
}
export declare const forwardOf: (h: number) => Vec3;
export declare const rightOf: (h: number) => Vec3;
/** The world point at a track sample, `d` to the right and `h` above the road. */
export declare function placeAt(t: Sample, d: number, h: number, out: [number, number, number]): [number, number, number];
/** Facing along `heading` (turned `yaw` further right), nose up by `pitch`, rolled left by `roll`. */
export declare function orient(heading: number, pitch: number, yaw?: number, roll?: number, out?: [number, number, number, number]): Quat;
/** A car: an invisible root at its middle (the collider's centre once wrecked) with body, glass and trim attached. */
export declare function spawnCar(world: World, a: Assets, paint: Color, position: Vec3, night: boolean): {
    root: Entity;
    body: Entity;
    glass: Entity;
    trim: Entity;
    lights: Entity[];
};
/** Toggle lamp meshes in place so switching theme preserves every car's pose and physics. */
export declare function setCarNight(world: World, car: {
    root: Entity;
    lights: Entity[];
}, night: boolean, height: number): void;
/** A stretch of road; `props` is its scenery, rebuilt for the zone it lands in each time it jumps ahead. */
export type Segment = {
    root: Entity;
    s: number;
    props: Entity[];
    lights: {
        entity: Entity;
        day: Color;
        night: Color;
    }[];
};
/** What the scenery needs from the game. */
export type SceneryContext = {
    world: World;
    assets: Assets;
    night: boolean;
    track: Track;
};
/**
 * Road segments: a root carrying the ground collider, with asphalt, curbs, markings, rails and
 * scenery attached. Segments that fall behind jump ahead with everything on them.
 */
export declare function buildRoad(world: World, a: Assets): Segment[];
/** Mountains and rolling hills all around (and, at night, a moon and stars), on a root that rides along with the player so they never get closer. */
export declare function buildHorizon(world: World, night: boolean): Entity;
export declare function setHorizonNight(world: World, horizon: Entity, night: boolean): void;
/** Puts a segment where its distance along the track is. */
export declare function placeSegment(g: SceneryContext, seg: Segment): void;
/** Fills a segment's roadside for its zone. Positions are in the segment's frame: x across, z along, y up. */
export declare function spawnProps(g: SceneryContext, seg: Segment): void;
/** Segments left behind jump to the front, with fresh scenery. */
export declare function recycleRoad(g: SceneryContext, segments: Segment[], s: number): void;
/** A wreck on fire: flames and smoke come off it until `until` (game time). */
export type Fire = {
    root: Entity;
    until: number;
    flame: number;
    smoke: number;
    ember: number;
};
export declare const burning: (root: Entity, until: number) => Fire;
/**
 * A crash: a white-hot flash, a fireball that swells and cools to red, sparks and car bits thrown out,
 * and smoke that billows up and thins.
 */
export declare function explode(w: World, at: Vec3): void;
export declare function burn(world: World, camera: Camera, fires: Fire[], time: number, dt: number): void;
/**
 * The race's start line (at `startS`) and finish gate (at `finishS`), placed on the road and facing the
 * driver, with FINISH written on the gate's banner once the HUD's font is in.
 */
export declare function spawnRaceMarkers(world: World, track: Track, startS: number, finishS: number, font: Font): {
    start: Entity;
    finish: Entity;
};
/** Reusable assets; the game loader advances one builder per frame. */
export declare function warmAssets(): Iterable<() => unknown>;
//# sourceMappingURL=CarRacingScene.d.ts.map