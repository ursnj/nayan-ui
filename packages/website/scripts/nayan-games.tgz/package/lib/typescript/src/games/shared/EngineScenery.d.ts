import type { Entity, World } from 'nayan-ui';
/**
 * Replaces a backdrop layer's scenery: despawns `previous`, spawns the new scenery and steps the layer
 * once (its matrices are written by the step, and the step is what tells the renderer to draw it again).
 */
export declare function refillBackdrop(backdrop: World, previous: readonly Entity[], spawn: (world: World) => Entity[]): Entity[];
//# sourceMappingURL=EngineScenery.d.ts.map