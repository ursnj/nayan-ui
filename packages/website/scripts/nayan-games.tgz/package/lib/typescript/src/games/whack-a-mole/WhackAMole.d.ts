export declare const WhackAMole: import("react").FC<import("../..").GameProps>;
//# sourceMappingURL=WhackAMole.d.ts.map