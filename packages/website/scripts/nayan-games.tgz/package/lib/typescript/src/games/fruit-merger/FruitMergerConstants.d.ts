/**
 * The merge chain, in order of real size (round fruits that stack and roll): two of a kind make the
 * next, up to the pumpkin (the win). Sizes and scores step up evenly, as the original chain did.
 */
export declare const FRUIT_TYPES: readonly [{
    readonly id: 0;
    readonly name: "strawberry";
    readonly size: number;
    readonly color: "#FFCDD2";
    readonly score: 10;
}, {
    readonly id: 1;
    readonly name: "kiwi";
    readonly size: number;
    readonly color: "#DCEDC8";
    readonly score: 20;
}, {
    readonly id: 2;
    readonly name: "lemon";
    readonly size: number;
    readonly color: "#FFF9C4";
    readonly score: 40;
}, {
    readonly id: 3;
    readonly name: "peach";
    readonly size: number;
    readonly color: "#FFE4E1";
    readonly score: 80;
}, {
    readonly id: 4;
    readonly name: "orange";
    readonly size: number;
    readonly color: "#FFE0B2";
    readonly score: 160;
}, {
    readonly id: 5;
    readonly name: "apple";
    readonly size: number;
    readonly color: "#FFCDD2";
    readonly score: 320;
}, {
    readonly id: 6;
    readonly name: "pomegranate";
    readonly size: number;
    readonly color: "#F8BBD0";
    readonly score: 640;
}, {
    readonly id: 7;
    readonly name: "papaya";
    readonly size: number;
    readonly color: "#FFE0B2";
    readonly score: 1280;
}, {
    readonly id: 8;
    readonly name: "watermelon";
    readonly size: number;
    readonly color: "#C8E6C9";
    readonly score: 2560;
}, {
    readonly id: 9;
    readonly name: "pumpkin";
    readonly size: number;
    readonly color: "#FFCC80";
    readonly score: 5120;
}];
export type FruitName = (typeof FRUIT_TYPES)[number]['name'];
export declare const LAST_TYPE: number;
export declare const GAME_TIME = 900;
/** A win scores by its time against two minutes, as the original game did. */
export declare const EXPECTED_TIME = 120;
export declare const BASE_SCORE = 100;
export declare const MAX_DROP_TYPE = 4;
export declare const CONTAINER_WIDTH: number;
export declare const CONTAINER_HEIGHT: number;
export declare const PLAY_WIDTH: number;
export declare const PLAY_HEIGHT: number;
export declare const GRAVITY: number;
export declare const BOUNCE = 0.3;
export declare const FRICTION = 0.99;
export declare const MERGE_DISTANCE: number;
export declare const COLLISION_SCALE = 0.96;
/** Passes over the fruit pairs each step, so a pile settles without fruits sinking into each other. */
export declare const SOLVER_PASSES = 24;
/** Overflow: a settled fruit's top above 5% of the height, for a second's worth of steps, loses. */
export declare const OVERFLOW_Y: number;
export declare const OVERFLOW_STEPS = 60;
/** The danger line warms from here up to the overflow line. */
export declare const DANGER_START_Y: number;
export declare const DANGER_SETTLE_MS = 1000;
export declare const SPAWN_DELAY_MS = 300;
export declare const STEP_MS: number;
export declare const STEP_TOLERANCE_MS = 2;
export declare const MAX_PENDING_MS = 50;
/** The camera looks straight at the tank: only its front shows, so its outline reads as single clean lines. */
export declare const TILT = 0;
/** Lit from the upper left, in front. */
export declare const LIGHT: import("nayan-ui").Light;
/** The glass is as deep as the biggest fruit. */
export declare const JAR_DEPTH: number;
export declare const WALL = 4;
/** The glass's bottom corners are rounded this much (inside), and the fruits roll round them. */
export declare const CORNER: number;
export declare const COLORS: {
    readonly DANGER_SAFE: "rgba(255, 255, 255, 0.28)";
    readonly DANGER_HOT: "rgba(255, 77, 77, 0.95)";
};
/**
 * Where the glass sits: centred below the header as the original glass was, or, on a screen too short for
 * it, scaled down (by `k`, view points per play-area point) to fit between the scoreboard and controls.
 */
export type Layout = {
    width: number;
    height: number;
    k: number;
    centerX: number;
    centerY: number;
    tilt: number;
};
export declare function getLayout(width: number, height: number, offset: number): Layout;
/** A play-area point (x right, y down from the top-left, z out of the glass) in the world. */
export declare const toWorld: (x: number, y: number, z?: number) => [number, number, number];
/** The play-area x under a view x. */
export declare const playX: (l: Layout, sx: number) => number;
//# sourceMappingURL=FruitMergerConstants.d.ts.map