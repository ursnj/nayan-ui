import { GAME_IDS, type GameThemeMode } from './UtilsService';
/**
 * Colour tokens shared by a game's chrome (background, scoreboard, controls, modals) and its board.
 *
 * `light` and `dark` mirror the host app's design tokens (Playtura `src/global.css`), so a themed
 * game sits on the same background, surfaces, borders, text and accent as the screens around it.
 * `classic` is the original look (white frosted panels on the indigo pattern) and is what every
 * game gets until it opts into theming via `GameThemeProvider`.
 */
export interface GameTheme {
    mode: 'classic' | GameThemeMode;
    isDark: boolean;
    BACKGROUND: string;
    PATTERN_OPACITY: number;
    SURFACE: string;
    BORDER: string;
    BORDER_WIDTH: number;
    DIVIDER: string;
    TEXT: string;
    TEXT_MUTED: string;
    LABEL: string;
    TEXT_SUBTLE: string;
    TEXT_SHADOW: string;
    SOLID: string;
    ON_SOLID: string;
    SCORE_HIGHLIGHT: string;
    DANGER: string;
    CHIP: string;
    OVERLAY: string;
    SWITCH_TRACK_OFF: string;
    SWITCH_TRACK_ON: string;
    SWITCH_THUMB: string;
    HEADER: {
        BACKGROUND: string;
        BORDER: string;
        TINT: string;
    };
    BOARD: {
        SURFACE: string;
        BORDER: string;
        CELL_EMPTY: string;
        GRID_LINE: string;
        CELL_HIGHLIGHT: string;
        CELL_INVALID: string;
        FLASH: string;
    };
}
/**
 * Shared night palette for games that paint their own outdoor scene (sky, moon, clouds, hills).
 * Dark mode recolours those scenes with these values so every night scene looks alike; light and
 * classic keep the original day art. Ordered far → near for hills (atmospheric perspective).
 */
export declare const NIGHT_SCENE: {
    readonly SKY: readonly ["#120E24", "#17122B", "#241D40", "#3A3160"];
    readonly HAZE: "rgba(153, 118, 249, 0.10)";
    readonly STAR: "rgba(249, 248, 251, 0.85)";
    readonly MOON: {
        readonly CORE: readonly ["#FFFFFF", "#EEEAF8", "#D6CEEC"];
        readonly CRATER: "rgba(120, 108, 165, 0.22)";
        readonly GLOW: "#C4B5FD";
    };
    readonly CLOUD: {
        readonly BODY: "rgba(92, 84, 132, 0.78)";
        readonly SHADOW: "rgba(52, 45, 84, 0.55)";
        readonly RIM: "rgba(196, 181, 253, 0.45)";
    };
    readonly HILL: {
        readonly FAR: readonly ["#22264E", "#1A1D40"];
        readonly MID: readonly ["#22334A", "#18263A"];
        readonly NEAR: readonly ["#17362A", "#0F241C"];
        readonly RIM: "rgba(214, 204, 255, 0.2)";
        readonly MIST: "rgba(120, 104, 190, 0.22)";
    };
    readonly GRASS: readonly ["#24442C", "#1A3322"];
    readonly GROUND: readonly ["#3B2F2A", "#2A211E"];
};
/**
 * Day palette for the shared scene hills in light mode (classic keeps each game's original hills).
 * Far layers are hazier and bluer (atmospheric perspective); each layer is [ridge, base].
 */
export declare const DAY_SCENE: {
    readonly HILL: {
        readonly FAR: readonly ["#BCD8C8", "#A6CBB6"];
        readonly MID: readonly ["#93C29E", "#7DB38A"];
        readonly NEAR: readonly ["#74AE7E", "#5E9C69"];
        readonly RIM: "rgba(255, 255, 240, 0.18)";
        readonly MIST: "rgba(255, 255, 255, 0.28)";
    };
};
/** Built-in palettes (light / dark default to Playtura's colours). Use resolveGameTheme to get the active ones. */
export declare const GAME_THEMES: {
    readonly classic: GameTheme;
    readonly light: GameTheme;
    readonly dark: GameTheme;
};
type DeepPartial<T> = {
    [K in keyof T]?: T[K] extends readonly unknown[] ? T[K] : T[K] extends object ? DeepPartial<T[K]> : T[K];
};
/** Colours a host app may override per mode; anything left out keeps the built-in value. */
export type GameThemeOverrides = Partial<Record<GameThemeMode, DeepPartial<Omit<GameTheme, 'mode' | 'isDark'>>>>;
/**
 * Override the light / dark game colours with the host app's palette. Call once at app start, before
 * any game renders (e.g. at module scope in the root layout). The classic theme is not configurable.
 *
 * configureGameThemes({ light: { BACKGROUND: '#DCE7F6', SOLID: '#0F62F2', BOARD: { CELL_HIGHLIGHT: 'rgba(15, 98, 242, 0.22)' } } });
 */
export declare const configureGameThemes: (overrides: GameThemeOverrides) => void;
/** Active theme for a settings value; games that have not opted in (or no theme passed) get `classic`. */
export declare const resolveGameTheme: (mode?: GameThemeMode) => GameTheme;
/**
 * Games that render with `settings.theme` (all of them, each wrapped in GameThemeProvider). Hosts use
 * this to theme their own chrome (header, status bar) to match. A new game must wrap itself in
 * GameThemeProvider too, or be listed as an exception here.
 */
export declare const THEMED_GAMES: ReadonlySet<GAME_IDS>;
export declare const isThemedGame: (gameId: GAME_IDS | null | undefined) => boolean;
export {};
//# sourceMappingURL=ThemeService.d.ts.map