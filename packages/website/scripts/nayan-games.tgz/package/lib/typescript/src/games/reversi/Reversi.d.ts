export declare const Reversi: import("react").FC<import("../..").GameProps>;
//# sourceMappingURL=Reversi.d.ts.map