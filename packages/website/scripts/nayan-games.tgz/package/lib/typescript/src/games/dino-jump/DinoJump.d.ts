export declare const DinoJump: import("react").FC<import("../..").GameProps>;
//# sourceMappingURL=DinoJump.d.ts.map