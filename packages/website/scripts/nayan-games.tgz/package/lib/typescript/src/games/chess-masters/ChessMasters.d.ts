export declare const ChessMasters: import("react").FC<import("../..").GameProps>;
//# sourceMappingURL=ChessMasters.d.ts.map