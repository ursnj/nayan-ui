import { type Grid } from './PaperIoConstants';
export type Vec = {
    dx: number;
    dy: number;
};
export declare const DIRECTIONS: {
    readonly UP: {
        readonly dx: 0;
        readonly dy: -1;
    };
    readonly DOWN: {
        readonly dx: 0;
        readonly dy: 1;
    };
    readonly LEFT: {
        readonly dx: -1;
        readonly dy: 0;
    };
    readonly RIGHT: {
        readonly dx: 1;
        readonly dy: 0;
    };
};
export type DirCode = keyof typeof DIRECTIONS;
export type Player = {
    id: number;
    index: number;
    isBot: boolean;
    alive: boolean;
    col: number;
    row: number;
    dir: Vec;
    pendingDir: Vec;
    trail: number[];
    homeCol: number;
    homeRow: number;
    botState: 'expand' | 'return';
    botStepsOut: number;
    botTurned: boolean;
};
export type Board = Grid & {
    total: number;
    owners: number[];
    trails: number[];
    players: Player[];
    counts: number[];
};
export type Stats = {
    score: number;
    territoryPct: number;
    aiPct: number;
    rank: number;
    alivePlayers: number;
};
export declare const countTerritory: (b: Board, id: number) => number;
/** A fresh board: you near the bottom middle, the AI near the top middle, each on a 3 x 3 patch. */
export declare function newBoard(g: Grid): Board;
export declare function stats(b: Board): Stats;
/** A swipe's turn for you: queued for the next step (no turning straight back). Whether it changed. */
export declare function turn(b: Board, code: DirCode): boolean;
/** What one step changed: land (and who captured), trails, and whether the board is full. */
export type StepResult = {
    trailCells: number[];
    territory: boolean;
    trails: boolean;
    captured: boolean[];
    full: boolean;
    won: boolean;
};
/** One grid step: the AI decides, head-on moves are blocked, everyone moves a cell. */
export declare function step(b: Board): StepResult;
//# sourceMappingURL=PaperIoRules.d.ts.map