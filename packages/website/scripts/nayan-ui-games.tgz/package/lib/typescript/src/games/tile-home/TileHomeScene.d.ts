import { type Entity, type Vec3, type World } from '@nayan-ui/engine';
import type { GameTheme } from '../../services/ThemeService';
import type { Fruit, FruitKind } from '../shared/EngineFruits';
import { type Layout } from './TileHomeConstants';
export declare const Z_BACKDROP = 1;
export declare const Z_FLYING = 420;
export declare const layerZ: (layer: number) => number;
export declare const trayZ = 20;
/** A view point (from the top-left) at depth `z`, in world space. */
export declare const toWorld: (l: Layout, x: number, y: number, z?: number) => Vec3;
export type Scenery = Entity[];
/** The background, the board panel and the tray with its empty slots, for a theme. */
export declare function buildScenery(world: World, l: Layout, theme: GameTheme): Scenery;
export type TileEntities = {
    root: Entity;
    shade: Entity;
    fruit: Entity | null; /** Body and fruit, for the match flash. */
    parts: Entity[];
};
/**
 * A tile at view point (cx, cy) (its centre), depth z: body, fruit and a hidden shade. Without its
 * fruit model yet (still being built), the tile shows straight away and the fruit is added later.
 */
export declare function spawnTile(world: World, l: Layout, fruit: Fruit | undefined, cx: number, cy: number, z: number, scale: number): TileEntities;
/** Puts `fruit` on a tile's face (filling it, centred on its bounding box, a point above the middle like the original icon); `pop` springs it in. */
export declare function addTileFruit(world: World, l: Layout, root: Entity, fruit: Fruit, pop: boolean): Entity;
/** The fruit models built so far (they arrive one kind at a time). */
export type FruitModels = Partial<Record<FruitKind, Fruit>>;
//# sourceMappingURL=TileHomeScene.d.ts.map