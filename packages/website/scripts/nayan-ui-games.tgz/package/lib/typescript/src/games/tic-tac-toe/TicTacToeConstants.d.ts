import type { TiltView } from '../shared/EngineTilt';
export declare const TIME_LIMIT = 120;
export declare const WIN_SCORE = 10000;
export declare const DRAW_SCORE = 5000;
export declare const LOSE_SCORE = 0;
/** Points for every second still on the clock when a game is won (half this for a draw). */
export declare const TIME_BONUS = 50;
export declare const ROBOT_DELAY = 0.5;
export declare const COLORS: {
    readonly X: "#E53935";
    readonly O: "#2E7D32";
    readonly WIN: "#FFC107";
    readonly FRAME: "#5c4033";
    readonly WELL: "#3a2518";
    readonly SURFACE: "#6b4c3b";
    readonly SURFACE_ALT: "#735342";
    readonly GRID: "#8d6e5a";
    readonly X_BADGE: "#F44336";
    readonly O_BADGE: "#4CAF50";
};
/** The camera leans back from straight down, so the board's depth and the pieces stand up. */
export declare const TILT = 0.42;
/** Lit from the upper left; surfaces facing up off the board (+z) keep their exact color. */
export declare const LIGHT: import("@nayan-ui/engine").Light;
export type Layout = TiltView & {
    cell: number;
    size: number;
    pad: number;
};
/** The board as big as the original board (85% of the width, at most 350 points, 420 on a tablet), smaller if the screen is short. */
export declare function getLayout(width: number, height: number, offset: number, tablet: boolean): Layout;
/** A cell's centre (0 top left, row by row), in world units. */
export declare function cellCentre(l: Layout, i: number): [number, number];
/** The cell under a board point, or -1. */
export declare function cellAt(l: Layout, x: number, y: number): number;
//# sourceMappingURL=TicTacToeConstants.d.ts.map