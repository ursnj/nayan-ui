import { type Entity, type Model, type TransformBatch, type World } from '@nayan-ui/engine';
import type { Fruit, FruitKind } from '../shared/EngineFruits';
import { type Layout } from './FruitNinjaConstants';
import { type View3D } from './FruitNinjaWorld';
export type ItemKind = {
    kind: 'fruit';
    fruit: FruitKind;
} | {
    kind: 'bomb';
} | {
    kind: 'star';
};
export type Models = {
    fruits: Record<FruitKind, Fruit>;
    bomb: Model;
    spark: Model;
    star: Model;
    disc: Model;
};
/** The bomb, its fuse spark, the star and a flat disc (glows, trail joints). Needs the native core. */
export declare function buildModels(fruits: Record<FruitKind, Fruit>): Models;
/**
 * A thrown item at screen point (x, y) (its centre), springing up to full size and spinning: `spin` is
 * its turn per frame in the picture's plane (clockwise positive, as original), plus a little tumble.
 */
export declare function spawnItem(world: World, v: View3D, l: Layout, m: Models, item: ItemKind, x: number, y: number, spin: number): Entity;
export declare function placeItem(world: World, v: View3D, root: Entity, x: number, y: number, updates?: TransformBatch): void;
/**
 * The blade cuts an item at screen (x, y), moving (vx, vy) points per frame, along screen direction
 * (dx, dy). A fruit falls apart in two halves split along the stroke, pushed apart and tumbling, under a
 * splash of its juice; a star bursts into gold; a bomb explodes.
 */
export declare function sliceItem(world: World, v: View3D, l: Layout, m: Models, root: Entity, item: ItemKind, x: number, y: number, vx: number, vy: number, dx: number, dy: number): void;
/**
 * The blade's trail, as Falling Sticks draws its finger: glowing beads through the last touch points,
 * shrinking toward the tail. It remembers how many beads are showing and whether they are fading, so a
 * redraw sets only the beads that change (one native call each) and stops animations only after a fade.
 */
export type Trail = {
    beads: Entity[];
    shown: number;
    fading: boolean;
};
export declare function spawnTrail(world: World): Trail;
/** Draws the trail through the first `n` points of `xs`, `ys` (screen points, oldest first). */
export declare function drawTrail(world: World, v: View3D, t: Trail, xs: ArrayLike<number>, ys: ArrayLike<number>, n: number): void;
/** The finger lifted: the trail shrinks and fades out where it is. */
export declare function fadeTrail(world: World, t: Trail): void;
export declare function hideTrail(world: World, t: Trail): void;
export declare function removeTrail(world: World, t: Trail): void;
/** Reusable assets; the game loader advances one builder per frame. */
export declare function warmAssets(): Iterable<() => unknown>;
//# sourceMappingURL=FruitNinjaScene.d.ts.map