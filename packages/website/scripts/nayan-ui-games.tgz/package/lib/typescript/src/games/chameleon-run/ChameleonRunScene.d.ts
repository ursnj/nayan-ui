import { type Camera, type Color, type Entity, type Vec3, type World } from '@nayan-ui/engine';
import type { GameTheme } from '../../services/ThemeService';
import { type Backdrop } from './ChameleonRunBackdrop';
import { type Config, type RunColor } from './ChameleonRunConstants';
import { type Platform, type Run } from './ChameleonRunRules';
interface PlatformView {
    root: Entity;
    star: Entity | null;
}
export interface Scene {
    syncedFirst?: number;
    syncedLast?: number;
    syncedCount?: number;
    backdrop: Backdrop;
    field: Entity;
    chameleon: Entity;
    skin: Entity[];
    legs: Entity[];
    tail: Entity;
    shadow: Entity;
    platforms: Map<number, PlatformView>;
    tint: Color;
    color: RunColor;
    stride: boolean;
}
export declare const starPosition: (p: Platform, distance: number) => Vec3;
/** A centered chase camera keeps the runner and course on the screen centerline. */
export declare function frameCamera(camera: Camera, c: Config, lift?: number): void;
export declare function buildScene(world: World, theme: GameTheme): Scene;
export declare function removeScene(world: World, s: Scene): void;
export declare function syncPlatforms(world: World, c: Config, s: Scene, platforms: Platform[]): void;
export declare function drawScene(world: World, c: Config, s: Scene, r: Run): void;
export declare function setStride(world: World, s: Scene, running: boolean): void;
export declare function tintChameleon(world: World, s: Scene, color: RunColor, y?: number): void;
export declare function hop(world: World, s: Scene, double: boolean): void;
export declare function land(world: World, s: Scene, p: Platform): void;
export declare function collectStar(world: World, s: Scene, p: Platform, distance: number): void;
/** A nonfatal stumble; the course keeps moving while the player is invulnerable. */
export declare function stumble(world: World, s: Scene, r: Run): void;
export declare function tumble(world: World, s: Scene, r: Run): void;
export declare function cheer(world: World, s: Scene, r: Run): void;
export declare function clearPlatforms(world: World, s: Scene): void;
export declare function resetChameleon(world: World, s: Scene): void;
export {};
//# sourceMappingURL=ChameleonRunScene.d.ts.map