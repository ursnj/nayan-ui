import { type Camera, type Entity, World } from '@nayan-ui/engine';
import type { GameTheme } from '../../services/ThemeService';
import type { HudFeedback } from '../shared/EngineHud';
import type { GamePhase as Phase } from '../shared/useEngineGame';
import { type Layout } from './StackTowerConstants';
import { type Scene } from './StackTowerScene';
/** place / perfect: a block set down; miss: it missed the tower. */
export type GameEvent = 'place' | 'perfect' | 'miss';
type Placed = {
    x: number;
    y: number;
    level: number;
    entity: Entity | null;
};
type Moving = {
    x: number;
    y: number;
    direction: number;
    level: number;
    entity: Entity | null;
};
export declare function createGame(theme: GameTheme): {
    world: World;
    camera: Camera;
    theme: GameTheme;
    layout: Layout | null;
    scene: Scene | null;
    phase: Phase;
    tower: Placed[];
    moving: Moving | null;
    falling: Entity | null;
    level: number;
    perfectCount: number;
    /** Score and the countdown live in the engine (Rust), advanced by world.update. */
    readonly score: number;
    readonly timeRemaining: number;
    won: boolean;
    /** How far the view has scrolled down to follow the tower, and where it's heading. */
    offset: number;
    offsetTarget: number;
    onPhase: (_p: Phase) => void;
    hudFeedback: HudFeedback;
    onEvent: (_e: GameEvent) => void;
};
export type Game = ReturnType<typeof createGame>;
/** Lays the tower out for the view (first layout, rotation): rebuilt from the game's state. */
export declare function setLayout(g: Game, l: Layout): void;
export declare function setTheme(g: Game, theme: GameTheme): void;
export declare function start(g: Game): void;
/** Back to the base block alone (Stop, Play Again). The world, and the GPU view drawing it, are kept. */
export declare function reset(g: Game): void;
/** The slide and the scrolling view; the engine steps the world after. */
export declare function tick(g: Game, dt: number): void;
/** A tap anywhere drops the sliding block where it is. */
export declare function tap(g: Game): void;
export {};
//# sourceMappingURL=StackTowerGame.d.ts.map