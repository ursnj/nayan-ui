import { type Quat } from 'nayan-ui';
import { type Point } from './TreasureHuntConstants';
export declare const SOLID_CELL = 8;
export declare const ROCK_RINGS = 12;
export declare const ROCK_SIDES = 18;
export declare const CAVE_INNER_WIDTH = 3.5;
export declare const CAVE_INNER_HEIGHT = 4.8;
export declare const BRIDGE_RAIL_INSET = 0.15;
export declare const BRIDGE_RAIL_DEPTH = 0.09;
export declare const BRIDGE_POST_WIDTH = 0.3;
export declare const BRIDGE_POST_HEIGHT = 1.12;
export type SolidTag = 'tree' | 'rock' | 'bridge-rail' | 'bridge-post';
interface SolidBounds extends Point {
    tag: SolidTag;
    bottom: number;
    top: number;
    minX: number;
    maxX: number;
    minZ: number;
    maxZ: number;
}
export type Solid = SolidBounds & ({
    shape: 'circle';
    radius: number;
} | {
    shape: 'polygon';
    points: Point[];
});
export type SolidCells = Map<string, Solid[]>;
/** Shared surface samples keep rendered boulders and their collision hulls in agreement. */
export declare function rockSurface(style: number, a: number, b: number): {
    position: [number, number, number];
    normal: [number, number, number];
};
export declare function circleSolid(tag: SolidTag, x: number, z: number, radius: number, bottom: number, top: number): Solid;
export declare function boxSolid(tag: SolidTag, x: number, z: number, halfX: number, halfZ: number, yaw: number, bottom: number, top: number): Solid;
export declare function rockSolid(x: number, y: number, z: number, scale: readonly [number, number, number], yaw: number, style: number): Solid;
/** Signed distance to the full visible footprint, including rounded corners around an actor. */
export declare function solidDistance(solid: Solid, x: number, z: number): number;
export declare function indexSolid(cells: SolidCells, solid: Solid): void;
export declare function solidClearance(cells: SolidCells, x: number, z: number, radius: number, bottom: number, top: number): number;
export interface BridgeBarrier extends Point {
    kind: 'rail' | 'post';
    halfX: number;
    halfZ: number;
}
/** The renderer and collision system share every railing and post position. */
export declare function bridgeBarriers(bridge: {
    halfLength: number;
    halfWidth: number;
}): BridgeBarrier[];
export interface Hill extends Point {
    height: number;
    width: number;
    depth: number;
    yaw: number;
}
export interface Cave extends Point {
    y: number;
    length: number;
}
export interface Bridge extends Point {
    halfLength: number;
    halfWidth: number;
    y: number;
}
export type TerrainSurface = 'grass' | 'hill' | 'river' | 'shore' | 'cave' | 'bridge';
export declare const TERRAIN_STEP = 1.6;
export declare const TERRAIN_EDGE: number;
export declare const TERRAIN_GRID: Float32Array<ArrayBuffer>;
export interface NatureProp extends Point {
    kind: 'pine' | 'birch' | 'rock';
    scale: number;
    yaw: number;
    style: number;
}
export interface NatureDecoration extends Point {
    kind: 'rock' | 'pine';
    area: 'horizon' | 'cave-roof' | 'cave-entrance';
    y: number;
    scale: [number, number, number];
    yaw: number;
    style: number;
}
export interface Landscape {
    profile: number;
    phase: number;
    hills: Hill[];
    caves: Cave[];
    bridges: Bridge[];
}
export interface NatureMap {
    seed: number;
    edge: number;
    rotation: number;
    landscape: Landscape;
    spawn: Point;
    props: NatureProp[];
    decorations: NatureDecoration[];
    obstacleCells: SolidCells;
    reachable: Point[];
    gems: Point[];
    enemies: Point[];
}
export declare function random(seed: number): () => number;
/** Bounded geometry library: native mesh IDs live for the app's lifetime. Seeds also rotate the
 * landscape and independently scatter vegetation, formations, enemies and treasure each run. */
export declare function landscapeFor(profile: number): Landscape;
export declare function riverX(landscape: Landscape, z: number): number;
export declare function riverWidth(landscape: Landscape, z: number): number;
export declare function waterLevel(_landscape: Landscape, z: number): number;
/** Compact rocky hills leave broad, gently rolling grassland between their distinct foothills. */
export declare function hillRise(landscape: Landscape, x: number, z: number): number;
export declare function terrainHeight(landscape: Landscape, x: number, z: number): number;
/** Sample the same triangle planes the renderer draws, including clipped material boundaries. */
export declare function terrainMeshHeight(landscape: Landscape, x: number, z: number): number;
/** Rounded cave surrounds avoid rectangular terrain cutouts at the entrances. */
export declare function caveDistance(cave: Cave, x: number, z: number): number;
export declare function caveClearance(landscape: Landscape, x: number, z: number): number;
/** Continuous contours are shared by visible terrain, movement and contact normals. */
export declare function terrainSurface(landscape: Landscape, x: number, z: number): Exclude<TerrainSurface, 'bridge'>;
export declare function toWorld(map: Pick<NatureMap, 'rotation'>, x: number, z: number): Point;
export declare function toLocal(map: Pick<NatureMap, 'rotation'>, x: number, z: number): Point;
export declare function groundHeight(map: NatureMap, x: number, z: number): number;
/** Surface tilt in a parent's yaw basis, for contact shadows that lie against the ground. */
export declare function groundTilt(map: NatureMap, x: number, z: number, yaw?: number): Quat;
export declare function bridgeAt(map: NatureMap, x: number, z: number): Bridge | undefined;
export declare function surfaceAt(map: NatureMap, x: number, z: number): TerrainSurface;
/** Immutable terrain samples; the screen owns colours, paths and live objective markers. */
export declare function mapOverview(map: NatureMap, size: number): readonly (TerrainSurface | null)[];
export declare function waterDepth(map: NatureMap, x: number, z: number): number;
export declare function caveAt(map: NatureMap, x: number, z: number): Cave | undefined;
/** Passage width accounts for the explorer's height beneath the actual curved arch. */
export declare function cavePassageClearance(landscape: Landscape, x: number, z: number): number;
/** Terrain and visible solids supply the same contact normals used by swept movement. */
export declare function navigationClearance(map: NatureMap, x: number, z: number, radius?: number): number;
/** Grass, bridge decks and cave passages are walkable; complete body footprints stay outside solids. */
export declare function isWalkable(map: NatureMap, x: number, z: number, radius?: number): boolean;
/**
 * The next run in the same world (Play Again, Stop): fresh places for the diamonds and robots, from
 * a seed derived from the world's and the run's number, so it's reproducible. The terrain, scenery
 * and reachable ground are reused as they are: no world is generated or rebuilt.
 */
export declare function createRunState(map: NatureMap, run: number): NatureState;
export declare function generateNature(seed?: number): NatureMap;
/** A generated world as plain data, to keep between visits: everything else is derived from it. */
export interface SavedWorld {
    seed: number;
    rotation: number;
    spawn: Point;
    props: NatureProp[];
    decorations: NatureDecoration[];
    reachable: Point[];
    gems: Point[];
    enemies: Point[];
    /** The minimap's terrain samples (MINIMAP_SIZE squared), when complete. */
    overview?: (TerrainSurface | null)[];
}
/** Where generated worlds are kept between visits (the game's procedural cache). */
export interface WorldStore {
    read(seed: number): SavedWorld | undefined;
    write(seed: number, world: SavedWorld): void;
    /** Whether a world is kept, cheaply (without reading it). */
    has?(seed: number): boolean;
}
/** Generated worlds are saved to, and restored from, `store` (none: every visit generates). */
export declare function keepWorlds(store: WorldStore | undefined): void;
/**
 * The one world each terrain profile has. Generating a world (scenery, reachability, objectives)
 * took about half a second of JS on a phone on every visit; with a fixed world per profile it's
 * generated once and restored after that, and the profiles still give sixteen different worlds.
 */
export declare const worldSeed: (profile: number) => number;
export declare function saveWorld(map: NatureMap): SavedWorld;
/** A saved world, as `generateNature` made it: the same landscape, solids (in the same order) and minimap. */
export declare function restoreWorld(saved: SavedWorld): NatureMap;
/** Prepare one fresh layout in bounded batches, without creating a world, actors or game state. */
export declare function warmNextMap(): Iterable<() => void>;
export declare const peekNextMap: () => NatureMap | undefined;
export type Phase = 'ready' | 'playing' | 'won' | 'lost';
export interface Enemy extends Point {
    id: number;
    home: Point;
    health: number;
    yaw: number;
    windup: number;
    recovery: number;
    stagger: number;
    moving: boolean;
}
export interface Gem extends Point {
    id: number;
    taken: boolean;
}
export interface NatureState {
    map: NatureMap;
    phase: Phase;
    player: Point;
    yaw: number;
    health: number;
    gems: number;
    defeated: number;
    score: number;
    time: number;
    attackCooldown: number;
    attackPending: number;
    invulnerable: number;
    moving: boolean;
    speed: number;
    velocity: Point;
    yawVelocity: number;
    enemies: Enemy[];
    pickups: Gem[];
}
export interface NatureInput {
    x: number;
    y: number;
    attack: boolean;
}
export interface NatureEvent {
    kind: 'attack' | 'hit' | 'defeated' | 'gem' | 'hurt' | 'won' | 'lost';
    x: number;
    z: number;
    id?: number;
}
export declare const distance: (a: Point, b: Point) => number;
export declare function createState(seed?: number): NatureState;
/** Sweep the full direction, settle just before contact, then slide along its continuous normal. */
export interface ActorBody extends Point {
    radius: number;
}
export declare function moveActor(map: NatureMap, point: Point, dx: number, dz: number, radius?: number, bodies?: readonly ActorBody[]): void;
/** No React or native calls: rules emit events for the engine's effects and HUD. */
export declare function step(state: NatureState, input: NatureInput, elapsed: number): NatureEvent[];
export {};
//# sourceMappingURL=TreasureHuntRules.d.ts.map