import { type Entity, type Vec3, type World } from '@nayan-ui/engine';
import type { GameTheme } from '../../services/ThemeService';
import { type Layout } from './NutsAndBoltsConstants';
import { type Plank } from './NutsAndBoltsRules';
export declare const holeRadius: (l: Layout) => number;
export declare const boltRadius: (l: Layout) => number;
/** Where a bolt sits: on top of the highest plank at its point (or the board). */
export declare const boltRest: (planks: Plank[], row: number, col: number) => number;
export type Scene = {
    backdrop: Entity;
    panel: Entity;
    rim: Entity | null;
    separator: Entity;
    sockets: Entity[];
    swaps: Entity[];
    planks: Map<string, Entity>;
    /** Each bolt: an unturned pivot (position and spin about z) carrying the standing bolt (its color). */
    bolts: Map<string, {
        pivot: Entity;
        body: Entity;
    }>;
};
export declare function buildScene(world: World, l: Layout, theme: GameTheme, homes: {
    row: number;
    col: number;
}[]): Scene;
export declare function removeScene(world: World, s: Scene): void;
export declare function setSceneTheme(world: World, l: Layout, s: Scene, theme: GameTheme): void;
/** The sockets at the bolts' homes (a new puzzle). */
export declare function placeSockets(world: World, l: Layout, s: Scene, homes: {
    row: number;
    col: number;
}[]): void;
export declare function spawnPlank(world: World, l: Layout, s: Scene, p: Plank): void;
/** A freed plank swings down off the board and fades, then goes. Returns how long that takes. */
export declare function dropPlank(world: World, l: Layout, s: Scene, p: Plank): number;
export declare function spawnBolt(world: World, l: Layout, s: Scene, id: string, at: Vec3): void;
export declare function removeBolts(world: World, s: Scene): void;
/** Picked up: the bolt turns gold and unscrews up out of its hole (turning as it rises), then hovers. */
export declare function liftBolt(world: World, l: Layout, s: Scene, id: string, at: Vec3): void;
/** Put back where it was: it screws back down (turning clockwise as it sinks) and seats, in silver. */
export declare function lowerBolt(world: World, l: Layout, s: Scene, id: string, at: Vec3): void;
/** A bolt whose plank underneath fell: it drops onto the next one down. */
export declare function settleBolt(world: World, s: Scene, id: string, at: Vec3): void;
/** Moved: it lifts clear, arcs over above the planks, then screws down into its new hole and seats. */
export declare function moveBolt(world: World, l: Layout, s: Scene, id: string, from: Vec3, to: Vec3): void;
/** Confetti over the board when every plank's down. */
export declare function celebrate(world: World, l: Layout): void;
//# sourceMappingURL=NutsAndBoltsScene.d.ts.map