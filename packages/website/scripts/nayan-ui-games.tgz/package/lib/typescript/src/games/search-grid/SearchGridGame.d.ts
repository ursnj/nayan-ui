import { type Camera, type DragEvent, World } from '@nayan-ui/engine';
import type { GameTheme } from '../../services/ThemeService';
import type { GamePhase as Phase } from '../shared/useEngineGame';
import { type Cell, type Layout, type Placed } from './SearchGridConstants';
import { type Scene } from './SearchGridScene';
export type Content = {
    list: readonly string[];
    alphabet: string;
};
export declare function createGame(theme: GameTheme, content: Content): {
    world: World;
    camera: Camera;
    theme: GameTheme;
    content: Content;
    layout: Layout | null;
    scene: Scene | null;
    phase: Phase;
    grid: string[][];
    placed: Placed[];
    found: Set<string>;
    /** The line being dragged: its first cell and where it ends now. */
    start: Cell | null;
    end: Cell | null;
    /** Score and the countdown live in the engine (Rust), advanced by world.update. */
    readonly score: number;
    readonly timeLeft: number;
    won: boolean;
    onPhase: (_p: Phase) => void;
    onScore: (_s: number) => void;
    /** A new grid's entries, in placement order (their colors follow it). */
    onEntries: (_entries: string[]) => void;
    onFound: (_found: ReadonlySet<string>) => void;
    /** One more entry found (its sound and haptic), then `onWin` if it was the last. */
    onFind: () => void;
    onWin: () => void;
};
export type Game = ReturnType<typeof createGame>;
/** Lays the scene out for the view (first layout, header height, rotation): rebuilt from the game's state. */
export declare function setLayout(g: Game, l: Layout): void;
export declare function setTheme(g: Game, theme: GameTheme): void;
/** Plays the grid that's showing. */
export declare function start(g: Game): void;
/** A fresh grid, not started (Stop, Play Again). The world, and the GPU view drawing it, are kept. */
export declare function reset(g: Game): void;
export declare const entries: (g: Game) => string[];
/** The selection following the finger; the engine steps the world after. */
export declare function tick(g: Game, dt: number): void;
/** The cell under a view point, as seen on the tiles' tops. */
export declare function cellUnder(g: Game, x: number, y: number): Cell | null;
/** Start a line on the cell under the finger, stretch it along a row, column or diagonal, check it on release. */
export declare function drag(g: Game, { phase, x, y }: DragEvent): void;
//# sourceMappingURL=SearchGridGame.d.ts.map