import { type Entity, type World } from '@nayan-ui/engine';
import type { GameTheme } from '../../services/ThemeService';
import { type Layout } from './TicTacToeConstants';
import type { Player } from './TicTacToeRules';
export type Scene = {
    backdrop: Entity;
    /** The board's frame, well and surface, its cells and grid bars (rebuilt on a theme change). */
    board: Entity[];
    pieces: (Entity | null)[];
    ghost: Entity;
    line: Entity | null;
};
export declare function buildScene(world: World, l: Layout, theme: GameTheme, board: (Player | null)[]): Scene;
export declare function removeScene(world: World, s: Scene): void;
export declare function setSceneTheme(world: World, l: Layout, s: Scene, theme: GameTheme): void;
/** A piece on a cell: it grows out of the cell with a little turn and settles (or is just there). */
export declare function place(world: World, l: Layout, s: Scene, i: number, p: Player, animate?: boolean): void;
/** A faint O over an empty cell while a finger rests on it. */
export declare function showGhost(world: World, l: Layout, s: Scene, i: number): void;
export declare function hideGhost(world: World, s: Scene): void;
/** Three in a row: they turn gold and hop, and a gold bar is laid across them, glowing softly. */
export declare function markWin(world: World, l: Layout, s: Scene, line: readonly [number, number, number]): void;
/** A draw: every piece gives a little shrug. */
export declare function shrug(world: World, l: Layout, s: Scene): void;
/** A fresh board: the pieces lift off and fade, and the win bar goes. */
export declare function clearPieces(world: World, s: Scene): void;
//# sourceMappingURL=TicTacToeScene.d.ts.map