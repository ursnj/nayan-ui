import type { TiltView } from '../shared/EngineTilt';
export declare const GAME_DURATION = 120;
export declare const POINTS_PER_PIECE = 1000;
export { TRAY_SCALE, RIM_RADIUS } from './TangramRules';
export declare const TAP_MAX = 0.25;
export declare const TAP_SLOP = 10;
export declare const ROTATE_STEP = 45;
export declare const ROTATE_TIME = 0.18;
export declare const SNAP_TIME = 0.16;
export declare const ENTRY_STAGGER = 0.045;
export declare const WIN_DELAY = 0.22;
export declare const WIN_STAGGER = 0.09;
export declare const COLORS: {
    readonly CLASSIC_SLOT: "rgba(255, 255, 255, 0.12)";
    readonly CLASSIC_SLOT_EDGE: "rgba(255, 255, 255, 0.30)";
};
/** A directly overhead camera and light keep shapes and finger positions aligned. */
export declare const TILT = 0;
export declare const LIGHT: import("@nayan-ui/engine").Light;
/** A tan's thickness, and the gap between stacked tans in the tray, in tan units. */
export declare const PIECE_DEPTH = 0.2;
export declare const STACK_STEP = 0.14;
/** How high a tan rises off the board while held. */
export declare const HELD_HEIGHT = 1.2;
export type Layout = TiltView & {
    unit: number;
    boardW: number;
    boardH: number;
};
/** Fit the entire grid, including its outline, inside the game width. */
export declare function getLayout(width: number, height: number, offset: number): Layout;
/** A board point (x right, y down from the board's top-left) in the world (the board centred on the origin, y up). */
export declare const toWorld: (l: Layout, x: number, y: number) => [number, number];
/** And back. */
export declare const toBoard: (l: Layout, wx: number, wy: number) => [number, number];
//# sourceMappingURL=TangramConstants.d.ts.map