import type { GAME_IDS, GameThemeMode } from '../../services/UtilsService';
interface GameLoadingProps {
    gameId: GAME_IDS;
    theme?: GameThemeMode;
    label?: string;
    error?: boolean;
    message?: string;
    onRetry?: () => void;
    offset?: number;
    visible?: boolean;
}
/** Shared engine loading world; only engine-unavailable/bootstrap failures use the text fallback. */
export declare const GameLoading: import("react").MemoExoticComponent<({ gameId, theme, label, error, message, onRetry, offset, visible }: GameLoadingProps) => import("react").JSX.Element>;
export {};
//# sourceMappingURL=GameLoading.d.ts.map