import type { TiltView } from '../shared/EngineTilt';
export declare const COLS = 19;
export declare const ROWS = 21;
export declare const POINTS_PER_DOT = 100;
export declare const POINTS_PER_POWER_PELLET = 500;
export declare const POINTS_PER_GHOST = 500;
export declare const POINTS_PER_FRUIT = 300;
export declare const INITIAL_LIVES = 3;
export declare const TIME_LIMIT = 300;
export declare const PAC_STEP = 0.16;
export declare const GHOST_STEP = 0.25;
export declare const GHOST_EATEN_STEP = 0.1;
export declare const POWER_PELLET_TIME = 7;
export declare const FLASH_TIME = 2;
export declare const SCATTER_TIME = 7;
export declare const CHASE_TIME = 20;
export declare const FRUIT_TIME = 10;
export declare const FRUIT_SPAWN_DOTS: number[];
export declare const CHOMP_TIME = 0.16;
export declare enum CellType {
    EMPTY = 0,
    WALL = 1,
    DOT = 2,
    POWER_PELLET = 3,
    GHOST_HOUSE = 4,
    GHOST_DOOR = 5,
    TUNNEL = 6
}
export declare enum GhostMode {
    SCATTER = "scatter",
    CHASE = "chase",
    FRIGHTENED = "frightened",
    EATEN = "eaten",
    IN_HOUSE = "in_house",
    LEAVING_HOUSE = "leaving_house"
}
export declare enum GhostName {
    BLINKY = "blinky",
    PINKY = "pinky",
    INKY = "inky",
    CLYDE = "clyde"
}
export type Direction = 'UP' | 'DOWN' | 'LEFT' | 'RIGHT' | 'NONE';
export declare const DIRECTIONS: Record<Direction, {
    x: number;
    y: number;
}>;
export declare const OPPOSITE: Record<Direction, Direction>;
export declare const GHOST_LIST: readonly [GhostName.BLINKY, GhostName.PINKY, GhostName.INKY, GhostName.CLYDE];
export declare const GHOST_COLORS: Record<GhostName, string>;
export declare const COLORS: {
    readonly BOARD: "#0A0A2E";
    readonly WALL: "#2742F0";
    readonly WALL_EDGE: "#5A72FF";
    readonly DOT: "#FFE2B0";
    readonly PELLET: "#FFF4D6";
    readonly PACMAN: "#FFE000";
    readonly FRUIT: "#FF4040";
    readonly FRUIT_STEM: "#4CAF50";
    readonly FRIGHTENED: "#2334E8";
    readonly FRIGHTENED_FLASH: "#F4F4FF";
    readonly EYE: "#FFFFFF";
    readonly PUPIL: "#1A1A6E";
};
export declare const LIGHT: import("@nayan-ui/engine").Light;
export declare const TILT = 0.34;
export declare const PACMAN_MAZE: number[][];
export declare const PACMAN_START: {
    x: number;
    y: number;
};
export declare const GHOST_START: Record<GhostName, {
    x: number;
    y: number;
}>;
export declare const GHOST_SCATTER: Record<GhostName, {
    x: number;
    y: number;
}>;
/** Seconds after the game starts before each ghost leaves the house. */
export declare const GHOST_RELEASE: Record<GhostName, number>;
export declare const HOUSE_DOOR: {
    x: number;
    y: number;
};
export type Layout = TiltView & {
    cell: number;
    sizeX: number;
    sizeY: number;
};
/** The maze as wide as the game area, centred between the scoreboard and the controls. */
export declare function getLayout(width: number, height: number, offset: number): Layout;
/** A grid point (cell units, 0.5 = a cell's centre) on the maze, in world units. Row 0 is the top. */
export declare const gridPoint: (l: Layout, x: number, y: number) => [number, number];
//# sourceMappingURL=PacManConstants.d.ts.map