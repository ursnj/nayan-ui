import type { Camera, DragEvent, World } from 'nayan-ui';
import { type HapticType } from '../../services/HapticsService';
import { type SoundConfig } from '../../services/SoundsService';
import { type GameTheme } from '../../services/ThemeService';
import type { GameProps } from '../../services/UtilsService';
import type { EngineGameScreenProps } from './EngineGameScreen';
import type { EngineHud, GameOverCard, HudFeedback } from './EngineHud';
/** Where a run is: before Start, running, or ended (the game-over card is up). */
export type GamePhase = 'ready' | 'playing' | 'over';
type Phase = GamePhase;
/** How an ended game came out; a draw is reported as a cancel. */
export type GameResult = 'win' | 'lose' | 'draw';
/** What every engine game's state exposes to its screen. */
export type EngineGameModel = {
    world: World | null;
    camera: Camera;
    score?: number;
    phase: Phase;
    won?: boolean;
    onPhase: (phase: Phase) => void;
    hudFeedback?: HudFeedback;
};
/** Plays a sound and/or a haptic, each only if the player has it switched on. */
export type Feedback = (sound?: SoundConfig | null, haptic?: HapticType | null) => void;
/** What a game event plays. */
export type EventFeedback = {
    sound?: SoundConfig | null;
    haptic?: HapticType | null;
};
/** The events a game reports through `g.onEvent(event)`. */
type EventOf<G> = G extends {
    onEvent: (event: infer E) => void;
} ? E : never;
/** The world's scoreboard (kept in Rust), as the screen shows it. */
export type BoardState = {
    score: number;
    /** Whole seconds shown: left on a countdown, elapsed otherwise. */
    seconds: number;
    lives: number;
};
export type EngineGameSpec<G extends EngineGameModel> = {
    gameId: string;
    create: (theme: GameTheme) => G;
    start: (g: G) => void;
    reset: (g: G) => void;
    /** What Play Again does; `reset` by default. */
    replay?: (g: G) => void;
    /** Releases what the game holds besides its world (which is disposed after this). */
    dispose?: (g: G) => void;
    /** The game's own per-frame work. The world steps by itself right after (unless this stepped it). */
    tick?: (g: G, dt: number) => void;
    hud?: (g: G, hud: EngineHud) => void;
    setTheme?: (g: G, theme: GameTheme) => void;
    setActive?: (g: G, active: boolean) => void;
    resize?: (g: G, width: number, height: number, offset: number) => number | void;
    drag?: (g: G, e: DragEvent) => void;
    tap?: (g: G, x: number, y: number) => void;
    /** How an ended game came out (reported, and returned as `status`); from `g.won` by default. */
    outcome?: (g: G) => GameResult;
    /** The score reported with a result; `g.score` by default. */
    reportScore?: (g: G, status: 'win' | 'lose' | 'cancel') => number;
    /** Optional game-specific completion metrics, sampled at the same time as the final score. */
    reportData?: (g: G, status: 'win' | 'lose' | 'cancel') => Record<string, unknown>;
    /** Each `g.onEvent(event)`'s sound and haptic (wired before `wire`). */
    events?: {
        readonly [E in EventOf<G> & PropertyKey]?: EventFeedback;
    };
    /** Hooks the game's events up to React state and feedback; called once. May return a cleanup, run on leaving. */
    wire?: (g: G, fx: Feedback) => void | (() => void);
    /** Cached ahead of the first sound. */
    sounds?: Record<string, SoundConfig>;
    /** Feedback on Start / Stop. */
    onStart?: (fx: Feedback) => void;
    onStop?: (fx: Feedback) => void;
    onPlayAgain?: (fx: Feedback) => void;
    /** Feedback as the game ends, beyond what its own events play. */
    onOver?: (fx: Feedback, status: GameResult, game: G) => void;
    /** Lets an ending play out (ms) before the game-over card covers it. */
    resultsDelay?: (status: GameResult) => number;
};
type ScreenProps = Pick<EngineGameScreenProps, 'onActiveChange' | 'feedback' | 'gameId' | 'settings' | 'onSettingsChange' | 'onShare' | 'onShowLeaderboard' | 'bannerAd' | 'source' | 'camera' | 'onUpdate' | 'onResize' | 'onDrag' | 'onTap' | 'playing' | 'onStart' | 'onStop'>;
export declare function useEngineGame<G extends EngineGameModel>(props: GameProps & {
    settings: NonNullable<GameProps['settings']>;
}, spec: EngineGameSpec<G>): {
    game: G;
    theme: GameTheme;
    phase: GamePhase;
    status: GameResult;
    board: BoardState;
    fx: Feedback;
    screen: ScreenProps;
    gameOver: (card: Omit<GameOverCard, "onPlayAgain" | "onShare">) => GameOverCard | null;
};
export {};
//# sourceMappingURL=useEngineGame.d.ts.map