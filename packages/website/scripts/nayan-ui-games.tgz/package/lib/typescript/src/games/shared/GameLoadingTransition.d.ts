import { type ReactNode } from 'react';
interface GameLoadingTransitionProps {
    ready: boolean;
    loader: ReactNode;
    children: ReactNode;
}
/** Keep the loading surface over the first game frame, then release it after fading. */
export declare const GameLoadingTransition: import("react").MemoExoticComponent<({ ready, loader, children }: GameLoadingTransitionProps) => import("react").JSX.Element>;
export {};
//# sourceMappingURL=GameLoadingTransition.d.ts.map