import React from 'react';
import { GameView } from 'nayan-ui';
import { type GAME_IDS, type GameProps } from '../../services/UtilsService';
import { EngineHud, type GameOverCard, type HudChoice, type HudColumn, type HudFeedback } from './EngineHud';
/** Everything GameView takes, but the HUD's overlay and the frame hooks this screen owns. */
type SceneProps = Omit<React.ComponentProps<typeof GameView>, 'overlay' | 'onOverlayTouch' | 'onUpdate' | 'onStats' | 'background' | 'source'> & {
    /** What to draw; null until the game has made its world (the view waits for it). */
    source: React.ComponentProps<typeof GameView>['source'] | null;
    /** The clear color; the theme's background by default. */
    background?: React.ComponentProps<typeof GameView>['background'];
};
export type EngineGameScreenProps = SceneProps & Pick<GameProps, 'settings' | 'onSettingsChange' | 'onShare' | 'onShowLeaderboard' | 'bannerAd'> & {
    gameId: string;
    /** Reserve overlay entities for dense engine-drawn interfaces. */
    hudCapacity?: number;
    /** Host fallback when the rendering surface reports an error. */
    errorMessage?: string;
    /** Transient game feedback rendered and animated by the engine HUD. */
    feedback?: HudFeedback;
    choices?: HudChoice[];
    /** Suspend/resume a game-owned audio loop with app activity, pause and sound settings. */
    onAudioChange?: (audible: boolean) => void;
    onActiveChange?: (active: boolean) => void;
    /** Called every frame before the HUD animates (the game's tick). */
    onUpdate?: (dt: number, hud: EngineHud) => void;
    /** The view's size and the header offset, whenever they change: lay the scene out for them. */
    onResize?: (width: number, height: number, offset: number) => number | void;
    /** The scoreboard's columns. */
    columns: HudColumn[];
    playing: boolean;
    /** The line under the controls while playing. */
    subtext?: string;
    onStart: () => void;
    onStop: () => void;
    /** The game-over card, or null while there's none. Android back plays again on it. */
    gameOver: GameOverCard | null;
    /** React Native views over the scene (under the settings modal). */
    children?: React.ReactNode;
};
export declare const EngineGameScreen: React.FC<EngineGameScreenProps>;
/**
 * Makes an engine game's component: memoised, with default settings, inside the game theme and a
 * container and the selected game's loader while the engine warms up.
 */
export declare function engineGame(id: GAME_IDS, Game: React.FC<GameProps & {
    settings: NonNullable<GameProps['settings']>;
}>): React.FC<GameProps>;
export {};
//# sourceMappingURL=EngineGameScreen.d.ts.map