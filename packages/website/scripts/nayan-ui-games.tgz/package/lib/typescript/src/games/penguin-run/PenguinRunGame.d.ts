import { type Camera, World } from '@nayan-ui/engine';
import type { GameTheme } from '../../services/ThemeService';
import type { GamePhase as Phase } from '../shared/useEngineGame';
import { type Tile, type TrackPlan } from './PenguinRunScene';
type Action = 'jump' | 'slide' | 'hit' | null;
export declare function createGame(theme: GameTheme): {
    world: World;
    theme: GameTheme;
    penguin: import("./PenguinModel").Penguin;
    camera: Camera;
    phase: Phase;
    won: boolean;
    plan: TrackPlan;
    tiles: Tile[];
    nextTile: number;
    lane: number;
    x: number;
    vx: number;
    camX: number;
    z: number;
    speed: number;
    distance: number;
    lastDistance: number;
    coins: number;
    gems: number;
    score: number;
    lives: number;
    invulnerable: number;
    action: Action;
    /** A jump / slide swiped while the same one was still playing: it goes as soon as that one ends, if within QUEUE_TIME. */
    queued: "jump" | "slide" | null;
    queuedT: number;
    actionT: number;
    actionDur: number;
    orbit: number;
    onPhase: (phase: Phase) => void;
    onScore: (score: number) => void;
    onCoins: (coins: number) => void;
    onLives: (lives: number) => void;
    onHurt: () => void;
    onDistance: (metres: number) => void;
    onCoin: (gem: boolean) => void;
    onJump: () => void;
    onSlide: () => void;
    onLane: () => void;
    onCrash: () => void;
    onWin: () => void;
};
export type Game = ReturnType<typeof createGame>;
/** A fresh attempt: a newly generated track, the penguin waiting at the start. */
export declare function reset(g: Game): void;
export declare function start(g: Game): void;
export declare function swipe(g: Game, direction: 'left' | 'right' | 'up' | 'down'): void;
/**
 * Drag controls, as in the other engine games: a move fires mid-stroke as soon as the finger has
 * travelled DRAG_THRESHOLD points (no waiting for release), one move per stroke.
 */
export declare function steer(g: Game, phase: 'start' | 'move' | 'end', x: number, y: number): void;
/** The run's own per-frame work; the engine steps the world after (finish steps it at once). */
export declare function tick(g: Game, dt: number): void;
export declare function setLayout(g: Game, width: number, height: number): void;
/** Day or night: rebuilds the tiles in view with the new lighting tint (the run carries on). */
export declare function setTheme(g: Game, theme: GameTheme): void;
export {};
//# sourceMappingURL=PenguinRunGame.d.ts.map