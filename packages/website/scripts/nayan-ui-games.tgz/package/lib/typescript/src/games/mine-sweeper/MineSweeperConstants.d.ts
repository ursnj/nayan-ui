import type { TiltView } from '../shared/EngineTilt';
export type Board = {
    rows: number;
    cols: number;
    mines: number;
};
/** 9 x 10 on a phone, 12 x 14 on a tablet (as the original game sized it), with 5 mines on either. */
export declare const boardFor: (tablet: boolean) => Board;
export declare const TIME_LIMIT = 180;
export declare const POINTS_PER_REVEAL = 100;
export declare const POINTS_PER_FLAG = 50;
export declare const WIN_BONUS = 5000;
export declare const FLAG_HOLD = 0.3;
export declare const TAP_SLOP = 10;
export declare const TAP_MAX = 0.5;
export declare const GAME_OVER_DELAY = 0.4;
export declare const REVEAL_STEP = 0.025;
export declare const NUMBER_COLORS: string[];
export declare const COLORS: {
    readonly HIDDEN: "#3D7A4E";
    readonly HIDDEN_ALT: "#5DA86E";
    readonly REVEALED: "#F0E6D0";
    readonly REVEALED_ALT: "#E5DABE";
    readonly MINE: "#E74C3C";
    readonly CLASSIC_BOARD: "rgba(255, 255, 255, 0.30)";
    readonly CLASSIC_GRID: "rgba(255, 255, 255, 0.10)";
};
/** The camera leans back from straight down, so the raised tiles, flags and mines stand up. */
export declare const TILT = 0.34;
/** Lit from the upper left; surfaces facing up off the board (+z) keep their exact color. */
export declare const LIGHT: import("@nayan-ui/engine").Light;
export declare const SPACING = 3;
export type Layout = TiltView & Board & {
    cell: number;
    pitch: number;
    gridWidth: number;
    gridHeight: number;
    boardWidth: number;
    boardHeight: number;
};
/** Whole-point cells as wide as the game area allows (as the original board), smaller if the screen is short. */
export declare function getLayout(width: number, height: number, offset: number, b: Board): Layout;
/** A cell's centre on the board (row 0 along the top), in world units. */
export declare function cellCentre(l: Layout, row: number, col: number): [number, number];
/** The cell a board point is on (not in the gaps between cells), or null. */
export declare function cellAt(l: Layout, x: number, y: number): [number, number] | null;
//# sourceMappingURL=MineSweeperConstants.d.ts.map