import { type Camera, type Color, type Entity, type Vec3, type World } from '@nayan-ui/engine';
import type { GameTheme } from '../../services/ThemeService';
import { type Layout } from './ColorSwitchConstants';
export type Scene = {
    syncedRings?: object;
    syncedStars?: object;
    ringCount?: number;
    starCount?: number;
    backdrop: Entity;
    ball: Entity;
    halo: Entity;
    rings: Map<string, Entity>;
    stars: Map<string, Entity>;
};
/** A field point (y down) in the world. */
export declare const toWorld: (l: Layout, x: number, y: number, z?: number) => Vec3;
export declare const colorOf: (i: number) => Color;
export declare function buildScene(world: World, l: Layout, theme: GameTheme): Scene;
export declare function removeScene(world: World, s: Scene): void;
export declare function setSceneTheme(world: World, s: Scene, theme: GameTheme): void;
/** Frames the field with the rules' camera (its top edge's field y), the backdrop kept fixed on screen. */
export declare function frame(world: World, l: Layout, s: Scene, camera: Camera, cameraY: number): void;
/** Keeps the rings and stars in step with the rules' lists: new ones appear, gone ones go. */
export declare function syncField(world: World, l: Layout, s: Scene, rings: {
    id: string;
    y: number;
}[], stars: {
    id: string;
    y: number;
    colorIndex: number;
}[]): void;
/** A ring turned to `rotation` (radians, clockwise on screen). */
export declare function turnRing(world: World, s: Scene, id: string, rotation: number): void;
export declare function placeBall(world: World, l: Layout, s: Scene, y: number): void;
/** A little squash on every hop. */
export declare function hop(world: World, l: Layout, s: Scene): void;
/** A star caught: the ball takes its colour with a pop, and a halo of it bursts out and fades. */
export declare function recolor(world: World, l: Layout, s: Scene, colorIndex: number, y: number, starId: string | null): void;
/** A crash: the ball bursts into its colour and fades where it was caught. */
/** The ball's crash, as Block Blast's cleared blocks go: it swells, flashes white and shrinks away in a burst of its colour. */
export declare function shatter(world: World, l: Layout, s: Scene, y: number, colorIndex: number): void;
/** Back to a whole ball of a colour (a new game or the preview). */
export declare function resetBall(world: World, l: Layout, s: Scene, colorIndex: number): void;
//# sourceMappingURL=ColorSwitchScene.d.ts.map