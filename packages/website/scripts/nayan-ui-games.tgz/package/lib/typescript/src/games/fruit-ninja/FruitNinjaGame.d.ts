import { type Camera, type Entity, World } from '@nayan-ui/engine';
import type { GameTheme } from '../../services/ThemeService';
import type { Fruit, FruitKind } from '../shared/EngineFruits';
import type { GamePhase as Phase } from '../shared/useEngineGame';
import { type Layout } from './FruitNinjaConstants';
import { type ItemKind, type Models, type Trail } from './FruitNinjaScene';
import { type View3D } from './FruitNinjaWorld';
/** A thrown item: its box's top-left (field points across, screen points down) and its velocity per frame. */
type Item = {
    what: ItemKind;
    x: number;
    y: number;
    vx: number;
    vy: number;
    root: Entity;
};
export declare function createGame(theme: GameTheme): {
    world: World;
    camera: Camera;
    theme: GameTheme;
    layout: Layout | null;
    view: View3D | null;
    /** Everything in the world around the play area (sky, hills, trees, ...). */
    scenery: Entity[];
    models: Models | null;
    trail: Trail | null;
    phase: Phase;
    /** Score, lives and the countdown live in the engine (Rust), advanced by world.update. */
    readonly score: number;
    readonly lives: number;
    readonly timeLeft: number;
    won: boolean;
    /** Game clock, seconds: drives the waves and the blade's window (they pause with the frame loop). */
    time: number;
    items: Item[];
    /** The fruit built so far (whole and halves): only these are thrown, so a throw or a cut never builds a mesh. */
    kinds: FruitKind[];
    /** The blade's recent touch points (screen x, y and the game time, oldest first), in fixed buffers. */
    bladeX: Float64Array<ArrayBuffer>;
    bladeY: Float64Array<ArrayBuffer>;
    bladeT: Float64Array<ArrayBuffer>;
    bladeLen: number;
    /** A finger is down: moves extend the stroke (after it lifts, the stroke only cuts for BLADE_WINDOW). */
    touching: boolean;
    /** The trail needs drawing: touches mark it, the next tick draws it once. */
    trailDirty: boolean;
    onPhase: (_p: Phase) => void;
    onTouch: () => void;
    onSlice: () => void;
    onBomb: () => void;
    onWin: () => void;
    onLose: () => void;
};
export type Game = ReturnType<typeof createGame>;
/** The fruit models are ready (built once per app, after the screen has opened). */
export declare function setModels(g: Game, fruits: Record<FruitKind, Fruit>): void;
/** A fruit is built (whole and halves) and can be thrown from now on. */
export declare function addFruit(g: Game, kind: FruitKind): void;
/** Lays the scene out for the view (first layout, header height, rotation). Items in the air are cleared. */
export declare function setLayout(g: Game, l: Layout): void;
/** A new theme: day or night outside (the screen swaps the light); the run carries on. */
export declare function setTheme(g: Game, theme: GameTheme): void;
export declare function start(g: Game): void;
/** A fresh run (Stop, Play Again). The world, and the GPU view drawing it, are kept. */
export declare function reset(g: Game): void;
export declare function dispose(g: Game): void;
/** The thrown items and the blade trail; the engine steps the world after. */
export declare function tick(g: Game, dt: number): void;
/** Finger down: the blade starts here. */
export declare function touchStart(g: Game, x: number, y: number): void;
export declare function touchMove(g: Game, x: number, y: number): void;
/** Finger up: the trail fades; the stroke can still cut for its last few milliseconds. */
export declare function touchEnd(g: Game): void;
export {};
//# sourceMappingURL=FruitNinjaGame.d.ts.map