import type { Camera, Entity, World } from '@nayan-ui/engine';
export type TiltView = {
    width: number;
    height: number;
    centerY: number;
    tilt: number;
};
/** Where a world point appears in the view. */
export declare function project(v: TiltView, x: number, y: number, z?: number): [number, number];
/** The world point at height `z` under a view point (a finger on the board). */
export declare function unproject(v: TiltView, sx: number, sy: number, z?: number): [number, number];
/** Points the camera so the board lands where the view puts it. */
export declare function aimTilted(camera: Camera, v: TiltView): void;
/**
 * Lays a game backdrop (shared/EngineBackdrop, drawn from its top-left) flat `depth` below the board,
 * stretched so it fills the view from its top-left as the original screens drew it. Lying flat, it faces
 * up (+z) like the board, so a front light keeps its exact colors.
 */
export declare function placeTiltedBackdrop(world: World, backdrop: Entity, v: TiltView, depth: number): void;
//# sourceMappingURL=EngineTilt.d.ts.map