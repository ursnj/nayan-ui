import type { TiltView } from '../shared/EngineTilt';
export declare const TIME_LIMIT: number;
export declare const LOW_TIME = 60;
export declare const FLASH_STEP = 0.028;
export declare const TAP_SLOP = 12;
export declare const COLORS: {
    readonly CELL: "#ffffff";
    readonly GIVEN: "#E8EAF6";
    readonly SELECTED: "#BBDEFB";
    readonly SAME_NUMBER: "#E3F2FD";
    readonly PEER: "#F3E5F5";
    readonly ERROR: "#FFCDD2";
    readonly TEXT_GIVEN: "#1a237e";
    readonly TEXT_PLACED: "#1565C0";
    readonly TEXT_ERROR: "#D32F2F";
    readonly LINES: "#1a237e";
    readonly FRAME: "#5c4033";
    readonly WELL: "#3a2518";
    readonly KEY: "#e8ddd0";
    readonly KEY_TEXT: "#3e2723";
    readonly KEY_REMAINING: "#8d6e63";
    readonly KEY_DISABLED: "#bdb5ad";
    readonly KEY_DISABLED_TEXT: "#9e9e9e";
};
/** The camera looks straight down at the board. */
export declare const TILT = 0;
/** Evenly lit, straight from the camera and all ambient: every face keeps its exact color, with no shading anywhere. */
export declare const LIGHT: import("@nayan-ui/engine").Light;
export declare const CELL_HEIGHT = 0.12;
export declare const KEY_HEIGHT = 0.3;
export declare const SPACING = 1.5;
export declare const BORDER = 3.5;
export type Layout = TiltView & {
    cell: number;
    /** The grid's side (cells, lines and borders), the board's (with its rim), where the board's centre is (world y). */
    grid: number;
    board: number;
    boardY: number;
    /** The number keys: their width, height, pitch and the row's centre (world y). */
    key: number;
    keyH: number;
    keyPitch: number;
    keysY: number;
};
/** Cells as big as the width allows (as the original grid), smaller if the screen is short; the keys spread under the board. */
export declare function getLayout(width: number, height: number, offset: number): Layout;
/** A cell's centre, in world units. */
export declare function cellCentre(l: Layout, row: number, col: number): [number, number];
/** A number key's centre (n = 1..9), in world units. */
export declare const keyCentre: (l: Layout, n: number) => [number, number];
/** The cell a board point is on (a line between counts as the nearer cell), or null off the grid. */
export declare function cellAt(l: Layout, x: number, y: number): [number, number] | null;
/** The number key a point is on, or 0. */
export declare function keyAt(l: Layout, x: number, y: number): number;
//# sourceMappingURL=SudokuConstants.d.ts.map