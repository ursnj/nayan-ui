import { type Model } from '@nayan-ui/engine';
export declare function unitMeshes(): readonly [Model, Model];
//# sourceMappingURL=MobControlMeshes.d.ts.map