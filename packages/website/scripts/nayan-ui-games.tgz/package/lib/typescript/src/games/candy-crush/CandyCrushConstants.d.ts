export declare const GRID_SIZE = 7;
export declare const CANDY_TYPES = 4;
export declare const MIN_MATCH = 3;
/** A run this long leaves a color bomb: swap it with any candy to clear every candy of that color (two bombs clear the board). */
export declare const BOMB_MATCH = 5;
/** A color bomb's type: it has no color, so it never matches. */
export declare const BOMB = -1;
export declare const BOMB_MULTIPLIER = 2;
export declare const ZAP_TIME = 0.25;
export declare const POINTS_PER_CANDY = 50;
export declare const COMBO_MULTIPLIER = 1.25;
export declare const TIME_LIMIT = 300;
export declare const WARNING_TIMES: readonly [30, 10];
export declare const CANDY_COLORS: readonly ["#EF2D36", "#2DC84E", "#3B9FFF", "#FFD020", "#B44CFF", "#FF8820"];
export declare const SWAP_TIME = 0.2;
export declare const MATCH_TIME = 0.42;
export declare const CLEAR_RIPPLE = 0.025;
export declare const FALL_TIME = 0.4;
export declare const FALL_SPRING: {
    damping: number;
    stiffness: number;
    mass: number;
};
export declare const LIFT_SPRING: {
    damping: number;
    stiffness: number;
};
export declare const RETURN_SPRING: {
    damping: number;
    stiffness: number;
};
export declare const LIFT_SCALE = 1.1;
export declare const NUDGE_TIME = 0.09;
export declare const NUDGE_SPRING: {
    damping: number;
    stiffness: number;
};
export declare const NUDGE_DISTANCE = 0.28;
export declare const INTRO_COL_STAGGER = 0.028;
export declare const INTRO_ROW_STAGGER = 0.022;
export declare const LIGHT: import("nayan-ui").Light;
export declare const CANDY_SHINE = 0.55;
export declare const CLASSIC_BOARD = "rgba(255, 255, 255, 0.13)";
export declare const CLASSIC_BORDER = "rgba(255, 255, 255, 0.25)";
export declare const CLASSIC_CELL = "rgba(255, 255, 255, 0.10)";
export declare const CLASSIC_RADIUS = 16;
export declare const THEMED_RADIUS = 8;
export declare const CELL_GAP = 3;
export type Layout = {
    /** The GameView's size. */
    width: number;
    height: number;
    boardLeft: number;
    boardTop: number;
    /** The board's side, padding included. */
    boardSize: number;
    cell: number;
    /** From one cell's top-left to the next. */
    step: number;
    /** A drag this far starts a swap. */
    swipeThreshold: number;
};
/** The board as wide as the game area (360 phones / 500 tablets), centred in the space below the header. */
export declare function getLayout(width: number, height: number, offset: number): Layout;
/** Centre of cell (row, col), in view points. `row` may be negative: above the board. */
export declare const cellCenter: (l: Layout, row: number, col: number) => [number, number];
//# sourceMappingURL=CandyCrushConstants.d.ts.map