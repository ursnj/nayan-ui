import { type Entity, type World } from '@nayan-ui/engine';
import type { GameTheme } from '../../services/ThemeService';
import { type Layout } from './ReversiConstants';
import type { Board, Player } from './ReversiRules';
export type Scene = {
    backdrop: Entity;
    /** The felt, grid and star points (the same in every theme). */
    felt: Entity[];
    discs: (Entity | null)[];
    hints: Entity[];
    last: Entity;
};
export declare function buildScene(world: World, l: Layout, theme: GameTheme, board: Board, hints: number[], last: number): Scene;
export declare function removeScene(world: World, s: Scene): void;
export declare function setSceneTheme(world: World, s: Scene, theme: GameTheme): void;
/** A disc set down on a cell: it drops on and settles (or is just there). */
export declare function placeDisc(world: World, l: Layout, s: Scene, i: number, p: Player, animate?: boolean): void;
/** Captured discs turn over to `p`, a ring at a time outward from the placed disc at `from`. */
export declare function flipDiscs(world: World, l: Layout, s: Scene, from: number, flips: number[], p: Player): void;
/** A ring on every legal move. */
export declare function showHints(world: World, l: Layout, s: Scene, hints: number[]): void;
/** The gold outline on the last move (-1: none). */
export declare function showLast(world: World, l: Layout, s: Scene, last: number): void;
/** A tap on a cell that isn't a legal move: the cell's disc (if any) shrugs. */
export declare function nudge(world: World, l: Layout, s: Scene, i: number): void;
/** You won: your discs hop in a wave and confetti bursts over the board. */
export declare function celebrate(world: World, l: Layout, s: Scene, board: Board): void;
//# sourceMappingURL=ReversiScene.d.ts.map