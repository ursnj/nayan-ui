import { type Camera, type Entity, World } from '@nayan-ui/engine';
import type { GameTheme } from '../../services/ThemeService';
import type { GamePhase as Phase } from '../shared/useEngineGame';
import { type Layout } from './ConnectEmAllConstants';
import { type Board, type Segment, type Trail } from './ConnectEmAllScene';
type Dot = {
    colorIndex: number;
    entity: Entity | null;
    glow: Entity | null;
};
export declare function createGame(theme: GameTheme): {
    world: World;
    camera: Camera;
    theme: GameTheme;
    layout: Layout | null;
    board: Board | null;
    phase: Phase;
    /** Score and the countdown live in the engine (Rust), advanced by world.update. */
    readonly score: number;
    readonly timeLeft: number;
    won: boolean;
    /** Row-major, `GRID_SIZE` x `GRID_SIZE`. */
    dots: Dot[];
    /** Dot indices, in the order they were joined. */
    chain: number[];
    touching: boolean;
    lastIndex: number;
    finger: [number, number];
    segments: Segment[];
    trail: Trail | null;
    /** The next board to appear rains in. */
    intro: boolean;
    /** Game seconds the current intro has been playing (-1 until its board spawns). */
    introAge: number;
    onPhase: (_p: Phase) => void;
    onConnect: () => void;
    onClear: () => void;
};
export type Game = ReturnType<typeof createGame>;
/** Lays the scene out for the view (first layout, header height, rotation): rebuilt from the run's state. */
export declare function setLayout(g: Game, l: Layout): void;
/** A new theme: the background and board are rebuilt; the dots and the run carry on. */
export declare function setTheme(g: Game, theme: GameTheme): void;
export declare function start(g: Game): void;
/** A fresh board and timer (Stop, Play Again). The world, and the GPU view drawing it, are kept. */
export declare function reset(g: Game): void;
/** The intro's clock; the engine steps the world after. */
export declare function tick(g: Game, dt: number): void;
export declare function touchStart(g: Game, x: number, y: number): void;
export declare function touchMove(g: Game, x: number, y: number): void;
export declare function touchEnd(g: Game): void;
export {};
//# sourceMappingURL=ConnectEmAllGame.d.ts.map