import { type Color, type Entity, type World } from '@nayan-ui/engine';
import type { GameTheme } from '../../services/ThemeService';
import { type Layout } from './PipeConnectConstants';
import type { PipeCell } from './PipeConnectRules';
/** A quarter turn clockwise per rotation step, as seen on the board. */
export declare const pieceRotation: (rotation: number) => import("@nayan-ui/engine").MutableQuat;
export type Scene = {
    backdrop: Entity;
    panel: Entity;
    tiles: Entity[];
    pieces: (Entity | null)[];
};
/** A piece's paint: the source green, the sink orange, other pipes steel-blue dry and water-blue wet. */
export declare const pieceColor: (cell: PipeCell, wet: boolean) => Color;
export declare function buildScene(world: World, l: Layout, theme: GameTheme, grid: PipeCell[][], wet: ReadonlySet<string>): Scene;
export declare function removeScene(world: World, s: Scene): void;
export declare function setSceneTheme(world: World, l: Layout, s: Scene, theme: GameTheme): void;
/** A pipe swings a quarter turn clockwise into its new rotation, overshooting a touch. */
export declare function turnPiece(world: World, e: Entity, rotation: number): void;
/**
 * The water's reach changed: pipes it now reaches fill one after another out from the source (`order`
 * is each one's place along the path, `base` the first new one's), and pipes it left drain at once.
 */
export declare function flow(world: World, l: Layout, e: Entity, cell: PipeCell, wet: boolean, order: number, base: number): void;
/** Solved: every pipe the water runs through pulses, out from the source. */
export declare function winPulse(world: World, l: Layout, e: Entity, order: number): void;
/** A splash of water at the sink when it fills. */
export declare function splash(world: World, l: Layout, row: number, col: number): void;
//# sourceMappingURL=PipeConnectScene.d.ts.map