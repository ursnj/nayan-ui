import { type Entity, type Model, type World } from 'nayan-ui';
import type { GameTheme } from '../../services/ThemeService';
/** Any front light works: these flat meshes face the camera, which it lights at exactly 1. */
export declare const BACKDROP_LIGHT: import("nayan-ui").Light;
/** The background mesh in pattern space: x right, y up from the window's top-left (y runs to -height). */
export declare function backdropMesh(theme: GameTheme): Model;
/**
 * A modal card's background: the window pattern's top-left `width` x `height` (its gradients and
 * shapes, without the grid lines), cut to a rounded rectangle of corner `radius`. Same space as
 * `backdropMesh` (from the top-left, y up).
 */
export declare function cardBackdropMesh(theme: GameTheme, width: number, height: number, radius: number): Model;
/**
 * The background behind a centred, one-unit-per-point scene `width` x `height` (the view's size), at
 * depth `z`: the pattern starts at the view's top-left, as the original screens draw it.
 */
export declare function spawnBackdrop(world: World, width: number, height: number, z: number, theme: GameTheme): Entity;
/** Repaints a backdrop for a new theme. */
export declare function setBackdropTheme(world: World, backdrop: Entity, theme: GameTheme): void;
//# sourceMappingURL=EngineBackdrop.d.ts.map