import { type Camera, type Entity, type World } from '@nayan-ui/engine';
import type { GameTheme } from '../../services/ThemeService';
import { type Layout } from './Snake3DConstants';
import { type Direction, type Food } from './Snake3DRules';
export type Scene = {
    backdrop: Entity;
    board: Entity[];
    /** The head (eyes and tongue attached), the beads behind it, and the joints between them. */
    head: Entity;
    tongue: Entity;
    beads: Entity[];
    joints: Entity[];
    food: Entity | null;
    foodId: number;
};
export declare function buildScene(world: World, l: Layout, theme: GameTheme): Scene;
export declare function removeScene(world: World, s: Scene): void;
export declare function setSceneTheme(world: World, l: Layout, s: Scene, theme: GameTheme): void;
/**
 * Every bead follows the head's rounded turns between cells, `t` of the way (0..1).
 * `prev` and `cur` are the cells (flattened x, y), head first.
 */
export declare function drawSnake(world: World, l: Layout, s: Scene, prev: number[], cur: number[], t: number): void;
/** The head turns to face the way it's heading. */
export declare function faceHead(world: World, s: Scene, d: Direction): void;
/** The tongue flicks out now and then while it's moving. */
export declare function flick(world: World, s: Scene): void;
/** A fresh snake's look (a new game or the preview). */
export declare function resetSnake(world: World, l: Layout, s: Scene): void;
/** Food eaten: the head gulps and the food bursts. */
export declare function gulp(world: World, l: Layout, s: Scene, food: Food): void;
/** A crash: the snake flushes red, a jolt runs through the board. */
export declare function crash(world: World, l: Layout, s: Scene, camera: Camera): void;
/** The food on the board (an apple, or a spinning gold star for a bonus), or none. */
export declare function placeFood(world: World, l: Layout, s: Scene, food: Food | null): void;
//# sourceMappingURL=Snake3DScene.d.ts.map