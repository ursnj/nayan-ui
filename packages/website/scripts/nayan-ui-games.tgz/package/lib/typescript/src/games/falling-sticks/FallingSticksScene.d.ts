import { type Entity, type TransformBatch, type World } from '@nayan-ui/engine';
import type { GameTheme } from '../../services/ThemeService';
import { type View3D } from '../shared/EngineMeadow';
import { type Layout } from './FallingSticksConstants';
import type { Stick } from './FallingSticksRules';
export type Scene = {
    view: View3D;
    scenery: Entity[];
    sticks: Entity[];
    trail: Entity[];
    tumble: number[];
};
export declare function buildScene(world: World, l: Layout, theme: GameTheme): Scene;
export declare function removeScene(world: World, s: Scene): void;
export declare function placeStick(world: World, _l: Layout, s: Scene, i: number, st: Stick, spinning?: boolean, updates?: TransformBatch): void;
/** Reuse a pooled baton, including its color and native animation state. */
export declare function showStick(world: World, l: Layout, s: Scene, i: number, st: Stick): void;
export declare function hideStick(world: World, s: Scene, i: number): void;
/** A soft landing bounce followed by a tumble into the grass. */
export declare function landStick(world: World, l: Layout, s: Scene, i: number, st: Stick): void;
/** Flash and pop the full baton, with a ring, flying chips and sparks along its length. */
export declare function popStick(world: World, l: Layout, s: Scene, i: number, st: Stick): void;
/** Connected tapered segments stay continuous even when touch events are far apart. */
export declare function drawTrail(world: World, _l: Layout, s: Scene, points: number[]): void;
export declare function fadeTrail(world: World, s: Scene): void;
export declare function celebrate(world: World, l: Layout, s: Scene): void;
//# sourceMappingURL=FallingSticksScene.d.ts.map