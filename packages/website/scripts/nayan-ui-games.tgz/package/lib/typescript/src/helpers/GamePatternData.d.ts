export declare const PATTERN_RAINBOW: readonly ["#E91E63", "#F44336", "#FF5722", "#FF9800", "#FFC107", "#8E24AA", "#CDDC39", "#8BC34A", "#4CAF50", "#009688", "#00BCD4", "#03A9F4", "#2196F3", "#3F51B5", "#9C27B0"];
/** A linear gradient across the whole pattern: evenly spaced CSS color stops from `start` to `end`. */
export type PatternGradient = {
    start: [number, number];
    end: [number, number];
    colors: readonly string[];
};
export type PatternShape = {
    kind: 'circle';
    cx: number;
    cy: number;
    r: number;
    color: string;
} | {
    kind: 'rrect';
    x: number;
    y: number;
    w: number;
    h: number;
    r: number;
    color: string;
} | {
    kind: 'diamond';
    cx: number;
    cy: number;
    size: number;
    color: string;
};
export type PatternLine = {
    x: number;
    y: number;
    w: number;
    h: number;
};
export type GamePattern = {
    width: number;
    height: number;
    gradients: PatternGradient[];
    /** Floating shapes, then the large decorations, in drawing order. */
    shapes: PatternShape[];
    /** The faint grid, drawn last in `GRID_COLOR`. */
    grid: PatternLine[];
};
export declare const PATTERN_GRID_COLOR = "rgba(0, 0, 0, 0.02)";
/** The pattern for a window `width` x `height` points. */
export declare function gamePattern(width: number, height: number): GamePattern;
//# sourceMappingURL=GamePatternData.d.ts.map