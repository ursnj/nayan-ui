import { type Entity, type World } from '@nayan-ui/engine';
import { type Layout } from './CrossyRoadConstants';
import type { CrossyMeshes } from './CrossyRoadMeshes';
import type { Vehicle } from './CrossyRoadRules';
/** A lane's centre (world y) and its surface height. */
export declare const laneY: (l: Layout, row: number) => number;
export declare const laneTop: (row: number) => number;
/** A view x on the board as world x. */
export declare const worldX: (l: Layout, x: number) => number;
export type Scene = {
    /** Everything hangs off this root, scaled to the world. */
    root: Entity;
    ground: Entity[];
    vehicles: Map<number, Entity>;
    player: {
        root: Entity;
        body: Entity;
        arms: [Entity, Entity];
        legs: [Entity, Entity];
        feet: [Entity, Entity];
    };
    night: boolean;
};
/** Keeps every vehicle where the rules have it. */
export declare function placeVehicles(world: World, l: Layout, s: Scene, vs: Vehicle[]): void;
/** The pedestrian on a lane and column, at once (a new board). */
export declare function placePlayer(world: World, l: Layout, s: Scene, row: number, col: number): void;
/** Grounded translation with alternating strides. Ankles counter-rotate so shoes stay level. */
export declare function hop(world: World, l: Layout, s: Scene, from: [number, number], to: [number, number], facing: 'up' | 'down' | 'left' | 'right'): void;
/** Run over: a non-graphic stumble and a small puff of road dust. */
export declare function stumble(world: World, l: Layout, s: Scene, row: number, col: number): void;
/** Made it across: a wave and confetti, standing on the finish lane. */
export declare function celebrate(world: World, l: Layout, s: Scene, row: number, col: number): void;
export declare function buildScene(world: World, l: Layout, a: CrossyMeshes, night: boolean, vs: Vehicle[]): Scene;
/** Replaces the traffic with a new board's (its vehicles are new ones, so recolored and resized). */
export declare function setTraffic(world: World, l: Layout, a: CrossyMeshes, s: Scene, vs: Vehicle[]): void;
/** Everything goes with the root. */
export declare function removeScene(world: World, s: Scene): void;
//# sourceMappingURL=CrossyRoadScene.d.ts.map