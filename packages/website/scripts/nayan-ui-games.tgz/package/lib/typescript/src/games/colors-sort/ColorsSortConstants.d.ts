import type { TiltView } from '../shared/EngineTilt';
export declare const COLORS: readonly ["#FF4444", "#32CD32", "#4169E1", "#FFD700", "#00CED1"];
export declare const PIECES_PER_COLOR = 4;
export declare const TUBES = 6;
export declare const CAPACITY: number;
export declare const TIME_LIMIT = 120;
export declare const SCORE_BASE = 100;
export declare const LIFT_TIME = 0.18;
export declare const MOVE_TIME = 0.36;
export declare const SHAKE_TIME = 0.3;
/** The camera looks down a little from in front, so the tubes' mouths and the pieces' tops show. */
export declare const TILT = -0.3;
/** Lit from the upper left; surfaces facing the camera (+z) keep their exact color. */
export declare const LIGHT: import("@nayan-ui/engine").Light;
export type Layout = TiltView & {
    /** Every size below is already scaled to fit. */
    tubeRadius: number;
    tubeHeight: number;
    pieceRadius: number;
    pieceHeight: number;
    pieceGap: number;
    padBottom: number;
    lift: number;
    shelfHeight: number;
    /** Each tube's base centre in the world (x right, y up, z toward the camera). */
    tubes: [number, number][];
    /** The rows' shelves: their top-face y and width. */
    shelves: {
        y: number;
        width: number;
    }[];
};
/** Two rows of three tubes on shelves, as big as the original grid (smaller if the screen is short), centred under the scoreboard. */
export declare function getLayout(width: number, height: number, offset: number): Layout;
/** Where the piece `slot` places up from a tube's bottom sits (its base), in world y. */
export declare const slotY: (l: Layout, tube: number, slot: number) => number;
/** Where a picked-up piece hovers: just out of its tube's mouth. */
export declare const hoverY: (l: Layout, tube: number) => number;
//# sourceMappingURL=ColorsSortConstants.d.ts.map