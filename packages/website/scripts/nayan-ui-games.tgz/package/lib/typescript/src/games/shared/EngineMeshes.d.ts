import { type Geometry, type Model, type ShapeOptions } from 'nayan-ui';
import { cacheGameAsset, peekGameAsset } from './EngineMeshCache';
export declare function createGameMesh(geometry: Geometry, options?: ShapeOptions): Model;
/**
 * One module's mesh cache: each recipe is built once per install (kept in memory for the session and
 * on disk across launches), so meshes are never rebuilt per spawn, reset or theme change.
 *
 * ```ts
 * const cached = meshCache('stack-tower/StackTowerScene:');
 * const blockMesh = (w: number) => cached(`block:${w}`, () => createGameMesh(blockGeometry(w)));
 * ```
 */
export declare function meshCache(prefix: string): <T = Model>(key: string, build: () => T) => T;
export { cacheGameAsset, peekGameAsset };
//# sourceMappingURL=EngineMeshes.d.ts.map