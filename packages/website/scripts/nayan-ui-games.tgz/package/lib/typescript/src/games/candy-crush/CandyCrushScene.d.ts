import { type Entity, type Vec3, type World } from '@nayan-ui/engine';
import type { GameTheme } from '../../services/ThemeService';
import { type Layout } from './CandyCrushConstants';
/** A view point (from the top-left) at depth `z`, in world space. */
export declare const toWorld: (l: Layout, x: number, y: number, z?: number) => Vec3;
export declare const dragZ: (l: Layout) => number;
/** Where the candy at (row, col) rests (row may be negative: above the board). */
export declare const candyPosition: (l: Layout, row: number, col: number, z?: number) => Vec3;
export type Scenery = {
    backdrop: Entity;
    parts: Entity[];
};
export declare function buildScenery(world: World, l: Layout, theme: GameTheme): Scenery;
export declare function removeScenery(world: World, s: Scenery): void;
/** A new theme: the background is repainted and the board rebuilt in its colors. */
export declare function setSceneryTheme(world: World, l: Layout, s: Scenery, theme: GameTheme): void;
export declare const candyColor: (type: number) => readonly [number, number, number, number];
/**
 * A candy at view-world `position`, `scale` of full size. A color bomb is a block blending all the
 * colors, gently pulsing so it stands out.
 */
export declare function spawnCandy(world: World, l: Layout, type: number, position: Vec3, scale: number): Entity;
/** A color bomb just made: it grows in where its match was, with a little overshoot. */
export declare function popInBomb(world: World, root: Entity): void;
/** A thin zap from a color bomb to a block it clears, fading. */
export declare function zap(world: World, l: Layout, from: Vec3, to: Vec3, type: number, delay: number): void;
/** A matched candy pops as Block Blast's blocks do (shared/EngineBlasts): it swells, flashes white, settles and shrinks away, bursting in its color over a fading glow. Resolves when it's gone. */
export declare function crushCandy(world: World, l: Layout, root: Entity, type: number, at: Vec3, duration: number, delay?: number): Promise<void>;
//# sourceMappingURL=CandyCrushScene.d.ts.map