import { type Model } from '@nayan-ui/engine';
/** The one-piece body: torso, head and every face detail in a single mesh. */
export declare function bodyMesh(): Model;
/** A paddle flipper hanging from its shoulder (origin): glossy navy outside, cream inside; `side` -1 is the left. */
export declare function flipperMesh(side: -1 | 1): Model;
/** A chunky orange foot from its heel (origin) forward: a rounded pad and three plump toes. */
export declare function footMesh(): Model;
/** Reusable assets; the game loader advances one builder per frame. */
export declare function warmAssets(): Iterable<() => unknown>;
//# sourceMappingURL=PenguinMeshes.d.ts.map