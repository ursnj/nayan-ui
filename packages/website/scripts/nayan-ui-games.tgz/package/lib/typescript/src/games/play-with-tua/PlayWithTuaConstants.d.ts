import type { Light } from '@nayan-ui/engine';
import type { GAME_SOUNDS } from '../../services/SoundsService';
/** Clip IDs are also the names embedded in play-with-tua.glb for other glTF viewers. */
export declare const PLAY_WITH_TUA_ANIMATIONS: {
    readonly standing: {
        readonly duration: 9.6;
        readonly loop: true;
    };
    readonly walking: {
        readonly duration: 3.75;
        readonly loop: true;
    };
    readonly running: {
        readonly duration: 3;
        readonly loop: true;
    };
    readonly jumping: {
        readonly duration: 2.5;
        readonly loop: false;
    };
    readonly waving: {
        readonly duration: 2.7;
        readonly loop: false;
    };
    readonly winking: {
        readonly duration: 1.65;
        readonly loop: false;
    };
    readonly dancing: {
        readonly duration: 5.25;
        readonly loop: true;
    };
    readonly laughing: {
        readonly duration: 3.6;
        readonly loop: true;
    };
    readonly fighting: {
        readonly duration: 7.8;
        readonly loop: false;
    };
    readonly falling: {
        readonly duration: 4.25;
        readonly loop: false;
    };
};
export type PlayWithTuaAnimation = keyof typeof PLAY_WITH_TUA_ANIMATIONS;
export interface ActionSoundCue {
    at: number;
    sound: keyof typeof GAME_SOUNDS.PLAY_WITH_TUA;
    once?: boolean;
}
/** Contact times sampled from the shipped GLB: no JS skinning or timers during playback. */
export declare const PLAY_WITH_TUA_SOUND_CUES: Readonly<Record<PlayWithTuaAnimation, readonly ActionSoundCue[]>>;
/** Feet at y=0, facing +Z. Scale the spawned entity for other sizes. */
export declare const PLAY_WITH_TUA_HEIGHT = 3.2;
export declare const PLAY_WITH_TUA_MODEL_SCALE = 1.21;
export declare const PLAY_WITH_TUA_CAMERA_HEIGHT: number;
export declare const PLAY_WITH_TUA_WORLD_CAPACITY = 16;
export declare const PLAY_WITH_TUA_ACTIONS: readonly {
    id: PlayWithTuaAnimation;
    label: string;
}[];
export declare const PLAY_WITH_TUA_LIGHT: Light;
export declare const PLAY_WITH_TUA_CONTROLS_HEIGHT = 156;
//# sourceMappingURL=PlayWithTuaConstants.d.ts.map