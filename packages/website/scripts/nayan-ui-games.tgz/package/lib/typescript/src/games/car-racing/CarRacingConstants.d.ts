import { type Color, type Font, type Light, type Model, type SoundBank, type Texture, type Vec3 } from 'nayan-ui';
import { type SceneryMeshes } from './CarRacingScenery';
export declare const TRACK_LENGTH = 2000;
export declare const LIVES = 3;
export declare const POINTS_PER_CAR_PASSED = 500;
/** No traffic is spawned this close to the finish, so the line is clear to cross. */
export declare const FINISH_CLEAR = 30;
export declare const LANE_W = 3.4;
export declare const LANES: number[];
export declare const ROAD_HALF: number;
export declare const EDGE: number;
export declare const START_SPEED = 20;
export declare const CAMERA_FOV = 0.95;
export declare const LATERAL_SPEED = 9;
export declare const STEER_RESPONSE = 10.5;
export declare const STEER_WIDTH = 0.6;
export declare const TRAFFIC_SPEED = 12;
export declare const SPAWN_AHEAD = 170;
export declare const CRASH_SLOWDOWN = 0.55;
export declare const INVULNERABLE = 1.6;
export declare const SEG_LEN = 6;
export declare const SEGMENTS = 42;
export declare const RS = 0.2;
export declare const BEHIND = 8;
export declare const SKY: readonly [0.62, 0.78, 0.95];
export declare const NIGHT_SKY: readonly [0.227, 0.192, 0.376];
export declare const DAY_LIGHT: Light;
export declare const NIGHT_LIGHT: Light;
export declare const LAMP: Color;
export declare const LAMP_LIT: Color;
export declare const LINE: Color;
export declare const RAIL: Color;
export declare const PAINTS: Color[];
export declare const PLAYER_PAINT: Color;
export declare const AUTOPLAY: boolean;
export declare const getRacingSounds: () => SoundBank<"win" | "hit" | "engine" | "nitro" | "point" | "die" | "bump">;
/**
 * One car for everyone, built in code (CarMeshes): a glossy white body each entity paints its own
 * color, the windows, and untinted trim (tyres, lights).
 */
export type CarModel = {
    body: Model;
    glass: Model;
    trim: Model;
    size: Vec3;
};
export type Assets = {
    car: CarModel;
    asphalt: Texture;
    facade: Texture;
    grass: Texture;
    ads: Texture[];
    tree: Model;
    scenery: SceneryMeshes;
    font: Font;
};
export declare const getCachedAssets: () => Assets | null;
export declare function loadAssets(): Promise<Assets>;
/** Starts loading the game's textures and building its models (they're cached), so opening it is quick. */
export declare function preloadRacing(): void;
/** Decode one texture per job before the asset bundle's cached assembly. */
export declare function warmAssets(): Iterable<() => unknown>;
//# sourceMappingURL=CarRacingConstants.d.ts.map