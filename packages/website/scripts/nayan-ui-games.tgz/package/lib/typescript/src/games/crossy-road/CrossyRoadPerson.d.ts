import { type Model } from '@nayan-ui/engine';
export interface PedestrianMeshes {
    torso: Model;
    arm: Model;
    leg: Model;
    shoe: Model;
}
export declare function pedestrianMeshes(): PedestrianMeshes;
/** Reusable assets; the game loader advances one builder per frame. */
export declare function warmAssets(): Iterable<() => unknown>;
//# sourceMappingURL=CrossyRoadPerson.d.ts.map