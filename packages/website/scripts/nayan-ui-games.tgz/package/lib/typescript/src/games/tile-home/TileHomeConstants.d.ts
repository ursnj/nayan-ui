import type { FruitKind } from '../shared/EngineFruits';
export declare const BOARD_COLS = 6;
export declare const BOARD_ROWS = 7;
export declare const LAYER_COUNT = 3;
export declare const TILES_PER_TYPE = 6;
export declare const SLOT_CAPACITY = 7;
export declare const MATCH_COUNT = 3;
export declare const TIME_LIMIT = 300;
export declare const POINTS_PER_SET = 500;
/** The 12 fruits, by tile type id (the original version's order), with each one's burst color. */
export declare const TILE_TYPES: readonly {
    fruit: FruitKind;
    color: string;
}[];
/** Sets of three in a board: 24. */
export declare const TOTAL_SETS: number;
export declare const FLY_TIME = 0.25;
export declare const LIFT_AT = 0.28;
export declare const LIFT_SCALE = 1.08;
export declare const MATCH_CHECK_DELAY = 0.3;
export declare const MATCH_REMOVE_DELAY = 0.4;
export declare const MATCH_BURST_TIME = 0.55;
export declare const SHADE_TIME = 0.22;
export declare const SHIFT_SPRING: {
    stiffness: number;
    damping: number;
};
export declare const LAND_SPRING: {
    stiffness: number;
    damping: number;
};
export declare const LAND_SQUASH = 1.12;
export declare const INTRO_SPRING: {
    stiffness: number;
    damping: number;
    mass: number;
};
export declare const RIPPLE_TIME = 0.3;
export declare const LAYER_STAGGER = 0.07;
/** How dark a covered tile is: more tiles over it, darker. */
export declare const shadeFor: (blockingCount: number) => number;
export declare const LIGHT: import("nayan-ui").Light;
export declare const TILE_FACE = "#fffdf7";
export declare const TILE_THICKNESS = 0.4;
export declare const CLASSIC_BOARD = "rgba(255, 255, 255, 0.35)";
export declare const CLASSIC_TRAY = "rgba(255, 255, 255, 0.45)";
export declare const CLASSIC_TRAY_BORDER = "rgba(255, 255, 255, 0.6)";
export declare const CLASSIC_SLOT = "rgba(255, 255, 255, 0.25)";
export declare const CLASSIC_SLOT_BORDER = "rgba(255, 255, 255, 0.5)";
export type Layout = {
    /** The GameView's size. */
    width: number;
    height: number;
    boardLeft: number;
    boardTop: number;
    boardWidth: number;
    boardHeight: number;
    cell: number;
    /** A board tile's side. */
    tile: number;
    /** The fruit's size on a board tile. */
    fruit: number;
    trayLeft: number;
    trayTop: number;
    trayWidth: number;
    trayHeight: number;
    /** A tray tile's side. */
    slot: number;
};
export declare function getLayout(width: number, height: number, offset: number): Layout;
/** A board tile's top-left, in view points. */
export declare const tileOrigin: (l: Layout, col: number, row: number, layer: number) => [number, number];
/** Tray slot `index`'s top-left, in view points. */
export declare const slotOrigin: (l: Layout, index: number) => [number, number];
//# sourceMappingURL=TileHomeConstants.d.ts.map