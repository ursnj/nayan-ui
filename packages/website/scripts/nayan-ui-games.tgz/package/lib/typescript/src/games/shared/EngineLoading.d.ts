import { type Camera, type Font, World } from 'nayan-ui';
import { GAME_IDS, type GameThemeMode } from '../../services/UtilsService';
export type LoadingScene = 'forest' | 'penguin' | 'car' | 'bike' | 'ninja' | 'merger' | 'tiles' | 'tua' | 'chameleon' | 'paper' | 'crossing';
export interface LoadingColours {
    sky: string;
    horizon: string;
    ground: string;
    accent: string;
    second: string;
    text: string;
    muted: string;
}
interface Look {
    scene: LoadingScene;
    tag: string;
    message: string;
    dark: LoadingColours;
    light: LoadingColours;
}
export declare function loadingLook(gameId: GAME_IDS, mode?: GameThemeMode): Look & {
    colours: LoadingColours;
};
export declare const LOADING_LIGHT: import("nayan-ui").Light;
export declare function loadingPlacement(width: number, height: number, offset?: number): {
    scale: number;
    top: number;
    retryBounds: {
        left: number;
        top: number;
        width: number;
        height: number;
    };
};
export interface LoadingStatus {
    label: string;
    error: boolean;
    message?: string;
    retry: boolean;
    reducedMotion: boolean;
}
export declare class EngineLoading {
    private font;
    readonly world: World;
    readonly camera: Camera;
    readonly look: ReturnType<typeof loadingLook>;
    readonly clearColor: readonly [number, number, number];
    private backdrop;
    private content;
    private progress;
    private retryButton;
    private statusText;
    private messageText;
    private motions;
    private status;
    private disposed;
    private retryBox;
    constructor(gameId: GAME_IDS, mode: GameThemeMode | undefined, font: Font);
    private box;
    private disc;
    private path;
    private text;
    private motion;
    private tree;
    private fruit;
    private drawHero;
    layout(width: number, height: number, offset?: number): void;
    get retryBounds(): {
        left: number;
        top: number;
        width: number;
        height: number;
    };
    setStatus(status: LoadingStatus): void;
    update(dt: number): void;
    dispose(): void;
}
export {};
//# sourceMappingURL=EngineLoading.d.ts.map