export declare const TileHome: import("react").FC<import("../..").GameProps>;
//# sourceMappingURL=TileHome.d.ts.map