import { type Camera, World } from '@nayan-ui/engine';
import type { GameTheme } from '../../services/ThemeService';
import type { GamePhase as Phase } from '../shared/useEngineGame';
import { type Layout } from './NutsAndBoltsConstants';
import { type Bolt, type Hole, type Plank } from './NutsAndBoltsRules';
import { type Scene } from './NutsAndBoltsScene';
/** select: a bolt picked up; place: one screwed into a new hole; complete: the last plank's down. */
export type GameEvent = 'select' | 'place' | 'complete';
export declare function createGame(theme: GameTheme): {
    selected: string | null;
    score: number;
    time: number;
    won: boolean;
    onPhase: (_p: Phase) => void;
    onPlanks: (_n: number) => void;
    onEvent: (_e: GameEvent) => void;
    holes: Hole[];
    bolts: Bolt[];
    planks: Plank[];
    homes: {
        row: number;
        col: number;
    }[];
    world: World;
    camera: Camera;
    theme: GameTheme;
    layout: Layout | null;
    scene: Scene | null;
    phase: Phase;
};
export type Game = ReturnType<typeof createGame>;
/** Lays the board out for the view (first layout, header height, rotation): rebuilt from the puzzle's state. */
export declare function setLayout(g: Game, l: Layout): void;
export declare function setTheme(g: Game, theme: GameTheme): void;
/** Plays the puzzle that's showing. */
export declare function start(g: Game): void;
/** A fresh puzzle, not started (Stop, Play Again). The world, and the GPU view drawing it, are kept. */
export declare function reset(g: Game): void;
type Target = {
    row: number;
    col: number;
    holeId: string | null;
};
/**
 * What a view point is on, within half a cell, checked as the original board did: the swap holes, then the
 * empty bolt holes on the board, then the bolts on it.
 */
export declare function targetAt(g: Game, x: number, y: number): Target | null;
export declare function tap(g: Game, x: number, y: number): void;
/** The store's handleTap: pick up, put back, switch to another bolt, or move the picked-up bolt. */
export declare function choose(g: Game, t: Target): void;
export {};
//# sourceMappingURL=NutsAndBoltsGame.d.ts.map