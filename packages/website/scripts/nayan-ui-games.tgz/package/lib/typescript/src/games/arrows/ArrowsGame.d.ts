import { type Camera, type Entity, World } from '@nayan-ui/engine';
import type { GameTheme } from '../../services/ThemeService';
import type { GamePhase as Phase } from '../shared/useEngineGame';
import { Direction, type Layout } from './ArrowsConstants';
import { type ArrowView, type Flight, type Scenery } from './ArrowsScene';
/** A cell on an arrow's path. */
export interface Waypoint {
    row: number;
    col: number;
}
/** A bent arrow: the cells it runs through, tail first, and the way its head points off the board. */
export interface Arrow {
    id: number;
    waypoints: Waypoint[];
    exitDir: Direction;
}
export declare function createGame(theme: GameTheme): {
    world: World;
    camera: Camera;
    theme: GameTheme;
    color: import("@nayan-ui/engine").Color;
    layout: Layout | null;
    scenery: Scenery | null;
    phase: Phase;
    /** Score and the countdown live in the engine (Rust), advanced by world.update. */
    readonly score: number;
    readonly timeLeft: number;
    won: boolean;
    /** By id; null once flown. */
    arrows: (Arrow | null)[];
    cellToArrowId: (number | null)[];
    remaining: number;
    views: (ArrowView | null)[];
    dots: Entity[];
    flights: Flight[];
    /** The next board to appear draws itself in. */
    intro: boolean;
    /** Game seconds the current intro has been playing (-1 until its board spawns). */
    introAge: number;
    onPhase: (_p: Phase) => void;
    onRemaining: (_n: number) => void;
    onClear: () => void;
    onBlocked: () => void;
    onWin: () => void;
    onLose: () => void;
};
export type Game = ReturnType<typeof createGame>;
/** Lays the scene out for the view (first layout, header height, rotation): rebuilt from the run's state. */
export declare function setLayout(g: Game, l: Layout): void;
/** A new theme: the background is repainted and the arrows recolored; the run carries on. */
export declare function setTheme(g: Game, theme: GameTheme): void;
export declare function start(g: Game): void;
/** A new board and timer (Stop, Play Again), drawing itself in. The world and its GPU view are kept. */
export declare function reset(g: Game): void;
export declare function dispose(g: Game): void;
/** The draw-in and flying arrows; the engine steps the world after. */
export declare function tick(g: Game, dt: number): void;
/** A tap: the arrow under it flies off if its way out is clear, or shakes if it's blocked. */
export declare function tap(g: Game, x: number, y: number): void;
//# sourceMappingURL=ArrowsGame.d.ts.map