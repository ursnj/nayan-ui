import type { Camera } from '@nayan-ui/engine';
import { type Layout } from './CrossyRoadConstants';
type V3 = [number, number, number];
/** The view point of a world point, for a camera at `eye` looking along +y tilted down by the pitch. */
export declare function viewPoint(l: Layout, eye: V3, p: V3): [number, number];
/**
 * Places the camera to frame the board (world units, a tenth of view points). With the pitch fixed, a
 * board point a distance `a` ahead of the eye shows at view height n (-1 bottom .. 1 top) when
 * a = h * g(n), h the eye's height; so the near and far edges' wanted heights give h and the eye's place
 * exactly. The far constraint includes the pedestrian's head, so the scoreboard cannot hide them at
 * the goal. If the nine columns wouldn't fit across the nearest lane, the band is narrowed until they do.
 */
export declare function frameCamera(camera: Camera, l: Layout): void;
export {};
//# sourceMappingURL=CrossyRoadCamera.d.ts.map