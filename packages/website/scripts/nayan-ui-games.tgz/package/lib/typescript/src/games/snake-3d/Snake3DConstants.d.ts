import type { TiltView } from '../shared/EngineTilt';
export declare const TIME_LIMIT = 300;
/** One move every 300 ms, the original game's fixed speed. */
export declare const TICK_MS = 300;
/** A long frame counts for at most this much, so the snake never jumps two cells or fast-forwards. */
export declare const MAX_FRAME_MS = 100;
export declare const SWIPE = 15;
export declare const COLORS: {
    readonly HEAD: "#00c853";
    readonly BODY: "#00a344";
    readonly TAIL: "#008035";
    readonly BELLY: "#7CF2A8";
    readonly EYE: "#FFFFFF";
    readonly PUPIL: "#111111";
    readonly TONGUE: "#E53935";
    readonly SPECIAL: "#ffa502";
    readonly CRASH: "#ff4757";
    readonly CLASSIC_BOARD: "rgba(255, 255, 255, 0.30)";
    readonly CLASSIC_DARK: "rgba(255, 255, 255, 0.10)";
    readonly CLASSIC_RIM: "rgba(255, 255, 255, 0.55)";
};
/** The camera looks straight down at the board. */
export declare const TILT = 0;
/** Lit from the upper left; surfaces facing up off the board (+z) keep their exact color. */
export declare const LIGHT: import("@nayan-ui/engine").Light;
export type Layout = TiltView & {
    cell: number;
    size: number;
};
/** The board as wide as the screen allows (as the original board, which filled the width), smaller if the screen is short. */
export declare function getLayout(width: number, height: number, offset: number): Layout;
/** A grid point (cells, 0.5 = the middle of the first) on the board, in world units. */
export declare const gridPoint: (l: Layout, x: number, y: number) => [number, number];
//# sourceMappingURL=Snake3DConstants.d.ts.map