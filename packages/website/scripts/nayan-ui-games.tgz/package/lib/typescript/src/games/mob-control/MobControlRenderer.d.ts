import { type Model, type RenderSource, type World } from '@nayan-ui/engine';
import type { Sim } from './MobControlRules';
export declare class MobControlRenderer implements RenderSource {
    private readonly world;
    private readonly poses;
    readonly capacity: number;
    readonly matrices: Float32Array;
    readonly colors: Float32Array;
    readonly regions: Float32Array;
    readonly ranges: Uint32Array;
    count: number;
    private disposed;
    private readonly sizeStrength;
    private readonly sizeKind;
    private readonly sizes;
    constructor(world: World, poses: readonly [Model, Model]);
    sync(s: Sim, alpha: number, clock: number): void;
    setView(matrix: Float32Array, width: number, height: number): void;
    dispose(): void;
}
//# sourceMappingURL=MobControlRenderer.d.ts.map