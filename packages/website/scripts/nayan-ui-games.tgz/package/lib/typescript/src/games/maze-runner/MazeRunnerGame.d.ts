import { type Camera, type DragEvent, World } from '@nayan-ui/engine';
import type { GameTheme } from '../../services/ThemeService';
import type { GamePhase as Phase } from '../shared/useEngineGame';
import { type Layout } from './MazeRunnerConstants';
import { type Scene } from './MazeRunnerScene';
/** turn: a swipe taken; bump: rolled into a wall; win / lose: how it ended. */
export type GameEvent = 'turn' | 'bump' | 'win' | 'lose';
export declare function createGame(theme: GameTheme): {
    world: World;
    camera: Camera;
    theme: GameTheme;
    layout: Layout | null;
    scene: Scene | null;
    /** ready: the maze waits; playing: rolling; over: won or lost (the game-over card comes up a beat later, through `onCard`). */
    phase: Phase;
    open: number[];
    ball: import("./MazeRunnerRules").Roll;
    /** Where the ball was last drawn (in cells), so its turn follows how far it rolled. */
    drawn: [number, number];
    /** Running: the clock's ticking and swipes roll the ball (false from the moment it ends). */
    running: boolean;
    /** Seconds played and the score: the clock and score live in the engine (Rust), advanced by world.update. */
    readonly elapsed: number;
    readonly score: number;
    won: boolean;
    onPhase: (_p: Phase) => void;
    onCard: () => void;
    onEvent: (_e: GameEvent) => void;
};
export type Game = ReturnType<typeof createGame>;
/** Lays the maze out for the view (first layout, header height, rotation): rebuilt where things stand. */
export declare function setLayout(g: Game, l: Layout): void;
export declare function setTheme(g: Game, theme: GameTheme): void;
/** Starts on the maze already shown, the ball at the start. */
export declare function start(g: Game): void;
/** Stop: the same maze, the ball back at the start, not running (as the original game). */
export declare function stop(g: Game): void;
/** Play Again: a new maze rises, the ball at the start, not running. */
export declare function newMaze(g: Game): void;
/** Rolls the ball on this frame; the engine steps the world after. */
export declare function tick(g: Game, dt: number): void;
/** Swipes anywhere: each stretch of a drag one way is a swipe, so one drag can chain turns. */
export declare function drag(g: Game, e: DragEvent): void;
//# sourceMappingURL=MazeRunnerGame.d.ts.map