import { type Entity, type Light, type World } from '@nayan-ui/engine';
import type { GameTheme } from '../../services/ThemeService';
type RGB = readonly [number, number, number];
export declare const lightFor: (theme: GameTheme) => Light;
export declare const backgroundFor: (theme: GameTheme) => RGB;
export interface Backdrop {
    root: Entity;
    alive: boolean;
}
export declare function spawnBackdrop(world: World, theme: GameTheme): Backdrop;
export declare function removeBackdrop(world: World, backdrop: Backdrop): void;
/** Landscape models depend only on the theme, not a running game. */
export declare function warmAssets(theme: GameTheme): Iterable<() => unknown>;
export {};
//# sourceMappingURL=ChameleonRunBackdrop.d.ts.map