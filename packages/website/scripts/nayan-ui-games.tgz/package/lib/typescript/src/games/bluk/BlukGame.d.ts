import { type Camera, type DragEvent, World } from '@nayan-ui/engine';
import type { GameTheme } from '../../services/ThemeService';
import type { HudFeedback } from '../shared/EngineHud';
import type { GamePhase as Phase } from '../shared/useEngineGame';
import { type Config } from './BlukConstants';
import { type Course, type Flight, type Pillar } from './BlukRules';
import { type Scene } from './BlukScene';
/** jump / land / perfect: the block's moves; fall: it went over the edge; gameOver: the run's lost a beat later. */
export type GameEvent = 'jump' | 'land' | 'perfect' | 'fall' | 'gameOver';
type Block = 'resting' | 'flying' | 'dead';
export declare function createGame(theme: GameTheme): {
    world: World;
    camera: Camera;
    theme: GameTheme;
    config: Config | null;
    scene: Scene | null;
    phase: Phase;
    course: Course | null;
    block: Block;
    flight: Flight;
    /** The pillars this jump can land on (fixed at launch, as the original flight's were). */
    targets: Pillar[];
    tilt: number;
    /** Whether the board on screen has been played on (Start deals a fresh one if so). */
    dirty: boolean;
    /** Score and the countdown live in the engine (Rust), advanced by world.update. */
    readonly score: number;
    combo: number;
    colorIndex: number;
    won: boolean;
    readonly timeLeft: number;
    /** The camera: where it is, and where it's sliding to (from, to, when it started). */
    camX: number;
    camMove: {
        from: number;
        to: number;
        at: number;
    } | null;
    /** Whether the finger has moved far enough to be aiming (the original pan only began after it moved). */
    aiming: boolean;
    pending: number;
    /** Seconds on the game's clock, for the camera's slide. */
    clock: number;
    onPhase: (_p: Phase) => void;
    onCombo: (_c: number) => void;
    hudFeedback: HudFeedback;
    onEvent: (_e: GameEvent) => void;
};
export type Game = ReturnType<typeof createGame>;
/** Sizes the course for the view: a fresh board if none was played on yet, else the board rebuilt where it stands. */
export declare function setLayout(g: Game, c: Config): void;
export declare function setTheme(g: Game, theme: GameTheme): void;
/** Starts play: on the board shown if it's fresh, on a fresh one if not (as the original game). */
export declare function start(g: Game): void;
/** A fresh board, not started (Stop, Play Again). The world, and the GPU view drawing it, are kept. */
export declare function reset(g: Game): void;
/** The flight and the camera's slide; the engine steps the world after. */
export declare function tick(g: Game, dt: number): void;
/** Dragging aims (the arc and a crouch follow the drag); letting go launches, if the drag was enough. */
export declare function drag(g: Game, { phase, dx, dy, cancelled }: DragEvent): void;
/** The block leaves the pillar. */
export declare function launch(g: Game, vx: number, vy: number): void;
export {};
//# sourceMappingURL=BlukGame.d.ts.map