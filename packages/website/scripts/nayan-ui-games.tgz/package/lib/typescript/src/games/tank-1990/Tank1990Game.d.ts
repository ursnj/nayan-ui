import { type Camera, type DragEvent, World } from '@nayan-ui/engine';
import type { GameTheme } from '../../services/ThemeService';
import type { GamePhase as Phase } from '../shared/useEngineGame';
import { type Direction, type Layout } from './Tank1990Constants';
import { type Bullet, type Tank, type Tile } from './Tank1990Rules';
import { type Scene } from './Tank1990Scene';
/** fire: a shot of yours; kill: an enemy destroyed; hit: you were hit. */
export type GameEvent = 'fire' | 'kill' | 'hit';
export declare function createGame(theme: GameTheme): {
    world: World;
    camera: Camera;
    theme: GameTheme;
    layout: Layout | null;
    scene: Scene | null;
    phase: Phase;
    tiles: Tile[][];
    player: Tank | null;
    enemies: Tank[];
    bullets: Bullet[];
    /** Score and lives live in the engine (Rust). */
    readonly lives: number;
    readonly score: number;
    /** Enemies still to roll in this level. */
    enemiesRemaining: number;
    won: boolean;
    /** Where the held swipe is steering, if anywhere. */
    direction: Direction | null;
    /** The game clock (ms), the fixed-step remainder, and the enemy roll-ins: a first one, then a steady interval from the start. */
    now: number;
    pending: number;
    firstSpawn: number | null;
    nextSpawn: number;
    onPhase: (_p: Phase) => void;
    onEnemies: (_n: number) => void;
    onEvent: (_e: GameEvent) => void;
};
export type Game = ReturnType<typeof createGame>;
/** Lays the battle out for the view (first layout, header height, rotation); a new cell size rescales the tanks and shells. */
export declare function setLayout(g: Game, l: Layout): void;
export declare function setTheme(g: Game, theme: GameTheme): void;
/** Plays the map that's showing, your tank freshly shielded. */
export declare function start(g: Game): void;
/** A new map, not started (Stop, Play Again). The world, and the GPU view drawing it, are kept. */
export declare function reset(g: Game): void;
/** The battle's fixed steps and the units' places; the engine steps the world after. */
export declare function tick(g: Game, dt: number): void;
/** Hold a swipe to drive: the way it's moved furthest from where it started; let go to stop. */
export declare function drag(g: Game, { phase, dx, dy }: DragEvent): void;
//# sourceMappingURL=Tank1990Game.d.ts.map