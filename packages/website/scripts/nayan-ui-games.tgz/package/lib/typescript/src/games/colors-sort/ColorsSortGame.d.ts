import { type Camera, type Entity, World } from '@nayan-ui/engine';
import type { GameTheme } from '../../services/ThemeService';
import type { GamePhase as Phase } from '../shared/useEngineGame';
import { type Layout } from './ColorsSortConstants';
import { type Scene } from './ColorsSortScene';
/** pick: a puck lifted; drop: a puck put back; move: one moved; refuse: an empty pick-up or a full tube; complete: all sorted. */
export type GameEvent = 'pick' | 'drop' | 'move' | 'refuse' | 'complete';
export declare function createGame(theme: GameTheme): {
    world: World;
    camera: Camera;
    theme: GameTheme;
    layout: Layout | null;
    scene: Scene | null;
    phase: Phase;
    tubes: number[][];
    /** Each tube's puck entities, parallel to `tubes`. */
    pieces: Entity[][];
    selected: number | null;
    /** Seconds played, and left: the countdown lives in the engine (Rust), advanced by world.update. */
    readonly time: number;
    readonly timeLeft: number;
    timedOut: boolean;
    onPhase: (_p: Phase) => void;
    onEvent: (_e: GameEvent) => void;
};
export type Game = ReturnType<typeof createGame>;
/** Lays the scene out for the view (first layout, header height, rotation): rebuilt from the board. */
export declare function setLayout(g: Game, l: Layout): void;
export declare function setTheme(g: Game, theme: GameTheme): void;
/** Plays the board that's showing. */
export declare function start(g: Game): void;
/** A freshly shuffled board, not started (Stop, Play Again). The world, and the GPU view drawing it, are kept. */
export declare function reset(g: Game): void;
/** The tube under a view point: its column, from just under its shelf to above its mouth (where a puck hovers). */
export declare function tubeAt(g: Game, x: number, y: number): number | null;
export declare function tap(g: Game, x: number, y: number): void;
/** The tube tapped: pick up from it, put back into it, or move the lifted puck onto it. */
export declare function choose(g: Game, t: number): void;
//# sourceMappingURL=ColorsSortGame.d.ts.map