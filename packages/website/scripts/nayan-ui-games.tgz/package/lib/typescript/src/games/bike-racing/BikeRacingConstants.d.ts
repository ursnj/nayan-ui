import type { Color, Model, Vec3 } from '@nayan-ui/engine';
import { type Assets as RoadAssets } from '../car-racing/CarRacingConstants';
export { AUTOPLAY, CAMERA_FOV, DAY_LIGHT, EDGE, FINISH_CLEAR, LANES, LATERAL_SPEED, NIGHT_LIGHT, NIGHT_SKY, ROAD_HALF, SKY, STEER_RESPONSE, STEER_WIDTH, TRACK_LENGTH, getRacingSounds } from '../car-racing/CarRacingConstants';
export declare const LIVES = 3;
export declare const POINTS_PER_BIKE_PASSED = 500;
export declare const START_SPEED = 30;
export declare const TRAFFIC_SPEED = 16;
export declare const SPAWN_AHEAD = 170;
export declare const CRASH_SLOWDOWN = 0.5;
export declare const INVULNERABLE = 1.6;
/** Passing a bike with this little between your middles (metres) counts as a near miss. */
export declare const NEAR_MISS_GAP = 1.3;
export declare const LEAN = 0.045;
export declare const MAX_LEAN = 0.5;
/** The original game's bike colors: the player's orange, traffic in blue, green and magenta (and a few more). */
export declare const PLAYER_PAINT: Color;
export declare const PAINTS: Color[];
export declare const SUIT: Color;
export declare const SUIT_TRIM: Color;
export declare const VISOR: Color;
/**
 * One bike for everyone, built in code (BikeMeshes). Its paint is white so each bike tints its own
 * color; the trim (frame, tyres, wheels, chrome, exhaust) and the smoked windscreen keep theirs. The
 * rider is built from the engine's shapes (BikeRacingScene).
 */
export type BikeModel = {
    body: Model;
    trim: Model;
    glass: Model;
    size: Vec3;
};
export type Assets = RoadAssets & {
    bike: BikeModel;
};
export declare const getCachedAssets: () => Assets | null;
export declare function loadAssets(): Promise<Assets>;
/** Starts loading the game's textures and building its models (they're cached), so opening it is quick. */
export declare function preloadBikeRacing(): void;
/** Road assets are warmed by Car Racing first and reused here. */
export declare function warmAssets(): Iterable<() => unknown>;
//# sourceMappingURL=BikeRacingConstants.d.ts.map