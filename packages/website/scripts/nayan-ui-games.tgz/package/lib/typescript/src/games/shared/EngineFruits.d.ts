import { type Color, type Model, type Vec3 } from '@nayan-ui/engine';
export type FruitKind = 'apple' | 'orange' | 'lemon' | 'pear' | 'strawberry' | 'watermelon' | 'banana' | 'cherries' | 'grapes' | 'kiwi' | 'mango' | 'peach' | 'pineapple' | 'pomegranate' | 'papaya';
export type Fruit = {
    whole: Model;
    /** The left and right pieces after a slice. */
    pieces: [Model, Model];
    /** Color of its juice (for splashes). */
    juice: Color;
    /** Centre of the whole fruit's bounding box (stems and leaves included), in its own units. */
    center: Vec3;
};
/**
 * One fruit, built on first use (mesh ids last for the whole app). Needs the native core.
 * `level` < 1 builds a lighter mesh for fruit shown small (0.35 still looks round at 60 points).
 */
export declare function getFruit(kind: FruitKind, level?: number): Fruit;
/** Whether `kind` is cached at `level`, including its sliced models when `withSlices` is true. */
export declare const isFruitBuilt: (kind: FruitKind, level?: number, withSlices?: boolean) => boolean;
/**
 * Builds `kinds` one per frame, so the screen keeps animating while they're made, then calls `done`.
 * Already built fruit cost nothing. Returns a cancel function.
 */
export declare function loadFruits(kinds: readonly FruitKind[], done: () => void, level?: number): () => void;
/** Every fruit, built once (mesh ids last for the whole app). Needs the native core. */
export declare function getFruits(): Record<FruitKind, Fruit>;
/** Whole bodies and cut pieces are separate jobs; board games never build unused slices. */
export declare function warmAssets(kinds: readonly FruitKind[], level: number, pieces?: boolean): Iterable<() => unknown>;
//# sourceMappingURL=EngineFruits.d.ts.map