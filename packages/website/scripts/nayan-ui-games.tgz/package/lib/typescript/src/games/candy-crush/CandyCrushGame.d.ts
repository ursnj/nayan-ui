import { type Camera, type Entity, World } from '@nayan-ui/engine';
import type { GameTheme } from '../../services/ThemeService';
import type { GamePhase as Phase } from '../shared/useEngineGame';
import { type Layout } from './CandyCrushConstants';
import { type Scenery } from './CandyCrushScene';
export type Direction = 'up' | 'down' | 'left' | 'right';
type Candy = {
    type: number;
    row: number;
    col: number;
    root: Entity | null;
};
type Grid = (Candy | null)[];
export declare function createGame(theme: GameTheme): {
    world: World;
    camera: Camera;
    theme: GameTheme;
    layout: Layout | null;
    scenery: Scenery | null;
    phase: Phase;
    /** Score and the countdown live in the engine (Rust), advanced by world.update. */
    readonly score: number;
    readonly timeLeft: number;
    /** Game clock, seconds: drives the delayed steps (they pause with the frame loop). */
    time: number;
    grid: Grid;
    /** A swap is resolving (matches, falls, cascades): no new moves until it settles. */
    busy: boolean;
    combo: number;
    /** The candy under the finger. */
    dragging: Candy | null;
    /** The next board to appear rains in. */
    intro: boolean;
    /** Game seconds the current intro has been playing (-1 until its board spawns). */
    introAge: number;
    onPhase: (_p: Phase) => void;
    onSelect: () => void;
    onSwap: () => void;
    onInvalid: () => void;
    onMatch: (_combo: number) => void;
    /** A color bomb was made. */
    onBomb: () => void;
    /** A color bomb went off. */
    onBlast: () => void;
    onWarning: (_secondsLeft: number) => void;
    onTimeUp: () => void;
};
export type Game = ReturnType<typeof createGame>;
/** Lays the scene out for the view (first layout, header height, rotation): rebuilt from the run's state. */
export declare function setLayout(g: Game, l: Layout): void;
/** A new theme: the background and board are repainted; the candies and the run carry on. */
export declare function setTheme(g: Game, theme: GameTheme): void;
export declare function start(g: Game): void;
/** A new board and timer (Stop, Play Again). The world, and the GPU view drawing it, are kept. */
export declare function reset(g: Game): void;
export declare function dispose(g: Game): void;
/** The game clock; the engine steps the world after. */
export declare function tick(g: Game, dt: number): void;
/** Finger down: the candy under it lifts and follows the finger. */
export declare function touchStart(g: Game, x: number, y: number): void;
export declare function touchMove(g: Game, dx: number, dy: number): void;
/** Finger up: a long enough drag swaps toward its main direction; otherwise the candy settles back. */
export declare function touchEnd(g: Game, dx: number, dy: number, cancelled?: boolean): void;
export {};
//# sourceMappingURL=CandyCrushGame.d.ts.map