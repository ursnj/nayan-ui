import { type Entity, type Vec3, type World } from '@nayan-ui/engine';
import type { GameTheme } from '../../services/ThemeService';
import { type Layout } from './WhackAMoleConstants';
export type Scene = {
    scenery: Entity[];
    mounds: Entity[];
    moles: Entity[];
};
/** A mole's place: up out of its hole, or hidden below the ground. */
export declare const molePosition: (l: Layout, hole: number, up: boolean) => Vec3;
/** The top of a mole that's up, for hit-testing and the hit's burst. */
export declare const moleTop: (l: Layout) => number;
export declare function buildScene(world: World, l: Layout, theme: GameTheme): Scene;
export declare function removeScene(world: World, s: Scene): void;
/** A mole springs up out of its hole and looks about. */
export declare function popUp(world: World, l: Layout, s: Scene, hole: number): void;
/** A mole that wasn't hit ducks back down. */
export declare function duck(world: World, l: Layout, s: Scene, hole: number): void;
/** A whacked mole squashes flat, sees stars and sinks away. */
export declare function bonk(world: World, l: Layout, s: Scene, hole: number): void;
/** Dirt kicked up where a tap hits an empty hole. */
export declare function thud(world: World, l: Layout, hole: number): void;
/**
 * A whack: a hot flash flares behind the mole's head, eight impact streaks shoot out from it, comic
 * style, and dust puffs out round the hole (the mole squashes and sees stars in `bonk`).
 */
export declare function hitEffect(world: World, l: Layout, hole: number): void;
/** A miss: a smaller puff of dust with the dirt. */
export declare function missEffect(world: World, l: Layout, hole: number): void;
/** Every mole back underground (a reset or the end of a game). */
export declare function hideAll(world: World, l: Layout, s: Scene): void;
//# sourceMappingURL=WhackAMoleScene.d.ts.map