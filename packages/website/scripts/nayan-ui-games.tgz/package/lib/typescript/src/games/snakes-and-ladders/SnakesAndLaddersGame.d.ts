import { type Camera, World } from '@nayan-ui/engine';
import type { GameTheme } from '../../services/ThemeService';
import type { GamePhase as Phase } from '../shared/useEngineGame';
import { type Layout } from './SnakesAndLaddersConstants';
import { type Scene } from './SnakesAndLaddersScene';
/** 0 is you, 1 the AI. */
export type Turn = 0 | 1;
export type GameEvent = 'tap' | 'roll' | 'six' | 'penalty' | 'cantMove' | 'move' | 'snake' | 'ladder';
export declare function createGame(theme: GameTheme): {
    world: World;
    camera: Camera;
    theme: GameTheme;
    layout: Layout | null;
    scene: Scene | null;
    phase: Phase;
    /** Each player's cell: 0 before the first move. */
    positions: [number, number];
    turn: Turn;
    /** Sixes in a row this turn. */
    sixes: number;
    /** A roll is in play (rolling, moving, or the AI thinking). */
    busy: boolean;
    /** The die is rolling or a pawn moving. */
    rolling: boolean;
    /** The score lives in the engine (Rust). */
    readonly score: number;
    won: boolean;
    onPhase: (_p: Phase) => void;
    onPositions: (_you: number, _ai: number) => void;
    onTurn: (_t: Turn) => void;
    onEvent: (_e: GameEvent, _who: Turn) => void;
};
export type Game = ReturnType<typeof createGame>;
/** Lays the scene out for the view (first layout, header height, rotation): rebuilt from the game's state. */
export declare function setLayout(g: Game, l: Layout): void;
/** A new theme repaints the backdrop; the board keeps its classic colors, as the original board did. */
export declare function setTheme(g: Game, theme: GameTheme): void;
export declare function start(g: Game): void;
/** A fresh game (Stop, Play Again). The world, and the GPU view drawing it, are kept. */
export declare function reset(g: Game): void;
export declare function tick(g: Game, dt: number): void;
/** Whether a tap at a view point should roll: the player's turn, nothing moving, the finger on the die. */
export declare function tap(g: Game, x: number, y: number): void;
//# sourceMappingURL=SnakesAndLaddersGame.d.ts.map