import { type ComponentType } from 'react';
import { type GAME_IDS, type GameProps } from '../../services/UtilsService';
/** The game module and its world are evaluated after the native loading animation is visible. */
export declare function withGameLoading(id: GAME_IDS, load: () => ComponentType<GameProps>): ComponentType<GameProps>;
//# sourceMappingURL=EngineGameLoader.d.ts.map