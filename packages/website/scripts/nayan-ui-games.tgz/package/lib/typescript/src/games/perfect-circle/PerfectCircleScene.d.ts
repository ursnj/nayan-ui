import { type Entity, type Vec3, type World } from '@nayan-ui/engine';
import type { GameTheme } from '../../services/ThemeService';
import { type Layout } from './PerfectCircleConstants';
import type { Point } from './PerfectCircleRules';
export type Scene = {
    backdrop: Entity;
    plate: Entity;
    ring: Entity;
    tip: Entity;
    /** The stroke's segments and joints, in drawing order. */
    stroke: Entity[];
    fit: Entity[];
};
/** A view point on the plate, in the world. */
export declare const toWorld: (l: Layout, p: Point, z?: number) => Vec3;
export declare function buildScene(world: World, l: Layout, theme: GameTheme): Scene;
export declare function removeScene(world: World, s: Scene): void;
export declare function setSceneTheme(world: World, s: Scene, theme: GameTheme): void;
/** The finger's first point: the pen tip comes down there. */
export declare function beginStroke(world: World, l: Layout, s: Scene, p: Point): void;
/** The stroke reaches a new point: a segment out to it and a joint there; the pen tip follows. */
export declare function extendStroke(world: World, l: Layout, s: Scene, from: Point, to: Point): void;
/** The finger lifts: the pen tip goes. */
export declare function endStroke(world: World, s: Scene): void;
/** The verdict: the stroke tints to green or red with a pulse, and the best-fit circle traces round over it. */
export declare function verdict(world: World, l: Layout, s: Scene, won: boolean, fit: {
    cx: number;
    cy: number;
    r: number;
} | null, theme: GameTheme): void;
/** Clears the stroke and the trace (a new game). */
export declare function clearStroke(world: World, s: Scene): void;
//# sourceMappingURL=PerfectCircleScene.d.ts.map