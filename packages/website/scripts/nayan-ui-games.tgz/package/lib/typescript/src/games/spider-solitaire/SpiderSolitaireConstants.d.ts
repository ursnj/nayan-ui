import { type TiltView } from '../shared/EngineTilt';
import type { Suit } from './SpiderSolitaireRules';
/** A win scores by its time against ten minutes, as the original game did. */
export declare const EXPECTED_TIME = 600;
export declare const BASE_SCORE = 100;
export declare const TAP_SLOP = 10;
export declare const MOVE_TIME = 0.24;
export declare const DEAL_STAGGER = 0.05;
export declare const RUN_STAGGER = 0.045;
export declare const WIN_DELAY = 1.1;
export declare const COLORS: {
    readonly FACE: "#FFFFFF";
    readonly BACK: "#1565C0";
    readonly BACK_LIGHT: "#3B82D6";
    readonly BACK_FRAME: "#E3F2FD";
    readonly RED: "#DC2626";
    readonly BLACK: "#1F2937";
    readonly SELECTED: "#FFE082";
    readonly CLASSIC_SLOT: "rgba(255, 255, 255, 0.35)";
};
export declare const SUIT_COLORS: Record<Suit, string>;
/** The camera leans back a little from straight down, so the cards' thickness and the stacks read as 3D. */
export declare const TILT = 0.2;
/** Lit from the upper left; surfaces facing up off the table (+z) keep their exact color. */
export declare const LIGHT: import("@nayan-ui/engine").Light;
/** A card is 1.4 times as tall as it is wide, and this thin (of its width). */
export declare const CARD_RATIO = 1.4;
export declare const THICKNESS = 0.024;
/** How far down a pile each card shows below the one under it (of a card's height), as the original piles. */
export declare const FACE_DOWN_STEP = 0.15;
export declare const FACE_UP_STEP = 0.25;
/** The deck and the finished runs along the bottom are drawn at this size. */
export declare const SMALL = 0.74;
export type Layout = TiltView & {
    /** A tableau card's width and height. */
    card: number;
    cardH: number;
    /** Each pile's centre (world x). */
    columns: number[];
    pitch: number;
    /** The top edge of a pile's first card, and the lowest a pile may reach (world y). */
    pileTop: number;
    pileBottom: number;
    /** The bottom row: its centre (world y), the deck's right edge and the first finished run's centre (world x). */
    rowY: number;
    stockRight: number;
    foundationX: number;
    /** Heights between stacked cards (world z). */
    dz: number;
};
/** All ten piles side by side across the game area (the original piles scrolled sideways), the deck and runs below. */
export declare function getLayout(width: number, height: number, offset: number, tablet: boolean): Layout;
/** Where a table point at height z shows in the view. */
export declare const onScreen: (l: Layout, x: number, y: number, z: number) => [number, number];
//# sourceMappingURL=SpiderSolitaireConstants.d.ts.map