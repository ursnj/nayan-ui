import type { Light } from '@nayan-ui/engine';
export declare const MOB_CONFIG: {
    readonly HALF_WIDTH: 5.2;
    readonly TRACK_NEAR_Z: 30;
    readonly TRACK_FAR_Z: -150;
    readonly CANNON_LIMIT: 4.25;
    readonly CANNON_Z: 1.2;
    readonly SPAWN_Z: -0.9;
    readonly BASE_Z: -32;
    readonly TARGET_LINE: -29.5;
    readonly BREACH_Z: 0.15;
    readonly PLAYER_HP: 1200;
    readonly PLAYER_SLOTS: 640;
    readonly ENEMY_SLOTS: 384;
    readonly CAPACITY: 1024;
    readonly BASE_HP: 1000;
    readonly CORE_HP: 1400;
    readonly ENEMY_WAVE_SIZE: 14;
    readonly ENEMY_WAVE_INTERVAL: 1.35;
    readonly ENEMY_SURGE_INTERVAL: 15;
    readonly ENEMY_MAX_SURGE: 8;
    readonly MAX_STRENGTH: 4096;
    readonly PLAYER_SPEED: 4.8;
    readonly ENEMY_SPEED: 2.65;
    readonly FIRE_INTERVAL: 0.105;
    readonly CHAMPION_CHARGE: 100;
    readonly CHAMPION_PER_SHOT: 1.6;
    readonly CHAMPION_STRENGTH: 42;
    readonly CHAMPION_SPEED: 6.2;
    readonly BOSS_STRENGTH: 170;
    readonly BOSS_SPEED: 1.55;
    readonly BOOST_SPEED: 1.65;
    readonly BOOST_DURATION: 1.4;
    readonly FLIGHT_DURATION: 0.38;
    readonly COLLISION_RADIUS: 0.34;
    readonly GRID_SIZE: 0.8;
    readonly GRID_COLUMNS: 14;
    readonly GRID_ROWS: 46;
    readonly MAX_COLLISION_VISITS: 48;
    readonly MAX_SEPARATION_VISITS: 12;
    readonly STEP: number;
    readonly MAX_FRAME: 0.05;
    readonly HUD_INTERVAL: 0.12;
    readonly EFFECT_INTERVAL: 0.075;
    readonly MAX_EFFECTS: 6;
    readonly WORLD_CAPACITY: 640;
    readonly KILL_POINTS: 5;
    readonly BASE_POINTS: 350;
    readonly LEVEL_POINTS: 500;
};
export interface Gate {
    id: number;
    x: number;
    originX: number;
    z: number;
    halfWidth: number;
    factor: number;
    operation: 'multiply' | 'add' | 'divide';
    moving: boolean;
    hits: number;
    remainder: number;
}
export interface Barrier {
    x: number;
    z: number;
    halfWidth: number;
    hp: number;
    maxHp: number;
}
export interface BoostPad {
    x: number;
    z: number;
    halfWidth: number;
    halfLength: number;
}
export interface Base {
    x: number;
    z: number;
    hp: number;
    maxHp: number;
    spawnClock: number;
}
export declare const MOB_COLORS: {
    readonly PLAYER: "#3998FF";
    readonly ENEMY: "#F25467";
    readonly PLAYER_DARK: "#1D568F";
    readonly ENEMY_DARK: "#8D2D42";
    readonly GATE: "#29BFFF";
    readonly GATE_HIGH: "#A14CF5";
    readonly GATE_DANGER: "#F16B68";
    readonly FRAME: "#1763A8";
    readonly ROAD: "#CDD0D2";
    readonly ROAD_EDGE: "#E6BA78";
    readonly GROUND: "#D7AB72";
    readonly CHAMPION: "#FFC83E";
    readonly BOOST: "#7DECF1";
    readonly HP_PLAYER: "#54CDA2";
    readonly HP_ENEMY: "#F25467";
};
export declare const SKY_DAY: readonly [0.67, 0.81, 0.88];
export declare const SKY_NIGHT: readonly [0.035, 0.07, 0.13];
export declare const DAY_LIGHT: Light;
export declare const NIGHT_LIGHT: Light;
//# sourceMappingURL=MobControlConstants.d.ts.map