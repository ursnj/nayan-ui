import type { Camera, Entity, LoadedModel, World } from 'nayan-ui';
import type { GameTheme } from '../../services/ThemeService';
export interface Scene {
    character: Entity;
    floor: Entity;
    camera: Camera;
}
export declare function buildScene(world: World, model: LoadedModel, theme: GameTheme): Scene;
export declare function layoutScene(scene: Scene, width: number, height: number, offset: number): {
    top: number;
    bottom: number;
};
export declare function setSceneTheme(world: World, scene: Scene, theme: GameTheme): void;
//# sourceMappingURL=PlayWithTuaScene.d.ts.map