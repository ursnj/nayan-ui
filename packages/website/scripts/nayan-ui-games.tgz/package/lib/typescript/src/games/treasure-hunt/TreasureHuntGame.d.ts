import { type Camera, type Entity, World } from '@nayan-ui/engine';
import { type GameAssets } from './TreasureHuntConstants';
import { createFootsteps, type MovementReference, type SwipeInput } from './TreasureHuntControls';
import { type Human } from './TreasureHuntModel';
import { type NatureInput, type NatureState } from './TreasureHuntRules';
import { type NatureVisual, type RobotVisual } from './TreasureHuntScene';
export interface NatureGame {
    readonly phase: 'ready' | 'playing' | 'over';
    readonly score: number;
    readonly won: boolean;
    onPhase: (phase: 'ready' | 'playing' | 'over') => void;
    world: World;
    assets: GameAssets;
    camera: Camera;
    movementReference: MovementReference;
    nature: NatureVisual;
    state: NatureState;
    human: Human;
    footsteps: ReturnType<typeof createFootsteps>;
    swipe: SwipeInput;
    attackBuffer: number;
    enemies: Map<number, RobotVisual>;
    gems: Map<number, Entity>;
    animationTime: number;
    combatTime: number;
    hudTime: number;
    /** Runs played in this world: each new one re-places the diamonds and robots. */
    run: number;
    onChange: () => void;
}
export declare function createGame(assets: GameAssets): NatureGame;
export declare function start(game: NatureGame): void;
/**
 * Stop and Play Again: the same world, with the diamonds and robots in fresh places and the
 * explorer back at the start. The terrain and scenery stay as they are, so a new run costs only
 * its few dozen actors: nothing is generated, built or loaded.
 */
export declare function reset(game: NatureGame): void;
export declare function clearInput(game: NatureGame): void;
export declare function punch(game: NatureGame): void;
/** Shared screen frame callback: sample gestures and consume at most one buffered punch. */
export declare function update(game: NatureGame, dt: number): void;
/** Called exclusively by GameView, which also suspends frames on AppState changes. */
export declare function tick(game: NatureGame, input: NatureInput, elapsed: number): void;
/** Releases input and footsteps; the shared screen disposes the world after this. */
export declare function dispose(game: NatureGame): void;
//# sourceMappingURL=TreasureHuntGame.d.ts.map