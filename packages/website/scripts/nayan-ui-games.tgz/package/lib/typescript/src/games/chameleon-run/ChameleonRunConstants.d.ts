/** Match Penguin Run: a fixed-distance run at a steady pace, with three lives. */
export declare const TRACK_LENGTH = 500;
export declare const MAX_LIVES = 3;
export declare const HURT_INVULNERABLE = 2.2;
export declare const RESULTS_DELAY_LOSE = 1700;
export declare const RESULTS_DELAY_WIN = 2600;
export declare const POINTS_PER_METRE = 1;
export declare const DRAG_THRESHOLD = 18;
export declare const STEP_SECONDS: number;
export declare const MAX_FRAME_SECONDS = 0.05;
export declare const SCORE_SYNC = 0.1;
export declare const STAR_POINTS = 250;
export declare const MAX_JUMPS = 2;
export declare const JUMP_BUFFER = 0.12;
export declare const COYOTE_TIME = 0.1;
export declare const COLOR_GRACE = 0.12;
export declare const BASE_SPEED = 7;
export type RunColor = 'yellow' | 'pink';
export declare const RUN_COLORS: {
    readonly yellow: "#FFD447";
    readonly pink: "#F653A6";
};
export declare const COLOR_NAMES: {
    readonly yellow: "YELLOW · STRIPES";
    readonly pink: "PINK · DOTS";
};
export interface Config {
    width: number;
    height: number;
    trackWidth: number;
    lookAhead: number;
    gravity: number;
    jump: number;
    doubleJump: number;
    fallY: number;
}
export declare function configFor(width: number, height: number): Config;
export declare const COLORS: {
    readonly STONE: "#496578";
    readonly STONE_DARK: "#304556";
    readonly NEUTRAL: "#D6E9EC";
    readonly STAR: "#FFF09A";
    readonly BELLY: "#FFF5DC";
    readonly EYE: "#16243A";
    readonly RIM: "#F5FCFF";
};
//# sourceMappingURL=ChameleonRunConstants.d.ts.map