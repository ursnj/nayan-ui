import { type Color, type Entity, type World } from '@nayan-ui/engine';
import type { GameTheme } from '../../services/ThemeService';
import { type Direction, type Layout } from './ArrowsConstants';
/** White line art on classic indigo; light / dark draw it in the theme's text color. */
export declare const arrowColor: (theme: GameTheme) => Color;
type Pt = [number, number];
export type ArrowShape = {
    waypoints: readonly {
        row: number;
        col: number;
    }[];
    exitDir: Direction;
};
export type Scenery = {
    backdrop: Entity;
    board: Entity;
};
/** The game background and the (invisible) board root the arrows and dots hang from. */
export declare function buildScenery(world: World, l: Layout, theme: GameTheme, entrance: boolean): Scenery;
/** The board's little bounce when the last arrow leaves. */
export declare function pulseBoard(world: World, board: Entity): void;
export type ArrowView = {
    root: Entity;
    parts: Entity[];
};
/**
 * An arrow at rest. With `intro`, it draws itself along its path from the tail, its start `intro`
 * seconds in (the original board's draw-in): each run grows after the one before, the head pops in last.
 */
export declare function spawnArrow(world: World, l: Layout, board: Entity, a: ArrowShape, color: Color, intro: number | null): ArrowView;
export declare function setArrowColor(world: World, view: ArrowView, color: Color): void;
/** A blocked tap: the arrow flashes red with a decaying wobble, then fades back to its color. */
export declare function flashBlocked(world: World, view: ArrowView, color: Color): void;
/** The arrow in the way of a blocked tap pulses amber once, so the player sees what to clear first. */
export declare function pulseBlocker(world: World, view: ArrowView, color: Color): void;
/**
 * An arrow on its way out. It slithers ALONG its own path: the head leads straight out of the board
 * and the body follows through the turns, opaque inside the board and fading once past its edge.
 * The path is a polyline from the tail through the turns to a point far off screen; `travel` slides
 * the arrow's span of it forward each frame.
 */
export type Flight = {
    root: Entity;
    /** One per run of the path; the last run's part beyond the board edge is `outside`. */
    bars: Entity[];
    outside: Entity;
    /** The tail, every turn, the shaft's end. */
    joints: Entity[];
    head: Entity;
    points: Pt[];
    /** Arc length at each point. */
    arcs: number[];
    /** The shaft's length, tail to the head's base. */
    shaft: number;
    /** Arc length where the path crosses the board edge, and how far past it the arrow fades out. */
    edge: number;
    fade: number;
    /** How far the arrow travels in its flight. */
    far: number;
    elapsed: number;
};
export declare function spawnFlight(world: World, l: Layout, board: Entity, a: ArrowShape): Flight;
/** Advances a flight by `dt` seconds; returns false once it has finished (and despawned). */
export declare function stepFlight(world: World, l: Layout, f: Flight, dt: number, duration: number): boolean;
/** The dot an empty cell shows, popping in just after an arrow's tail has left it. */
export declare function spawnDot(world: World, l: Layout, board: Entity, row: number, col: number): Entity;
export {};
//# sourceMappingURL=ArrowsScene.d.ts.map