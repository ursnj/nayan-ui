/** Product recipe revisioning is separate from the engine's geometry/storage format. */
export declare function cacheGameAsset<T>(key: string, build: () => T): T;
/** A saved asset from this or an earlier launch, or undefined: nothing is built. */
export declare function peekGameAsset<T>(key: string): T | undefined;
export declare const flushProceduralCache: () => Promise<void>;
//# sourceMappingURL=EngineMeshCache.d.ts.map