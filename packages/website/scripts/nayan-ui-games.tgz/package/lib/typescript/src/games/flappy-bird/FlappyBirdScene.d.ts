import { type Entity, type TransformBatch, type World } from '@nayan-ui/engine';
import { type View3D } from '../shared/EngineMeadow';
import { type Layout } from './FlappyBirdConstants';
export type Walls = {
    top: Entity;
    bottom: Entity;
};
export declare function spawnWalls(world: World, v: View3D, l: Layout): Walls;
/**
 * Scrolls the walls with the pipes. They move at the pipes' speed in the world (the pipes pass through
 * them, so they stay put against the bricks), which on screen is a touch slower for the deeper bottom
 * wall: real parallax. Each wraps by a whole shade period, where its bricks look exactly the same.
 */
export declare function placeWalls(world: World, v: View3D, l: Layout, walls: Walls, scroll: number): void;
/** A pair of pipes: the top one comes out of the top wall down to the gap, the bottom one up out of the bottom wall. */
export declare function spawnPipe(world: World, v: View3D, l: Layout, x: number, gapTop: number, gapBottom: number): Entity;
export declare function placePipe(world: World, v: View3D, root: Entity, x: number, updates?: TransformBatch): void;
export type BirdView = {
    root: Entity;
    body: Entity;
    wing: Entity;
    farWing: Entity;
    lid: Entity;
    size: number;
};
/** The bird, its body centred on screen point (x, y). In the ready state it hovers, bobbing gently. */
export declare function spawnBird(world: World, v: View3D, x: number, y: number): BirdView;
/** Moves the bird: leaning by `tilt`, the wings lifted by `lift` (radians: up positive), the far one a beat behind. */
export declare function placeBird(world: World, v: View3D, b: BirdView, x: number, y: number, tilt: number, lift: number, farLift?: number): void;
/** The squash and stretch of a flap: the body stretches up as it pushes off, then settles. */
export declare function flapPop(world: World, b: BirdView): void;
/** A blink: the lid closes over the eye and opens again. */
export declare function blink(world: World, b: BirdView): void;
/** Knocked silly by a crash: a shake, eyes half shut, wings drooping. */
export declare function dazeBird(world: World, b: BirdView): void;
/** Back to normal after a crash (a new run). */
export declare function wakeBird(world: World, b: BirdView): void;
/** A gentle hover while waiting to start (none while flying). */
export declare function hoverBird(world: World, b: BirdView, on: boolean, v: View3D): void;
/** Feathers fly and a puff of dust where the bird hit. */
export declare function crashBurst(world: World, v: View3D, x: number, y: number): void;
//# sourceMappingURL=FlappyBirdScene.d.ts.map