import { type Camera, type Entity, type Vec3, type World } from '@nayan-ui/engine';
import type { GameTheme } from '../../services/ThemeService';
import { type Config, type Sky } from './BlukConstants';
import type { Pillar } from './BlukRules';
/** The theme's sky: the built-in one, its base following the theme's background (as the original scene). */
export declare function skyFor(theme: GameTheme): Sky;
type PillarView = {
    root: Entity;
};
type Decor = {
    entity: Entity;
    x: number;
    y: number;
    z: number;
};
export type Scene = {
    sky: Entity;
    towers: Decor[];
    frameX?: number;
    frameWidth?: number;
    frameHeight?: number;
    pillars: Map<string, PillarView>;
    block: Entity;
    figure: Entity;
    body: Entity;
    dots: Entity[];
    ring: Entity;
};
/** World point for a course point (x along the world, y down in the view). */
export declare const toWorld: (x: number, y: number, z?: number) => Vec3;
export declare function buildScene(world: World, c: Config, theme: GameTheme, pillars: Pillar[], block: [number, number], colorIndex: number): Scene;
export declare function removeScene(world: World, s: Scene): void;
/** Keeps the pillars in step with the course: new ones appear, dropped ones go. */
export declare function syncPillars(world: World, c: Config, s: Scene, pillars: Pillar[]): void;
/** Points the camera at the course scrolled `camX` along, the sky and towers following. */
export declare function frame(world: World, c: Config, s: Scene, camera: Camera, camX: number): void;
/** The block at its centre (course point), tilted `tilt` (radians, clockwise on screen). */
export declare function placeBlock(world: World, s: Scene, x: number, y: number, tilt: number): void;
/** The character's squash (above 0 stretches it tall, below squashes it flat), set at once. */
export declare function squash(world: World, c: Config, s: Scene, q: number): void;
/** Springing out of the crouch into a quick stretch, for a launch. */
export declare function stretch(world: World, c: Config, s: Scene): void;
/** Relaxing a crouch that didn't jump. */
export declare function relax(world: World, c: Config, s: Scene): void;
/** A landing: the tilt eases out, the character squashes and springs back, dust puffs up, and on a perfect one a gold ring spreads. */
export declare function land(world: World, c: Config, s: Scene, x: number, topY: number, perfect: boolean, colorIndex: number): void;
/** Off the edge: the block tumbles forward and fades as it drops into the void. */
export declare function fall(world: World, s: Scene, tilt: number, colorIndex: number): void;
/** The block whole again, at rest and in a color (a new board). */
export declare function resetBlock(world: World, c: Config, s: Scene, colorIndex: number): void;
/** The preview arc: a dot at each point (course coordinates), shrinking along it; the rest hidden. */
export declare function showArc(world: World, c: Config, s: Scene, pts: number[]): void;
export declare const hideArc: (world: World, c: Config, s: Scene) => void;
export {};
//# sourceMappingURL=BlukScene.d.ts.map