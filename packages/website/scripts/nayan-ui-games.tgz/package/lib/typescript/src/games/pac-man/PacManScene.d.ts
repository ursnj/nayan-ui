import { type Entity, type World } from '@nayan-ui/engine';
import type { GameTheme } from '../../services/ThemeService';
import { type Direction, GhostMode, GhostName, type Layout } from './PacManConstants';
type GhostRig = {
    root: Entity;
    body: Entity;
    eyes: [Entity, Entity];
    pupils: [Entity, Entity];
};
export type Scene = {
    backdrop: Entity;
    board: Entity;
    dots: Map<number, Entity>;
    pacman: Entity;
    mouth: Entity;
    /** The mouth's full size (world units): it chomps between almost shut and this. */
    mouthSize: number;
    ghosts: Record<GhostName, GhostRig>;
    fruit: Entity | null;
};
export declare function buildScene(world: World, l: Layout, theme: GameTheme): Scene;
export declare function removeScene(world: World, s: Scene): void;
export declare function setSceneTheme(world: World, s: Scene, theme: GameTheme): void;
export declare function eatDot(world: World, s: Scene, x: number, y: number): void;
export declare function clearDots(world: World, s: Scene): void;
export declare function placeFruit(world: World, l: Layout, s: Scene, fruit: {
    x: number;
    y: number;
} | null): void;
export declare function fruitEaten(world: World, l: Layout, s: Scene, x: number, y: number): void;
/** Moves Pac-Man to a cell: gliding over `time`, or snapping across the side tunnel. */
export declare function movePacman(world: World, l: Layout, s: Scene, cx: number, cy: number, dir: Direction, time: number, snap: boolean): void;
export declare function setPacman(world: World, l: Layout, s: Scene, cx: number, cy: number, dir: Direction): void;
/** The mouth chomps open and shut while Pac-Man moves. */
export declare function startChomp(world: World, s: Scene, chompTime: number): void;
/** The mouth stops, half open (his look at rest). */
export declare function stopChomp(world: World, s: Scene): void;
/** Pac-Man caught: a flash of yellow sparks where he stood. */
export declare function pacmanHit(world: World, l: Layout, cx: number, cy: number): void;
export declare function moveGhost(world: World, l: Layout, s: Scene, name: GhostName, cx: number, cy: number, time: number, snap: boolean): void;
/** A ghost's colour and body (just the eyes race home when eaten) for its mode. */
export declare function dressGhost(world: World, l: Layout, s: Scene, name: GhostName, mode: GhostMode, flashing: boolean): void;
export declare function ghostEaten(world: World, l: Layout, cx: number, cy: number): void;
export {};
//# sourceMappingURL=PacManScene.d.ts.map