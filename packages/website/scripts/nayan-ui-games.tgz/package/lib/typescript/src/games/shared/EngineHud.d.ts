import { type Color, type Entity, type Font, World } from '@nayan-ui/engine';
import type { GameTheme } from '../../services/ThemeService';
/** A scoreboard column: text (optionally colored), or `lives` drawn as hearts. */
export type HudColumn = {
    label: string;
    value: string;
    color?: string;
    valueColor?: string;
    lives?: {
        count: number;
        max: number;
    };
};
/** Top edge of the scoreboard; `offset` is the height of the host app's header, 0 when there is none. */
export declare const getScoreBoardTop: (offset?: number) => number;
/** Insets for a React touch surface over the scene, leaving the native HUD's controls reachable. */
export declare const getSceneInputInsets: (offset?: number) => {
    top: number;
    bottom: number;
};
/** The usual columns. */
export declare const scoreColumn: (score: number, label?: string, format?: (n: number) => string) => HudColumn;
/** Time as m:ss, red at or under `lowAt` seconds (0: only at zero). */
export declare const timerColumn: (seconds: number, theme: GameTheme, lowAt?: number, label?: string) => HudColumn;
export declare const livesColumn: (count: number, max: number, label?: string) => HudColumn;
export declare const textColumn: (label: string, value: string | number, color?: string) => HudColumn;
export type HudButton = 'main' | 'leaderboard' | 'share' | 'choice';
export type HudActions = {
    onStart: () => void;
    onStop: () => void;
    onShare?: () => void;
    onShowLeaderboard?: () => void;
};
export type GameOverCard = {
    title: string;
    message?: string;
    scoreLabel: string;
    score: number;
    formatter?: (score: number) => string;
    buttonText: string;
    onPlayAgain: () => void;
    onShare?: () => void;
};
export interface HudChoice {
    id: string;
    label: string;
    selected?: boolean;
    onPress: () => void;
}
/** Events coalesce until the next engine frame; consuming them never triggers a React render. */
export interface HudFeedback {
    flash?: boolean;
    message?: string;
}
type Fonts = {
    semi: Font;
    regular: Font;
};
/** Inter SemiBold for all HUD text, flat (depth 0) like normal text: loaded once per app. */
export declare function loadHudFonts(): Promise<Fonts>;
/** The engine-drawn scoreboard and controls. Feed it state; pass `world` as GameView's `overlay`. */
export declare class EngineHud {
    readonly world: World;
    private theme;
    private size;
    private columns;
    private playing;
    private subtext;
    private actions;
    private board;
    private controls;
    private values;
    private buttons;
    private pressed;
    private over;
    private overReserve;
    private disposed;
    private feedback;
    private waiting;
    private layers;
    private choices;
    private choiceRoot;
    private choiceButtons;
    private choicePage;
    get ready(): boolean;
    get viewport(): {
        width: number;
        height: number;
        offset: number;
    };
    layer(key: string): Entity;
    clearLayer(key: string): void;
    text(parent: Entity, text: string, x: number, y: number, size: number, color: Color): Entity;
    rectangle(parent: Entity, x: number, y: number, width: number, height: number, color: Color, z?: number): Entity;
    setChoices(choices: HudChoice[]): void;
    private buildChoices;
    constructor(theme: GameTheme, capacity?: number);
    setActions(actions: HudActions): void;
    layout(width: number, height: number, offset: number): void;
    setTheme(theme: GameTheme): void;
    /** The scoreboard's columns; only values that changed are redrawn. */
    setColumns(columns: HudColumn[]): void;
    setPlaying(playing: boolean, subtext?: string): void;
    update(dt: number, feedback?: HudFeedback): void;
    private showFeedback;
    private layoutFeedback;
    private clearFeedback;
    /** Shows the game-over card over everything (it takes every touch until hidden). */
    showGameOver(card: GameOverCard): void;
    hideGameOver(): void;
    /** Where an RN banner ad sits under the card's buttons (null: no card). */
    get gameOverBanner(): {
        top: number;
        width: number;
    } | null;
    /** Room left in the card for the banner ad (its measured height), in points. */
    setGameOverReserve(height: number): void;
    /** GameView's onOverlayTouch: true when a button took the touch. */
    touch: (phase: "start" | "move" | "end" | "cancel", x: number, y: number) => boolean;
    dispose(): void;
    private release;
    private pulse;
    private fire;
    /** A themed button panel (border behind the face) under a root at its centre. */
    private panel;
    private setOverScore;
    /** The card, laid out top to bottom as GameOverModal; `animate` plays its entrance. */
    private buildOver;
    private buildBoard;
    /** The same primary control for keyboard input, including the results card. */
    activatePrimary(): void;
    /** A column's value: its text, or a row of hearts. */
    private spawnValue;
    private buildControls;
}
/** Reusable assets; the game loader advances one builder per frame. */
export declare function warmAssets(): Iterable<() => unknown>;
export {};
//# sourceMappingURL=EngineHud.d.ts.map