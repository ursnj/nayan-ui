import { type Entity, type World } from '@nayan-ui/engine';
import type { GameTheme } from '../../services/ThemeService';
import { type Layout } from './CheckersConstants';
import type { CheckersBoard, Piece } from './CheckersRules';
type PieceView = {
    root: Entity;
    crown: Entity | null;
};
export type Scene = {
    backdrop: Entity;
    board: Entity[];
    pieces: Map<number, PieceView>;
    select: Entity;
    dots: Entity[];
    rings: Entity[];
    /** Bursts waiting for their moment (a burst can't be delayed), and the scene's clock. */
    queue: {
        at: number;
        run: () => void;
    }[];
    time: number;
};
export declare function buildScene(world: World, l: Layout, theme: GameTheme, board: CheckersBoard): Scene;
export declare function removeScene(world: World, s: Scene): void;
export declare function setSceneTheme(world: World, l: Layout, s: Scene, theme: GameTheme): void;
/** Puts every piece back where the board has it (a new game): the old ones go, fresh ones are set down. */
export declare function resetPieces(world: World, l: Layout, s: Scene, board: CheckersBoard): void;
/** The picked piece's square glows; where it may go shows a green dot (a slide) or a red ring (a jump). */
export declare function showHints(world: World, l: Layout, s: Scene, selected: number, targets: number[], captures: number[]): void;
/** The picked piece lifts a little off the board. */
export declare function lift(world: World, l: Layout, s: Scene, index: number, up: boolean): void;
/**
 * A piece goes from `from` along `path` (its landing squares), sliding or hopping over the pieces it
 * takes (which pop and go as it clears them), and is crowned if it becomes a king. `delay` starts it later.
 */
export declare function movePiece(world: World, l: Layout, s: Scene, from: number, path: number[], captured: number[], king: Piece | null, delay?: number): void;
/** Runs the scene's queued bursts; called once a frame. */
export declare function stepScene(s: Scene, dt: number): void;
/** The game won: confetti over the board, the red pieces hop. */
export declare function celebrate(world: World, l: Layout, s: Scene, board: CheckersBoard): void;
export {};
//# sourceMappingURL=CheckersScene.d.ts.map