/** The four colors, one per quarter of every ring (quarter k from k x 90 degrees, clockwise on screen). */
export declare const GAME_COLORS: readonly ["#FF6B6B", "#FFE66D", "#4ECDC4", "#A855F7"];
export declare const TIME_LIMIT = 120;
export declare const POINTS_PER_PASS = 1000;
export declare const STEP_MS: number;
export declare const STEP_TOLERANCE_MS = 2;
export declare const MAX_PENDING_MS = 50;
export declare const GRAVITY = 0.2;
export declare const JUMP_VELOCITY = -4.5;
export declare const MAX_VELOCITY = 12;
export declare const ROTATION_SPEED = 0.017;
export declare const FORGIVENESS: number;
export declare const SPAWN_MARGIN = 100;
/** Lit from the upper left; faces toward the camera (+z) keep their exact color. */
export declare const LIGHT: import("@nayan-ui/engine").Light;
export type Layout = {
    width: number;
    height: number;
    /** The field's top edge in the view (the original canvas sat centred under the header, as tall as the window). */
    top: number;
    fieldHeight: number;
    ballRadius: number;
    ringRadius: number;
    ringThickness: number;
    gap: number;
    starRadius: number;
    ballStartY: number;
};
export declare function getLayout(width: number, height: number, offset: number): Layout;
//# sourceMappingURL=ColorSwitchConstants.d.ts.map