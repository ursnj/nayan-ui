import { type Entity, type World } from '@nayan-ui/engine';
import type { GameTheme } from '../../services/ThemeService';
import { type Layout } from './SpiderSolitaireConstants';
import { type Board, type Card } from './SpiderSolitaireRules';
/** Where a card should be: its centre on the table, its height, face up or down, its size, picked up or not. */
export type Spot = {
    x: number;
    y: number;
    z: number;
    faceUp: boolean;
    small: boolean;
    selected: boolean;
};
type CardView = {
    body: Entity;
    spot: Spot | null;
};
type Slot = {
    ring: Entity;
    fill: Entity | null;
};
export type Scene = {
    backdrop: Entity;
    piles: Slot[];
    stock: Slot;
    foundation: Slot;
    cards: Map<string, CardView>;
};
/** The table: the backdrop, an outline for each pile, the deck's place and the first run's, and all 104 cards. */
export declare function buildScene(world: World, l: Layout, theme: GameTheme, cards: Card[]): Scene;
export declare function removeScene(world: World, s: Scene): void;
export declare function setSceneTheme(world: World, s: Scene, theme: GameTheme): void;
/** How far down from the pile's top edge each card's top edge is: the original steps, squeezed if the pile would run too long. */
export declare function pileOffsets(l: Layout, pile: Card[]): number[];
/** A pile card's place: its centre and height (each card a little above the one under it). */
export declare function pileSpot(l: Layout, column: number, offset: number, index: number): [number, number, number];
/** What the player holds: a picked-up run (lifted), or a dragged one (following the finger, its top card's centre at x, y). */
export type Held = {
    pile: number;
    index: number;
    drag: {
        x: number;
        y: number;
    } | null;
} | null;
/** Every card's place on the table, from the board and what's held. */
export declare function layoutCards(l: Layout, b: Board, held: Held, onlyHeld?: boolean): Map<string, Spot>;
/**
 * Moves every card that's changed place to its new one: it glides (rising over the cards between and
 * turning over on the way if it flips), after `delay(id)` seconds. `instant` puts them there at once
 * (a dragged run following the finger).
 */
export declare function placeCards(world: World, l: Layout, s: Scene, spots: Map<string, Spot>, delay?: (id: string) => number, instant?: boolean): void;
/** A move that isn't allowed: the cards shake where they are. */
export declare function shakeCards(world: World, s: Scene, ids: string[]): void;
/** A finished run lifted off: a sparkle where it was. */
export declare function sparkle(world: World, l: Layout, x: number, y: number): void;
/** All eight runs home: confetti over the table. */
export declare function celebrate(world: World, l: Layout): void;
export {};
//# sourceMappingURL=SpiderSolitaireScene.d.ts.map