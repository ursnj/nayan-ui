/** Follows every source: for cache keys outside a game folder's namespace. */
export declare const PROCEDURAL_CACHE_VERSION = "4ed78c8647c15e10d298f3c2725979ff";
/** Per namespace ("<folder>/..." keys): a game's own sources, what it imports, shared code and the engine. */
export declare const PROCEDURAL_CACHE_VERSIONS: Readonly<Record<string, string>>;
//# sourceMappingURL=ProceduralCacheVersion.d.ts.map