import { type Camera, type Entity, type Voice, World } from '@nayan-ui/engine';
import { type Fire, Track } from '../car-racing/CarRacingScene';
import type { HudFeedback } from '../shared/EngineHud';
import type { GamePhase as Phase } from '../shared/useEngineGame';
import { type Assets } from './BikeRacingConstants';
export type { Phase };
export declare function createGame(a: Assets, night: boolean): {
    world: World;
    night: boolean;
    track: Track;
    chase: {
        eye: [number, number, number];
        target: [number, number, number];
        initialized: boolean;
    };
    assets: Assets;
    camera: Camera;
    player: {
        root: Entity;
        lean: Entity;
        lights: Entity[];
    };
    horizon: Entity;
    segments: import("../car-racing/CarRacingScene").Segment[];
    traffic: Bike[];
    /** Wrecks on fire. */
    burning: Fire[];
    phase: Phase;
    time: number;
    s: number;
    d: number;
    target: number;
    dragX: number;
    speed: number;
    lateral: number;
    steeringGoal: number;
    steeringPose: {
        yaw: number;
        roll: number;
    };
    spawnTimer: number;
    invulnerable: number;
    scrape: number;
    orbit: number;
    /** Seconds left of the start's wheelie, and of the wobble after a crash. */
    wheelie: number;
    wobble: number;
    /** Score, lives and the countdown live in the engine (Rust), advanced by world.update. */
    readonly score: number;
    readonly lives: number;
    /** Metres left to the finish gate. */
    left: number;
    shake: number;
    engine: Voice | null;
    audible: boolean;
    onPhase: (_p: Phase) => void;
    onScore: (_s: number) => void;
    onLives: (_l: number) => void;
    onDistance: (_metres: number) => void;
    hudFeedback: HudFeedback;
};
export type Game = ReturnType<typeof createGame>;
export declare function start(g: Game): void;
/** Mirrors the shared screen's audible state without letting an engine loop leak to another screen. */
export declare function setAudible(g: Game, enabled: boolean): void;
/** Change the scene in place when the host theme changes. */
export declare function setNight(g: Game, night: boolean): void;
/** Steers toward the finger: `dx` is the drag's distance so far, `metresPerPoint` how far that moves the bike. */
export declare function steer(g: Game, phase: 'start' | 'move' | 'end', dx: number, metresPerPoint: number): void;
/** Stops the run's sounds and frees its world (the screen unmounting). */
export declare function dispose(g: Game): void;
export declare function tick(g: Game, dt: number): void;
export type Bike = {
    root: Entity;
    lean: Entity;
    lights: Entity[];
    s: number;
    d: number;
    /** Its lane's centre, and which lane (0..2). */
    lane: number;
    laneIndex: number;
    /** A gentle weave about the lane's centre. */
    weave: number;
    weaveSpeed: number;
    phase: number;
    /** How far a sideswipe has shoved it out of its line, and how fast it's still sliding. */
    shove: number;
    vshove: number;
    passed: boolean;
    crashed: boolean;
    /** It was sideswiped (no near-miss bonus for it). */
    bumped: boolean;
    /** Seconds until another sideswipe makes a sound again. */
    bumpCooldown: number;
    /** Closest it came beside the player, for near misses. */
    closest: number;
    /** How far ahead of the player it was last frame, and whether it's touching (and met nose to tail). */
    wasAhead: number;
    touching: boolean;
    headOn: boolean;
};
/** Traffic ahead, in a lane that doesn't close the road: bikes close together always leave a lane open. */
export declare function spawnTraffic(g: Game, ahead?: number): void;
/** Demo bot: head for the lane whose next bike is furthest away. */
export declare function autopilot(g: Game): void;
//# sourceMappingURL=BikeRacingGame.d.ts.map