import { type Camera, type DragEvent, World } from '@nayan-ui/engine';
import type { GameTheme } from '../../services/ThemeService';
import type { GamePhase as Phase } from '../shared/useEngineGame';
import { type Layout } from './MemoryMatchConstants';
import { type Card } from './MemoryMatchRules';
import { type Scene } from './MemoryMatchScene';
/** flip: a first card turned; match / wrong: how a pair went; win / lose: how it ended. */
export type GameEvent = 'flip' | 'match' | 'wrong' | 'win' | 'lose';
export declare function createGame(theme: GameTheme): {
    world: World;
    camera: Camera;
    theme: GameTheme;
    layout: Layout | null;
    scene: Scene | null;
    phase: Phase;
    cards: Card[];
    totalPairs: number;
    firstIndex: number;
    /** Input is locked while a miss is shown. */
    lock: boolean;
    matchedPairs: number;
    moves: number;
    /** Score and the countdown live in the engine (Rust), advanced by world.update. */
    readonly score: number;
    readonly timeLeft: number;
    won: boolean;
    press: {
        x: number;
        y: number;
        index: number;
    } | null;
    onPhase: (_p: Phase) => void;
    onPairs: (_matched: number, _total: number) => void;
    onEvent: (_e: GameEvent) => void;
};
export type Game = ReturnType<typeof createGame>;
/** Lays the table out for the view (first layout, header height, rotation): rebuilt where things stand. */
export declare function setLayout(g: Game, l: Layout): void;
export declare function setTheme(g: Game, theme: GameTheme): void;
/** Starts play on the deal already on the table. */
export declare function start(g: Game): void;
/** A fresh deal, not started (Stop, Play Again), as the original store's reset. The world is kept. */
export declare function reset(g: Game): void;
/** Turns a card over: the first of a pair waits, the second matches or misses. */
export declare function flipCard(g: Game, index: number): void;
/** The card under a view point (on the cards' tops), or -1. */
export declare function cardUnder(g: Game, x: number, y: number): number;
/** A tap (down and up without wandering, however long) turns the card under it. */
export declare function drag(g: Game, { phase, x, y }: DragEvent): void;
//# sourceMappingURL=MemoryMatchGame.d.ts.map