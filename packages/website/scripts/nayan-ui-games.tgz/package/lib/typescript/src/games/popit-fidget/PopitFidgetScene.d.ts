import { type Entity, type World } from 'nayan-ui';
import type { GameTheme } from '../../services/ThemeService';
import { type Layout } from './PopitFidgetConstants';
export type Scene = {
    backdrop: Entity;
    sheet: Entity;
    lip: Entity;
    domes: Entity[];
    dimples: Entity[];
};
export declare function buildScene(world: World, l: Layout, theme: GameTheme, popped: readonly boolean[]): Scene;
export declare function removeScene(world: World, s: Scene): void;
export declare function setSceneTheme(world: World, s: Scene, theme: GameTheme): void;
/** Pop: the dome squashes flat under the finger and a dimple springs out in its place, with a few flecks. */
export declare function pop(world: World, l: Layout, s: Scene, index: number): void;
/** Every bubble back up (a new sheet). */
export declare function restore(world: World, l: Layout, s: Scene): void;
/** Confetti over the sheet when every bubble's popped. */
export declare function celebrate(world: World, l: Layout): void;
//# sourceMappingURL=PopitFidgetScene.d.ts.map