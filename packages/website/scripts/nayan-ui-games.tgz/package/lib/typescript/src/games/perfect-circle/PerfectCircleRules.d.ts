export type Point = {
    x: number;
    y: number;
};
export type Circle = {
    centerX: number;
    centerY: number;
    radius: number;
};
export declare const MIN_POINTS = 20;
export declare const WIN_ACCURACY = 80;
export declare const SUCCESS_ACCURACY = 70;
/** The circle that best fits the points (least squares), or the centroid's average radius if they're degenerate. */
export declare function fitCircle(points: Point[]): Circle;
/** The stroke's accuracy (0..100) against the guide circle (centre and radius in view points). */
export declare function accuracyOf(points: Point[], guide: Circle): number;
/** The accuracy levels the game-over card names, best first. */
export declare const ACCURACY_LEVELS: readonly [{
    readonly min: 95;
    readonly label: "PERFECT!";
}, {
    readonly min: 90;
    readonly label: "EXCELLENT!";
}, {
    readonly min: 85;
    readonly label: "GREAT!";
}, {
    readonly min: 80;
    readonly label: "GOOD!";
}, {
    readonly min: 70;
    readonly label: "NICE TRY!";
}, {
    readonly min: 0;
    readonly label: "KEEP TRYING!";
}];
export declare const levelOf: (accuracy: number) => {
    readonly min: 95;
    readonly label: "PERFECT!";
} | {
    readonly min: 90;
    readonly label: "EXCELLENT!";
} | {
    readonly min: 85;
    readonly label: "GREAT!";
} | {
    readonly min: 80;
    readonly label: "GOOD!";
} | {
    readonly min: 70;
    readonly label: "NICE TRY!";
} | {
    readonly min: 0;
    readonly label: "KEEP TRYING!";
};
//# sourceMappingURL=PerfectCircleRules.d.ts.map