import { type Camera, World } from '@nayan-ui/engine';
import type { GameTheme } from '../../services/ThemeService';
import type { GamePhase as Phase } from '../shared/useEngineGame';
import { MobControlRenderer } from './MobControlRenderer';
import { type Scene, type View } from './MobControlScene';
export type GameEvent = 'shoot' | 'gate' | 'hit' | 'clash' | 'boss' | 'damage' | 'champion' | 'win' | 'lose';
export interface Hud {
    score: number;
    hp: number;
    army: number;
    level: number;
}
export declare const INITIAL_HUD: Hud;
export declare function createGame(theme: GameTheme): {
    world: World;
    renderer: MobControlRenderer;
    sim: import("./MobControlRules").Sim;
    camera: Camera;
    night: boolean;
    view: View | null;
    scene: Scene | null;
    phase: Phase;
    won: boolean;
    active: boolean;
    pending: number;
    clock: number;
    lastHud: number;
    lastEffect: number;
    hudKey: string;
    feedback: Partial<Record<GameEvent, number>>;
    readonly score: number;
    onPhase: (_phase: Phase) => void;
    onHud: (_hud: Hud) => void;
    onEvent: (_event: GameEvent) => void;
};
export type Game = ReturnType<typeof createGame>;
export declare function setLayout(g: Game, width: number, height: number): void;
export declare function setTheme(g: Game, theme: GameTheme): void;
export declare function reset(g: Game): void;
export declare function replay(g: Game): void;
export declare function start(g: Game): void;
export declare function aim(g: Game, x: number): void;
export declare function setActive(g: Game, active: boolean): void;
/** Releases the unit renderer; the screen disposes the world after. */
export declare function dispose(g: Game): void;
export declare function tick(g: Game, dt: number): void;
//# sourceMappingURL=MobControlGame.d.ts.map