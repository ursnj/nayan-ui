import type { ClipOptions, Entity, LoadedModel, World } from 'nayan-ui';
import { type PlayWithTuaAnimation } from './PlayWithTuaConstants';
export declare const getCachedCharacter: () => LoadedModel | null;
export declare function loadCharacter(): Promise<LoadedModel>;
export declare function spawnCharacter(world: World, model: LoadedModel): Entity;
/** Native clip playback; independent poses per entity, with no JS vertex updates. */
export declare function playAnimation(world: World, entity: Entity, animation: PlayWithTuaAnimation, options?: ClipOptions): boolean;
/** Reusable assets; the game loader advances one builder per frame. */
export declare function warmAssets(): Iterable<() => unknown>;
//# sourceMappingURL=PlayWithTuaModel.d.ts.map