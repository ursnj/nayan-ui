import type { FruitKind } from '../shared/EngineFruits';
export declare const TIME_LIMIT = 120;
export declare const MAX_LIVES = 3;
export declare const POINTS_PER_FRUIT = 100;
export declare const POINTS_PER_STAR = 500;
export declare const BOMB_CHANCE = 0.18;
export declare const STAR_CHANCE = 0.07;
/** The fruits that fly, as the original version's set (all modelled in EngineFruits). */
export declare const FRUIT_KINDS: readonly FruitKind[];
export declare const FIRST_WAVE = 1;
export declare const WAVE_SIZE = 2;
export declare const WAVE_STAGGER = 0.7;
export declare const WAVE_INTERVAL = 1.8;
export declare const WAVE_JITTER = 0.4;
export declare const WAVE_MIN = 0.5;
export declare const FRAME_TIME: number;
export declare const MAX_FRAMES = 2;
export declare const FRUIT_SIZE: number;
/** Mesh detail for fruit this small (EngineFruits: 0.35 still looks round at 60 points); about level² the vertices of full detail. */
export declare const FRUIT_DETAIL: number;
/** Fruit built back to back when the screen opens (enough to play); the rest follow one every FRUIT_BUILD_GAP ms. */
export declare const FIRST_FRUITS = 3;
export declare const FRUIT_BUILD_GAP = 300;
export declare const WALL_BOUNCE = 0.8;
export declare const SPIN_RANGE = 0.2;
export declare const BLADE_WINDOW = 0.07;
export declare const BLADE_POINTS = 10;
export declare const SPAWN_FROM = 0.55;
export declare const SPAWN_SPRING: {
    damping: number;
    stiffness: number;
};
export declare const TRAIL_FADE = 0.22;
export declare const PIECE_LIFETIME = 1.1;
export declare const PIECE_SPREAD = 2.5;
export declare const BOMB_COLORS: readonly ["#1f2937", "#374151", "#f97316", "#fde047"];
export declare const STAR_COLORS: readonly ["#fbbf24", "#f59e0b", "#fef3c7", "#ffffff"];
export type Layout = {
    /** The GameView's size: the whole screen, as the original game area. */
    width: number;
    height: number;
    offset: number;
    /** Fruits fly within the game area's width, centred (the original version used its left part). */
    fieldLeft: number;
    fieldWidth: number;
    size: number;
    gravity: number;
    /** Launch speed up, so a fruit peaks near the top on any screen height. */
    launchVy: number;
    launchVxRange: number;
    spawnY: number;
};
export declare function getLayout(width: number, height: number, offset: number): Layout;
//# sourceMappingURL=FruitNinjaConstants.d.ts.map