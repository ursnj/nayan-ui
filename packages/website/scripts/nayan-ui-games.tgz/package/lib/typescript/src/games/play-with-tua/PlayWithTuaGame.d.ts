import { type DragEvent, type LoadedModel, World } from '@nayan-ui/engine';
import type { GameTheme } from '../../services/ThemeService';
import { type ActionSoundCue, type PlayWithTuaAnimation } from './PlayWithTuaConstants';
import { type Scene } from './PlayWithTuaScene';
export interface Game extends Scene {
    world: World;
    phase: 'ready' | 'playing';
    score: number;
    move: PlayWithTuaAnimation;
    angle: number;
    dragStart: number;
    dragging: boolean;
    inputTop: number;
    inputBottom: number;
    audible: boolean;
    moveTime: number;
    soundTime: number;
    onSound: (cue: ActionSoundCue) => void;
    onSilence: () => void;
    onPhase: (phase: 'ready' | 'playing' | 'over') => void;
    onScore: (score: number) => void;
    onMove: (move: PlayWithTuaAnimation) => void;
}
export declare function createGame(model: LoadedModel, theme: GameTheme): Game;
export declare function reset(g: Game): void;
export declare function start(g: Game): void;
export declare function selectMove(g: Game, move: PlayWithTuaAnimation): void;
export declare function cycleMove(g: Game): void;
export declare function drag(g: Game, event: DragEvent): void;
export declare function resize(g: Game, width: number, height: number, offset: number): void;
export declare function setTheme(g: Game, theme: GameTheme): void;
export declare function tick(g: Game, dt: number): void;
export declare function setAudible(g: Game, audible: boolean): void;
/** Silences Tua's voices; the world is disposed after this. */
export declare function dispose(g: Game): void;
//# sourceMappingURL=PlayWithTuaGame.d.ts.map