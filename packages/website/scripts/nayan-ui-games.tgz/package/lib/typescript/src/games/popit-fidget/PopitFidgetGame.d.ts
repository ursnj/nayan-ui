import { type Camera, World } from 'nayan-ui';
import type { GameTheme } from '../../services/ThemeService';
import type { GamePhase as Phase } from '../shared/useEngineGame';
import { type Layout } from './PopitFidgetConstants';
import { type Scene } from './PopitFidgetScene';
export declare function createGame(theme: GameTheme): {
    world: World;
    camera: Camera;
    theme: GameTheme;
    layout: Layout | null;
    scene: Scene | null;
    phase: Phase;
    popped: boolean[];
    count: number;
    /** Score and the countdown live in the engine (Rust), advanced by world.update. */
    readonly score: number;
    readonly timeLeft: number;
    won: boolean;
    onPhase: (_p: Phase) => void;
    onScore: (_s: number) => void;
    onPop: () => void;
};
export type Game = ReturnType<typeof createGame>;
/** Lays the scene out for the view (first layout, header height, rotation): rebuilt from the sheet's state. */
export declare function setLayout(g: Game, l: Layout): void;
export declare function setTheme(g: Game, theme: GameTheme): void;
/** A fresh sheet, and the clock running. */
export declare function start(g: Game): void;
/** A fresh sheet, not started (Stop, Play Again). The world, and the GPU view drawing it, are kept. */
export declare function reset(g: Game): void;
/** The unpopped bubble under a view point, if any. */
export declare function bubbleAt(g: Game, x: number, y: number): number | null;
/** A finger comes down: pops the bubble under it. */
export declare function press(g: Game, x: number, y: number): void;
//# sourceMappingURL=PopitFidgetGame.d.ts.map