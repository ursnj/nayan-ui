import { type Entity, type LoadedModel, type Quat, type Texture, type TransformBatch, type Vec3, type World } from '@nayan-ui/engine';
import { type HumanAnimation, type Point } from './TreasureHuntConstants';
import { type NatureMap } from './TreasureHuntRules';
export interface HumanAssets {
    model: LoadedModel;
    atlas: Texture;
    soleIndices: Uint32Array;
    supportIndices: Uint32Array;
    leftCount: number;
}
/** Native GLB skinning shares one mesh and clips across every explorer instance. */
export declare function loadHumanAssets(): Promise<HumanAssets>;
export interface Human {
    root: Entity;
    body: Entity;
    animation: HumanAnimation | null;
    rate: number;
    strikes: number;
    phase: number;
    indices: Uint32Array;
    supportIndices: Uint32Array;
    samples: Float32Array;
    leftCount: number;
    soles: [[number, number, number], [number, number, number]];
    shadows: [Entity[], Entity[]];
}
export declare function spawnHuman(world: World, position: Vec3, assets: HumanAssets): Human;
/** Query only boot vertices; full-body skinning and clip blending stay on the native GPU path. */
export declare function placeHuman(world: World, human: Human, map: NatureMap, point: Point, yaw: number, dt?: number, updates?: TransformBatch): void;
export declare function playHuman(world: World, human: Human, animation: HumanAnimation, speed?: number): void;
export declare function resetHuman(world: World, human: Human): void;
export declare function advanceHuman(human: Human, dt: number): void;
export interface RobotVisual {
    root: Entity;
    warning: Entity;
    chassis: Entity;
    head: Entity;
    armL: Entity;
    armR: Entity;
    elbowL: Entity;
    elbowR: Entity;
    legL: Entity;
    legR: Entity;
    kneeL: Entity;
    kneeR: Entity;
    motion: 'idle' | 'walk' | 'attack' | 'stagger' | null;
    /** Game time it last moved: walking holds briefly after, so a patrol that catches up doesn't flicker. */
    movedAt: number;
    colorState: number | null;
    warningVisible: boolean;
    pose: [number, number, number, number];
}
export declare function spawnRobot(world: World, x: number, y: number, z: number): RobotVisual;
export declare function placeRobot(world: World, visual: RobotVisual, x: number, z: number, y: number, yaw: number, windup: number, stagger: number, moving: boolean, time: number, updates?: TransformBatch): void;
/** One cached mesh for all foot and trunk contact shadows, owned by their actor/scenery root. */
export declare function spawnContactShadow(world: World, parent: Entity): Entity[];
export declare function placeContactShadow(world: World, layers: Entity[], position: Vec3, rotation: Quat, width: number, depth: number, opacity: number, updates?: TransformBatch): void;
/** The explorer loader and robot caches are shared with the actual game. */
export declare function warmAssets(): Iterable<() => unknown>;
//# sourceMappingURL=TreasureHuntModel.d.ts.map