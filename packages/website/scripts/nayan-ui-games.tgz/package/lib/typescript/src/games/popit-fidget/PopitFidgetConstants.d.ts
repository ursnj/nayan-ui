import type { TiltView } from '../shared/EngineTilt';
export declare const GRID_SIZE = 6;
export declare const TIME_LIMIT = 120;
export declare const POINTS_PER_BUBBLE = 250;
export declare const TIME_WARNING = 10;
/** One vivid color per row, top to bottom. */
export declare const ROW_COLORS: readonly ["#FF3B3B", "#32CD32", "#FFD700", "#4DA6FF", "#BF5AF2", "#FF9500"];
export declare const PRESS_TIME = 0.07;
export declare const FLIP_TIME = 0.16;
/** The camera leans back from straight down, so the domes stand up off the sheet. */
export declare const TILT = 0.4;
/** Lit from straight overhead with strong ambient, so nothing falls into shadow; surfaces facing up off the sheet (+z) keep their exact color. */
export declare const LIGHT: import("@nayan-ui/engine").Light;
export type Layout = TiltView & {
    bubble: number;
    spacing: number;
    /** The sheet: the bubbles plus `GRID_PADDING` all round. */
    sheet: number;
};
/**
 * A bubble as big as the original grid had it (the game area, 30 narrower than the screen and at most 500
 * across, filled edge to edge), smaller if the screen is short; the sheet centred under the scoreboard.
 */
export declare function getLayout(width: number, height: number, offset: number): Layout;
/** A bubble's centre on the sheet (row 0 along the top), in world units. */
export declare function bubbleCentre(l: Layout, row: number, col: number): [number, number];
//# sourceMappingURL=PopitFidgetConstants.d.ts.map