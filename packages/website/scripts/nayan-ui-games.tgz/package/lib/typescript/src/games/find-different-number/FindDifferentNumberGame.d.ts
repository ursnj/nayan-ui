import { type Camera, type DragEvent, World } from '@nayan-ui/engine';
import type { GameTheme } from '../../services/ThemeService';
import type { GamePhase as Phase } from '../shared/useEngineGame';
import { type Layout } from './FindDifferentNumberConstants';
import { type Puzzle } from './FindDifferentNumberRules';
import { type Scene } from './FindDifferentNumberScene';
/** correct / wrong: a tap's verdict; win / lose: how it ended. */
export type GameEvent = 'correct' | 'wrong' | 'win' | 'lose';
export declare function createGame(theme: GameTheme): {
    world: World;
    camera: Camera;
    theme: GameTheme;
    layout: Layout | null;
    scene: Scene | null;
    phase: Phase;
    puzzle: Puzzle;
    found: Set<number>;
    won: boolean;
    /** Score and the countdown live in the engine (Rust), advanced by world.update. */
    readonly score: number;
    readonly timeLeft: number;
    onPhase: (_p: Phase) => void;
    onLeft: (_n: number) => void;
    onEvent: (_e: GameEvent) => void;
};
export type Game = ReturnType<typeof createGame>;
/** Lays the board out for the view (first layout, header height, rotation): rebuilt where things stand. */
export declare function setLayout(g: Game, l: Layout): void;
export declare function setTheme(g: Game, theme: GameTheme): void;
/** Starts on the round already shown. */
export declare function start(g: Game): void;
/** A fresh round, not started (Stop, Play Again, as the original game). */
export declare function reset(g: Game): void;
/** A tap on a cell: a different number found, or a wrong guess (three seconds off). Found cells are ignored. */
export declare function tapCell(g: Game, i: number): void;
/** The cell under a view point (on the tiles' tops), or -1. */
export declare function cellUnder(g: Game, x: number, y: number): number;
/** Taps land on touch-down, as the original grid's did. */
export declare function drag(g: Game, { phase, x, y }: DragEvent): void;
//# sourceMappingURL=FindDifferentNumberGame.d.ts.map