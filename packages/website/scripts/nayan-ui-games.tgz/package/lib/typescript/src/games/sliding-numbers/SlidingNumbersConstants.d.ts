import type { TiltView } from '../shared/EngineTilt';
export declare const GAME_DURATION = 300;
export declare const SLIDE_TIME = 0.2;
export declare const PRESS_SCALE = 0.92;
export declare const TAP_SLOP = 10;
export declare const SWIPE = 18;
/** Tiles 1..8, as the original tiles. */
export declare const TILE_COLORS: readonly ["#FF6B6B", "#51CF66", "#339AF0", "#FCC419", "#CC5DE8", "#FF922B", "#22B8CF", "#F06595"];
export declare const NUMBER_WORDS: readonly ["", "ONE", "TWO", "THREE", "FOUR", "FIVE", "SIX", "SEVEN", "EIGHT"];
export declare const COLORS: {
    readonly FRAME: "#5c4033";
    readonly WELL: "#3a2518";
    readonly SLOT: "#2e1d12";
    readonly NUMBER: "#FFFFFF";
};
/** The camera leans back from straight down, so the tiles stand up off the board. */
export declare const TILT = 0;
/** Lit straight on, with no light falling from the top: every face toward the camera keeps its exact color. */
export declare const LIGHT: import("@nayan-ui/engine").Light;
/** A tile's height, of its width. */
export declare const TILE_HEIGHT = 0.4;
export type Layout = TiltView & {
    tile: number;
    gap: number;
    pitch: number;
    pad: number;
    size: number;
};
/** The board as big as the original board (88% of the width, at most 340 points, 420 on a tablet), smaller if the screen is short. */
export declare function getLayout(width: number, height: number, offset: number, tablet: boolean): Layout;
/** A cell's centre on the board (row 0 along the top), in world units. */
export declare const cellCentre: (l: Layout, row: number, col: number) => [number, number];
/** The cell under a board point, or null. */
export declare function cellAt(l: Layout, x: number, y: number): [number, number] | null;
//# sourceMappingURL=SlidingNumbersConstants.d.ts.map