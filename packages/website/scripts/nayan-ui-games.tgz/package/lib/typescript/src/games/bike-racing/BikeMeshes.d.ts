import { type Model } from '@nayan-ui/engine';
import type { Footprint } from '../shared/EngineFootprint';
/**
 * The bike's outline from above, with its rider, for collisions: the narrow tyres at each end, the
 * fairing, the bars and grips at their widest, the rider's knees and boots, then the slim tail.
 */
export declare const BIKE_FOOTPRINT: Footprint;
export type BikeMeshes = {
    body: Model;
    trim: Model;
    glass: Model;
};
/** The bike's three meshes, built once per app. */
export declare function bikeMeshes(): BikeMeshes;
//# sourceMappingURL=BikeMeshes.d.ts.map