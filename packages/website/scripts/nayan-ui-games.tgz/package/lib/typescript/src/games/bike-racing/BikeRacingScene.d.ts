import { type Color, type Entity, type Vec3, type World } from '@nayan-ui/engine';
import { type Assets } from './BikeRacingConstants';
/**
 * A bike: an invisible root at its middle (the collider's centre once wrecked), a lean pivot where the
 * tyres touch the road, and on it the body (painted), tyres, rider and helmet (in the bike's color).
 */
export declare function spawnBike(world: World, a: Assets, paint: Color, position: Vec3, night: boolean): {
    root: Entity;
    lean: Entity;
    lights: Entity[];
};
/** Repaint lights without rebuilding the bike or disturbing its lean and wheelie. */
export declare function setBikeNight(world: World, bike: {
    root: Entity;
    lean: Entity;
    lights: Entity[];
}, night: boolean): void;
/**
 * Leans a bike `roll` radians into a turn (positive to the right) about where its tyres touch the
 * road, and lifts its nose `wheelie` radians about the rear tyre. `ground` is the pivot's place under
 * the root (half the bike's height down).
 */
export declare function leanBike(world: World, lean: Entity, ground: number, roll: number, wheelie?: number): void;
/** Reusable assets; the game loader advances one builder per frame. */
export declare function warmAssets(): Iterable<() => unknown>;
//# sourceMappingURL=BikeRacingScene.d.ts.map