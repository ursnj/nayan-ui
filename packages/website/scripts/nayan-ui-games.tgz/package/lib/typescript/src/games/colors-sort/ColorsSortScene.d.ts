import { type Entity, type World } from '@nayan-ui/engine';
import type { GameTheme } from '../../services/ThemeService';
import { type Layout } from './ColorsSortConstants';
export declare const pieceColor: (colorIndex: number) => [number, number, number, number];
export type Tube = {
    glass: Entity;
    rim: Entity;
    streak: Entity;
    edges: Entity[];
    cork: Entity;
};
export type Scene = {
    backdrop: Entity;
    tubes: Tube[];
};
export declare function buildScene(world: World, l: Layout, theme: GameTheme): Scene;
export declare function removeScene(world: World, s: Scene): void;
export declare function setSceneTheme(world: World, s: Scene, theme: GameTheme): void;
export declare function spawnPiece(world: World, l: Layout, colorIndex: number, tube: number, slot: number): Entity;
/** Picked up: the top puck springs up out of its tube and hovers. */
export declare function liftPiece(world: World, l: Layout, piece: Entity, tube: number): void;
/** Put back: it drops into its own slot again. */
export declare function lowerPiece(world: World, l: Layout, piece: Entity, tube: number, slot: number): void;
/** Moved: it flies over to the other tube's mouth, then drops in and settles with a bounce. */
export declare function movePiece(world: World, l: Layout, piece: Entity, from: number, to: number, slot: number): void;
/** A refused tap: the tube and what's in it shake. */
export declare function shakeTube(world: World, l: Layout, t: Tube, pieces: Entity[]): void;
/** A whole color in one tube: it pops, sparkles in that color and a cork drops into its mouth. */
export declare function completeTube(world: World, l: Layout, t: Tube, tube: number, colorIndex: number): void;
/** The cork in a sorted tube's mouth (dropping in, or simply there), or taken away. */
export declare function showCork(world: World, l: Layout, t: Tube, tube: number, on: boolean, animate?: boolean): void;
/** Confetti over the shelves when everything's sorted. */
export declare function celebrate(world: World, l: Layout): void;
//# sourceMappingURL=ColorsSortScene.d.ts.map