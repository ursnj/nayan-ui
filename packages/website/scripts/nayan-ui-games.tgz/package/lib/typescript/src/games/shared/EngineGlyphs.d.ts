import { type Model } from '@nayan-ui/engine';
/** A stroke's tube radius, and the space a character takes in a run of text (both in glyph heights). */
export declare const GLYPH_RADIUS = 0.1;
export declare const GLYPH_ADVANCE = 0.72;
export declare const GLYPH_WIDTH = 0.6;
/** Whether a character has a glyph. */
export declare const hasGlyph: (char: string) => boolean;
/** A character's mesh, one glyph height tall at scale 1 (spawn it with `scale` = the height you want). */
export declare function glyphMesh(char: string): Model;
/**
 * A character printed flat and matte (numbers on a board, not standing up): the glyph pressed to a
 * twentieth of its depth, with no highlight, so it reads evenly everywhere on a flat surface. `weight`
 * thickens its strokes (1 is the usual; bolder reads better small).
 */
export declare function flatGlyphMesh(char: string, weight?: number): Model;
//# sourceMappingURL=EngineGlyphs.d.ts.map