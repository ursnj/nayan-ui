import type { TiltView } from '../shared/EngineTilt';
export declare const GAME_DURATION = 120;
export declare const POINTS_PER_FIND = 500;
export declare const WRONG_PENALTY = 3;
export declare const COLORS: {
    readonly CLASSIC_BOARD: "rgba(255, 255, 255, 0.10)";
    readonly CLASSIC_RIM: "rgba(255, 255, 255, 0.35)";
    readonly LIGHT_BOARD: "#D3DBE8";
    readonly LIGHT_RIM: "#AEBBD0";
    readonly TILE: "#FFFFFF";
    readonly TEXT: "#0D1757";
    readonly FOUND: "#4FC562";
    readonly FOUND_TEXT: "#FFFFFF";
    readonly WRONG: "#FF5252";
};
/** The camera looks straight down at the board. */
export declare const TILT = 0;
/** Evenly lit, straight from the camera and all ambient: every face keeps its exact color, with no shading anywhere. */
export declare const LIGHT: import("@nayan-ui/engine").Light;
/** A tile's height, of its width. */
export declare const TILE_HEIGHT = 0.2;
export declare const FOUND_SCALE = 1.18;
export type Layout = TiltView & {
    tile: number;
    gap: number;
    pitch: number;
    pad: number;
    size: number;
};
/** Tiles as wide as the screen allows (as the original grid), smaller if the screen is short. */
export declare function getLayout(width: number, height: number, offset: number, tablet: boolean): Layout;
/** A cell's centre (row 0 along the top), in world units. */
export declare const cellCentre: (l: Layout, i: number) => [number, number];
/** The cell under a board point (on a tile, not the gap between), or -1. */
export declare function cellAt(l: Layout, x: number, y: number): number;
//# sourceMappingURL=FindDifferentNumberConstants.d.ts.map