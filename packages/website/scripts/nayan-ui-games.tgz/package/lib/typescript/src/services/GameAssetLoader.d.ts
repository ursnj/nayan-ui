export type AssetTask = () => unknown;
export interface AssetStage {
    label: string;
    tasks: () => Iterable<AssetTask>;
}
export interface LoadTiming {
    afterPaint(run: () => void): () => void;
    now?: () => number;
}
/**
 * Work per frame while the loader is up. The loading scene itself takes only a few milliseconds to
 * step and draw, so most of each 16.7 ms frame can go to loading. (It used to be 4 ms: three
 * quarters of every frame sat idle and a game took four times as long to load.)
 */
export declare const FRAME_BUDGET_MS = 10;
/** Paint first, then batch small jobs within a frame budget, yielding between expensive builders. */
export declare class GameAssetLoader {
    private stages;
    private changed;
    private finished;
    private failed;
    private clock;
    private stage;
    private iterator?;
    private task?;
    private cancel?;
    private active;
    private busy;
    private disposed;
    private done;
    constructor(stages: readonly AssetStage[], changed: (label: string) => void, finished: () => void, failed: (error: unknown) => void, clock?: LoadTiming);
    start(): void;
    pause(): void;
    dispose(): void;
    private schedule;
    private step;
    private reject;
}
//# sourceMappingURL=GameAssetLoader.d.ts.map