import { type Camera, type DragEvent, World } from '@nayan-ui/engine';
import type { GameTheme } from '../../services/ThemeService';
import type { GamePhase as Phase } from '../shared/useEngineGame';
import { type Layout } from './SpaceFighterConstants';
import { type Belt, type Ship, type Space } from './SpaceFighterScene';
export type GameEvent = 'grab' | 'release' | 'dodge' | 'hit';
/** A falling pair: the top of its belts (screen y), where its gap starts, and whether it's been passed. */
type Pair = {
    top: number;
    gapLeft: number;
    passed: boolean;
    seed: number;
    belts: Belt | null;
};
export declare function createGame(theme: GameTheme): {
    world: World;
    camera: Camera;
    layout: Layout | null;
    space: Space | null;
    /** Day (the sun) or night (the moon), from the theme. */
    day: boolean;
    ship: Ship | null;
    phase: Phase;
    /** Score, lives and the countdown live in the engine (Rust), advanced by world.update. */
    readonly score: number;
    readonly lives: number;
    readonly timeLeft: number;
    won: boolean;
    shipX: number;
    bank: number;
    lastShipX: number;
    dragging: boolean;
    dragFrom: number;
    dragStart: number;
    pairs: Pair[];
    nextSpawn: number;
    lastHit: number;
    clock: number;
    seed: number;
    onPhase: (_p: Phase) => void;
    onEvent: (_e: GameEvent) => void;
};
export type Game = ReturnType<typeof createGame>;
/** A new theme: the sun comes out by day, the moon by night; the run carries on. */
export declare function setTheme(g: Game, theme: GameTheme): void;
/** Lays the world out for the view (first layout, header height, rotation): rebuilt from the game's state. */
export declare function setLayout(g: Game, l: Layout): void;
export declare function start(g: Game): void;
/** Back to a fresh, unstarted game (Stop, Play Again). The world, and the GPU view drawing it, are kept. */
export declare function reset(g: Game): void;
export declare function tick(g: Game, frame: number): void;
/** Dragging anywhere moves the ship sideways by as much as the finger moves. */
export declare function drag(g: Game, { phase, x }: DragEvent): void;
export {};
//# sourceMappingURL=SpaceFighterGame.d.ts.map