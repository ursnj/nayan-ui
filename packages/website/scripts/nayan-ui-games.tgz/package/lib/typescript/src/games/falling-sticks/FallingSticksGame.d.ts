import { type Camera, type DragEvent, World } from '@nayan-ui/engine';
import type { GameTheme } from '../../services/ThemeService';
import type { GamePhase as Phase } from '../shared/useEngineGame';
import { type Layout } from './FallingSticksConstants';
import { type Field } from './FallingSticksRules';
import { type Scene } from './FallingSticksScene';
/** catch: a stick caught (one per stick); miss: one landed (one per stick); win / lose: how it ended. */
export type GameEvent = 'catch' | 'miss' | 'win' | 'lose';
export declare function createGame(theme: GameTheme): {
    world: World;
    camera: Camera;
    theme: GameTheme;
    layout: Layout | null;
    scene: Scene | null;
    phase: Phase;
    field: Field;
    /** Score, lives and the countdown live in the engine (Rust), advanced by world.update. */
    readonly lives: number;
    readonly score: number;
    readonly timeLeft: number;
    won: boolean;
    /** The finger's recent points, for its trail (only while playing). */
    trail: number[];
    pending: number;
    onPhase: (_p: Phase) => void;
    onEvent: (_e: GameEvent) => void;
};
export type Game = ReturnType<typeof createGame>;
/** Lays the field out for the view (first layout, header height, rotation), or the night sky for a dark theme: rebuilt where things stand. */
export declare function setLayout(g: Game, l: Layout): void;
/** Change the scenery in place while preserving the current run and stick colors. */
export declare function setTheme(g: Game, theme: GameTheme): void;
export declare function start(g: Game): void;
/** Back to an empty field, not started (Stop, Play Again). The world, and the GPU view drawing it, are kept. */
export declare function reset(g: Game): void;
/** The sticks in fixed 60 Hz frames, then the world stepped with a long frame clamped. */
export declare function tick(g: Game, dt: number): void;
/** Down catches the sticks under the finger at once; moving catches every stick it passes over, leaving a trail. */
export declare function drag(g: Game, { phase, x, y, cancelled }: DragEvent): void;
//# sourceMappingURL=FallingSticksGame.d.ts.map