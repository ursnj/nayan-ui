import { type Model } from '@nayan-ui/engine';
export type VehicleStyle = 'compact' | 'taxi' | 'pickup' | 'bus';
export interface VehicleMeshes {
    body: Model;
    details: Model;
    lights: Model;
}
export interface CrossyMeshes {
    vehicles: Record<VehicleStyle, VehicleMeshes>;
    tree: Model;
    bush: Model;
    rock: Model;
}
export declare function crossyMeshes(): CrossyMeshes;
/** Reusable assets; the game loader advances one builder per frame. */
export declare function warmAssets(): Iterable<() => unknown>;
//# sourceMappingURL=CrossyRoadMeshes.d.ts.map