import { type Camera, type DragEvent, World } from '@nayan-ui/engine';
import type { GamePhase as Phase } from '../shared/useEngineGame';
import { type Layout } from './CrossyRoadConstants';
import { type Hop, type Player, type Vehicle } from './CrossyRoadRules';
import { type Scene } from './CrossyRoadScene';
/** hop: a hop taken; cross: a road crossed (and the goal reached); crash: hit; timeUp: the clock ran out. */
export type GameEvent = 'hop' | 'cross' | 'crash' | 'timeUp';
type Dir = 'up' | 'down' | 'left' | 'right';
type MovingHop = {
    from: Player;
    to: Player;
    result: Hop;
    elapsed: number;
    direction: Dir;
};
export declare function createGame(night: boolean): {
    world: World;
    camera: Camera;
    assets: import("./CrossyRoadMeshes").CrossyMeshes;
    night: boolean;
    layout: Layout | null;
    scene: Scene | null;
    phase: Phase;
    traffic: Vehicle[];
    nextId: number;
    player: Player;
    hopping: MovingHop | null;
    queuedHop: Dir | null;
    alive: boolean;
    won: boolean;
    /** Score and the countdown live in the engine (Rust), advanced by world.update. */
    readonly score: number;
    /** The whole seconds shown. */
    timeLeft: number;
    pending: number;
    clock: number;
    /** A finger down: where and when, and whether it's already swiped. */
    press: {
        x: number;
        y: number;
        at: number;
        swiped: boolean;
    } | null;
    onPhase: (_p: Phase) => void;
    onScore: (_s: number, _crossings: number) => void;
    onTime: (_t: number) => void;
    onEvent: (_e: GameEvent) => void;
};
export type Game = ReturnType<typeof createGame>;
/** Lays the board out for the view (first layout, header height, rotation): a fresh board is dealt for the new size. */
export declare function setLayout(g: Game, l: Layout): void;
/** Day or night (the dark theme): the scene is rebuilt where things stand. */
export declare function setNight(g: Game, night: boolean): void;
/** Start: a fresh board, and the clock running (as the original Start dealt one). */
export declare function start(g: Game): void;
/** Stop and Play Again: a fresh board, waiting. The world, and the GPU view drawing it, are kept. */
export declare function reset(g: Game): void;
export declare function tick(g: Game, dt: number): void;
/** Finish the active hop before taking one buffered move; taps cannot teleport through traffic. */
export declare function hopTo(g: Game, dir: Dir): void;
/** A tap hops forward; a swipe hops its way (as soon as it's gone far enough, once per touch). */
export declare function drag(g: Game, { phase, x, y, cancelled }: DragEvent): void;
export {};
//# sourceMappingURL=CrossyRoadGame.d.ts.map