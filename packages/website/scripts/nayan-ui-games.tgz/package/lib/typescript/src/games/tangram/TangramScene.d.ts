import { type Entity, type Quat, type World } from '@nayan-ui/engine';
import type { GameTheme } from '../../services/ThemeService';
import { type Layout } from './TangramConstants';
import { type TangramLevel } from './TangramRules';
/** Where a tan is drawn: its centre (board points), turn (degrees, clockwise on screen), size and height (tan units). */
export type Pose = {
    x: number;
    y: number;
    rot: number;
    scale: number;
    lift: number;
};
type TanView = {
    root: Entity;
    slab: Entity;
    rim: Entity;
};
export type Scene = {
    backdrop: Entity;
    slots: Entity[];
    tans: TanView[];
};
/** A turn clockwise on screen (y down) is a turn the other way in the world (y up). */
export declare const turn: (deg: number) => Quat;
export declare function buildScene(world: World, l: Layout, theme: GameTheme, level: TangramLevel, poses: Pose[]): Scene;
export declare function removeScene(world: World, s: Scene): void;
export declare function setSceneTheme(world: World, s: Scene, theme: GameTheme): void;
/** Puts a tan at a pose at once (following the finger). */
export declare function setPose(world: World, l: Layout, s: Scene, id: number, p: Pose): void;
/** Glides a tan to a pose. */
export declare function moveTo(world: World, l: Layout, s: Scene, id: number, p: Pose, duration: number, easing?: 'easeOut' | 'back'): void;
/** A new level: every tan grows in on its tray spot, one after another. */
export declare function enter(world: World, l: Layout, s: Scene, poses: Pose[], stagger: number): void;
/** A tan snapped into its slot: a small pop as it lands. */
export declare function pop(world: World, l: Layout, s: Scene, id: number, delay: number): void;
/** Over a matching slot at the wrong turn: a wiggle. */
export declare function wiggle(world: World, s: Scene, id: number, rot: number): void;
/** Solved: a wave of pops round the shape, and confetti over it. */
export declare function celebrate(world: World, l: Layout, s: Scene, level: TangramLevel, delay: number, stagger: number): void;
/** Out of time: the tans still in the tray dim. */
export declare function dim(world: World, s: Scene, ids: number[], colors: string[]): void;
export {};
//# sourceMappingURL=TangramScene.d.ts.map