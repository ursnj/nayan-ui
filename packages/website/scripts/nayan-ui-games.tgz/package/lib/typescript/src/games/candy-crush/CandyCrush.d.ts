export declare const CandyCrush: import("react").FC<import("../..").GameProps>;
//# sourceMappingURL=CandyCrush.d.ts.map