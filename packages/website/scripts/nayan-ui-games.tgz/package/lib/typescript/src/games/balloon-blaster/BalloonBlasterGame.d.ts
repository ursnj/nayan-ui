import { type Camera, type Entity, World } from '@nayan-ui/engine';
import type { GameTheme } from '../../services/ThemeService';
import { type View3D } from '../shared/EngineMeadow';
import type { GamePhase as Phase } from '../shared/useEngineGame';
import { type Layout } from './BalloonBlasterConstants';
import { type BalloonKind } from './BalloonBlasterScene';
/** A balloon: its box's top-left in screen points and its velocity per frame. */
type Balloon = {
    what: BalloonKind;
    x: number;
    y: number;
    vx: number;
    vy: number;
    root: Entity;
};
export declare function createGame(theme: GameTheme): {
    world: World;
    camera: Camera;
    theme: GameTheme;
    layout: Layout | null;
    view: View3D | null;
    /** Everything in the world around the play area (sky, hills, trees, ...). */
    scenery: Entity[];
    phase: Phase;
    /** Score, lives and the countdown live in the engine (Rust), advanced by world.update. */
    readonly score: number;
    readonly lives: number;
    won: boolean;
    /** Game clock, seconds: drives spawning (it pauses with the frame loop). */
    time: number;
    pending: number;
    balloons: Balloon[];
    onPhase: (_p: Phase) => void;
    onTime: (_t: number) => void;
    onPop: () => void;
    onBomb: () => void;
    onWin: () => void;
    onLose: () => void;
};
export type Game = ReturnType<typeof createGame>;
/** Lays the world out for the view (first layout, rotation). Balloons in the air are cleared. */
export declare function setLayout(g: Game, l: Layout): void;
/** A new theme: day or night (the screen swaps the light); the run carries on. */
export declare function setTheme(g: Game, theme: GameTheme): void;
export declare function start(g: Game): void;
/** A fresh run (Stop, Play Again). The world, and the GPU view drawing it, are kept. */
export declare function reset(g: Game): void;
export declare function dispose(g: Game): void;
export declare function tick(g: Game, dt: number): void;
/**
 * Finger down: pops the balloon under it (its body and string, padded for fingertips). Bombs win over
 * balloons they overlap, as they're drawn on top; otherwise the balloon whose body centre is nearest.
 */
export declare function touch(g: Game, x: number, y: number): void;
export {};
//# sourceMappingURL=BalloonBlasterGame.d.ts.map