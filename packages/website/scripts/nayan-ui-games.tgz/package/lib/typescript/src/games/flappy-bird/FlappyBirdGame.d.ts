import { type Camera, type Entity, World } from '@nayan-ui/engine';
import type { GameTheme } from '../../services/ThemeService';
import { type View3D } from '../shared/EngineMeadow';
import type { GamePhase as Phase } from '../shared/useEngineGame';
import { type Layout } from './FlappyBirdConstants';
import { type BirdView, type Walls } from './FlappyBirdScene';
/** A pipe pair: its left edge (screen points) and its gap. */
type Pipe = {
    x: number;
    gapTop: number;
    gapBottom: number;
    passed: boolean;
    root: Entity;
};
export declare function createGame(theme: GameTheme): {
    world: World;
    camera: Camera;
    theme: GameTheme;
    layout: Layout | null;
    view: View3D | null;
    /** The meadow around the play area. */
    scenery: Entity[];
    walls: Walls | null;
    /** How far the pipes (and the walls with them) have scrolled, in points. */
    scroll: number;
    bird: BirdView | null;
    phase: Phase;
    /** Score and the countdown live in the engine (Rust), advanced by world.update. */
    readonly score: number;
    readonly timeLeft: number;
    won: boolean;
    /** Game clock, seconds: drives the pipe spawns (it pauses with the frame loop). */
    time: number;
    /** Unspent frame time, stepped in fixed 60 Hz steps. */
    pending: number;
    birdY: number;
    velocity: number;
    /** How the bird looks this frame: its lean (eased toward its speed's), its wings, time since the last flap, the next blink. */
    tiltShown: number;
    wingPhase: number;
    wingLift: number;
    farLift: number;
    flapT: number;
    blinkIn: number;
    pipes: Pipe[];
    onPhase: (_p: Phase) => void;
    onFlap: () => void;
    onPass: () => void;
    onCrash: () => void;
    onWin: () => void;
};
export type Game = ReturnType<typeof createGame>;
/** Lays the world out for the view and header: the meadow, the walls and the bird, from the run's state. */
export declare function setLayout(g: Game, l: Layout): void;
/** A new theme: day or night (the screen swaps the light); the run carries on. */
export declare function setTheme(g: Game, theme: GameTheme): void;
export declare function start(g: Game): void;
/** A fresh run (Stop, Play Again): the bird back at the start, hovering. The world is kept. */
export declare function reset(g: Game): void;
/** Its timers stop before the world is disposed. */
export declare function dispose(g: Game): void;
/** The bird and pipes in fixed steps, and the bird's looks; the engine steps the world after. */
export declare function tick(g: Game, dt: number): void;
/** Finger down: flap. */
export declare function flap(g: Game): void;
export {};
//# sourceMappingURL=FlappyBirdGame.d.ts.map