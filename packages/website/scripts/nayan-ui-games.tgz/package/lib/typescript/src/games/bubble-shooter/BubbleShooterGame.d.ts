import { type Camera, type Entity, World } from '@nayan-ui/engine';
import type { GameTheme } from '../../services/ThemeService';
import type { GamePhase as Phase } from '../shared/useEngineGame';
import { type Layout } from './BubbleShooterConstants';
import { type Scenery } from './BubbleShooterScene';
type Bubble = {
    x: number;
    y: number;
    color: number;
    row: number;
    entity: Entity | null;
};
type Shot = {
    x: number;
    y: number;
    vx: number;
    vy: number;
    color: number;
    entity: Entity;
};
export declare function createGame(theme: GameTheme): {
    world: World;
    camera: Camera;
    theme: GameTheme;
    layout: Layout | null;
    scenery: Scenery | null;
    phase: Phase;
    /** Score and the countdown live in the engine (Rust), advanced by world.update. */
    readonly score: number;
    readonly timeLeft: number;
    won: boolean;
    /** Built for the first layout (positions depend on the bubble size). */
    bubbles: Bubble[] | null;
    /** The shooter's loaded color and the one after it. */
    current: number;
    next: number;
    currentEntity: Entity | null;
    nextEntity: Entity | null;
    aimDots: Entity[];
    /** Aim, radians from straight up (right is positive). */
    angle: number;
    shot: Shot | null;
    /** The next board to appear fills in. */
    intro: boolean;
    /** Game seconds the current intro has been playing (-1 until its board spawns). */
    introAge: number;
    onPhase: (_p: Phase) => void;
    onBubbles: (_n: number) => void;
    onShoot: () => void;
    onPop: () => void;
    onWin: () => void;
    onLose: () => void;
};
export type Game = ReturnType<typeof createGame>;
/** Lays the scene out for the view (first layout, header height, rotation): rebuilt from the run's state. */
export declare function setLayout(g: Game, l: Layout): void;
/** A new theme: the background, board and aim dots are repainted; the run carries on. */
export declare function setTheme(g: Game, theme: GameTheme): void;
export declare function start(g: Game): void;
/** A new board and timer (Stop, Play Again). The world, and the GPU view drawing it, are kept. */
export declare function reset(g: Game): void;
export declare function dispose(g: Game): void;
/** The shot's flight; the engine steps the world after. */
export declare function tick(g: Game, dt: number): void;
/** Aims at a view point (a finger), clamped to ±72° from straight up. */
export declare function aimAt(g: Game, x: number, y: number): void;
/** Fires the loaded bubble along the aim; the next one loads, from the colors on the board. */
export declare function fire(g: Game): void;
export {};
//# sourceMappingURL=BubbleShooterGame.d.ts.map