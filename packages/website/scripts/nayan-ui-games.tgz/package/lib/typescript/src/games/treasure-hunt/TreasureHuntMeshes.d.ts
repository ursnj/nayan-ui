import { type Geometry, type Vec3 } from 'nayan-ui';
import { type Landscape } from './TreasureHuntRules';
export type HumanSoles = readonly [Vec3, Vec3];
/** Keep the support foot planted; retain airborne height only for running. */
export declare function humanSupportHeight(feet: HumanSoles, ground: readonly [number, number], airborne?: boolean): number;
/** A shared horizontal disc; layered at low alpha for a soft contact shadow. */
export declare function contactShadowGeometry(): Geometry;
/** A brilliant cut: table, star/bezel crown, thin girdle and pointed pavilion.
 * Each facet owns flat normals and a cool reflected-light tint, so cuts stay crisp while spinning. */
export declare function diamondGeometry(): Geometry;
export interface TerrainGeometry {
    meadow: Geometry;
    stone: Geometry;
    shore: Geometry;
}
export declare function terrainGeometry(profile: number): TerrainGeometry;
/** The same vertices and contours, yielded in row batches so preparation cannot monopolize JS. */
export declare function terrainGeometrySteps(profile: number): Generator<void, TerrainGeometry>;
export declare function riverGeometry(land: Landscape): Geometry;
/** Hollow stone tunnel: both exterior and interior faces, open portals at either end. */
export declare function caveGeometry(): Geometry;
/** Irregular stratified boulders, with smooth normals and repeatable UVs rather than scaled cubes. */
export declare function boulderGeometry(style: number): Geometry;
export declare function foliageGeometry(pine: boolean, style: number): Geometry;
/** Tiny bent blades, distributed in shared clumps; actual grass rather than an entirely flat field. */
export declare function grassGeometry(style: number): Geometry;
//# sourceMappingURL=TreasureHuntMeshes.d.ts.map