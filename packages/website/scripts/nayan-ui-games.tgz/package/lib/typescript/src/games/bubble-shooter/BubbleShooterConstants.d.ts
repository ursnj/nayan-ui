export declare const ROW_COUNT = 5;
export declare const COLS_PER_ROW = 9;
export declare const COLOR_COUNT = 4;
export declare const MIN_MATCH = 3;
export declare const POINTS_PER_BUBBLE = 200;
export declare const TIME_LIMIT = 300;
export declare const BUBBLE_COLORS: readonly ["#FF3B3B", "#32CD32", "#FFD700", "#4DA6FF", "#BF5AF2"];
export declare const SHOT_SPEED = 20;
export declare const FRAME_TIME: number;
export declare const MAX_AIM_ANGLE: number;
export declare const TOP_BOUNDARY = 10;
export declare const SNAP_FROM = 0.55;
export declare const POP_SPRING: {
    damping: number;
    stiffness: number;
};
export declare const INTRO_SPRING: {
    damping: number;
    stiffness: number;
};
export declare const INTRO_ROW_STAGGER = 0.055;
export declare const INTRO_SWEEP = 0.0006;
export declare const LOAD_FROM = 0.4;
export declare const NEXT_DELAY = 0.08;
export declare const BURST_TIME = 0.45;
export declare const AIM_DOT_COUNT = 40;
export declare const AIM_DOT_SPACING = 18;
export declare const AIM_DOT_RADIUS_START = 3;
export declare const AIM_DOT_RADIUS_END = 1.5;
export declare const AIM_ALPHA_NEAR = 0.6;
export declare const AIM_ALPHA_FAR = 0.3;
export declare const LIGHT: import("@nayan-ui/engine").Light;
export declare const BUBBLE_SHINE = 0.4;
export declare const CLASSIC_BOARD = "rgba(255, 255, 255, 0.30)";
export declare const CLASSIC_BORDER = "rgba(255, 255, 255, 0.35)";
export declare const CLASSIC_AIM = "#ffffff";
export declare const CLASSIC_RADIUS = 16;
export declare const THEMED_RADIUS = 8;
export type Layout = {
    /** The GameView's size. */
    width: number;
    height: number;
    /** The board fits between the shared HUD and controls, independently of its full-width background. */
    boardLeft: number;
    boardTop: number;
    boardWidth: number;
    boardHeight: number;
    radius: number;
    /** From one bubble's centre to its neighbour's. */
    diameter: number;
    /** Where shots leave from and aim is measured. All positions are board points, from its top-left. */
    shooterX: number;
    shooterY: number;
    /** Where a shot's centre stays between (it bounces off the side walls). */
    minX: number;
    maxX: number;
};
export declare function getLayout(width: number, height: number, offset: number): Layout;
//# sourceMappingURL=BubbleShooterConstants.d.ts.map