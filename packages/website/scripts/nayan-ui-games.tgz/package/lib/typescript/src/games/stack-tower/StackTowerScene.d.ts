import { type Entity, type Vec3, type World } from 'nayan-ui';
import type { GameTheme } from '../../services/ThemeService';
import { aimTilted, type TiltView } from '../shared/EngineTilt';
import { type Layout } from './StackTowerConstants';
export type Scene = {
    frameOffset?: number;
    backdrop: Entity;
    plinth: Entity;
    blocks: Entity[];
    moving: Entity | null;
};
/** The view the camera frames, scrolled down by `offset` points as the tower grows. */
export declare const viewFor: (l: Layout, offset: number) => TiltView;
/** A block's face centre in the world, from its top-left in tower points. */
export declare function blockAt(l: Layout, x: number, y: number): Vec3;
export declare const blockColor: (level: number) => [number, number, number, number];
export declare function buildScene(world: World, l: Layout, theme: GameTheme): Scene;
export declare function removeScene(world: World, s: Scene): void;
export declare function setSceneTheme(world: World, s: Scene, theme: GameTheme): void;
/** Frames the tower: the camera scrolled `offset` down, the backdrop kept fixed behind it. */
export declare function frame(world: World, l: Layout, s: Scene, camera: Parameters<typeof aimTilted>[0], offset: number): void;
export declare function spawnBlock(world: World, l: Layout, x: number, y: number, level: number, fadeIn?: boolean): Entity;
export declare function slideBlock(world: World, l: Layout, e: Entity, x: number, y: number): void;
/** A block set down: it flashes bright and puffs dust from under its ends; a perfect one also rings gold. */
export declare function land(world: World, l: Layout, e: Entity, x: number, y: number, level: number, perfect: boolean): void;
/** A missed block tumbles off the way it was sliding, fading as it goes. */
export declare function tumble(world: World, l: Layout, e: Entity, x: number, y: number, direction: number, level: number): void;
//# sourceMappingURL=StackTowerScene.d.ts.map