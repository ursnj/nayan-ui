import type { Light } from '@nayan-ui/engine';
export declare const TIME_LIMIT = 120;
export declare const LIVES = 3;
export declare const DODGE_POINTS = 500;
export declare const HIT_COOLDOWN = 2;
export declare const BASE_FRAME = 0.016;
export declare const MAX_FRAME = 0.064;
/** How far ahead of the camera the game plays, in world units: screen points map onto this plane. */
export declare const PLAY_DEPTH = 12;
export declare const FOV = 0.9;
export declare const BACKGROUND = "#050311";
export declare const DAY_BACKGROUND = "#A8DCF7";
/** A cool starlight from the upper left, a touch of violet in the shadows. */
export declare const LIGHT: Light;
export type Layout = {
    width: number;
    height: number;
    offset: number;
    /** World units per screen point on the play plane. */
    k: number;
    shipSize: number;
    shipY: number;
    beltHeight: number;
    gap: number;
    spawnInterval: number;
    /** Points per second. */
    fallSpeed: number;
    spawnY: number;
    /** Where the scoreboard ends, for the start hint. */
    scoreboardBottom: number;
};
export declare function getLayout(width: number, height: number, offset: number): Layout;
/** Where a pair's opening goes: near the centre, wandering a little, never squeezing a belt off the edge. */
export declare function gapLeft(l: Layout, random?: () => number): number;
//# sourceMappingURL=SpaceFighterConstants.d.ts.map