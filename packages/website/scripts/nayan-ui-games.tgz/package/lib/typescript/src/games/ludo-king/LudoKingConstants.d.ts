export type PlayerColor = 'red' | 'green' | 'yellow' | 'blue';
export declare const GRID = 15;
export declare const TOKENS_PER_PLAYER = 4;
export declare const TRACK_LENGTH = 56;
export declare const MAX_SIXES = 3;
export declare const PLAYER_COLORS: Record<PlayerColor, string>;
export declare const BOARD_WHITE = "#FBF7EC";
export declare const BOARD_FRAME = "#2A2550";
export declare const STAR_COLOR = "#8A8AA0";
export declare const PLAYER_COLOR: string;
export declare const AI_COLOR: string;
export declare const ROLL_TIME = 0.9;
export declare const MOVE_DELAY = 0.35;
export declare const HOP_TIME = 0.14;
export declare const NEXT_TURN_DELAY = 0.45;
export declare const PENALTY_DELAY = 0.9;
export declare const CANT_MOVE_DELAY = 0.6;
export declare const AI_THINK = 0.7;
export declare const TILT = 0.35;
export declare const LIGHT: import("@nayan-ui/engine").Light;
export declare const RIM = 0.014;
export declare const TILE_TOP = 0.012;
export declare const DIE_SIZE = 0.15;
export declare const DIE_Y: number;
export declare const TOKEN_HEIGHT = 0.07;
/** Absolute index on MAIN_PATH where each player joins. */
export declare const ENTRY: Record<PlayerColor, number>;
/** Entry cells and stars: no capture here. */
export declare const SAFE_POSITIONS: number[];
/** The 52 shared cells, clockwise, as {row, col} on the 15 x 15 grid. */
export declare const MAIN_PATH: {
    row: number;
    col: number;
}[];
/** Each player's 6 home-stretch cells, from the first inside the arm to the centre. */
export declare const HOME_STRETCH: Record<PlayerColor, {
    row: number;
    col: number;
}[]>;
/** The four token yards in each player's home base. */
export declare const HOME_YARDS: Record<PlayerColor, {
    row: number;
    col: number;
}[]>;
export declare const CENTER: {
    row: number;
    col: number;
};
/** A grid cell (row, col; may be fractional for yards) as a board-unit point (x right, y up, centred). */
export declare function cellPoint(row: number, col: number): [number, number];
export type Layout = {
    width: number;
    height: number;
    size: number;
    centerY: number;
};
export declare function getLayout(width: number, height: number, offset: number): Layout;
/** Where a point on (or `z` above) the board, in board units, appears in the view. */
export declare function toView(l: Layout, x: number, y: number, z?: number): [number, number];
//# sourceMappingURL=LudoKingConstants.d.ts.map