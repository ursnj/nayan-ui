import { type Camera, type DragEvent, World } from '@nayan-ui/engine';
import type { GameTheme } from '../../services/ThemeService';
import type { GamePhase as Phase } from '../shared/useEngineGame';
import { type Layout } from './SudokuConstants';
import { type Puzzle } from './SudokuRules';
import { type Scene } from './SudokuScene';
/** place: a right number; wrong: a wrong one; win / lose: how it ended. */
export type GameEvent = 'place' | 'wrong' | 'win' | 'lose';
export declare function createGame(theme: GameTheme): {
    world: World;
    camera: Camera;
    theme: GameTheme;
    layout: Layout | null;
    scene: Scene | null;
    phase: Phase;
    puzzle: Puzzle;
    filled: number;
    selRow: number;
    selCol: number;
    /** Score and the countdown live in the engine (Rust), advanced by world.update. */
    readonly score: number;
    readonly timeLeft: number;
    won: boolean;
    /** A finger down: where, and on which key (0 on the board). */
    press: {
        x: number;
        y: number;
        key: number;
    } | null;
    onPhase: (_p: Phase) => void;
    onEvent: (_e: GameEvent) => void;
};
export type Game = ReturnType<typeof createGame>;
/** Lays the board out for the view (first layout, header height, rotation): rebuilt where things stand. */
export declare function setLayout(g: Game, l: Layout): void;
export declare function setTheme(g: Game, theme: GameTheme): void;
/** Starts on the puzzle already shown, nothing selected. */
export declare function start(g: Game): void;
/** A fresh puzzle, not started (Stop, Play Again, as the original game). */
export declare function reset(g: Game): void;
/** Selects a cell (any cell, given or not). */
export declare function select(g: Game, row: number, col: number): void;
/** Places a number in the selected cell (not a given one): checked against the solution and scored. */
export declare function enter(g: Game, n: number): void;
/** What's under a view point: a number key (1..9), a cell, or nothing. */
export declare function hitAt(g: Game, x: number, y: number): {
    key: number;
} | {
    cell: [number, number];
} | null;
/** A finger down presses a key in; a tap (lifting without wandering) selects a cell or enters a number. */
export declare function drag(g: Game, { phase, x, y }: DragEvent): void;
//# sourceMappingURL=SudokuGame.d.ts.map