import { type Camera, type DragEvent, World } from '@nayan-ui/engine';
import type { GameTheme } from '../../services/ThemeService';
import type { GamePhase as Phase } from '../shared/useEngineGame';
import { type Layout } from './Snake3DConstants';
import { type Scene } from './Snake3DScene';
/** eat / special: food eaten; crash: a wall or the body. */
export type GameEvent = 'eat' | 'special' | 'crash';
export declare function createGame(theme: GameTheme): {
    world: World;
    camera: Camera;
    theme: GameTheme;
    layout: Layout | null;
    scene: Scene | null;
    phase: Phase;
    st: import("./Snake3DRules").SnakeState;
    /** The cells as of the move before last, for the glide. */
    prev: number[];
    pending: number;
    /** Score and the countdown live in the engine (Rust), advanced by world.update. */
    readonly score: number;
    readonly timeLeft: number;
    /** Seconds on the game's clock (the bonus food's expiry runs on it, so a pause can't expire it). */
    clock: number;
    moves: number;
    /** Where the current drag stretch began (each 15 points one way is a swipe). */
    anchor: [number, number] | null;
    onPhase: (_p: Phase) => void;
    onEvent: (_e: GameEvent) => void;
};
export type Game = ReturnType<typeof createGame>;
/** Lays the board out for the view (first layout, header height, rotation): rebuilt where things stand. */
export declare function setLayout(g: Game, l: Layout): void;
export declare function setTheme(g: Game, theme: GameTheme): void;
export declare function start(g: Game): void;
/** Stop and Play Again: the idle board. The world, and the GPU view drawing it, are kept. */
export declare function reset(g: Game): void;
/** The game's clock, the snake's steps and its glide; the engine steps the world after. */
export declare function tick(g: Game, dt: number): void;
/** Swipes anywhere turn the snake: each stretch of 15 points one way is a turn, so one drag can chain them. */
export declare function drag(g: Game, { phase, x, y, cancelled }: DragEvent): void;
//# sourceMappingURL=Snake3DGame.d.ts.map