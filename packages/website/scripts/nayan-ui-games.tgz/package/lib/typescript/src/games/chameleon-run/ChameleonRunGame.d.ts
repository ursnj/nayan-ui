import { type Camera, type DragEvent, World } from '@nayan-ui/engine';
import type { GameTheme } from '../../services/ThemeService';
import type { GamePhase as Phase } from '../shared/useEngineGame';
import { type Config, type RunColor } from './ChameleonRunConstants';
import { type Failure, type Run } from './ChameleonRunRules';
import { type Scene } from './ChameleonRunScene';
export type GameEvent = 'jump' | 'land' | 'star' | 'swap' | 'hurt' | 'fall' | 'win';
export interface RunHud {
    color: RunColor;
    next: RunColor | null;
    combo: number;
    jumps: number;
    progress: number;
    failure: Failure | null;
}
export declare const INITIAL_HUD: RunHud;
export declare function createGame(theme: GameTheme): {
    world: World;
    camera: Camera;
    theme: GameTheme;
    config: Config | null;
    scene: Scene | null;
    run: Run | null;
    phase: Phase;
    running: boolean;
    won: boolean;
    active: boolean;
    pending: number;
    clock: number;
    lastScoreSync: number;
    syncedScore: number;
    shownDistance: number;
    shownLives: number;
    finishSpeed: number;
    coast: number;
    dragFired: boolean;
    hudKey: string;
    cameraLift: number;
    onPhase: (_p: Phase) => void;
    onScore: (_s: number) => void;
    onStars: (_n: number) => void;
    onDistance: (_metres: number) => void;
    onLives: (_lives: number) => void;
    onHud: (_hud: RunHud) => void;
    onEvent: (_e: GameEvent) => void;
};
export type Game = ReturnType<typeof createGame>;
export declare function setLayout(g: Game, width: number, height: number): void;
export declare function setTheme(g: Game, theme: GameTheme): void;
export declare function start(g: Game): void;
export declare function reset(g: Game): void;
export declare function dispose(g: Game): void;
export declare function setActive(g: Game, active: boolean): void;
export declare function tick(g: Game, dt: number): void;
export declare function tap(g: Game): void;
export declare function swap(g: Game): void;
/** Penguin Run's mid-stroke response: one jump as soon as an upward swipe passes 18 points. */
export declare function steer(g: Game, e: DragEvent): void;
/** A stroke that already jumped must never also switch color when its finger is released. */
export declare function changeColor(g: Game): void;
//# sourceMappingURL=ChameleonRunGame.d.ts.map