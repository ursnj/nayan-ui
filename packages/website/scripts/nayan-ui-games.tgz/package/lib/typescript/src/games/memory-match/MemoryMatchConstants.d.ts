import type { TiltView } from '../shared/EngineTilt';
export declare const GAME_DURATION = 300;
export declare const MISMATCH_DELAY = 0.8;
export declare const POINTS_PER_MATCH = 1000;
export declare const WIN_BONUS = 5000;
export declare const FLIP_TIME = 0.22;
export declare const TAP_SLOP = 12;
export declare const COLORS: {
    readonly CARD_FRONT: "#FFFDF7";
    readonly CARD_MATCHED: "#E5F7EC";
    readonly FRONT_BORDER: "#DFE3F1";
    readonly MATCHED_BORDER: "#8BD3AD";
    readonly MATCHED_BADGE: "#32A875";
    readonly BACK_TOP: "#6378E0";
    readonly BACK_BOTTOM: "#3E4EAE";
    readonly BACK_BORDER: "#97A7EF";
    readonly BACK_HALO: "#6072CE";
    readonly BACK_MOTIF: "#EAF0FF";
    readonly BACK_PAIR: "#B9CCFF";
};
/** The camera leans back a little from straight down, so the cards and fruit stand up. */
export declare const TILT = 0.2;
/** Lit from the upper left; surfaces facing up off the table (+z) keep their exact color. */
export declare const LIGHT: import("@nayan-ui/engine").Light;
/** A card's thickness, and its fruit's size, of its width. */
export declare const THICKNESS = 0.28;
/** The flat face of EngineBlocks' bevel occupies 78% of the block's width. */
export declare const FACE_SIZE = 0.78;
export declare const FRUIT_SIZE = 0.62;
/**
 * Mesh detail for the card fruit (EngineFruits): about as big on screen as Fruit Ninja's, so the same
 * lighter models serve both games; ten full-detail fruit would be built in one frame on the first deal.
 */
export declare const FRUIT_DETAIL: number;
export type Layout = TiltView & {
    rows: number;
    cols: number;
    card: number;
    gap: number;
    pitch: number;
    boardW: number;
    boardH: number;
};
/** Fill the shared game width without outer gutters; fit shorter screens inside the available height. */
export declare function getLayout(width: number, height: number, offset: number, tablet: boolean): Layout;
/** A card's centre on the table (index row-major, row 0 along the top), in world units. */
export declare function cardCentre(l: Layout, i: number): [number, number];
/** The card under a table point (not in the gaps), or -1. */
export declare function cardAt(l: Layout, x: number, y: number): number;
//# sourceMappingURL=MemoryMatchConstants.d.ts.map