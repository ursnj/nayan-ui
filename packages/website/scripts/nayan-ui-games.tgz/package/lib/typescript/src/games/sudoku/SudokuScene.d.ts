import { type Entity, type World } from '@nayan-ui/engine';
import type { GameTheme } from '../../services/ThemeService';
import { type Layout } from './SudokuConstants';
import type { Cell } from './SudokuRules';
/** How a cell reads: selected, wrong, sharing the selected number, in the selected cell's row / column / box, or none. */
export type Highlight = 'selected' | 'same' | 'peer' | 'none';
type Key = {
    root: Entity;
    block: Entity;
    digit: Entity;
    count: Entity;
};
export type Scene = {
    backdrop: Entity;
    board: Entity[];
    cells: Entity[];
    /** The digit on each cell (null while empty), and what it shows. */
    digits: (Entity | null)[];
    shown: string[];
    selected: number;
    keys: Key[];
    keyCounts: number[];
};
declare const cellTop: (l: Layout) => number;
declare const keyTop: (l: Layout) => number;
export declare function buildScene(world: World, l: Layout, theme: GameTheme): Scene;
export declare function removeScene(world: World, s: Scene): void;
export declare function setSceneTheme(world: World, l: Layout, s: Scene, theme: GameTheme): void;
/**
 * Brings every cell up to date: its tint for the highlight, and its digit (spawned, recolored or
 * removed only where it changed). `pop` is the cell just placed: its digit drops in.
 */
export declare function drawGrid(world: World, l: Layout, s: Scene, grid: Cell[][], highlight: (r: number, c: number) => Highlight, pop?: number): void;
/** The keys' counts of digits left, greyed out at none. */
export declare function drawKeys(world: World, l: Layout, s: Scene, counts: number[]): void;
/** A key pressed down into the board while touched. */
export declare function pressKey(world: World, l: Layout, s: Scene, n: number, down: boolean): void;
/** A wrong number: the cell shakes. */
export declare function shakeCell(world: World, l: Layout, s: Scene, i: number): void;
/** A completed row / column / box (or the whole board): its cells hop and flash in a sweep from `origin`. */
export declare function flash(world: World, l: Layout, s: Scene, cells: number[], origin: number): void;
/** Solved: confetti over the board. */
export declare function celebrate(world: World, l: Layout): void;
export { keyTop, cellTop };
//# sourceMappingURL=SudokuScene.d.ts.map