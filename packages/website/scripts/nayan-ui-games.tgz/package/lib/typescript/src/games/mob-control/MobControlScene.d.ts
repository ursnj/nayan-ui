import { type Camera, type Entity, type World } from '@nayan-ui/engine';
import type { Sim } from './MobControlRules';
export interface View {
    width: number;
    height: number;
    k: number;
}
interface BaseView {
    root: Entity;
    body: Entity;
    bar: Entity;
    digits: Entity[];
    shown: string;
    hp: number;
    captured: boolean;
}
interface GateView {
    root: Entity;
    panel: Entity;
    hits: number;
    factor: number;
}
interface BarrierView {
    root: Entity;
    digits: Entity[];
    shown: number;
    broken: boolean;
}
interface BossView {
    root: Entity;
    bar: Entity;
    digits: Entity[];
    shown: number;
    visible: boolean;
}
export interface Scene {
    root: Entity;
    battleRoot: Entity;
    cannon: Entity;
    barrel: Entity;
    chargeBar: Entity;
    chargeShown: number;
    battle: Sim | null;
    bases: BaseView[];
    gates: GateView[];
    barriers: BarrierView[];
    boss: BossView | null;
    night: boolean;
}
export declare function makeView(width: number, height: number, camera: Camera): View;
export declare function buildScene(world: World, night: boolean, sim: Sim): Scene;
export declare function syncScene(world: World, s: Scene, sim: Sim, labels: boolean): void;
export declare function recoil(world: World, s: Scene): void;
export declare function battleEffect(world: World, x: number, z: number, player: boolean): void;
export declare function captured(world: World, x: number, z: number): void;
export declare function celebrate(world: World): void;
export declare function removeScene(world: World, s: Scene): void;
export {};
//# sourceMappingURL=MobControlScene.d.ts.map