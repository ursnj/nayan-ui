import { type GameProps } from '../../services/UtilsService';
export declare const PlayWithTua: import("react").FC<GameProps>;
//# sourceMappingURL=PlayWithTua.d.ts.map