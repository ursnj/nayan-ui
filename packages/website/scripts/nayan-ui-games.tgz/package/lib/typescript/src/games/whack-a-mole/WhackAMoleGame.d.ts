import { type Camera, World } from '@nayan-ui/engine';
import type { GameTheme } from '../../services/ThemeService';
import type { GamePhase as Phase } from '../shared/useEngineGame';
import { type Layout } from './WhackAMoleConstants';
import { type Scene } from './WhackAMoleScene';
export type GameEvent = 'spawn' | 'hit' | 'miss' | 'empty' | 'warning';
export declare function createGame(theme: GameTheme): {
    world: World;
    camera: Camera;
    theme: GameTheme;
    layout: Layout | null;
    hitLayout: Layout | null;
    hitZones: {
        rim: [number, number];
        up: [number, number];
        down: [number, number];
        reach: number;
    }[];
    scene: Scene | null;
    phase: Phase;
    /** Score and the countdown live in the engine (Rust), advanced by world.update. */
    readonly score: number;
    readonly timeLeft: number;
    /** Which holes have a mole up, and when each one ducks back (game clock). */
    up: boolean[];
    hideAt: number[];
    nextSpawn: number;
    /** Seconds on the game's clock, for spawns and each mole's time up. */
    clock: number;
    onPhase: (_p: Phase) => void;
    onEvent: (_e: GameEvent) => void;
};
export type Game = ReturnType<typeof createGame>;
/** Lays the world out for the view (first layout, header height, rotation): rebuilt from the game's state. */
export declare function setLayout(g: Game, l: Layout): void;
/** A new theme: day or night (the screen swaps the light); the game carries on. */
export declare function setTheme(g: Game, theme: GameTheme): void;
export declare function start(g: Game): void;
/** Back to a fresh, unstarted game (Stop, Play Again). The world, and the GPU view drawing it, are kept. */
export declare function reset(g: Game): void;
/** The game's clock, ducking and spawning moles; the engine steps the world after. */
export declare function tick(g: Game, dt: number): void;
/**
 * The hole a view point is over: its rim, or the mole standing in it. Each hole's zone reaches half way
 * to its neighbours in its row (the far row's are smaller, as it looks), and the nearest one wins.
 */
export declare function holeAt(g: Game, x: number, y: number): number | null;
/** A tap: a hit lands on the hole under it at once, whacking the mole if one's up. */
export declare function tap(g: Game, x: number, y: number): void;
//# sourceMappingURL=WhackAMoleGame.d.ts.map