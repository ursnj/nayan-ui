import { type Camera, type DragEvent, World } from '@nayan-ui/engine';
import type { GameTheme } from '../../services/ThemeService';
import type { GamePhase as Phase } from '../shared/useEngineGame';
import { type Layout } from './TangramConstants';
import { type TangramLevel } from './TangramRules';
import { type Scene } from './TangramScene';
/** rotate: a tan turned; place: one snapped in; wrong: dropped over its slot at the wrong turn; win / lose: how it ended. */
export type GameEvent = 'rotate' | 'place' | 'wrong' | 'win' | 'lose';
/** A tan's state: its centre (board points), its turn (degrees, clockwise), and whether it's in a slot. */
type Tan = {
    x: number;
    y: number;
    rot: number;
    placed: boolean;
};
export declare function createGame(theme: GameTheme): {
    world: World;
    camera: Camera;
    theme: GameTheme;
    layout: Layout | null;
    scene: Scene | null;
    phase: Phase;
    level: number;
    data: TangramLevel | null;
    tans: Tan[];
    occupied: boolean[];
    /** The tan last picked up (shown full size, on top), or -1. */
    active: number;
    /** A finger on a tan: where it went down (view and board points), when, and whether it's dragging. */
    held: {
        id: number;
        sx: number;
        sy: number;
        bx: number;
        by: number;
        ox: number;
        oy: number;
        at: number;
        moved: boolean;
    } | null;
    placed: number;
    /** Score and the countdown live in the engine (Rust), advanced by world.update. */
    readonly score: number;
    readonly timeLeft: number;
    won: boolean;
    /** Seconds since the game was made, for telling taps from holds. */
    clock: number;
    onPhase: (_p: Phase) => void;
    onPlaced: (_n: number) => void;
    onEvent: (_e: GameEvent) => void;
};
export type Game = ReturnType<typeof createGame>;
/** Lays the board out for the view (first layout, header height, rotation): the level is rebuilt for its size. */
export declare function setLayout(g: Game, l: Layout): void;
export declare function setTheme(g: Game, theme: GameTheme): void;
export declare function start(g: Game): void;
/** Stop: back to the first silhouette, set out afresh (as the original game). */
export declare function stop(g: Game): void;
/** Play Again: the next silhouette after a win, the same one again after running out of time. */
export declare function playAgain(g: Game): void;
/** The game's clock; the engine steps the world after. */
export declare function tick(g: Game, dt: number): void;
/** The tan under a board point: the active one first, then the higher ids (drawn above), never a placed one. */
export declare function tanAt(g: Game, bx: number, by: number): number;
export declare function drag(g: Game, e: DragEvent): void;
export {};
//# sourceMappingURL=TangramGame.d.ts.map