import { type Camera, type DragEvent, World } from '@nayan-ui/engine';
import type { GameTheme } from '../../services/ThemeService';
import type { GamePhase as Phase } from '../shared/useEngineGame';
import { type Layout } from './SlidingNumbersConstants';
import { type Board, type Tile } from './SlidingNumbersRules';
import { type Scene } from './SlidingNumbersScene';
/** move: a tile slid; blocked: a tile that can't move; win / lose: how it ended. */
export type GameEvent = 'move' | 'blocked' | 'win' | 'lose';
export declare function createGame(theme: GameTheme): {
    world: World;
    camera: Camera;
    theme: GameTheme;
    layout: Layout | null;
    scene: Scene | null;
    phase: Phase;
    board: Board;
    won: boolean;
    /** Score and the countdown live in the engine (Rust), advanced by world.update. */
    readonly score: number;
    readonly timeLeft: number;
    /** A finger down on a tile: where, and which. */
    press: {
        x: number;
        y: number;
        id: number;
    } | null;
    onPhase: (_p: Phase) => void;
    onEvent: (_e: GameEvent) => void;
};
export type Game = ReturnType<typeof createGame>;
/** Lays the board out for the view (first layout, header height, rotation): rebuilt where things stand. */
export declare function setLayout(g: Game, l: Layout): void;
export declare function setTheme(g: Game, theme: GameTheme): void;
/** Starts on the board already shown. */
export declare function start(g: Game): void;
/** Stop: the same board, the clock back to five minutes (as the original game). */
export declare function stop(g: Game): void;
/** Play Again: a fresh shuffle, the tiles gliding to their new places. */
export declare function newBoard(g: Game): void;
/** Slides a tile into the gap if it's beside it; shakes it if not. A solved board wins. */
export declare function move(g: Game, t: Tile): void;
/** The tile under a view point (on the tiles' tops), or null. */
export declare function tileUnder(g: Game, x: number, y: number): Tile | null;
/** A finger down sinks the tile under it; a tap slides it, and so does a swipe toward the gap. */
export declare function drag(g: Game, { phase, x, y }: DragEvent): void;
//# sourceMappingURL=SlidingNumbersGame.d.ts.map