export declare const GRID_COLS = 12;
export declare const GRID_ROWS = 16;
export declare const TOTAL_CELLS: number;
export declare const TIME_LIMIT = 300;
export declare const POINTS_PER_ARROW = 500;
export declare enum Direction {
    UP = 0,
    RIGHT = 1,
    DOWN = 2,
    LEFT = 3
}
/** Row and column steps per direction (plain lookups: destructuring is slow on Hermes in hot loops). */
export declare const DIR_DR: readonly number[];
export declare const DIR_DC: readonly number[];
export declare const FLY_TIME = 0.8;
export declare const BLOCK_TIME = 0.32;
export declare const BLOCK_SHAKE = 5;
export declare const BLOCKER_TIME = 0.42;
export declare const DOT_DELAY = 0.12;
export declare const DOT_SPRING: {
    damping: number;
    stiffness: number;
};
export declare const DRAW_IN_TIME = 0.7;
export declare const DRAW_IN_STAGGER = 0.35;
export declare const ENTRANCE_TIME = 0.35;
export declare const COMPLETION_SCALE = 1.04;
export declare const COMPLETION_SPRING: {
    damping: number;
    stiffness: number;
};
export declare const ARROW_COLOR = "#ffffff";
export declare const FLY_COLOR = "#22c55e";
export declare const BLOCKED_COLOR = "#ef4444";
export declare const BLOCKER_COLOR = "#fbbf24";
export declare const EMPTY_DOT_COLOR = "rgba(180, 180, 200, 0.5)";
export declare const LIGHT: import("@nayan-ui/engine").Light;
export type Layout = {
    /** The GameView's size. */
    width: number;
    height: number;
    boardLeft: number;
    boardTop: number;
    boardWidth: number;
    boardHeight: number;
    tile: number;
    /** From one cell's top-left to the next. */
    stride: number;
    /** Arrow line thickness. */
    stroke: number;
    headLength: number;
    headHalfWidth: number;
    dotRadius: number;
    /** Taps this far outside a cell (into the gap) still count for it. */
    hitMargin: number;
};
/** The board as wide as the game area (and no taller than 58% of the screen), centred below the header. */
export declare function getLayout(width: number, height: number, offset: number): Layout;
/** Centre of cell (row, col), in board points (from the board's top-left, y down). */
export declare const cellCenter: (l: Layout, row: number, col: number) => [number, number];
/** How far the arrowhead's tip sits from its cell's centre: inside the tile, clear of its neighbours. */
export declare const tipDistance: (l: Layout) => number;
//# sourceMappingURL=ArrowsConstants.d.ts.map