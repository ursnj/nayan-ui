import type { TiltView } from '../shared/EngineTilt';
export declare const GAME_DURATION = 300;
export declare const POINTS_PER_FLIP = 200;
export declare const WIN_BONUS = 5000;
export declare const AI_DELAY = 0.5;
export declare const TAP_SLOP = 12;
export declare const FLIP_TIME = 0.24;
export declare const RIPPLE = 0.07;
export declare const PLACE_LEAD = 0.09;
export declare const COLORS: {
    readonly FELT: "#1F7A46";
    readonly BOARD_BORDER: "#0F3D24";
    readonly GRID: "#155a33";
    readonly STAR: "#0d3b21";
    readonly HINT: "rgba(255,255,255,0.75)";
    readonly LAST_MOVE: "rgba(255,213,79,0.9)";
    readonly BLACK: "#2A2A2A";
    readonly WHITE: "#F2F2F2";
};
/** Directly overhead, like Checkers: a flat board with only the discs raised in 3D. */
export declare const TILT = 0;
export declare const BOARD_BORDER_WIDTH = 3;
export declare const BOARD_SURFACE = 0.2;
/** Lit from the upper left; surfaces facing up off the board (+z) keep their exact color. */
export declare const LIGHT: import("@nayan-ui/engine").Light;
export type Layout = TiltView & {
    cell: number;
    size: number;
};
/** Use Checkers' centered board sizing, reserving space for the thin outer border. */
export declare function getLayout(width: number, height: number, offset: number): Layout;
/** A cell's centre (row 0 along the top), in world units. */
export declare const cellCentre: (l: Layout, index: number) => [number, number];
/** The cell under a board point, or -1. */
export declare function cellAt(l: Layout, x: number, y: number): number;
//# sourceMappingURL=ReversiConstants.d.ts.map