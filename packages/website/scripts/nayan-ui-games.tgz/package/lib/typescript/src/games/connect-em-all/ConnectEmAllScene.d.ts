import { type Color, type Entity, type Vec3, type World } from '@nayan-ui/engine';
import type { GameTheme } from '../../services/ThemeService';
import type { PopBurstOptions } from '../shared/EngineBlasts';
import { type Layout } from './ConnectEmAllConstants';
/** A view point (from the top-left) at depth `z`, in world space. */
export declare const toWorld: (l: Layout, x: number, y: number, z?: number) => Vec3;
/** Centre of the dot at (row, col), in view points. `row` may be negative: above the board, falling in. */
export declare const dotPoint: (l: Layout, row: number, col: number) => [number, number];
export declare const dotPosition: (l: Layout, row: number, col: number) => Vec3;
export type Board = {
    backdrop: Entity;
    panel: Entity;
    rim: Entity;
};
/** The game background, and behind the whole grid the board panel and its rim, as Block Blast's: in the theme's board colors. */
export declare function buildBoard(world: World, l: Layout, theme: GameTheme): Board;
export declare function removeBoard(world: World, b: Board): void;
export declare const dotColor: (colorIndex: number) => [number, number, number, number];
export declare const lineColor: (colorIndex: number) => [number, number, number, number];
export declare function loadGlowTexture(): void;
/** A dot and its glow: a soft halo behind it, shown while it's in the chain. */
export declare function spawnDot(world: World, l: Layout, row: number, col: number, colorIndex: number): {
    entity: Entity;
    glow: Entity;
};
/** The halo blooms in (overshooting a touch) and stays steady while the dot is in the chain, or fades away. */
export declare function showGlow(world: World, glow: Entity, on: boolean): void;
/** Where a cleared dot's burst flies from (in front of it) and glows (behind it, over the chain lines). */
export declare function dotBurst(l: Layout, row: number, col: number, colorIndex: number): PopBurstOptions;
/** A dot's scale at rest (for popping it away). */
export declare const dotScale: (l: Layout) => number;
/** A chain segment: its drop shadow and the line itself. */
export type Segment = {
    shadow: Entity;
    line: Entity;
};
export declare function spawnSegment(world: World): Segment;
export declare const lineWidth: (l: Layout) => number;
export declare function showSegment(world: World, l: Layout, s: Segment, a: [number, number], b: [number, number], color: Color): void;
export declare function hideSegment(world: World, s: Segment): void;
/** The line from the chain's last dot to the finger, with a round end at the finger. */
export type Trail = {
    line: Entity;
    cap: Entity;
};
export declare function spawnTrail(world: World): Trail;
export declare function showTrail(world: World, l: Layout, t: Trail, from: [number, number], to: [number, number], color: Color): void;
export declare function hideTrail(world: World, t: Trail): void;
export declare const DOT_COUNT: number;
//# sourceMappingURL=ConnectEmAllScene.d.ts.map