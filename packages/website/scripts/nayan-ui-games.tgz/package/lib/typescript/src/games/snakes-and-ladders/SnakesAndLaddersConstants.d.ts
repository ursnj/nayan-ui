export declare const BOARD_SIZE = 10;
export declare const WINNING_POSITION = 100;
export declare const MAX_SIXES = 3;
export type SnakeData = {
    head: number;
    tail: number;
    color: string;
    accent: string;
    belly: string;
};
export type LadderData = {
    bottom: number;
    top: number;
    color: string;
    highlight: string;
};
/** Head (high) to tail (low): land on a head and slide down. */
export declare const SNAKES: readonly SnakeData[];
/** Bottom (low) to top (high): land on a foot and climb. */
export declare const LADDERS: readonly LadderData[];
export declare const SNAKE_AT: ReadonlyMap<number, SnakeData>;
export declare const LADDER_AT: ReadonlyMap<number, LadderData>;
/** Where a roll from `from` ends: past 100 it doesn't move; a snake or ladder at the landing cell is taken. */
export declare function landing(from: number, roll: number): {
    step: number;
    end: number;
};
/** The player's score: 100 a cell, or 10,000 plus 50 for every cell the opponent is short of 100 on a win. */
export declare function scoreFor(you: number, opponent: number): number;
/** Pastel cells, cycling along the diagonals as the original board did. */
export declare const CELL_PALETTE: string[];
export declare const START_CELL = "#E8F5E9";
export declare const FINISH_CELL = "#FFF3E0";
export declare const NUMBER_COLOR = "#5B4E42";
export declare const STAR_NUMBER_COLOR = "#F57F17";
export declare const PLAYER_COLOR = "#43A047";
export declare const AI_COLOR = "#E53935";
export declare const ROLL_TIME = 0.9;
export declare const MOVE_DELAY = 0.4;
export declare const HOP_TIME = 0.17;
export declare const SLIDE_PAUSE = 0.15;
export declare const NEXT_TURN_DELAY = 0.4;
export declare const PENALTY_DELAY = 1;
export declare const CANT_MOVE_DELAY = 0.5;
export declare const AI_DELAY = 0.8;
/** The camera leans back this far from straight down, so the board's depth, snakes and pawns read as 3D. */
export declare const TILT = 0.35;
/** Lit from the upper left; surfaces facing up off the board (+z) keep their exact color. */
export declare const LIGHT: import("@nayan-ui/engine").Light;
/** In board units (the board's playing area is 1 across, centred on the origin, y up the board). */
export declare const RIM = 0.014;
export declare const TILE_TOP = 0.013;
export declare const DIE_SIZE = 0.15;
export declare const DIE_Y: number;
export declare const START_X = -0.33;
export declare const START_Z = 0.01;
export declare const TOKEN_HEIGHT = 0.062;
export type Layout = {
    width: number;
    height: number;
    /** Points per board unit. */
    size: number;
    /** Where the board's centre is in the view. */
    centerY: number;
};
/** The board as wide as the game area, centred between the scoreboard and the controls, the die below it. */
export declare function getLayout(width: number, height: number, offset: number): Layout;
/** Where a point on (or `z` above) the board, in board units, appears in the view. */
export declare function toView(l: Layout, x: number, y: number, z?: number): [number, number];
/** A cell's centre in board units: row 1 runs left to right along the bottom, then the rows snake upward. */
export declare function cellCenter(cell: number): [number, number];
//# sourceMappingURL=SnakesAndLaddersConstants.d.ts.map