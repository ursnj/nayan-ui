import { type Camera, type Entity, World } from '@nayan-ui/engine';
import type { GameTheme } from '../../services/ThemeService';
import type { Fruit, FruitKind } from '../shared/EngineFruits';
import type { GamePhase as Phase } from '../shared/useEngineGame';
import { type Layout } from './TileHomeConstants';
import { type FruitModels } from './TileHomeScene';
type Tile = {
    typeId: number;
    col: number;
    row: number;
    layer: number;
    /** Tiles on higher layers covering this one (0 = free to pick). */
    blocking: number;
    /** Lower tiles uncovered when this tile leaves the board (computed once per deal). */
    covers: Tile[];
    root: Entity | null;
    shade: Entity | null;
    /** Its fruit, once that model is built (the tile shows before it). */
    fruit: Entity | null;
    parts: Entity[];
};
export declare function createGame(theme: GameTheme): {
    world: World;
    camera: Camera;
    theme: GameTheme;
    layout: Layout | null;
    fruits: FruitModels;
    scenery: Entity[];
    phase: Phase;
    /** Score and the countdown live in the engine (Rust), advanced by world.update. */
    readonly score: number;
    won: boolean;
    board: Tile[];
    /** The tray, in order. */
    slot: Tile[];
    /** The tile on its way to the tray, and the slot it's headed for. */
    flying: {
        tile: Tile;
        index: number;
    } | null;
    /** Tray tiles bursting, removed when the burst has shown. */
    matching: Tile[];
    /** The next board to appear plays the intro. */
    intro: boolean;
    /** Game seconds the current intro has been playing (-1 until its board spawns). */
    introAge: number;
    onPhase: (_p: Phase) => void;
    onPick: () => void;
    onMatch: () => void;
    onWin: () => void;
    onLose: () => void;
};
export type Game = ReturnType<typeof createGame>;
/**
 * One kind of fruit's model is ready (they're built once per app, one per frame after the screen
 * opens): it pops onto every tile of that kind already showing, and is used for any made from now on.
 */
export declare function addFruit(g: Game, kind: FruitKind, fruit: Fruit): void;
/** Lays the scene out for the view and header. Same tile size: everything just moves; else it's rebuilt. */
export declare function setLayout(g: Game, l: Layout): void;
/** A new theme: the background, board and tray are rebuilt; the tiles and the run carry on. */
export declare function setTheme(g: Game, theme: GameTheme): void;
export declare function start(g: Game): void;
/** A new board and timer (Stop, Play Again), springing in. The world and its GPU view are kept. */
export declare function reset(g: Game): void;
/** Drops pending timers; the world is disposed after. */
export declare function dispose(g: Game): void;
/** The intro's clock; the engine steps the world after. */
export declare function tick(g: Game, dt: number): void;
/** A tap: sends the uncovered tile under it to the tray. */
export declare function tap(g: Game, x: number, y: number): void;
export {};
//# sourceMappingURL=TileHomeGame.d.ts.map