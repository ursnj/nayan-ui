import { type Entity, type Model, type TransformBatch, type World } from '@nayan-ui/engine';
import { type View3D } from '../shared/EngineMeadow';
import { type BalloonColor, type Layout } from './BalloonBlasterConstants';
export type BalloonKind = {
    kind: 'balloon';
    color: BalloonColor;
} | {
    kind: 'bomb';
} | {
    kind: 'life';
};
type Meshes = {
    body: Model;
    rainbow: Model;
    string: Model;
    danger: Model;
};
/** The balloon meshes. Needs the native core. */
export declare function balloonMeshes(): Meshes;
/**
 * A balloon whose body is centred on screen point (x, y), rocking gently within its collision bounds.
 * Its string sways independently; bombs retain the same projected size as ordinary balloons.
 */
export declare function spawnBalloon(world: World, v: View3D, l: Layout, b: BalloonKind, x: number, y: number, spin: number): Entity;
export declare function placeBalloon(world: World, v: View3D, root: Entity, b: BalloonKind, x: number, y: number, updates?: TransformBatch): void;
/**
 * Pops a balloon at screen point (x, y): a quick swell and it's gone, in a burst of rubber bits in its
 * color (the life balloon bursts in rainbow sparkles; a bomb explodes in smoke and fire with a flash).
 */
export declare function popBalloon(world: World, v: View3D, l: Layout, root: Entity, b: BalloonKind, x: number, y: number): void;
export {};
//# sourceMappingURL=BalloonBlasterScene.d.ts.map