import { type Entity, type MutableQuat, type Quat, type Vec3, type World } from '@nayan-ui/engine';
import { type Layout } from './SpaceFighterConstants';
/** A screen point on the play plane (or `depth` ahead), in world units. */
export declare const toWorld: (l: Layout, x: number, y: number, depth?: number) => Vec3;
/** The ship's lean and bank; pass `out` to reuse it (the result is only valid until the next call with it). */
export declare const shipRotation: (bank: number, out?: MutableQuat) => Quat;
export type Ship = {
    root: Entity;
    body: Entity;
    flames: Entity[];
};
export declare function spawnShip(world: World, l: Layout, x: number): Ship;
/** The exhausts flicker; dragging (thrusters on) burns them bigger and white-blue. */
export declare function flicker(world: World, _l: Layout, s: Ship, boost: boolean): void;
/** A run starts: the ship zooms up into place from below the screen. */
export declare function launchShip(world: World, l: Layout, s: Ship): void;
export declare function placeShip(world: World, l: Layout, s: Ship, x: number, bank: number): void;
/** Hit: the ship barrel-rolls off the blow and blinks through its safe spell. */
export declare function blinkShip(world: World, s: Ship): void;
export declare function steadyShip(world: World, s: Ship): void;
export type Belt = {
    root: Entity;
};
/**
 * A pair's two belts of tumbling asteroids, its top edge at screen y: one from the left edge to the
 * gap's left side, one from its right side to the right edge. The rocks reach the gap's edges exactly,
 * as the belts' hitboxes do, with smaller ones filling the corners; sizes vary along each belt.
 */
export declare function spawnBelts(world: World, l: Layout, top: number, gapLeft: number, seed: number): Belt;
export declare function placeBelts(world: World, l: Layout, b: Belt, top: number): void;
/** A hit: fire and debris where the ship struck. */
export declare function explode(world: World, l: Layout, x: number, y: number): void;
/** A ringed ice planet: banded in pale blues and teals, its rings tilted round it. */
export type Space = {
    all: Entity[];
    /** The sun (day) or the moon (night), with its glow. */ sky: Entity[];
    stars: {
        e: Entity;
        x: number;
        y: number;
        z: number;
        since: number;
    }[];
};
export declare const STAR_DRIFT = 5;
/** A new theme: the sun comes out by day, the moon by night. */
export declare function setSpaceTheme(world: World, l: Layout, space: Space, day: boolean): void;
export declare function spawnSpace(world: World, l: Layout, clock: number, day: boolean): Space;
/** Stars that have drifted below the view come back in above it. */
export declare function wrapStars(world: World, s: Space, clock: number): void;
export declare function removeAll(world: World, entities: Entity[]): void;
//# sourceMappingURL=SpaceFighterScene.d.ts.map