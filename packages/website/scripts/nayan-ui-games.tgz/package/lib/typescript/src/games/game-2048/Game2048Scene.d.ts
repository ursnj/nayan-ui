import { type Entity, type World } from '@nayan-ui/engine';
import type { GameTheme } from '../../services/ThemeService';
import { type Layout } from './Game2048Constants';
import { type Ghost, type Tile } from './Game2048Rules';
type TileView = {
    root: Entity;
    block: Entity;
    digits: Entity[];
    value: number;
    row: number;
    col: number;
};
export type Scene = {
    backdrop: Entity;
    board: Entity[];
    tiles: Map<number, TileView>;
};
export declare function buildScene(world: World, l: Layout, theme: GameTheme, tiles: Tile[]): Scene;
export declare function removeScene(world: World, s: Scene): void;
export declare function setSceneTheme(world: World, l: Layout, s: Scene, theme: GameTheme): void;
/** A fresh board: the old tiles go, the new ones grow in. */
export declare function resetTiles(world: World, l: Layout, s: Scene, tiles: Tile[]): void;
/**
 * After a slide: every tile glides to its cell; a swallowed tile slides into its partner and goes; a
 * merged tile takes its new value and pops as it lands; a new tile grows in after the slide.
 */
export declare function slideTiles(world: World, l: Layout, s: Scene, tiles: Tile[], ghosts: Ghost[]): void;
/** A swipe that moves nothing: the board gives a little shake. */
export declare function bump(world: World, l: Layout, s: Scene): void;
/** The target (1024) reached: the tiles hop in a wave across the board, and confetti bursts over it. */
export declare function celebrate(world: World, l: Layout, s: Scene): void;
/** Out of time, or out of moves: the tiles dim. */
export declare function dim(world: World, s: Scene): void;
export {};
//# sourceMappingURL=Game2048Scene.d.ts.map