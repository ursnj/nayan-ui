import type { Light } from '@nayan-ui/engine';
export declare const COLS = 9;
export declare const TOTAL_ROADS = 9;
export type LaneType = 'grass' | 'road';
/** A grass start lane, nine roads with a grass rest lane after every three, a grass goal lane (bottom to top). */
export declare const LANE_TYPES: LaneType[];
export declare const TOTAL_LANES: number;
export declare const GOAL_ROW: number;
export declare const GAME_DURATION = 120;
export declare const SCORE_PER_CROSS = 2000;
export declare const LOW_TIME = 10;
export declare const CAR_SPEED_MIN: number;
export declare const CAR_SPEED_MAX: number;
export declare const STEP_MS: number;
export declare const MAX_PENDING_MS = 50;
/** Traffic speeds up a little with every road crossed. */
export declare const speedScale: (crossings: number) => number;
export declare const MOVE_TIME = 0.2;
export declare const SWIPE = 18;
export declare const TAP_MAX = 0.25;
export declare const COLORS: {
    readonly GRASS_LIGHT: "#95CF69";
    readonly GRASS_DARK: "#83BF5C";
    readonly GRASS_TUFT: "#4E9A2E";
    readonly ROAD: "#4B5667";
    readonly ROAD_EDGE: "#3C3C46";
    readonly ROAD_LINE: "#C9C9CF";
    readonly CAR_COLORS: readonly ["#FF5C5C", "#FFD93D", "#6BCB77", "#A66CFF", "#FF9F45", "#4D96FF", "#37C7C2", "#F2EEE2", "#EF7CAB"];
    readonly WHEEL: "#15151A";
    readonly WINDOW: "#2A3442";
    readonly PLAYER: "#3B82C4";
    readonly TRUNK: "#7A4E2D";
    readonly LEAVES: "#3FA34D";
    readonly FLOWERS: readonly ["#FFFFFF", "#FFD1EC", "#C7B3FF", "#FFF2B0"];
    readonly CURB: "#C9C6BE";
    readonly LINE: "#F2F2EE";
    readonly BUSH: "#3E8E3A";
    readonly ROCK: "#8E8C88";
};
export declare const PERSON: {
    readonly SCALE: 0.82;
    readonly HEIGHT: 1.817;
    readonly STRIDE: 0.5;
};
export declare const PERSON_COLORS: {
    readonly SKIN: "#DCA67D";
    readonly JACKET: "#3B82C4";
    readonly PANTS: "#3B4558";
    readonly HAIR: "#352B27";
    readonly SHOE: "#39434C";
    readonly SOLE: "#F0ECE1";
    readonly BACKPACK: "#CE8248";
    readonly STRAP: "#72513A";
};
/**
 * The rules are in view points (a lane is about 40 of them), but the engine draws only what's within
 * 500 units of the camera and shadows a few dozen units round it, so the whole scene hangs off a root
 * scaled to a tenth: one world unit is ten points.
 */
export declare const WORLD_SCALE = 0.1;
/** A perspective camera behind and above the start lane, looking up the board at this angle below level. */
export declare const CAMERA_PITCH = 0.92;
export declare const CAMERA_FOV = 0.7;
export declare const SKY_DAY: readonly [0.62, 0.78, 0.95];
export declare const SKY_NIGHT: readonly [0.227, 0.192, 0.376];
/** The sun high to the front left (z is up off the board), shadows falling up and right; the night's dim bluish moonlight. */
export declare const DAY_LIGHT: Light;
export declare const NIGHT_LIGHT: Light;
export type Layout = {
    width: number;
    height: number;
    /** A column's width, a lane's depth, the player grid's width and its left edge (view x). */
    tile: number;
    laneH: number;
    gridW: number;
    gridLeft: number;
    /** The view's band between the scoreboard and the controls, where the board is framed (view y). */
    top: number;
    bottom: number;
};
/** Wider lanes fill more of the view while the camera keeps all nine columns reachable. */
export declare function getLayout(width: number, height: number, offset: number): Layout;
/** A column's centre (view x). */
export declare const colX: (l: Layout, col: number) => number;
//# sourceMappingURL=CrossyRoadConstants.d.ts.map