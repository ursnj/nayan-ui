# @nayan-ui/games

**53 ready-made 3D games** for React Native apps and React websites. Each game is one component with the same props, rendered by [nayan-ui](https://www.nayanui.com/game-engine).

**[Play them in your browser](https://www.nayanui.com/games)** · **[Installation](https://www.nayanui.com/games/installation)** · **[API reference](https://www.nayanui.com/games/api-reference)** · **[Build your own game](https://www.nayanui.com/games/build-a-game)**

- Runs on iOS, Android and the web from one package
- Built-in scoreboard, Start/Stop, results, settings and light/dark themes
- Sounds and haptics that respect the player's settings
- Keyboard, mouse and touch input

## Games

| Category          | Games                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
| ----------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Puzzle            | [Arrows](https://www.nayanui.com/games/arrows) · [Bubble Shooter](https://www.nayanui.com/games/bubble-shooter) · [Colors Sort](https://www.nayanui.com/games/colors-sort) · [Nuts and Bolts](https://www.nayanui.com/games/nuts-and-bolts) · [Pipe Connect](https://www.nayanui.com/games/pipe-connect) · [Maze Runner](https://www.nayanui.com/games/maze-runner) · [Sliding Numbers](https://www.nayanui.com/games/sliding-numbers) · [2048](https://www.nayanui.com/games/game-2048) · [Tangram](https://www.nayanui.com/games/tangram)                                                                                                                                                             |
| Blocks & matching | [Block Blast](https://www.nayanui.com/games/block-blast) · [Connect Em All](https://www.nayanui.com/games/connect-em-all) · [Tile Home](https://www.nayanui.com/games/tile-home) · [Candy Crush](https://www.nayanui.com/games/candy-crush) · [Block Breaker](https://www.nayanui.com/games/block-breaker)                                                                                                                                                                                                                                                                                                                                                                                              |
| Arcade            | [Flappy Bird](https://www.nayanui.com/games/flappy-bird) · [Dino Jump](https://www.nayanui.com/games/dino-jump) · [Pac-Man](https://www.nayanui.com/games/pac-man) · [Stack Tower](https://www.nayanui.com/games/stack-tower) · [Color Switch](https://www.nayanui.com/games/color-switch) · [Snake 3D](https://www.nayanui.com/games/snake-3d) · [Bluk](https://www.nayanui.com/games/bluk) · [Chameleon Run](https://www.nayanui.com/games/chameleon-run) · [Mob Control](https://www.nayanui.com/games/mob-control) · [Paper IO](https://www.nayanui.com/games/paper-io) · [Crossy Road](https://www.nayanui.com/games/crossy-road) · [Falling Sticks](https://www.nayanui.com/games/falling-sticks) |
| Action            | [Penguin Run](https://www.nayanui.com/games/penguin-run) · [Treasure Hunt](https://www.nayanui.com/games/treasure-hunt) · [Fruit Ninja](https://www.nayanui.com/games/fruit-ninja) · [Balloon Blaster](https://www.nayanui.com/games/balloon-blaster) · [Whack A Mole](https://www.nayanui.com/games/whack-a-mole) · [Space Fighter](https://www.nayanui.com/games/space-fighter) · [Tank 1990](https://www.nayanui.com/games/tank-1990) · [Knife Hit](https://www.nayanui.com/games/knife-hit)                                                                                                                                                                                                         |
| Racing            | [Car Racing](https://www.nayanui.com/games/car-racing) · [Bike Racing](https://www.nayanui.com/games/bike-racing)                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
| Board & strategy  | [Snakes and Ladders](https://www.nayanui.com/games/snakes-and-ladders) · [Ludo King](https://www.nayanui.com/games/ludo-king) · [Checkers](https://www.nayanui.com/games/checkers) · [Reversi](https://www.nayanui.com/games/reversi)                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
| Brain             | [Dots and Boxes](https://www.nayanui.com/games/dots-and-boxes) · [Mine Sweeper](https://www.nayanui.com/games/mine-sweeper) · [Spider Solitaire](https://www.nayanui.com/games/spider-solitaire) · [Tic Tac Toe](https://www.nayanui.com/games/tic-tac-toe) · [Sudoku](https://www.nayanui.com/games/sudoku) · [Memory Match](https://www.nayanui.com/games/memory-match)                                                                                                                                                                                                                                                                                                                               |
| Words & numbers   | [Word Search](https://www.nayanui.com/games/word-search) · [Number Search](https://www.nayanui.com/games/number-search) · [Find Different Number](https://www.nayanui.com/games/find-different-number)                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |
| Casual            | [Play With Tua](https://www.nayanui.com/games/play-with-tua) · [Popit Fidget](https://www.nayanui.com/games/popit-fidget) · [Perfect Circle](https://www.nayanui.com/games/perfect-circle) · [Fruit Merger](https://www.nayanui.com/games/fruit-merger)                                                                                                                                                                                                                                                                                                                                                                                                                                                 |

## Install

```sh
# React Native (Expo development build; Expo Go is not supported)
npm install @nayan-ui/games nayan-ui expo-asset expo-modules-core

# React website
npm install @nayan-ui/games nayan-ui react-dom
```

React Native apps also need `glb` and `gltf` in Metro's `assetExts`, Android `minSdkVersion` 26 and the `VIBRATE` permission. See the [installation guide](https://www.nayanui.com/games/installation) for full setup, including Next.js.

## Usage

Render a game inside a container with a real height:

```tsx
import { useState } from 'react';
import { BlockBlast, DEFAULT_GAME_SETTINGS, type GameCompletionMetrics } from '@nayan-ui/games';

export function Game() {
  const [settings, setSettings] = useState(DEFAULT_GAME_SETTINGS);
  return (
    <BlockBlast
      settings={settings}
      onSettingsChange={setSettings}
      onEndGame={(result: GameCompletionMetrics) => console.log(result.status, result.score)}
    />
  );
}
```

Load any game by id, for example from a catalog screen:

```tsx
import { DEFAULT_GAME_SETTINGS, GAME_IDS, loadGameComponent } from '@nayan-ui/games/services';

const Game = loadGameComponent(GAME_IDS.CAR_RACING);
// <Game settings={DEFAULT_GAME_SETTINGS} />
```

**Common props**

| Prop                           | Purpose                                                                                       |
| ------------------------------ | --------------------------------------------------------------------------------------------- |
| `settings`                     | Sounds, haptics, theme (`'light'` / `'dark'`), `paused`, header `offset`, settings visibility |
| `onSettingsChange`             | Called when the player changes settings in the game's settings panel                          |
| `onEndGame`                    | `{ status: 'win' \| 'lose' \| 'cancel', score }`, reported once per run                       |
| `onPlayingChange`              | Disable navigation gestures while a run is in progress                                        |
| `onShare`, `onShowLeaderboard` | Show the share and leaderboard buttons on the results screen                                  |

Pause a game while your own overlays are open with `settings.paused`. On the web, use `createKeyboardInput` from `nayan-ui` to add arrow-key and Enter controls (see the [installation guide](https://www.nayanui.com/games/installation)).

## License

Dual licensed: **free for non-commercial use** (personal projects, learning, open source) and a **paid license for commercial use** (monetized or revenue-generating apps). See [LICENSE](LICENSE).

Commercial license and support: [niranjan.devasani@gmail.com](mailto:niranjan.devasani@gmail.com?subject=Nayan%20UI%20Games%20-%20Commercial%20License) · [Issues](https://github.com/ursnj/nayan-ui/issues)

Made by [Niranjan Devasani](https://github.com/ursnj)
